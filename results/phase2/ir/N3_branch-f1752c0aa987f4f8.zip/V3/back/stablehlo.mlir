module @jit_back attributes {mhlo.num_partitions = 1 : i32, mhlo.num_replicas = 1 : i32} {
  sdy.mesh @empty_mesh = <[]>
  func.func public @main(%arg0: tensor<1024x256xf32> {sdy.sharding = #sdy.sharding<@empty_mesh, [{}, {}]>}, %arg1: tensor<256xf32> {sdy.sharding = #sdy.sharding<@empty_mesh, [{}]>}, %arg2: tensor<256xf32> {sdy.sharding = #sdy.sharding<@empty_mesh, [{}]>}) -> (tensor<1024x256xf32> {jax.result_info = "result[0]"}, tensor<i32> {jax.result_info = "result[1]"}) {
    %0 = chlo.square %arg0 : tensor<1024x256xf32> -> tensor<1024x256xf32>
    %cst = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %1 = stablehlo.reduce(%0 init: %cst) applies stablehlo.add across dimensions = [1] : (tensor<1024x256xf32>, tensor<f32>) -> tensor<1024xf32>
    %2 = stablehlo.broadcast_in_dim %1, dims = [0] : (tensor<1024xf32>) -> tensor<1024x1xf32>
    %cst_0 = stablehlo.constant dense<2.560000e+02> : tensor<f32>
    %3 = stablehlo.broadcast_in_dim %cst_0, dims = [] : (tensor<f32>) -> tensor<1024x1xf32>
    %4 = stablehlo.divide %2, %3 : tensor<1024x1xf32>
    %cst_1 = stablehlo.constant dense<9.99999974E-5> : tensor<f32>
    %5 = stablehlo.broadcast_in_dim %cst_1, dims = [] : (tensor<f32>) -> tensor<1024x1xf32>
    %6 = stablehlo.add %4, %5 : tensor<1024x1xf32>
    %7 = stablehlo.rsqrt %6 : tensor<1024x1xf32>
    %8 = stablehlo.broadcast_in_dim %7, dims = [0, 1] : (tensor<1024x1xf32>) -> tensor<1024x256xf32>
    %9 = stablehlo.multiply %arg0, %8 : tensor<1024x256xf32>
    %10 = stablehlo.broadcast_in_dim %arg1, dims = [1] : (tensor<256xf32>) -> tensor<1x256xf32>
    %11 = stablehlo.broadcast_in_dim %10, dims = [0, 1] : (tensor<1x256xf32>) -> tensor<1024x256xf32>
    %12 = stablehlo.multiply %9, %11 : tensor<1024x256xf32>
    %13 = stablehlo.broadcast_in_dim %arg2, dims = [1] : (tensor<256xf32>) -> tensor<1x256xf32>
    %14 = stablehlo.broadcast_in_dim %13, dims = [0, 1] : (tensor<1x256xf32>) -> tensor<1024x256xf32>
    %15 = stablehlo.add %12, %14 : tensor<1024x256xf32>
    %cst_2 = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %16 = stablehlo.broadcast_in_dim %cst_2, dims = [] : (tensor<f32>) -> tensor<1024x256xf32>
    %17 = stablehlo.maximum %15, %16 : tensor<1024x256xf32>
    %cst_3 = stablehlo.constant dense<7.500000e-01> : tensor<f32>
    %18 = stablehlo.broadcast_in_dim %cst_3, dims = [] : (tensor<f32>) -> tensor<1024x256xf32>
    %19 = stablehlo.multiply %17, %18 : tensor<1024x256xf32>
    %cst_4 = stablehlo.constant dense<1.250000e-01> : tensor<f32>
    %20 = stablehlo.broadcast_in_dim %cst_4, dims = [] : (tensor<f32>) -> tensor<1024x256xf32>
    %21 = stablehlo.add %19, %20 : tensor<1024x256xf32>
    %cst_5 = stablehlo.constant dense<2.500000e-01> : tensor<f32>
    %22 = stablehlo.broadcast_in_dim %cst_5, dims = [] : (tensor<f32>) -> tensor<1024x256xf32>
    %23 = stablehlo.multiply %arg0, %22 : tensor<1024x256xf32>
    %24 = stablehlo.add %21, %23 : tensor<1024x256xf32>
    %cst_6 = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %25 = stablehlo.broadcast_in_dim %cst_6, dims = [] : (tensor<f32>) -> tensor<1024x256xf32>
    %26 = stablehlo.compare  GT, %17, %25,  FLOAT : (tensor<1024x256xf32>, tensor<1024x256xf32>) -> tensor<1024x256xi1>
    %27 = stablehlo.convert %26 : (tensor<1024x256xi1>) -> tensor<1024x256xi32>
    %c = stablehlo.constant dense<0> : tensor<i32>
    %28 = stablehlo.reduce(%27 init: %c) applies stablehlo.add across dimensions = [0, 1] : (tensor<1024x256xi32>, tensor<i32>) -> tensor<i32>
    return %24, %28 : tensor<1024x256xf32>, tensor<i32>
  }
}
