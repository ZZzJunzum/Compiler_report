module @jit_execute attributes {mhlo.num_partitions = 1 : i32, mhlo.num_replicas = 1 : i32} {
  sdy.mesh @empty_mesh = <[]>
  func.func public @main(%arg0: tensor<64x256xf32> {sdy.sharding = #sdy.sharding<@empty_mesh, [{}, {}]>}, %arg1: tensor<256x256xf32> {sdy.sharding = #sdy.sharding<@empty_mesh, [{}, {}]>}, %arg2: tensor<256xf32> {sdy.sharding = #sdy.sharding<@empty_mesh, [{}]>}, %arg3: tensor<256x256xf32> {sdy.sharding = #sdy.sharding<@empty_mesh, [{}, {}]>}, %arg4: tensor<256xf32> {sdy.sharding = #sdy.sharding<@empty_mesh, [{}]>}) -> (tensor<64x256xf32> {jax.result_info = "result[0]"}, tensor<i32> {jax.result_info = "result[1]"}, tensor<i32> {jax.result_info = "result[2]"}) {
    %0 = stablehlo.dot_general %arg0, %arg1, contracting_dims = [1] x [0], precision = [DEFAULT, DEFAULT] : (tensor<64x256xf32>, tensor<256x256xf32>) -> tensor<64x256xf32>
    %1 = stablehlo.broadcast_in_dim %arg2, dims = [1] : (tensor<256xf32>) -> tensor<1x256xf32>
    %2 = stablehlo.broadcast_in_dim %1, dims = [0, 1] : (tensor<1x256xf32>) -> tensor<64x256xf32>
    %3 = stablehlo.add %0, %2 : tensor<64x256xf32>
    %cst = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %4 = stablehlo.broadcast_in_dim %cst, dims = [] : (tensor<f32>) -> tensor<64x256xf32>
    %5 = stablehlo.maximum %3, %4 : tensor<64x256xf32>
    %6 = stablehlo.dot_general %5, %arg3, contracting_dims = [1] x [0], precision = [DEFAULT, DEFAULT] : (tensor<64x256xf32>, tensor<256x256xf32>) -> tensor<64x256xf32>
    %7 = stablehlo.broadcast_in_dim %arg4, dims = [1] : (tensor<256xf32>) -> tensor<1x256xf32>
    %8 = stablehlo.broadcast_in_dim %7, dims = [0, 1] : (tensor<1x256xf32>) -> tensor<64x256xf32>
    %9 = stablehlo.add %6, %8 : tensor<64x256xf32>
    %cst_0 = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %10 = stablehlo.broadcast_in_dim %cst_0, dims = [] : (tensor<f32>) -> tensor<64x256xf32>
    %11 = stablehlo.maximum %9, %10 : tensor<64x256xf32>
    %cst_1 = stablehlo.constant dense<7.500000e-01> : tensor<f32>
    %12 = stablehlo.broadcast_in_dim %cst_1, dims = [] : (tensor<f32>) -> tensor<64x256xf32>
    %13 = stablehlo.multiply %11, %12 : tensor<64x256xf32>
    %cst_2 = stablehlo.constant dense<1.250000e-01> : tensor<f32>
    %14 = stablehlo.broadcast_in_dim %cst_2, dims = [] : (tensor<f32>) -> tensor<64x256xf32>
    %15 = stablehlo.add %13, %14 : tensor<64x256xf32>
    %cst_3 = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %16 = stablehlo.broadcast_in_dim %cst_3, dims = [] : (tensor<f32>) -> tensor<64x256xf32>
    %17 = stablehlo.compare  GT, %5, %16,  FLOAT : (tensor<64x256xf32>, tensor<64x256xf32>) -> tensor<64x256xi1>
    %18 = stablehlo.convert %17 : (tensor<64x256xi1>) -> tensor<64x256xi32>
    %cst_4 = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %19 = stablehlo.broadcast_in_dim %cst_4, dims = [] : (tensor<f32>) -> tensor<64x256xf32>
    %20 = stablehlo.compare  GT, %11, %19,  FLOAT : (tensor<64x256xf32>, tensor<64x256xf32>) -> tensor<64x256xi1>
    %21 = stablehlo.convert %20 : (tensor<64x256xi1>) -> tensor<64x256xi32>
    %c = stablehlo.constant dense<0> : tensor<i32>
    %c_5 = stablehlo.constant dense<0> : tensor<i32>
    %22:2 = stablehlo.reduce(%18 init: %c), (%21 init: %c_5) across dimensions = [0, 1] : (tensor<64x256xi32>, tensor<64x256xi32>, tensor<i32>, tensor<i32>) -> (tensor<i32>, tensor<i32>)
     reducer(%arg5: tensor<i32>, %arg7: tensor<i32>) (%arg6: tensor<i32>, %arg8: tensor<i32>)  {
      %23 = stablehlo.add %arg5, %arg7 : tensor<i32>
      %24 = stablehlo.add %arg6, %arg8 : tensor<i32>
      stablehlo.return %23, %24 : tensor<i32>, tensor<i32>
    }
    return %15, %22#0, %22#1 : tensor<64x256xf32>, tensor<i32>, tensor<i32>
  }
}
