module @jit_execute attributes {mhlo.num_partitions = 1 : i32, mhlo.num_replicas = 1 : i32} {
  sdy.mesh @empty_mesh = <[]>
  func.func public @main(%arg0: tensor<64x256xf32> {sdy.sharding = #sdy.sharding<@empty_mesh, [{}, {}]>}, %arg1: tensor<256x256xf32> {sdy.sharding = #sdy.sharding<@empty_mesh, [{}, {}]>}, %arg2: tensor<256xf32> {sdy.sharding = #sdy.sharding<@empty_mesh, [{}]>}, %arg3: tensor<256x256xf32> {sdy.sharding = #sdy.sharding<@empty_mesh, [{}, {}]>}, %arg4: tensor<256xf32> {sdy.sharding = #sdy.sharding<@empty_mesh, [{}]>}) -> (tensor<64x256xf32> {jax.result_info = "result[0]"}, tensor<i32> {jax.result_info = "result[1]"}, tensor<i32> {jax.result_info = "result[2]"}) {
    %0 = stablehlo.reshape %arg0 : (tensor<64x256xf32>) -> tensor<64x1x256xf32>
    %cst = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %1 = stablehlo.broadcast_in_dim %cst, dims = [] : (tensor<f32>) -> tensor<64x1x256xf32>
    %c = stablehlo.constant dense<0> : tensor<i32>
    %2 = stablehlo.broadcast_in_dim %c, dims = [] : (tensor<i32>) -> tensor<64xi32>
    %c_0 = stablehlo.constant dense<0> : tensor<i32>
    %3 = stablehlo.broadcast_in_dim %c_0, dims = [] : (tensor<i32>) -> tensor<64xi32>
    %c_1 = stablehlo.constant dense<0> : tensor<i32>
    %4:9 = stablehlo.while(%iterArg = %0, %iterArg_4 = %arg1, %iterArg_5 = %arg2, %iterArg_6 = %arg3, %iterArg_7 = %arg4, %iterArg_8 = %c_1, %iterArg_9 = %1, %iterArg_10 = %2, %iterArg_11 = %3) : tensor<64x1x256xf32>, tensor<256x256xf32>, tensor<256xf32>, tensor<256x256xf32>, tensor<256xf32>, tensor<i32>, tensor<64x1x256xf32>, tensor<64xi32>, tensor<64xi32>
    cond {
      %c_12 = stablehlo.constant dense<64> : tensor<i32>
      %8 = stablehlo.compare  LT, %iterArg_8, %c_12,  SIGNED : (tensor<i32>, tensor<i32>) -> tensor<i1>
      stablehlo.return %8 : tensor<i1>
    } do {
      %c_12 = stablehlo.constant dense<0> : tensor<i32>
      %c_13 = stablehlo.constant dense<0> : tensor<i32>
      %8 = stablehlo.dynamic_slice %iterArg, %iterArg_8, %c_12, %c_13, sizes = [1, 1, 256] : (tensor<64x1x256xf32>, tensor<i32>, tensor<i32>, tensor<i32>) -> tensor<1x1x256xf32>
      %9 = stablehlo.reshape %8 : (tensor<1x1x256xf32>) -> tensor<1x256xf32>
      %10:3 = func.call @closed_call(%iterArg_4, %iterArg_5, %iterArg_6, %iterArg_7, %9) : (tensor<256x256xf32>, tensor<256xf32>, tensor<256x256xf32>, tensor<256xf32>, tensor<1x256xf32>) -> (tensor<1x256xf32>, tensor<i32>, tensor<i32>)
      %11 = stablehlo.broadcast_in_dim %10#0, dims = [1, 2] : (tensor<1x256xf32>) -> tensor<1x1x256xf32>
      %c_14 = stablehlo.constant dense<0> : tensor<i32>
      %c_15 = stablehlo.constant dense<0> : tensor<i32>
      %12 = stablehlo.dynamic_update_slice %iterArg_9, %11, %iterArg_8, %c_14, %c_15 : (tensor<64x1x256xf32>, tensor<1x1x256xf32>, tensor<i32>, tensor<i32>, tensor<i32>) -> tensor<64x1x256xf32>
      %13 = stablehlo.broadcast_in_dim %10#1, dims = [] : (tensor<i32>) -> tensor<1xi32>
      %14 = stablehlo.dynamic_update_slice %iterArg_10, %13, %iterArg_8 : (tensor<64xi32>, tensor<1xi32>, tensor<i32>) -> tensor<64xi32>
      %15 = stablehlo.broadcast_in_dim %10#2, dims = [] : (tensor<i32>) -> tensor<1xi32>
      %16 = stablehlo.dynamic_update_slice %iterArg_11, %15, %iterArg_8 : (tensor<64xi32>, tensor<1xi32>, tensor<i32>) -> tensor<64xi32>
      %c_16 = stablehlo.constant dense<1> : tensor<i32>
      %17 = stablehlo.add %iterArg_8, %c_16 : tensor<i32>
      stablehlo.return %iterArg, %iterArg_4, %iterArg_5, %iterArg_6, %iterArg_7, %17, %12, %14, %16 : tensor<64x1x256xf32>, tensor<256x256xf32>, tensor<256xf32>, tensor<256x256xf32>, tensor<256xf32>, tensor<i32>, tensor<64x1x256xf32>, tensor<64xi32>, tensor<64xi32>
    }
    %5 = stablehlo.reshape %4#6 : (tensor<64x1x256xf32>) -> tensor<64x256xf32>
    %c_2 = stablehlo.constant dense<0> : tensor<i32>
    %6 = stablehlo.reduce(%4#7 init: %c_2) applies stablehlo.add across dimensions = [0] : (tensor<64xi32>, tensor<i32>) -> tensor<i32>
    %c_3 = stablehlo.constant dense<0> : tensor<i32>
    %7 = stablehlo.reduce(%4#8 init: %c_3) applies stablehlo.add across dimensions = [0] : (tensor<64xi32>, tensor<i32>) -> tensor<i32>
    return %5, %6, %7 : tensor<64x256xf32>, tensor<i32>, tensor<i32>
  }
  func.func private @closed_call(%arg0: tensor<256x256xf32>, %arg1: tensor<256xf32>, %arg2: tensor<256x256xf32>, %arg3: tensor<256xf32>, %arg4: tensor<1x256xf32>) -> (tensor<1x256xf32>, tensor<i32>, tensor<i32>) {
    %0 = stablehlo.dot_general %arg4, %arg0, contracting_dims = [1] x [0], precision = [DEFAULT, DEFAULT] : (tensor<1x256xf32>, tensor<256x256xf32>) -> tensor<1x256xf32>
    %1 = stablehlo.broadcast_in_dim %arg1, dims = [1] : (tensor<256xf32>) -> tensor<1x256xf32>
    %2 = stablehlo.add %0, %1 : tensor<1x256xf32>
    %cst = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %3 = stablehlo.broadcast_in_dim %cst, dims = [] : (tensor<f32>) -> tensor<1x256xf32>
    %4 = stablehlo.maximum %2, %3 : tensor<1x256xf32>
    %cst_0 = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %5 = stablehlo.broadcast_in_dim %cst_0, dims = [] : (tensor<f32>) -> tensor<1x256xf32>
    %6 = stablehlo.compare  GT, %4, %5,  FLOAT : (tensor<1x256xf32>, tensor<1x256xf32>) -> tensor<1x256xi1>
    %7 = stablehlo.convert %6 : (tensor<1x256xi1>) -> tensor<1x256xi32>
    %c = stablehlo.constant dense<0> : tensor<i32>
    %8 = stablehlo.reduce(%7 init: %c) applies stablehlo.add across dimensions = [0, 1] : (tensor<1x256xi32>, tensor<i32>) -> tensor<i32>
    %9 = stablehlo.dot_general %4, %arg2, contracting_dims = [1] x [0], precision = [DEFAULT, DEFAULT] : (tensor<1x256xf32>, tensor<256x256xf32>) -> tensor<1x256xf32>
    %10 = stablehlo.broadcast_in_dim %arg3, dims = [1] : (tensor<256xf32>) -> tensor<1x256xf32>
    %11 = stablehlo.add %9, %10 : tensor<1x256xf32>
    %cst_1 = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %12 = stablehlo.broadcast_in_dim %cst_1, dims = [] : (tensor<f32>) -> tensor<1x256xf32>
    %13 = stablehlo.maximum %11, %12 : tensor<1x256xf32>
    %cst_2 = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %14 = stablehlo.broadcast_in_dim %cst_2, dims = [] : (tensor<f32>) -> tensor<1x256xf32>
    %15 = stablehlo.compare  GT, %13, %14,  FLOAT : (tensor<1x256xf32>, tensor<1x256xf32>) -> tensor<1x256xi1>
    %16 = stablehlo.convert %15 : (tensor<1x256xi1>) -> tensor<1x256xi32>
    %c_3 = stablehlo.constant dense<0> : tensor<i32>
    %17 = stablehlo.reduce(%16 init: %c_3) applies stablehlo.add across dimensions = [0, 1] : (tensor<1x256xi32>, tensor<i32>) -> tensor<i32>
    %cst_4 = stablehlo.constant dense<7.500000e-01> : tensor<f32>
    %18 = stablehlo.broadcast_in_dim %cst_4, dims = [] : (tensor<f32>) -> tensor<1x256xf32>
    %19 = stablehlo.multiply %13, %18 : tensor<1x256xf32>
    %cst_5 = stablehlo.constant dense<1.250000e-01> : tensor<f32>
    %20 = stablehlo.broadcast_in_dim %cst_5, dims = [] : (tensor<f32>) -> tensor<1x256xf32>
    %21 = stablehlo.add %19, %20 : tensor<1x256xf32>
    return %21, %8, %17 : tensor<1x256xf32>, tensor<i32>, tensor<i32>
  }
}
