module @jit_back attributes {mhlo.num_partitions = 1 : i32, mhlo.num_replicas = 1 : i32} {
  sdy.mesh @empty_mesh = <[]>
  func.func public @main(%arg0: tensor<64x256xf32> {sdy.sharding = #sdy.sharding<@empty_mesh, [{}, {}]>}, %arg1: tensor<256x256xf32> {sdy.sharding = #sdy.sharding<@empty_mesh, [{}, {}]>}, %arg2: tensor<256xf32> {sdy.sharding = #sdy.sharding<@empty_mesh, [{}]>}) -> (tensor<64x256xf32> {jax.result_info = "result[0]"}, tensor<i32> {jax.result_info = "result[1]"}) {
    %0 = stablehlo.dot_general %arg0, %arg1, contracting_dims = [1] x [0], precision = [DEFAULT, DEFAULT] : (tensor<64x256xf32>, tensor<256x256xf32>) -> tensor<64x256xf32>
    %1 = stablehlo.broadcast_in_dim %arg2, dims = [1] : (tensor<256xf32>) -> tensor<1x256xf32>
    %2 = stablehlo.broadcast_in_dim %1, dims = [0, 1] : (tensor<1x256xf32>) -> tensor<64x256xf32>
    %3 = stablehlo.add %0, %2 : tensor<64x256xf32>
    %cst = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %4 = stablehlo.broadcast_in_dim %cst, dims = [] : (tensor<f32>) -> tensor<64x256xf32>
    %5 = stablehlo.maximum %3, %4 : tensor<64x256xf32>
    %cst_0 = stablehlo.constant dense<7.500000e-01> : tensor<f32>
    %6 = stablehlo.broadcast_in_dim %cst_0, dims = [] : (tensor<f32>) -> tensor<64x256xf32>
    %7 = stablehlo.multiply %5, %6 : tensor<64x256xf32>
    %cst_1 = stablehlo.constant dense<1.250000e-01> : tensor<f32>
    %8 = stablehlo.broadcast_in_dim %cst_1, dims = [] : (tensor<f32>) -> tensor<64x256xf32>
    %9 = stablehlo.add %7, %8 : tensor<64x256xf32>
    %cst_2 = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %10 = stablehlo.broadcast_in_dim %cst_2, dims = [] : (tensor<f32>) -> tensor<64x256xf32>
    %11 = stablehlo.compare  GT, %5, %10,  FLOAT : (tensor<64x256xf32>, tensor<64x256xf32>) -> tensor<64x256xi1>
    %12 = stablehlo.convert %11 : (tensor<64x256xi1>) -> tensor<64x256xi32>
    %c = stablehlo.constant dense<0> : tensor<i32>
    %13 = stablehlo.reduce(%12 init: %c) applies stablehlo.add across dimensions = [0, 1] : (tensor<64x256xi32>, tensor<i32>) -> tensor<i32>
    return %9, %13 : tensor<64x256xf32>, tensor<i32>
  }
}
