module @jit_execute attributes {mhlo.num_partitions = 1 : i32, mhlo.num_replicas = 1 : i32} {
  sdy.mesh @empty_mesh = <[]>
  func.func public @main(%arg0: tensor<1024x256xf32> {sdy.sharding = #sdy.sharding<@empty_mesh, [{}, {}]>}, %arg1: tensor<256xf32> {sdy.sharding = #sdy.sharding<@empty_mesh, [{}]>}, %arg2: tensor<256xf32> {sdy.sharding = #sdy.sharding<@empty_mesh, [{}]>}, %arg3: tensor<256xf32> {sdy.sharding = #sdy.sharding<@empty_mesh, [{}]>}, %arg4: tensor<256xf32> {sdy.sharding = #sdy.sharding<@empty_mesh, [{}]>}) -> (tensor<1024x256xf32> {jax.result_info = "result[0]"}, tensor<i32> {jax.result_info = "result[1]"}, tensor<i32> {jax.result_info = "result[2]"}) {
    %0 = stablehlo.broadcast_in_dim %arg1, dims = [1] : (tensor<256xf32>) -> tensor<1x256xf32>
    %1 = stablehlo.broadcast_in_dim %0, dims = [0, 1] : (tensor<1x256xf32>) -> tensor<1024x256xf32>
    %2 = stablehlo.multiply %arg0, %1 : tensor<1024x256xf32>
    %3 = stablehlo.broadcast_in_dim %arg2, dims = [1] : (tensor<256xf32>) -> tensor<1x256xf32>
    %4 = stablehlo.broadcast_in_dim %3, dims = [0, 1] : (tensor<1x256xf32>) -> tensor<1024x256xf32>
    %5 = stablehlo.add %2, %4 : tensor<1024x256xf32>
    %cst = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %6 = stablehlo.broadcast_in_dim %cst, dims = [] : (tensor<f32>) -> tensor<1024x256xf32>
    %7 = stablehlo.maximum %5, %6 : tensor<1024x256xf32>
    %8 = stablehlo.broadcast_in_dim %arg3, dims = [1] : (tensor<256xf32>) -> tensor<1x256xf32>
    %9 = stablehlo.broadcast_in_dim %8, dims = [0, 1] : (tensor<1x256xf32>) -> tensor<1024x256xf32>
    %10 = stablehlo.multiply %7, %9 : tensor<1024x256xf32>
    %11 = stablehlo.broadcast_in_dim %arg4, dims = [1] : (tensor<256xf32>) -> tensor<1x256xf32>
    %12 = stablehlo.broadcast_in_dim %11, dims = [0, 1] : (tensor<1x256xf32>) -> tensor<1024x256xf32>
    %13 = stablehlo.add %10, %12 : tensor<1024x256xf32>
    %cst_0 = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %14 = stablehlo.broadcast_in_dim %cst_0, dims = [] : (tensor<f32>) -> tensor<1024x256xf32>
    %15 = stablehlo.maximum %13, %14 : tensor<1024x256xf32>
    %cst_1 = stablehlo.constant dense<7.500000e-01> : tensor<f32>
    %16 = stablehlo.broadcast_in_dim %cst_1, dims = [] : (tensor<f32>) -> tensor<1024x256xf32>
    %17 = stablehlo.multiply %15, %16 : tensor<1024x256xf32>
    %cst_2 = stablehlo.constant dense<1.250000e-01> : tensor<f32>
    %18 = stablehlo.broadcast_in_dim %cst_2, dims = [] : (tensor<f32>) -> tensor<1024x256xf32>
    %19 = stablehlo.add %17, %18 : tensor<1024x256xf32>
    %cst_3 = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %20 = stablehlo.broadcast_in_dim %cst_3, dims = [] : (tensor<f32>) -> tensor<1024x256xf32>
    %21 = stablehlo.compare  GT, %7, %20,  FLOAT : (tensor<1024x256xf32>, tensor<1024x256xf32>) -> tensor<1024x256xi1>
    %22 = stablehlo.convert %21 : (tensor<1024x256xi1>) -> tensor<1024x256xi32>
    %cst_4 = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %23 = stablehlo.broadcast_in_dim %cst_4, dims = [] : (tensor<f32>) -> tensor<1024x256xf32>
    %24 = stablehlo.compare  GT, %15, %23,  FLOAT : (tensor<1024x256xf32>, tensor<1024x256xf32>) -> tensor<1024x256xi1>
    %25 = stablehlo.convert %24 : (tensor<1024x256xi1>) -> tensor<1024x256xi32>
    %c = stablehlo.constant dense<0> : tensor<i32>
    %c_5 = stablehlo.constant dense<0> : tensor<i32>
    %26:2 = stablehlo.reduce(%22 init: %c), (%25 init: %c_5) across dimensions = [0, 1] : (tensor<1024x256xi32>, tensor<1024x256xi32>, tensor<i32>, tensor<i32>) -> (tensor<i32>, tensor<i32>)
     reducer(%arg5: tensor<i32>, %arg7: tensor<i32>) (%arg6: tensor<i32>, %arg8: tensor<i32>)  {
      %27 = stablehlo.add %arg5, %arg7 : tensor<i32>
      %28 = stablehlo.add %arg6, %arg8 : tensor<i32>
      stablehlo.return %27, %28 : tensor<i32>, tensor<i32>
    }
    return %19, %26#0, %26#1 : tensor<1024x256xf32>, tensor<i32>, tensor<i32>
  }
}
