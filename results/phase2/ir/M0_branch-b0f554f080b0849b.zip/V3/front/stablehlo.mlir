module @jit_front attributes {mhlo.num_partitions = 1 : i32, mhlo.num_replicas = 1 : i32} {
  sdy.mesh @empty_mesh = <[]>
  func.func public @main(%arg0: tensor<4x256xf32> {sdy.sharding = #sdy.sharding<@empty_mesh, [{}, {}]>}, %arg1: tensor<256x256xf32> {sdy.sharding = #sdy.sharding<@empty_mesh, [{}, {}]>}, %arg2: tensor<256xf32> {sdy.sharding = #sdy.sharding<@empty_mesh, [{}]>}) -> (tensor<4x256xf32> {jax.result_info = "result[0]"}, tensor<i32> {jax.result_info = "result[1]"}) {
    %0 = stablehlo.dot_general %arg0, %arg1, contracting_dims = [1] x [0], precision = [DEFAULT, DEFAULT] : (tensor<4x256xf32>, tensor<256x256xf32>) -> tensor<4x256xf32>
    %1 = stablehlo.broadcast_in_dim %arg2, dims = [1] : (tensor<256xf32>) -> tensor<1x256xf32>
    %2 = stablehlo.broadcast_in_dim %1, dims = [0, 1] : (tensor<1x256xf32>) -> tensor<4x256xf32>
    %3 = stablehlo.add %0, %2 : tensor<4x256xf32>
    %cst = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %4 = stablehlo.broadcast_in_dim %cst, dims = [] : (tensor<f32>) -> tensor<4x256xf32>
    %5 = stablehlo.maximum %3, %4 : tensor<4x256xf32>
    %cst_0 = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %6 = stablehlo.broadcast_in_dim %cst_0, dims = [] : (tensor<f32>) -> tensor<4x256xf32>
    %7 = stablehlo.compare  GT, %5, %6,  FLOAT : (tensor<4x256xf32>, tensor<4x256xf32>) -> tensor<4x256xi1>
    %8 = stablehlo.convert %7 : (tensor<4x256xi1>) -> tensor<4x256xi32>
    %c = stablehlo.constant dense<0> : tensor<i32>
    %9 = stablehlo.reduce(%8 init: %c) applies stablehlo.add across dimensions = [0, 1] : (tensor<4x256xi32>, tensor<i32>) -> tensor<i32>
    return %5, %9 : tensor<4x256xf32>, tensor<i32>
  }
}
