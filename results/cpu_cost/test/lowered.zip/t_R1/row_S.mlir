module @jit_forward attributes {mhlo.num_partitions = 1 : i32, mhlo.num_replicas = 1 : i32} {
  func.func public @main(%arg0: tensor<3x23x23x20xf32>, %arg1: tensor<20xf32>, %arg2: tensor<20xf32>, %arg3: tensor<20xf32>, %arg4: tensor<20xf32>, %arg5: tensor<20xf32>, %arg6: tensor<20xf32>, %arg7: tensor<20xf32>, %arg8: tensor<20xf32>, %arg9: tensor<3x3x20x20xf32>, %arg10: tensor<3x3x20x20xf32>, %arg11: tensor<20xf32>, %arg12: tensor<20xf32>, %arg13: tensor<20xf32>, %arg14: tensor<20xf32>, %arg15: tensor<20xf32>, %arg16: tensor<20xf32>, %arg17: tensor<20xf32>, %arg18: tensor<20xf32>, %arg19: tensor<3x3x20x20xf32>, %arg20: tensor<3x3x20x20xf32>) -> (tensor<3x23x23x20xf32> {jax.result_info = "result[0]"}, tensor<3x23x23xi32> {jax.result_info = "result[1]"}, tensor<3x23x23xi32> {jax.result_info = "result[2]"}) {
    %0 = stablehlo.convolution(%arg0, %arg9) dim_numbers = [b, 0, 1, f]x[0, 1, i, o]->[b, 0, 1, f], window = {stride = [1, 1], pad = [[1, 1], [1, 1]], lhs_dilate = [1, 1], rhs_dilate = [1, 1], reverse = [false, false]} {batch_group_count = 1 : i64, feature_group_count = 1 : i64, precision_config = [#stablehlo<precision DEFAULT>, #stablehlo<precision DEFAULT>]} : (tensor<3x23x23x20xf32>, tensor<3x3x20x20xf32>) -> tensor<3x23x23x20xf32>
    %1 = stablehlo.broadcast_in_dim %arg1, dims = [3] : (tensor<20xf32>) -> tensor<1x1x1x20xf32>
    %2 = stablehlo.broadcast_in_dim %arg2, dims = [3] : (tensor<20xf32>) -> tensor<1x1x1x20xf32>
    %3 = stablehlo.broadcast_in_dim %1, dims = [0, 1, 2, 3] : (tensor<1x1x1x20xf32>) -> tensor<3x23x23x20xf32>
    %4 = stablehlo.subtract %0, %3 : tensor<3x23x23x20xf32>
    %cst = stablehlo.constant dense<9.99999974E-6> : tensor<f32>
    %5 = stablehlo.broadcast_in_dim %cst, dims = [] : (tensor<f32>) -> tensor<1x1x1x20xf32>
    %6 = stablehlo.add %2, %5 : tensor<1x1x1x20xf32>
    %7 = stablehlo.rsqrt %6 : tensor<1x1x1x20xf32>
    %8 = stablehlo.reshape %arg6 : (tensor<20xf32>) -> tensor<1x1x1x20xf32>
    %9 = stablehlo.multiply %7, %8 : tensor<1x1x1x20xf32>
    %10 = stablehlo.broadcast_in_dim %9, dims = [0, 1, 2, 3] : (tensor<1x1x1x20xf32>) -> tensor<3x23x23x20xf32>
    %11 = stablehlo.multiply %4, %10 : tensor<3x23x23x20xf32>
    %12 = stablehlo.reshape %arg5 : (tensor<20xf32>) -> tensor<1x1x1x20xf32>
    %13 = stablehlo.broadcast_in_dim %12, dims = [0, 1, 2, 3] : (tensor<1x1x1x20xf32>) -> tensor<3x23x23x20xf32>
    %14 = stablehlo.add %11, %13 : tensor<3x23x23x20xf32>
    %15 = call @relu(%14) : (tensor<3x23x23x20xf32>) -> tensor<3x23x23x20xf32>
    %16 = stablehlo.convolution(%15, %arg10) dim_numbers = [b, 0, 1, f]x[0, 1, i, o]->[b, 0, 1, f], window = {stride = [1, 1], pad = [[1, 1], [1, 1]], lhs_dilate = [1, 1], rhs_dilate = [1, 1], reverse = [false, false]} {batch_group_count = 1 : i64, feature_group_count = 1 : i64, precision_config = [#stablehlo<precision DEFAULT>, #stablehlo<precision DEFAULT>]} : (tensor<3x23x23x20xf32>, tensor<3x3x20x20xf32>) -> tensor<3x23x23x20xf32>
    %17 = stablehlo.broadcast_in_dim %arg3, dims = [3] : (tensor<20xf32>) -> tensor<1x1x1x20xf32>
    %18 = stablehlo.broadcast_in_dim %arg4, dims = [3] : (tensor<20xf32>) -> tensor<1x1x1x20xf32>
    %19 = stablehlo.broadcast_in_dim %17, dims = [0, 1, 2, 3] : (tensor<1x1x1x20xf32>) -> tensor<3x23x23x20xf32>
    %20 = stablehlo.subtract %16, %19 : tensor<3x23x23x20xf32>
    %cst_0 = stablehlo.constant dense<9.99999974E-6> : tensor<f32>
    %21 = stablehlo.broadcast_in_dim %cst_0, dims = [] : (tensor<f32>) -> tensor<1x1x1x20xf32>
    %22 = stablehlo.add %18, %21 : tensor<1x1x1x20xf32>
    %23 = stablehlo.rsqrt %22 : tensor<1x1x1x20xf32>
    %24 = stablehlo.reshape %arg8 : (tensor<20xf32>) -> tensor<1x1x1x20xf32>
    %25 = stablehlo.multiply %23, %24 : tensor<1x1x1x20xf32>
    %26 = stablehlo.broadcast_in_dim %25, dims = [0, 1, 2, 3] : (tensor<1x1x1x20xf32>) -> tensor<3x23x23x20xf32>
    %27 = stablehlo.multiply %20, %26 : tensor<3x23x23x20xf32>
    %28 = stablehlo.reshape %arg7 : (tensor<20xf32>) -> tensor<1x1x1x20xf32>
    %29 = stablehlo.broadcast_in_dim %28, dims = [0, 1, 2, 3] : (tensor<1x1x1x20xf32>) -> tensor<3x23x23x20xf32>
    %30 = stablehlo.add %27, %29 : tensor<3x23x23x20xf32>
    %31 = stablehlo.add %arg0, %30 : tensor<3x23x23x20xf32>
    %32 = call @relu(%31) : (tensor<3x23x23x20xf32>) -> tensor<3x23x23x20xf32>
    %33 = stablehlo.convolution(%32, %arg19) dim_numbers = [b, 0, 1, f]x[0, 1, i, o]->[b, 0, 1, f], window = {stride = [1, 1], pad = [[1, 1], [1, 1]], lhs_dilate = [1, 1], rhs_dilate = [1, 1], reverse = [false, false]} {batch_group_count = 1 : i64, feature_group_count = 1 : i64, precision_config = [#stablehlo<precision DEFAULT>, #stablehlo<precision DEFAULT>]} : (tensor<3x23x23x20xf32>, tensor<3x3x20x20xf32>) -> tensor<3x23x23x20xf32>
    %34 = stablehlo.broadcast_in_dim %arg11, dims = [3] : (tensor<20xf32>) -> tensor<1x1x1x20xf32>
    %35 = stablehlo.broadcast_in_dim %arg12, dims = [3] : (tensor<20xf32>) -> tensor<1x1x1x20xf32>
    %36 = stablehlo.broadcast_in_dim %34, dims = [0, 1, 2, 3] : (tensor<1x1x1x20xf32>) -> tensor<3x23x23x20xf32>
    %37 = stablehlo.subtract %33, %36 : tensor<3x23x23x20xf32>
    %cst_1 = stablehlo.constant dense<9.99999974E-6> : tensor<f32>
    %38 = stablehlo.broadcast_in_dim %cst_1, dims = [] : (tensor<f32>) -> tensor<1x1x1x20xf32>
    %39 = stablehlo.add %35, %38 : tensor<1x1x1x20xf32>
    %40 = stablehlo.rsqrt %39 : tensor<1x1x1x20xf32>
    %41 = stablehlo.reshape %arg16 : (tensor<20xf32>) -> tensor<1x1x1x20xf32>
    %42 = stablehlo.multiply %40, %41 : tensor<1x1x1x20xf32>
    %43 = stablehlo.broadcast_in_dim %42, dims = [0, 1, 2, 3] : (tensor<1x1x1x20xf32>) -> tensor<3x23x23x20xf32>
    %44 = stablehlo.multiply %37, %43 : tensor<3x23x23x20xf32>
    %45 = stablehlo.reshape %arg15 : (tensor<20xf32>) -> tensor<1x1x1x20xf32>
    %46 = stablehlo.broadcast_in_dim %45, dims = [0, 1, 2, 3] : (tensor<1x1x1x20xf32>) -> tensor<3x23x23x20xf32>
    %47 = stablehlo.add %44, %46 : tensor<3x23x23x20xf32>
    %48 = call @relu(%47) : (tensor<3x23x23x20xf32>) -> tensor<3x23x23x20xf32>
    %49 = stablehlo.convolution(%48, %arg20) dim_numbers = [b, 0, 1, f]x[0, 1, i, o]->[b, 0, 1, f], window = {stride = [1, 1], pad = [[1, 1], [1, 1]], lhs_dilate = [1, 1], rhs_dilate = [1, 1], reverse = [false, false]} {batch_group_count = 1 : i64, feature_group_count = 1 : i64, precision_config = [#stablehlo<precision DEFAULT>, #stablehlo<precision DEFAULT>]} : (tensor<3x23x23x20xf32>, tensor<3x3x20x20xf32>) -> tensor<3x23x23x20xf32>
    %50 = stablehlo.broadcast_in_dim %arg13, dims = [3] : (tensor<20xf32>) -> tensor<1x1x1x20xf32>
    %51 = stablehlo.broadcast_in_dim %arg14, dims = [3] : (tensor<20xf32>) -> tensor<1x1x1x20xf32>
    %52 = stablehlo.broadcast_in_dim %50, dims = [0, 1, 2, 3] : (tensor<1x1x1x20xf32>) -> tensor<3x23x23x20xf32>
    %53 = stablehlo.subtract %49, %52 : tensor<3x23x23x20xf32>
    %cst_2 = stablehlo.constant dense<9.99999974E-6> : tensor<f32>
    %54 = stablehlo.broadcast_in_dim %cst_2, dims = [] : (tensor<f32>) -> tensor<1x1x1x20xf32>
    %55 = stablehlo.add %51, %54 : tensor<1x1x1x20xf32>
    %56 = stablehlo.rsqrt %55 : tensor<1x1x1x20xf32>
    %57 = stablehlo.reshape %arg18 : (tensor<20xf32>) -> tensor<1x1x1x20xf32>
    %58 = stablehlo.multiply %56, %57 : tensor<1x1x1x20xf32>
    %59 = stablehlo.broadcast_in_dim %58, dims = [0, 1, 2, 3] : (tensor<1x1x1x20xf32>) -> tensor<3x23x23x20xf32>
    %60 = stablehlo.multiply %53, %59 : tensor<3x23x23x20xf32>
    %61 = stablehlo.reshape %arg17 : (tensor<20xf32>) -> tensor<1x1x1x20xf32>
    %62 = stablehlo.broadcast_in_dim %61, dims = [0, 1, 2, 3] : (tensor<1x1x1x20xf32>) -> tensor<3x23x23x20xf32>
    %63 = stablehlo.add %60, %62 : tensor<3x23x23x20xf32>
    %64 = stablehlo.add %32, %63 : tensor<3x23x23x20xf32>
    %65 = call @relu(%64) : (tensor<3x23x23x20xf32>) -> tensor<3x23x23x20xf32>
    %cst_3 = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %66 = stablehlo.broadcast_in_dim %cst_3, dims = [] : (tensor<f32>) -> tensor<3x23x23x20xf32>
    %67 = stablehlo.compare  GT, %14, %66,  FLOAT : (tensor<3x23x23x20xf32>, tensor<3x23x23x20xf32>) -> tensor<3x23x23x20xi1>
    %68 = stablehlo.convert %67 : (tensor<3x23x23x20xi1>) -> tensor<3x23x23x20xi32>
    %cst_4 = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %69 = stablehlo.broadcast_in_dim %cst_4, dims = [] : (tensor<f32>) -> tensor<3x23x23x20xf32>
    %70 = stablehlo.compare  GT, %31, %69,  FLOAT : (tensor<3x23x23x20xf32>, tensor<3x23x23x20xf32>) -> tensor<3x23x23x20xi1>
    %71 = stablehlo.convert %70 : (tensor<3x23x23x20xi1>) -> tensor<3x23x23x20xi32>
    %c = stablehlo.constant dense<0> : tensor<i32>
    %72 = stablehlo.reduce(%68 init: %c) applies stablehlo.add across dimensions = [3] : (tensor<3x23x23x20xi32>, tensor<i32>) -> tensor<3x23x23xi32>
    %c_5 = stablehlo.constant dense<0> : tensor<i32>
    %73 = stablehlo.reduce(%71 init: %c_5) applies stablehlo.add across dimensions = [3] : (tensor<3x23x23x20xi32>, tensor<i32>) -> tensor<3x23x23xi32>
    return %65, %72, %73 : tensor<3x23x23x20xf32>, tensor<3x23x23xi32>, tensor<3x23x23xi32>
  }
  func.func private @relu(%arg0: tensor<3x23x23x20xf32>) -> tensor<3x23x23x20xf32> {
    %cst = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %0 = stablehlo.broadcast_in_dim %cst, dims = [] : (tensor<f32>) -> tensor<3x23x23x20xf32>
    %1 = stablehlo.maximum %arg0, %0 : tensor<3x23x23x20xf32>
    return %1 : tensor<3x23x23x20xf32>
  }
}
