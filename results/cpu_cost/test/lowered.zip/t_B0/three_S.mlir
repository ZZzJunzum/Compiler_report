module @jit_forward attributes {mhlo.num_partitions = 1 : i32, mhlo.num_replicas = 1 : i32} {
  func.func public @main(%arg0: tensor<2x18x18x16xf32>, %arg1: tensor<16xf32>, %arg2: tensor<16xf32>, %arg3: tensor<16xf32>, %arg4: tensor<16xf32>, %arg5: tensor<64xf32>, %arg6: tensor<64xf32>, %arg7: tensor<64xf32>, %arg8: tensor<64xf32>, %arg9: tensor<16xf32>, %arg10: tensor<16xf32>, %arg11: tensor<16xf32>, %arg12: tensor<16xf32>, %arg13: tensor<64xf32>, %arg14: tensor<64xf32>, %arg15: tensor<1x1x16x16xf32>, %arg16: tensor<3x3x16x16xf32>, %arg17: tensor<1x1x16x64xf32>, %arg18: tensor<1x1x16x64xf32>, %arg19: tensor<64xf32>, %arg20: tensor<64xf32>) -> (tensor<2x9x9x64xf32> {jax.result_info = "result[0]"}, tensor<i32> {jax.result_info = "result[1]"}, tensor<i32> {jax.result_info = "result[2]"}, tensor<i32> {jax.result_info = "result[3]"}) {
    %0 = stablehlo.convolution(%arg0, %arg15) dim_numbers = [b, 0, 1, f]x[0, 1, i, o]->[b, 0, 1, f], window = {stride = [1, 1], pad = [[0, 0], [0, 0]], lhs_dilate = [1, 1], rhs_dilate = [1, 1], reverse = [false, false]} {batch_group_count = 1 : i64, feature_group_count = 1 : i64, precision_config = [#stablehlo<precision DEFAULT>, #stablehlo<precision DEFAULT>]} : (tensor<2x18x18x16xf32>, tensor<1x1x16x16xf32>) -> tensor<2x18x18x16xf32>
    %1 = stablehlo.broadcast_in_dim %arg1, dims = [3] : (tensor<16xf32>) -> tensor<1x1x1x16xf32>
    %2 = stablehlo.broadcast_in_dim %arg2, dims = [3] : (tensor<16xf32>) -> tensor<1x1x1x16xf32>
    %3 = stablehlo.broadcast_in_dim %1, dims = [0, 1, 2, 3] : (tensor<1x1x1x16xf32>) -> tensor<2x18x18x16xf32>
    %4 = stablehlo.subtract %0, %3 : tensor<2x18x18x16xf32>
    %cst = stablehlo.constant dense<9.99999974E-6> : tensor<f32>
    %5 = stablehlo.broadcast_in_dim %cst, dims = [] : (tensor<f32>) -> tensor<1x1x1x16xf32>
    %6 = stablehlo.add %2, %5 : tensor<1x1x1x16xf32>
    %7 = stablehlo.rsqrt %6 : tensor<1x1x1x16xf32>
    %8 = stablehlo.reshape %arg10 : (tensor<16xf32>) -> tensor<1x1x1x16xf32>
    %9 = stablehlo.multiply %7, %8 : tensor<1x1x1x16xf32>
    %10 = stablehlo.broadcast_in_dim %9, dims = [0, 1, 2, 3] : (tensor<1x1x1x16xf32>) -> tensor<2x18x18x16xf32>
    %11 = stablehlo.multiply %4, %10 : tensor<2x18x18x16xf32>
    %12 = stablehlo.reshape %arg9 : (tensor<16xf32>) -> tensor<1x1x1x16xf32>
    %13 = stablehlo.broadcast_in_dim %12, dims = [0, 1, 2, 3] : (tensor<1x1x1x16xf32>) -> tensor<2x18x18x16xf32>
    %14 = stablehlo.add %11, %13 : tensor<2x18x18x16xf32>
    %15 = call @relu(%14) : (tensor<2x18x18x16xf32>) -> tensor<2x18x18x16xf32>
    %16 = stablehlo.convolution(%15, %arg16) dim_numbers = [b, 0, 1, f]x[0, 1, i, o]->[b, 0, 1, f], window = {stride = [2, 2], pad = [[0, 1], [0, 1]], lhs_dilate = [1, 1], rhs_dilate = [1, 1], reverse = [false, false]} {batch_group_count = 1 : i64, feature_group_count = 1 : i64, precision_config = [#stablehlo<precision DEFAULT>, #stablehlo<precision DEFAULT>]} : (tensor<2x18x18x16xf32>, tensor<3x3x16x16xf32>) -> tensor<2x9x9x16xf32>
    %17 = stablehlo.broadcast_in_dim %arg3, dims = [3] : (tensor<16xf32>) -> tensor<1x1x1x16xf32>
    %18 = stablehlo.broadcast_in_dim %arg4, dims = [3] : (tensor<16xf32>) -> tensor<1x1x1x16xf32>
    %19 = stablehlo.broadcast_in_dim %17, dims = [0, 1, 2, 3] : (tensor<1x1x1x16xf32>) -> tensor<2x9x9x16xf32>
    %20 = stablehlo.subtract %16, %19 : tensor<2x9x9x16xf32>
    %cst_0 = stablehlo.constant dense<9.99999974E-6> : tensor<f32>
    %21 = stablehlo.broadcast_in_dim %cst_0, dims = [] : (tensor<f32>) -> tensor<1x1x1x16xf32>
    %22 = stablehlo.add %18, %21 : tensor<1x1x1x16xf32>
    %23 = stablehlo.rsqrt %22 : tensor<1x1x1x16xf32>
    %24 = stablehlo.reshape %arg12 : (tensor<16xf32>) -> tensor<1x1x1x16xf32>
    %25 = stablehlo.multiply %23, %24 : tensor<1x1x1x16xf32>
    %26 = stablehlo.broadcast_in_dim %25, dims = [0, 1, 2, 3] : (tensor<1x1x1x16xf32>) -> tensor<2x9x9x16xf32>
    %27 = stablehlo.multiply %20, %26 : tensor<2x9x9x16xf32>
    %28 = stablehlo.reshape %arg11 : (tensor<16xf32>) -> tensor<1x1x1x16xf32>
    %29 = stablehlo.broadcast_in_dim %28, dims = [0, 1, 2, 3] : (tensor<1x1x1x16xf32>) -> tensor<2x9x9x16xf32>
    %30 = stablehlo.add %27, %29 : tensor<2x9x9x16xf32>
    %31 = call @relu_7(%30) : (tensor<2x9x9x16xf32>) -> tensor<2x9x9x16xf32>
    %32 = stablehlo.convolution(%31, %arg17) dim_numbers = [b, 0, 1, f]x[0, 1, i, o]->[b, 0, 1, f], window = {stride = [1, 1], pad = [[0, 0], [0, 0]], lhs_dilate = [1, 1], rhs_dilate = [1, 1], reverse = [false, false]} {batch_group_count = 1 : i64, feature_group_count = 1 : i64, precision_config = [#stablehlo<precision DEFAULT>, #stablehlo<precision DEFAULT>]} : (tensor<2x9x9x16xf32>, tensor<1x1x16x64xf32>) -> tensor<2x9x9x64xf32>
    %33 = stablehlo.broadcast_in_dim %arg5, dims = [3] : (tensor<64xf32>) -> tensor<1x1x1x64xf32>
    %34 = stablehlo.broadcast_in_dim %arg6, dims = [3] : (tensor<64xf32>) -> tensor<1x1x1x64xf32>
    %35 = stablehlo.broadcast_in_dim %33, dims = [0, 1, 2, 3] : (tensor<1x1x1x64xf32>) -> tensor<2x9x9x64xf32>
    %36 = stablehlo.subtract %32, %35 : tensor<2x9x9x64xf32>
    %cst_1 = stablehlo.constant dense<9.99999974E-6> : tensor<f32>
    %37 = stablehlo.broadcast_in_dim %cst_1, dims = [] : (tensor<f32>) -> tensor<1x1x1x64xf32>
    %38 = stablehlo.add %34, %37 : tensor<1x1x1x64xf32>
    %39 = stablehlo.rsqrt %38 : tensor<1x1x1x64xf32>
    %40 = stablehlo.reshape %arg14 : (tensor<64xf32>) -> tensor<1x1x1x64xf32>
    %41 = stablehlo.multiply %39, %40 : tensor<1x1x1x64xf32>
    %42 = stablehlo.broadcast_in_dim %41, dims = [0, 1, 2, 3] : (tensor<1x1x1x64xf32>) -> tensor<2x9x9x64xf32>
    %43 = stablehlo.multiply %36, %42 : tensor<2x9x9x64xf32>
    %44 = stablehlo.reshape %arg13 : (tensor<64xf32>) -> tensor<1x1x1x64xf32>
    %45 = stablehlo.broadcast_in_dim %44, dims = [0, 1, 2, 3] : (tensor<1x1x1x64xf32>) -> tensor<2x9x9x64xf32>
    %46 = stablehlo.add %43, %45 : tensor<2x9x9x64xf32>
    %47 = stablehlo.convolution(%arg0, %arg18) dim_numbers = [b, 0, 1, f]x[0, 1, i, o]->[b, 0, 1, f], window = {stride = [2, 2], pad = [[0, 0], [0, 0]], lhs_dilate = [1, 1], rhs_dilate = [1, 1], reverse = [false, false]} {batch_group_count = 1 : i64, feature_group_count = 1 : i64, precision_config = [#stablehlo<precision DEFAULT>, #stablehlo<precision DEFAULT>]} : (tensor<2x18x18x16xf32>, tensor<1x1x16x64xf32>) -> tensor<2x9x9x64xf32>
    %48 = stablehlo.broadcast_in_dim %arg7, dims = [3] : (tensor<64xf32>) -> tensor<1x1x1x64xf32>
    %49 = stablehlo.broadcast_in_dim %arg8, dims = [3] : (tensor<64xf32>) -> tensor<1x1x1x64xf32>
    %50 = stablehlo.broadcast_in_dim %48, dims = [0, 1, 2, 3] : (tensor<1x1x1x64xf32>) -> tensor<2x9x9x64xf32>
    %51 = stablehlo.subtract %47, %50 : tensor<2x9x9x64xf32>
    %cst_2 = stablehlo.constant dense<9.99999974E-6> : tensor<f32>
    %52 = stablehlo.broadcast_in_dim %cst_2, dims = [] : (tensor<f32>) -> tensor<1x1x1x64xf32>
    %53 = stablehlo.add %49, %52 : tensor<1x1x1x64xf32>
    %54 = stablehlo.rsqrt %53 : tensor<1x1x1x64xf32>
    %55 = stablehlo.reshape %arg20 : (tensor<64xf32>) -> tensor<1x1x1x64xf32>
    %56 = stablehlo.multiply %54, %55 : tensor<1x1x1x64xf32>
    %57 = stablehlo.broadcast_in_dim %56, dims = [0, 1, 2, 3] : (tensor<1x1x1x64xf32>) -> tensor<2x9x9x64xf32>
    %58 = stablehlo.multiply %51, %57 : tensor<2x9x9x64xf32>
    %59 = stablehlo.reshape %arg19 : (tensor<64xf32>) -> tensor<1x1x1x64xf32>
    %60 = stablehlo.broadcast_in_dim %59, dims = [0, 1, 2, 3] : (tensor<1x1x1x64xf32>) -> tensor<2x9x9x64xf32>
    %61 = stablehlo.add %58, %60 : tensor<2x9x9x64xf32>
    %62 = stablehlo.add %61, %46 : tensor<2x9x9x64xf32>
    %63 = call @relu_21(%62) : (tensor<2x9x9x64xf32>) -> tensor<2x9x9x64xf32>
    %cst_3 = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %64 = stablehlo.broadcast_in_dim %cst_3, dims = [] : (tensor<f32>) -> tensor<2x18x18x16xf32>
    %65 = stablehlo.compare  GT, %14, %64,  FLOAT : (tensor<2x18x18x16xf32>, tensor<2x18x18x16xf32>) -> tensor<2x18x18x16xi1>
    %66 = stablehlo.convert %65 : (tensor<2x18x18x16xi1>) -> tensor<2x18x18x16xi32>
    %cst_4 = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %67 = stablehlo.broadcast_in_dim %cst_4, dims = [] : (tensor<f32>) -> tensor<2x9x9x16xf32>
    %68 = stablehlo.compare  GT, %30, %67,  FLOAT : (tensor<2x9x9x16xf32>, tensor<2x9x9x16xf32>) -> tensor<2x9x9x16xi1>
    %69 = stablehlo.convert %68 : (tensor<2x9x9x16xi1>) -> tensor<2x9x9x16xi32>
    %cst_5 = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %70 = stablehlo.broadcast_in_dim %cst_5, dims = [] : (tensor<f32>) -> tensor<2x9x9x64xf32>
    %71 = stablehlo.compare  GT, %62, %70,  FLOAT : (tensor<2x9x9x64xf32>, tensor<2x9x9x64xf32>) -> tensor<2x9x9x64xi1>
    %72 = stablehlo.convert %71 : (tensor<2x9x9x64xi1>) -> tensor<2x9x9x64xi32>
    %c = stablehlo.constant dense<0> : tensor<i32>
    %73 = stablehlo.reduce(%66 init: %c) applies stablehlo.add across dimensions = [0, 1, 2, 3] : (tensor<2x18x18x16xi32>, tensor<i32>) -> tensor<i32>
    %c_6 = stablehlo.constant dense<0> : tensor<i32>
    %74 = stablehlo.reduce(%69 init: %c_6) applies stablehlo.add across dimensions = [0, 1, 2, 3] : (tensor<2x9x9x16xi32>, tensor<i32>) -> tensor<i32>
    %c_7 = stablehlo.constant dense<0> : tensor<i32>
    %75 = stablehlo.reduce(%72 init: %c_7) applies stablehlo.add across dimensions = [0, 1, 2, 3] : (tensor<2x9x9x64xi32>, tensor<i32>) -> tensor<i32>
    return %63, %73, %74, %75 : tensor<2x9x9x64xf32>, tensor<i32>, tensor<i32>, tensor<i32>
  }
  func.func private @relu(%arg0: tensor<2x18x18x16xf32>) -> tensor<2x18x18x16xf32> {
    %cst = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %0 = stablehlo.broadcast_in_dim %cst, dims = [] : (tensor<f32>) -> tensor<2x18x18x16xf32>
    %1 = stablehlo.maximum %arg0, %0 : tensor<2x18x18x16xf32>
    return %1 : tensor<2x18x18x16xf32>
  }
  func.func private @relu_7(%arg0: tensor<2x9x9x16xf32>) -> tensor<2x9x9x16xf32> {
    %cst = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %0 = stablehlo.broadcast_in_dim %cst, dims = [] : (tensor<f32>) -> tensor<2x9x9x16xf32>
    %1 = stablehlo.maximum %arg0, %0 : tensor<2x9x9x16xf32>
    return %1 : tensor<2x9x9x16xf32>
  }
  func.func private @relu_21(%arg0: tensor<2x9x9x64xf32>) -> tensor<2x9x9x64xf32> {
    %cst = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %0 = stablehlo.broadcast_in_dim %cst, dims = [] : (tensor<f32>) -> tensor<2x9x9x64xf32>
    %1 = stablehlo.maximum %arg0, %0 : tensor<2x9x9x64xf32>
    return %1 : tensor<2x9x9x64xf32>
  }
}
