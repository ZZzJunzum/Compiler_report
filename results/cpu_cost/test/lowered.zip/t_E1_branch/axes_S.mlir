module @jit_forward attributes {mhlo.num_partitions = 1 : i32, mhlo.num_replicas = 1 : i32} {
  func.func public @main(%arg0: tensor<320x160xf32>, %arg1: tensor<160xf32>, %arg2: tensor<160xf32>, %arg3: tensor<160xf32>, %arg4: tensor<160xf32>, %arg5: tensor<160xf32>, %arg6: tensor<160xf32>) -> (tensor<320x160xf32> {jax.result_info = "result[0]"}, tensor<i32> {jax.result_info = "result[1]"}, tensor<320xi32> {jax.result_info = "result[2]"}) {
    %0 = stablehlo.broadcast_in_dim %arg1, dims = [1] : (tensor<160xf32>) -> tensor<1x160xf32>
    %1 = stablehlo.broadcast_in_dim %0, dims = [0, 1] : (tensor<1x160xf32>) -> tensor<320x160xf32>
    %2 = stablehlo.multiply %arg0, %1 : tensor<320x160xf32>
    %3 = stablehlo.broadcast_in_dim %arg2, dims = [1] : (tensor<160xf32>) -> tensor<1x160xf32>
    %4 = stablehlo.broadcast_in_dim %3, dims = [0, 1] : (tensor<1x160xf32>) -> tensor<320x160xf32>
    %5 = stablehlo.add %2, %4 : tensor<320x160xf32>
    %cst = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %6 = stablehlo.broadcast_in_dim %cst, dims = [] : (tensor<f32>) -> tensor<320x160xf32>
    %7 = stablehlo.maximum %5, %6 : tensor<320x160xf32>
    %8 = stablehlo.broadcast_in_dim %arg3, dims = [1] : (tensor<160xf32>) -> tensor<1x160xf32>
    %9 = stablehlo.broadcast_in_dim %8, dims = [0, 1] : (tensor<1x160xf32>) -> tensor<320x160xf32>
    %10 = stablehlo.multiply %7, %9 : tensor<320x160xf32>
    %11 = stablehlo.broadcast_in_dim %arg4, dims = [1] : (tensor<160xf32>) -> tensor<1x160xf32>
    %12 = stablehlo.broadcast_in_dim %11, dims = [0, 1] : (tensor<1x160xf32>) -> tensor<320x160xf32>
    %13 = stablehlo.add %10, %12 : tensor<320x160xf32>
    %cst_0 = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %14 = stablehlo.broadcast_in_dim %cst_0, dims = [] : (tensor<f32>) -> tensor<320x160xf32>
    %15 = stablehlo.maximum %13, %14 : tensor<320x160xf32>
    %16 = stablehlo.broadcast_in_dim %arg5, dims = [1] : (tensor<160xf32>) -> tensor<1x160xf32>
    %17 = stablehlo.broadcast_in_dim %16, dims = [0, 1] : (tensor<1x160xf32>) -> tensor<320x160xf32>
    %18 = stablehlo.multiply %15, %17 : tensor<320x160xf32>
    %19 = stablehlo.broadcast_in_dim %arg6, dims = [1] : (tensor<160xf32>) -> tensor<1x160xf32>
    %20 = stablehlo.broadcast_in_dim %19, dims = [0, 1] : (tensor<1x160xf32>) -> tensor<320x160xf32>
    %21 = stablehlo.add %18, %20 : tensor<320x160xf32>
    %cst_1 = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %22 = stablehlo.broadcast_in_dim %cst_1, dims = [] : (tensor<f32>) -> tensor<320x160xf32>
    %23 = stablehlo.maximum %21, %22 : tensor<320x160xf32>
    %cst_2 = stablehlo.constant dense<7.500000e-01> : tensor<f32>
    %24 = stablehlo.broadcast_in_dim %cst_2, dims = [] : (tensor<f32>) -> tensor<320x160xf32>
    %25 = stablehlo.multiply %23, %24 : tensor<320x160xf32>
    %cst_3 = stablehlo.constant dense<1.250000e-01> : tensor<f32>
    %26 = stablehlo.broadcast_in_dim %cst_3, dims = [] : (tensor<f32>) -> tensor<320x160xf32>
    %27 = stablehlo.add %25, %26 : tensor<320x160xf32>
    %cst_4 = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %28 = stablehlo.broadcast_in_dim %cst_4, dims = [] : (tensor<f32>) -> tensor<320x160xf32>
    %29 = stablehlo.maximum %5, %28 : tensor<320x160xf32>
    %cst_5 = stablehlo.constant dense<2.500000e-01> : tensor<f32>
    %30 = stablehlo.broadcast_in_dim %cst_5, dims = [] : (tensor<f32>) -> tensor<320x160xf32>
    %31 = stablehlo.multiply %30, %29 : tensor<320x160xf32>
    %32 = stablehlo.add %27, %31 : tensor<320x160xf32>
    %cst_6 = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %33 = stablehlo.broadcast_in_dim %cst_6, dims = [] : (tensor<f32>) -> tensor<320x160xf32>
    %34 = stablehlo.compare  GT, %5, %33,  FLOAT : (tensor<320x160xf32>, tensor<320x160xf32>) -> tensor<320x160xi1>
    %35 = stablehlo.convert %34 : (tensor<320x160xi1>) -> tensor<320x160xi32>
    %cst_7 = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %36 = stablehlo.broadcast_in_dim %cst_7, dims = [] : (tensor<f32>) -> tensor<320x160xf32>
    %37 = stablehlo.compare  GT, %13, %36,  FLOAT : (tensor<320x160xf32>, tensor<320x160xf32>) -> tensor<320x160xi1>
    %38 = stablehlo.convert %37 : (tensor<320x160xi1>) -> tensor<320x160xi32>
    %c = stablehlo.constant dense<0> : tensor<i32>
    %39 = stablehlo.reduce(%35 init: %c) applies stablehlo.add across dimensions = [0, 1] : (tensor<320x160xi32>, tensor<i32>) -> tensor<i32>
    %c_8 = stablehlo.constant dense<0> : tensor<i32>
    %40 = stablehlo.reduce(%38 init: %c_8) applies stablehlo.add across dimensions = [1] : (tensor<320x160xi32>, tensor<i32>) -> tensor<320xi32>
    return %32, %39, %40 : tensor<320x160xf32>, tensor<i32>, tensor<320xi32>
  }
}
