module @jit_forward attributes {mhlo.num_partitions = 1 : i32, mhlo.num_replicas = 1 : i32} {
  func.func public @main(%arg0: tensor<192x128xf32>, %arg1: tensor<128x256xf32>, %arg2: tensor<256xf32>, %arg3: tensor<128x256xf32>, %arg4: tensor<256xf32>, %arg5: tensor<256x128xf32>, %arg6: tensor<128xf32>) -> (tensor<192x128xf32> {jax.result_info = "result[0]"}, tensor<i32> {jax.result_info = "result[1]"}, tensor<f32> {jax.result_info = "result[2]"}) {
    %0 = stablehlo.dot_general %arg0, %arg1, contracting_dims = [1] x [0], precision = [DEFAULT, DEFAULT] : (tensor<192x128xf32>, tensor<128x256xf32>) -> tensor<192x256xf32>
    %1 = stablehlo.broadcast_in_dim %arg2, dims = [1] : (tensor<256xf32>) -> tensor<1x256xf32>
    %2 = stablehlo.broadcast_in_dim %1, dims = [0, 1] : (tensor<1x256xf32>) -> tensor<192x256xf32>
    %3 = stablehlo.add %0, %2 : tensor<192x256xf32>
    %4 = call @silu(%3) : (tensor<192x256xf32>) -> tensor<192x256xf32>
    %5 = stablehlo.dot_general %arg0, %arg3, contracting_dims = [1] x [0], precision = [DEFAULT, DEFAULT] : (tensor<192x128xf32>, tensor<128x256xf32>) -> tensor<192x256xf32>
    %6 = stablehlo.broadcast_in_dim %arg4, dims = [1] : (tensor<256xf32>) -> tensor<1x256xf32>
    %7 = stablehlo.broadcast_in_dim %6, dims = [0, 1] : (tensor<1x256xf32>) -> tensor<192x256xf32>
    %8 = stablehlo.add %5, %7 : tensor<192x256xf32>
    %9 = stablehlo.multiply %4, %8 : tensor<192x256xf32>
    %10 = stablehlo.dot_general %9, %arg5, contracting_dims = [1] x [0], precision = [DEFAULT, DEFAULT] : (tensor<192x256xf32>, tensor<256x128xf32>) -> tensor<192x128xf32>
    %11 = stablehlo.broadcast_in_dim %arg6, dims = [1] : (tensor<128xf32>) -> tensor<1x128xf32>
    %12 = stablehlo.broadcast_in_dim %11, dims = [0, 1] : (tensor<1x128xf32>) -> tensor<192x128xf32>
    %13 = stablehlo.add %10, %12 : tensor<192x128xf32>
    %14 = stablehlo.add %arg0, %13 : tensor<192x128xf32>
    %cst = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %15 = stablehlo.broadcast_in_dim %cst, dims = [] : (tensor<f32>) -> tensor<192x256xf32>
    %16 = stablehlo.compare  GT, %3, %15,  FLOAT : (tensor<192x256xf32>, tensor<192x256xf32>) -> tensor<192x256xi1>
    %17 = stablehlo.convert %16 : (tensor<192x256xi1>) -> tensor<192x256xi32>
    %c = stablehlo.constant dense<0> : tensor<i32>
    %cst_0 = stablehlo.constant dense<0xFF800000> : tensor<f32>
    %18:2 = stablehlo.reduce(%17 init: %c), (%9 init: %cst_0) across dimensions = [0, 1] : (tensor<192x256xi32>, tensor<192x256xf32>, tensor<i32>, tensor<f32>) -> (tensor<i32>, tensor<f32>)
     reducer(%arg7: tensor<i32>, %arg9: tensor<i32>) (%arg8: tensor<f32>, %arg10: tensor<f32>)  {
      %19 = stablehlo.add %arg7, %arg9 : tensor<i32>
      %20 = stablehlo.maximum %arg8, %arg10 : tensor<f32>
      stablehlo.return %19, %20 : tensor<i32>, tensor<f32>
    }
    return %14, %18#0, %18#1 : tensor<192x128xf32>, tensor<i32>, tensor<f32>
  }
  func.func private @silu(%arg0: tensor<192x256xf32>) -> tensor<192x256xf32> {
    %0 = stablehlo.negate %arg0 : tensor<192x256xf32>
    %1 = stablehlo.exponential %0 : tensor<192x256xf32>
    %cst = stablehlo.constant dense<1.000000e+00> : tensor<f32>
    %2 = stablehlo.broadcast_in_dim %cst, dims = [] : (tensor<f32>) -> tensor<192x256xf32>
    %3 = stablehlo.add %2, %1 : tensor<192x256xf32>
    %cst_0 = stablehlo.constant dense<1.000000e+00> : tensor<f32>
    %4 = stablehlo.broadcast_in_dim %cst_0, dims = [] : (tensor<f32>) -> tensor<192x256xf32>
    %5 = stablehlo.divide %4, %3 : tensor<192x256xf32>
    %6 = stablehlo.multiply %arg0, %5 : tensor<192x256xf32>
    return %6 : tensor<192x256xf32>
  }
}
