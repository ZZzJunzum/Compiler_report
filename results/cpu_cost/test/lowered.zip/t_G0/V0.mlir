module @jit_forward attributes {mhlo.num_partitions = 1 : i32, mhlo.num_replicas = 1 : i32} {
  func.func public @main(%arg0: tensor<40x72xf32>, %arg1: tensor<72x144xf32>, %arg2: tensor<144xf32>, %arg3: tensor<72x144xf32>, %arg4: tensor<144xf32>, %arg5: tensor<144x72xf32>, %arg6: tensor<72xf32>) -> (tensor<40x72xf32> {jax.result_info = "result[0]"}) {
    %0 = stablehlo.dot_general %arg0, %arg1, contracting_dims = [1] x [0], precision = [DEFAULT, DEFAULT] : (tensor<40x72xf32>, tensor<72x144xf32>) -> tensor<40x144xf32>
    %1 = stablehlo.broadcast_in_dim %arg2, dims = [1] : (tensor<144xf32>) -> tensor<1x144xf32>
    %2 = stablehlo.broadcast_in_dim %1, dims = [0, 1] : (tensor<1x144xf32>) -> tensor<40x144xf32>
    %3 = stablehlo.add %0, %2 : tensor<40x144xf32>
    %4 = call @silu(%3) : (tensor<40x144xf32>) -> tensor<40x144xf32>
    %5 = stablehlo.dot_general %arg0, %arg3, contracting_dims = [1] x [0], precision = [DEFAULT, DEFAULT] : (tensor<40x72xf32>, tensor<72x144xf32>) -> tensor<40x144xf32>
    %6 = stablehlo.broadcast_in_dim %arg4, dims = [1] : (tensor<144xf32>) -> tensor<1x144xf32>
    %7 = stablehlo.broadcast_in_dim %6, dims = [0, 1] : (tensor<1x144xf32>) -> tensor<40x144xf32>
    %8 = stablehlo.add %5, %7 : tensor<40x144xf32>
    %9 = stablehlo.multiply %4, %8 : tensor<40x144xf32>
    %10 = stablehlo.dot_general %9, %arg5, contracting_dims = [1] x [0], precision = [DEFAULT, DEFAULT] : (tensor<40x144xf32>, tensor<144x72xf32>) -> tensor<40x72xf32>
    %11 = stablehlo.broadcast_in_dim %arg6, dims = [1] : (tensor<72xf32>) -> tensor<1x72xf32>
    %12 = stablehlo.broadcast_in_dim %11, dims = [0, 1] : (tensor<1x72xf32>) -> tensor<40x72xf32>
    %13 = stablehlo.add %10, %12 : tensor<40x72xf32>
    %14 = stablehlo.add %arg0, %13 : tensor<40x72xf32>
    return %14 : tensor<40x72xf32>
  }
  func.func private @silu(%arg0: tensor<40x144xf32>) -> tensor<40x144xf32> {
    %0 = stablehlo.negate %arg0 : tensor<40x144xf32>
    %1 = stablehlo.exponential %0 : tensor<40x144xf32>
    %cst = stablehlo.constant dense<1.000000e+00> : tensor<f32>
    %2 = stablehlo.broadcast_in_dim %cst, dims = [] : (tensor<f32>) -> tensor<40x144xf32>
    %3 = stablehlo.add %2, %1 : tensor<40x144xf32>
    %cst_0 = stablehlo.constant dense<1.000000e+00> : tensor<f32>
    %4 = stablehlo.broadcast_in_dim %cst_0, dims = [] : (tensor<f32>) -> tensor<40x144xf32>
    %5 = stablehlo.divide %4, %3 : tensor<40x144xf32>
    %6 = stablehlo.multiply %arg0, %5 : tensor<40x144xf32>
    return %6 : tensor<40x144xf32>
  }
}
