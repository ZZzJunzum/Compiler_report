module @jit_forward attributes {mhlo.num_partitions = 1 : i32, mhlo.num_replicas = 1 : i32} {
  func.func public @main(%arg0: tensor<48x80xf32>, %arg1: tensor<80x80xf32>, %arg2: tensor<80xf32>, %arg3: tensor<80x80xf32>, %arg4: tensor<80xf32>, %arg5: tensor<80x80xf32>, %arg6: tensor<80xf32>) -> (tensor<48x80xf32> {jax.result_info = "result[0]"}, tensor<i32> {jax.result_info = "result[1]"}, tensor<f32> {jax.result_info = "result[2]"}) {
    %0 = stablehlo.dot_general %arg0, %arg1, contracting_dims = [1] x [0], precision = [DEFAULT, DEFAULT] : (tensor<48x80xf32>, tensor<80x80xf32>) -> tensor<48x80xf32>
    %1 = stablehlo.broadcast_in_dim %arg2, dims = [1] : (tensor<80xf32>) -> tensor<1x80xf32>
    %2 = stablehlo.broadcast_in_dim %1, dims = [0, 1] : (tensor<1x80xf32>) -> tensor<48x80xf32>
    %3 = stablehlo.add %0, %2 : tensor<48x80xf32>
    %cst = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %4 = stablehlo.broadcast_in_dim %cst, dims = [] : (tensor<f32>) -> tensor<48x80xf32>
    %5 = stablehlo.maximum %3, %4 : tensor<48x80xf32>
    %6 = stablehlo.dot_general %5, %arg3, contracting_dims = [1] x [0], precision = [DEFAULT, DEFAULT] : (tensor<48x80xf32>, tensor<80x80xf32>) -> tensor<48x80xf32>
    %7 = stablehlo.broadcast_in_dim %arg4, dims = [1] : (tensor<80xf32>) -> tensor<1x80xf32>
    %8 = stablehlo.broadcast_in_dim %7, dims = [0, 1] : (tensor<1x80xf32>) -> tensor<48x80xf32>
    %9 = stablehlo.add %6, %8 : tensor<48x80xf32>
    %cst_0 = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %10 = stablehlo.broadcast_in_dim %cst_0, dims = [] : (tensor<f32>) -> tensor<48x80xf32>
    %11 = stablehlo.maximum %9, %10 : tensor<48x80xf32>
    %12 = stablehlo.dot_general %11, %arg5, contracting_dims = [1] x [0], precision = [DEFAULT, DEFAULT] : (tensor<48x80xf32>, tensor<80x80xf32>) -> tensor<48x80xf32>
    %13 = stablehlo.broadcast_in_dim %arg6, dims = [1] : (tensor<80xf32>) -> tensor<1x80xf32>
    %14 = stablehlo.broadcast_in_dim %13, dims = [0, 1] : (tensor<1x80xf32>) -> tensor<48x80xf32>
    %15 = stablehlo.add %12, %14 : tensor<48x80xf32>
    %cst_1 = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %16 = stablehlo.broadcast_in_dim %cst_1, dims = [] : (tensor<f32>) -> tensor<48x80xf32>
    %17 = stablehlo.maximum %15, %16 : tensor<48x80xf32>
    %cst_2 = stablehlo.constant dense<7.500000e-01> : tensor<f32>
    %18 = stablehlo.broadcast_in_dim %cst_2, dims = [] : (tensor<f32>) -> tensor<48x80xf32>
    %19 = stablehlo.multiply %17, %18 : tensor<48x80xf32>
    %cst_3 = stablehlo.constant dense<1.250000e-01> : tensor<f32>
    %20 = stablehlo.broadcast_in_dim %cst_3, dims = [] : (tensor<f32>) -> tensor<48x80xf32>
    %21 = stablehlo.add %19, %20 : tensor<48x80xf32>
    %cst_4 = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %22 = stablehlo.broadcast_in_dim %cst_4, dims = [] : (tensor<f32>) -> tensor<48x80xf32>
    %23 = stablehlo.compare  GT, %3, %22,  FLOAT : (tensor<48x80xf32>, tensor<48x80xf32>) -> tensor<48x80xi1>
    %24 = stablehlo.convert %23 : (tensor<48x80xi1>) -> tensor<48x80xi32>
    %c = stablehlo.constant dense<0> : tensor<i32>
    %cst_5 = stablehlo.constant dense<0xFF800000> : tensor<f32>
    %25:2 = stablehlo.reduce(%24 init: %c), (%9 init: %cst_5) across dimensions = [0, 1] : (tensor<48x80xi32>, tensor<48x80xf32>, tensor<i32>, tensor<f32>) -> (tensor<i32>, tensor<f32>)
     reducer(%arg7: tensor<i32>, %arg9: tensor<i32>) (%arg8: tensor<f32>, %arg10: tensor<f32>)  {
      %26 = stablehlo.add %arg7, %arg9 : tensor<i32>
      %27 = stablehlo.maximum %arg8, %arg10 : tensor<f32>
      stablehlo.return %26, %27 : tensor<i32>, tensor<f32>
    }
    return %21, %25#0, %25#1 : tensor<48x80xf32>, tensor<i32>, tensor<f32>
  }
}
