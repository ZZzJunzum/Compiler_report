module @jit_forward attributes {mhlo.num_partitions = 1 : i32, mhlo.num_replicas = 1 : i32} {
  func.func public @main(%arg0: tensor<48x80xf32>, %arg1: tensor<80xf32>, %arg2: tensor<80xf32>, %arg3: tensor<80xf32>, %arg4: tensor<80xf32>, %arg5: tensor<80xf32>, %arg6: tensor<80xf32>) -> (tensor<48x80xf32> {jax.result_info = "result[0]"}, tensor<i32> {jax.result_info = "result[1]"}, tensor<i32> {jax.result_info = "result[2]"}) {
    %0 = stablehlo.broadcast_in_dim %arg1, dims = [1] : (tensor<80xf32>) -> tensor<1x80xf32>
    %1 = stablehlo.broadcast_in_dim %0, dims = [0, 1] : (tensor<1x80xf32>) -> tensor<48x80xf32>
    %2 = stablehlo.multiply %arg0, %1 : tensor<48x80xf32>
    %3 = stablehlo.broadcast_in_dim %arg2, dims = [1] : (tensor<80xf32>) -> tensor<1x80xf32>
    %4 = stablehlo.broadcast_in_dim %3, dims = [0, 1] : (tensor<1x80xf32>) -> tensor<48x80xf32>
    %5 = stablehlo.add %2, %4 : tensor<48x80xf32>
    %cst = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %6 = stablehlo.broadcast_in_dim %cst, dims = [] : (tensor<f32>) -> tensor<48x80xf32>
    %7 = stablehlo.maximum %5, %6 : tensor<48x80xf32>
    %8 = stablehlo.broadcast_in_dim %arg3, dims = [1] : (tensor<80xf32>) -> tensor<1x80xf32>
    %9 = stablehlo.broadcast_in_dim %8, dims = [0, 1] : (tensor<1x80xf32>) -> tensor<48x80xf32>
    %10 = stablehlo.multiply %7, %9 : tensor<48x80xf32>
    %11 = stablehlo.broadcast_in_dim %arg4, dims = [1] : (tensor<80xf32>) -> tensor<1x80xf32>
    %12 = stablehlo.broadcast_in_dim %11, dims = [0, 1] : (tensor<1x80xf32>) -> tensor<48x80xf32>
    %13 = stablehlo.add %10, %12 : tensor<48x80xf32>
    %cst_0 = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %14 = stablehlo.broadcast_in_dim %cst_0, dims = [] : (tensor<f32>) -> tensor<48x80xf32>
    %15 = stablehlo.maximum %13, %14 : tensor<48x80xf32>
    %16 = stablehlo.broadcast_in_dim %arg5, dims = [1] : (tensor<80xf32>) -> tensor<1x80xf32>
    %17 = stablehlo.broadcast_in_dim %16, dims = [0, 1] : (tensor<1x80xf32>) -> tensor<48x80xf32>
    %18 = stablehlo.multiply %15, %17 : tensor<48x80xf32>
    %19 = stablehlo.broadcast_in_dim %arg6, dims = [1] : (tensor<80xf32>) -> tensor<1x80xf32>
    %20 = stablehlo.broadcast_in_dim %19, dims = [0, 1] : (tensor<1x80xf32>) -> tensor<48x80xf32>
    %21 = stablehlo.add %18, %20 : tensor<48x80xf32>
    %cst_1 = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %22 = stablehlo.broadcast_in_dim %cst_1, dims = [] : (tensor<f32>) -> tensor<48x80xf32>
    %23 = stablehlo.maximum %21, %22 : tensor<48x80xf32>
    %cst_2 = stablehlo.constant dense<7.500000e-01> : tensor<f32>
    %24 = stablehlo.broadcast_in_dim %cst_2, dims = [] : (tensor<f32>) -> tensor<48x80xf32>
    %25 = stablehlo.multiply %23, %24 : tensor<48x80xf32>
    %cst_3 = stablehlo.constant dense<1.250000e-01> : tensor<f32>
    %26 = stablehlo.broadcast_in_dim %cst_3, dims = [] : (tensor<f32>) -> tensor<48x80xf32>
    %27 = stablehlo.add %25, %26 : tensor<48x80xf32>
    %cst_4 = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %28 = stablehlo.broadcast_in_dim %cst_4, dims = [] : (tensor<f32>) -> tensor<48x80xf32>
    %29 = stablehlo.compare  GT, %5, %28,  FLOAT : (tensor<48x80xf32>, tensor<48x80xf32>) -> tensor<48x80xi1>
    %30 = stablehlo.convert %29 : (tensor<48x80xi1>) -> tensor<48x80xi32>
    %cst_5 = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %31 = stablehlo.broadcast_in_dim %cst_5, dims = [] : (tensor<f32>) -> tensor<48x80xf32>
    %32 = stablehlo.compare  GT, %13, %31,  FLOAT : (tensor<48x80xf32>, tensor<48x80xf32>) -> tensor<48x80xi1>
    %33 = stablehlo.convert %32 : (tensor<48x80xi1>) -> tensor<48x80xi32>
    %c = stablehlo.constant dense<0> : tensor<i32>
    %c_6 = stablehlo.constant dense<0> : tensor<i32>
    %34:2 = stablehlo.reduce(%30 init: %c), (%33 init: %c_6) across dimensions = [0, 1] : (tensor<48x80xi32>, tensor<48x80xi32>, tensor<i32>, tensor<i32>) -> (tensor<i32>, tensor<i32>)
     reducer(%arg7: tensor<i32>, %arg9: tensor<i32>) (%arg8: tensor<i32>, %arg10: tensor<i32>)  {
      %35 = stablehlo.add %arg7, %arg9 : tensor<i32>
      %36 = stablehlo.add %arg8, %arg10 : tensor<i32>
      stablehlo.return %35, %36 : tensor<i32>, tensor<i32>
    }
    return %27, %34#0, %34#1 : tensor<48x80xf32>, tensor<i32>, tensor<i32>
  }
}
