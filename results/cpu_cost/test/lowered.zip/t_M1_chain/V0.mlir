module @jit_forward attributes {mhlo.num_partitions = 1 : i32, mhlo.num_replicas = 1 : i32} {
  func.func public @main(%arg0: tensor<320x160xf32>, %arg1: tensor<160x160xf32>, %arg2: tensor<160xf32>, %arg3: tensor<160x160xf32>, %arg4: tensor<160xf32>, %arg5: tensor<160x160xf32>, %arg6: tensor<160xf32>) -> (tensor<320x160xf32> {jax.result_info = "result[0]"}) {
    %0 = stablehlo.dot_general %arg0, %arg1, contracting_dims = [1] x [0], precision = [DEFAULT, DEFAULT] : (tensor<320x160xf32>, tensor<160x160xf32>) -> tensor<320x160xf32>
    %1 = stablehlo.broadcast_in_dim %arg2, dims = [1] : (tensor<160xf32>) -> tensor<1x160xf32>
    %2 = stablehlo.broadcast_in_dim %1, dims = [0, 1] : (tensor<1x160xf32>) -> tensor<320x160xf32>
    %3 = stablehlo.add %0, %2 : tensor<320x160xf32>
    %cst = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %4 = stablehlo.broadcast_in_dim %cst, dims = [] : (tensor<f32>) -> tensor<320x160xf32>
    %5 = stablehlo.maximum %3, %4 : tensor<320x160xf32>
    %6 = stablehlo.dot_general %5, %arg3, contracting_dims = [1] x [0], precision = [DEFAULT, DEFAULT] : (tensor<320x160xf32>, tensor<160x160xf32>) -> tensor<320x160xf32>
    %7 = stablehlo.broadcast_in_dim %arg4, dims = [1] : (tensor<160xf32>) -> tensor<1x160xf32>
    %8 = stablehlo.broadcast_in_dim %7, dims = [0, 1] : (tensor<1x160xf32>) -> tensor<320x160xf32>
    %9 = stablehlo.add %6, %8 : tensor<320x160xf32>
    %cst_0 = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %10 = stablehlo.broadcast_in_dim %cst_0, dims = [] : (tensor<f32>) -> tensor<320x160xf32>
    %11 = stablehlo.maximum %9, %10 : tensor<320x160xf32>
    %12 = stablehlo.dot_general %11, %arg5, contracting_dims = [1] x [0], precision = [DEFAULT, DEFAULT] : (tensor<320x160xf32>, tensor<160x160xf32>) -> tensor<320x160xf32>
    %13 = stablehlo.broadcast_in_dim %arg6, dims = [1] : (tensor<160xf32>) -> tensor<1x160xf32>
    %14 = stablehlo.broadcast_in_dim %13, dims = [0, 1] : (tensor<1x160xf32>) -> tensor<320x160xf32>
    %15 = stablehlo.add %12, %14 : tensor<320x160xf32>
    %cst_1 = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %16 = stablehlo.broadcast_in_dim %cst_1, dims = [] : (tensor<f32>) -> tensor<320x160xf32>
    %17 = stablehlo.maximum %15, %16 : tensor<320x160xf32>
    %cst_2 = stablehlo.constant dense<7.500000e-01> : tensor<f32>
    %18 = stablehlo.broadcast_in_dim %cst_2, dims = [] : (tensor<f32>) -> tensor<320x160xf32>
    %19 = stablehlo.multiply %17, %18 : tensor<320x160xf32>
    %cst_3 = stablehlo.constant dense<1.250000e-01> : tensor<f32>
    %20 = stablehlo.broadcast_in_dim %cst_3, dims = [] : (tensor<f32>) -> tensor<320x160xf32>
    %21 = stablehlo.add %19, %20 : tensor<320x160xf32>
    return %21 : tensor<320x160xf32>
  }
}
