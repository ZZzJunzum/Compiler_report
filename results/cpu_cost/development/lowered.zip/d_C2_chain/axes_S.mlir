module @jit_forward attributes {mhlo.num_partitions = 1 : i32, mhlo.num_replicas = 1 : i32} {
  func.func public @main(%arg0: tensor<4x24x24x16xf32>, %arg1: tensor<3x3x16x16xf32>, %arg2: tensor<16xf32>, %arg3: tensor<3x3x16x16xf32>, %arg4: tensor<16xf32>, %arg5: tensor<3x3x16x16xf32>, %arg6: tensor<16xf32>) -> (tensor<4x24x24x16xf32> {jax.result_info = "result[0]"}, tensor<i32> {jax.result_info = "result[1]"}, tensor<4x24x24xi32> {jax.result_info = "result[2]"}) {
    %0 = stablehlo.convolution(%arg0, %arg1) dim_numbers = [b, 0, 1, f]x[0, 1, i, o]->[b, 0, 1, f], window = {stride = [1, 1], pad = [[1, 1], [1, 1]], lhs_dilate = [1, 1], rhs_dilate = [1, 1], reverse = [false, false]} {batch_group_count = 1 : i64, feature_group_count = 1 : i64, precision_config = [#stablehlo<precision DEFAULT>, #stablehlo<precision DEFAULT>]} : (tensor<4x24x24x16xf32>, tensor<3x3x16x16xf32>) -> tensor<4x24x24x16xf32>
    %1 = stablehlo.broadcast_in_dim %arg2, dims = [3] : (tensor<16xf32>) -> tensor<1x1x1x16xf32>
    %2 = stablehlo.broadcast_in_dim %1, dims = [0, 1, 2, 3] : (tensor<1x1x1x16xf32>) -> tensor<4x24x24x16xf32>
    %3 = stablehlo.add %0, %2 : tensor<4x24x24x16xf32>
    %cst = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %4 = stablehlo.broadcast_in_dim %cst, dims = [] : (tensor<f32>) -> tensor<4x24x24x16xf32>
    %5 = stablehlo.maximum %3, %4 : tensor<4x24x24x16xf32>
    %6 = stablehlo.convolution(%5, %arg3) dim_numbers = [b, 0, 1, f]x[0, 1, i, o]->[b, 0, 1, f], window = {stride = [1, 1], pad = [[1, 1], [1, 1]], lhs_dilate = [1, 1], rhs_dilate = [1, 1], reverse = [false, false]} {batch_group_count = 1 : i64, feature_group_count = 1 : i64, precision_config = [#stablehlo<precision DEFAULT>, #stablehlo<precision DEFAULT>]} : (tensor<4x24x24x16xf32>, tensor<3x3x16x16xf32>) -> tensor<4x24x24x16xf32>
    %7 = stablehlo.broadcast_in_dim %arg4, dims = [3] : (tensor<16xf32>) -> tensor<1x1x1x16xf32>
    %8 = stablehlo.broadcast_in_dim %7, dims = [0, 1, 2, 3] : (tensor<1x1x1x16xf32>) -> tensor<4x24x24x16xf32>
    %9 = stablehlo.add %6, %8 : tensor<4x24x24x16xf32>
    %cst_0 = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %10 = stablehlo.broadcast_in_dim %cst_0, dims = [] : (tensor<f32>) -> tensor<4x24x24x16xf32>
    %11 = stablehlo.maximum %9, %10 : tensor<4x24x24x16xf32>
    %12 = stablehlo.convolution(%11, %arg5) dim_numbers = [b, 0, 1, f]x[0, 1, i, o]->[b, 0, 1, f], window = {stride = [1, 1], pad = [[1, 1], [1, 1]], lhs_dilate = [1, 1], rhs_dilate = [1, 1], reverse = [false, false]} {batch_group_count = 1 : i64, feature_group_count = 1 : i64, precision_config = [#stablehlo<precision DEFAULT>, #stablehlo<precision DEFAULT>]} : (tensor<4x24x24x16xf32>, tensor<3x3x16x16xf32>) -> tensor<4x24x24x16xf32>
    %13 = stablehlo.broadcast_in_dim %arg6, dims = [3] : (tensor<16xf32>) -> tensor<1x1x1x16xf32>
    %14 = stablehlo.broadcast_in_dim %13, dims = [0, 1, 2, 3] : (tensor<1x1x1x16xf32>) -> tensor<4x24x24x16xf32>
    %15 = stablehlo.add %12, %14 : tensor<4x24x24x16xf32>
    %cst_1 = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %16 = stablehlo.broadcast_in_dim %cst_1, dims = [] : (tensor<f32>) -> tensor<4x24x24x16xf32>
    %17 = stablehlo.maximum %15, %16 : tensor<4x24x24x16xf32>
    %cst_2 = stablehlo.constant dense<7.500000e-01> : tensor<f32>
    %18 = stablehlo.broadcast_in_dim %cst_2, dims = [] : (tensor<f32>) -> tensor<4x24x24x16xf32>
    %19 = stablehlo.multiply %17, %18 : tensor<4x24x24x16xf32>
    %cst_3 = stablehlo.constant dense<1.250000e-01> : tensor<f32>
    %20 = stablehlo.broadcast_in_dim %cst_3, dims = [] : (tensor<f32>) -> tensor<4x24x24x16xf32>
    %21 = stablehlo.add %19, %20 : tensor<4x24x24x16xf32>
    %cst_4 = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %22 = stablehlo.broadcast_in_dim %cst_4, dims = [] : (tensor<f32>) -> tensor<4x24x24x16xf32>
    %23 = stablehlo.compare  GT, %3, %22,  FLOAT : (tensor<4x24x24x16xf32>, tensor<4x24x24x16xf32>) -> tensor<4x24x24x16xi1>
    %24 = stablehlo.convert %23 : (tensor<4x24x24x16xi1>) -> tensor<4x24x24x16xi32>
    %cst_5 = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %25 = stablehlo.broadcast_in_dim %cst_5, dims = [] : (tensor<f32>) -> tensor<4x24x24x16xf32>
    %26 = stablehlo.compare  GT, %9, %25,  FLOAT : (tensor<4x24x24x16xf32>, tensor<4x24x24x16xf32>) -> tensor<4x24x24x16xi1>
    %27 = stablehlo.convert %26 : (tensor<4x24x24x16xi1>) -> tensor<4x24x24x16xi32>
    %c = stablehlo.constant dense<0> : tensor<i32>
    %28 = stablehlo.reduce(%24 init: %c) applies stablehlo.add across dimensions = [0, 1, 2, 3] : (tensor<4x24x24x16xi32>, tensor<i32>) -> tensor<i32>
    %c_6 = stablehlo.constant dense<0> : tensor<i32>
    %29 = stablehlo.reduce(%27 init: %c_6) applies stablehlo.add across dimensions = [3] : (tensor<4x24x24x16xi32>, tensor<i32>) -> tensor<4x24x24xi32>
    return %21, %28, %29 : tensor<4x24x24x16xf32>, tensor<i32>, tensor<4x24x24xi32>
  }
}
