module @jit_forward attributes {mhlo.num_partitions = 1 : i32, mhlo.num_replicas = 1 : i32} {
  func.func public @main(%arg0: tensor<512x192xf32>, %arg1: tensor<192xf32>, %arg2: tensor<192xf32>, %arg3: tensor<192xf32>, %arg4: tensor<192xf32>, %arg5: tensor<192xf32>, %arg6: tensor<192xf32>) -> (tensor<512x192xf32> {jax.result_info = "result[0]"}, tensor<f32> {jax.result_info = "result[1]"}, tensor<f32> {jax.result_info = "result[2]"}) {
    %0 = chlo.square %arg0 : tensor<512x192xf32> -> tensor<512x192xf32>
    %cst = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %1 = stablehlo.reduce(%0 init: %cst) applies stablehlo.add across dimensions = [1] : (tensor<512x192xf32>, tensor<f32>) -> tensor<512xf32>
    %2 = stablehlo.broadcast_in_dim %1, dims = [0] : (tensor<512xf32>) -> tensor<512x1xf32>
    %cst_0 = stablehlo.constant dense<1.920000e+02> : tensor<f32>
    %3 = stablehlo.broadcast_in_dim %cst_0, dims = [] : (tensor<f32>) -> tensor<512x1xf32>
    %4 = stablehlo.divide %2, %3 : tensor<512x1xf32>
    %cst_1 = stablehlo.constant dense<9.99999974E-5> : tensor<f32>
    %5 = stablehlo.broadcast_in_dim %cst_1, dims = [] : (tensor<f32>) -> tensor<512x1xf32>
    %6 = stablehlo.add %4, %5 : tensor<512x1xf32>
    %7 = stablehlo.rsqrt %6 : tensor<512x1xf32>
    %8 = stablehlo.broadcast_in_dim %7, dims = [0, 1] : (tensor<512x1xf32>) -> tensor<512x192xf32>
    %9 = stablehlo.multiply %arg0, %8 : tensor<512x192xf32>
    %10 = stablehlo.broadcast_in_dim %arg1, dims = [1] : (tensor<192xf32>) -> tensor<1x192xf32>
    %11 = stablehlo.broadcast_in_dim %10, dims = [0, 1] : (tensor<1x192xf32>) -> tensor<512x192xf32>
    %12 = stablehlo.multiply %9, %11 : tensor<512x192xf32>
    %13 = stablehlo.broadcast_in_dim %arg2, dims = [1] : (tensor<192xf32>) -> tensor<1x192xf32>
    %14 = stablehlo.broadcast_in_dim %13, dims = [0, 1] : (tensor<1x192xf32>) -> tensor<512x192xf32>
    %15 = stablehlo.add %12, %14 : tensor<512x192xf32>
    %cst_2 = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %16 = stablehlo.broadcast_in_dim %cst_2, dims = [] : (tensor<f32>) -> tensor<512x192xf32>
    %17 = stablehlo.maximum %15, %16 : tensor<512x192xf32>
    %18 = chlo.square %17 : tensor<512x192xf32> -> tensor<512x192xf32>
    %cst_3 = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %19 = stablehlo.reduce(%18 init: %cst_3) applies stablehlo.add across dimensions = [1] : (tensor<512x192xf32>, tensor<f32>) -> tensor<512xf32>
    %20 = stablehlo.broadcast_in_dim %19, dims = [0] : (tensor<512xf32>) -> tensor<512x1xf32>
    %cst_4 = stablehlo.constant dense<1.920000e+02> : tensor<f32>
    %21 = stablehlo.broadcast_in_dim %cst_4, dims = [] : (tensor<f32>) -> tensor<512x1xf32>
    %22 = stablehlo.divide %20, %21 : tensor<512x1xf32>
    %cst_5 = stablehlo.constant dense<9.99999974E-5> : tensor<f32>
    %23 = stablehlo.broadcast_in_dim %cst_5, dims = [] : (tensor<f32>) -> tensor<512x1xf32>
    %24 = stablehlo.add %22, %23 : tensor<512x1xf32>
    %25 = stablehlo.rsqrt %24 : tensor<512x1xf32>
    %26 = stablehlo.broadcast_in_dim %25, dims = [0, 1] : (tensor<512x1xf32>) -> tensor<512x192xf32>
    %27 = stablehlo.multiply %17, %26 : tensor<512x192xf32>
    %28 = stablehlo.broadcast_in_dim %arg3, dims = [1] : (tensor<192xf32>) -> tensor<1x192xf32>
    %29 = stablehlo.broadcast_in_dim %28, dims = [0, 1] : (tensor<1x192xf32>) -> tensor<512x192xf32>
    %30 = stablehlo.multiply %27, %29 : tensor<512x192xf32>
    %31 = stablehlo.broadcast_in_dim %arg4, dims = [1] : (tensor<192xf32>) -> tensor<1x192xf32>
    %32 = stablehlo.broadcast_in_dim %31, dims = [0, 1] : (tensor<1x192xf32>) -> tensor<512x192xf32>
    %33 = stablehlo.add %30, %32 : tensor<512x192xf32>
    %cst_6 = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %34 = stablehlo.broadcast_in_dim %cst_6, dims = [] : (tensor<f32>) -> tensor<512x192xf32>
    %35 = stablehlo.maximum %33, %34 : tensor<512x192xf32>
    %36 = chlo.square %35 : tensor<512x192xf32> -> tensor<512x192xf32>
    %cst_7 = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %37 = stablehlo.reduce(%36 init: %cst_7) applies stablehlo.add across dimensions = [1] : (tensor<512x192xf32>, tensor<f32>) -> tensor<512xf32>
    %38 = stablehlo.broadcast_in_dim %37, dims = [0] : (tensor<512xf32>) -> tensor<512x1xf32>
    %cst_8 = stablehlo.constant dense<1.920000e+02> : tensor<f32>
    %39 = stablehlo.broadcast_in_dim %cst_8, dims = [] : (tensor<f32>) -> tensor<512x1xf32>
    %40 = stablehlo.divide %38, %39 : tensor<512x1xf32>
    %cst_9 = stablehlo.constant dense<9.99999974E-5> : tensor<f32>
    %41 = stablehlo.broadcast_in_dim %cst_9, dims = [] : (tensor<f32>) -> tensor<512x1xf32>
    %42 = stablehlo.add %40, %41 : tensor<512x1xf32>
    %43 = stablehlo.rsqrt %42 : tensor<512x1xf32>
    %44 = stablehlo.broadcast_in_dim %43, dims = [0, 1] : (tensor<512x1xf32>) -> tensor<512x192xf32>
    %45 = stablehlo.multiply %35, %44 : tensor<512x192xf32>
    %46 = stablehlo.broadcast_in_dim %arg5, dims = [1] : (tensor<192xf32>) -> tensor<1x192xf32>
    %47 = stablehlo.broadcast_in_dim %46, dims = [0, 1] : (tensor<1x192xf32>) -> tensor<512x192xf32>
    %48 = stablehlo.multiply %45, %47 : tensor<512x192xf32>
    %49 = stablehlo.broadcast_in_dim %arg6, dims = [1] : (tensor<192xf32>) -> tensor<1x192xf32>
    %50 = stablehlo.broadcast_in_dim %49, dims = [0, 1] : (tensor<1x192xf32>) -> tensor<512x192xf32>
    %51 = stablehlo.add %48, %50 : tensor<512x192xf32>
    %cst_10 = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %52 = stablehlo.broadcast_in_dim %cst_10, dims = [] : (tensor<f32>) -> tensor<512x192xf32>
    %53 = stablehlo.maximum %51, %52 : tensor<512x192xf32>
    %cst_11 = stablehlo.constant dense<7.500000e-01> : tensor<f32>
    %54 = stablehlo.broadcast_in_dim %cst_11, dims = [] : (tensor<f32>) -> tensor<512x192xf32>
    %55 = stablehlo.multiply %53, %54 : tensor<512x192xf32>
    %cst_12 = stablehlo.constant dense<1.250000e-01> : tensor<f32>
    %56 = stablehlo.broadcast_in_dim %cst_12, dims = [] : (tensor<f32>) -> tensor<512x192xf32>
    %57 = stablehlo.add %55, %56 : tensor<512x192xf32>
    %58 = stablehlo.multiply %15, %15 : tensor<512x192xf32>
    %cst_13 = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %cst_14 = stablehlo.constant dense<0xFF800000> : tensor<f32>
    %59:2 = stablehlo.reduce(%58 init: %cst_13), (%15 init: %cst_14) across dimensions = [0, 1] : (tensor<512x192xf32>, tensor<512x192xf32>, tensor<f32>, tensor<f32>) -> (tensor<f32>, tensor<f32>)
     reducer(%arg7: tensor<f32>, %arg9: tensor<f32>) (%arg8: tensor<f32>, %arg10: tensor<f32>)  {
      %60 = stablehlo.add %arg7, %arg9 : tensor<f32>
      %61 = stablehlo.maximum %arg8, %arg10 : tensor<f32>
      stablehlo.return %60, %61 : tensor<f32>, tensor<f32>
    }
    return %57, %59#0, %59#1 : tensor<512x192xf32>, tensor<f32>, tensor<f32>
  }
}
