module @jit_forward attributes {mhlo.num_partitions = 1 : i32, mhlo.num_replicas = 1 : i32} {
  func.func public @main(%arg0: tensor<256x144xf32>, %arg1: tensor<144x144xf32>, %arg2: tensor<144xf32>, %arg3: tensor<144x144xf32>, %arg4: tensor<144xf32>, %arg5: tensor<144x144xf32>, %arg6: tensor<144xf32>) -> (tensor<256x144xf32> {jax.result_info = "result[0]"}, tensor<f32> {jax.result_info = "result[1]"}, tensor<f32> {jax.result_info = "result[2]"}) {
    %0 = stablehlo.dot_general %arg0, %arg1, contracting_dims = [1] x [0], precision = [DEFAULT, DEFAULT] : (tensor<256x144xf32>, tensor<144x144xf32>) -> tensor<256x144xf32>
    %1 = stablehlo.broadcast_in_dim %arg2, dims = [1] : (tensor<144xf32>) -> tensor<1x144xf32>
    %2 = stablehlo.broadcast_in_dim %1, dims = [0, 1] : (tensor<1x144xf32>) -> tensor<256x144xf32>
    %3 = stablehlo.add %0, %2 : tensor<256x144xf32>
    %cst = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %4 = stablehlo.broadcast_in_dim %cst, dims = [] : (tensor<f32>) -> tensor<256x144xf32>
    %5 = stablehlo.maximum %3, %4 : tensor<256x144xf32>
    %6 = stablehlo.dot_general %5, %arg3, contracting_dims = [1] x [0], precision = [DEFAULT, DEFAULT] : (tensor<256x144xf32>, tensor<144x144xf32>) -> tensor<256x144xf32>
    %7 = stablehlo.broadcast_in_dim %arg4, dims = [1] : (tensor<144xf32>) -> tensor<1x144xf32>
    %8 = stablehlo.broadcast_in_dim %7, dims = [0, 1] : (tensor<1x144xf32>) -> tensor<256x144xf32>
    %9 = stablehlo.add %6, %8 : tensor<256x144xf32>
    %cst_0 = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %10 = stablehlo.broadcast_in_dim %cst_0, dims = [] : (tensor<f32>) -> tensor<256x144xf32>
    %11 = stablehlo.maximum %9, %10 : tensor<256x144xf32>
    %12 = stablehlo.dot_general %11, %arg5, contracting_dims = [1] x [0], precision = [DEFAULT, DEFAULT] : (tensor<256x144xf32>, tensor<144x144xf32>) -> tensor<256x144xf32>
    %13 = stablehlo.broadcast_in_dim %arg6, dims = [1] : (tensor<144xf32>) -> tensor<1x144xf32>
    %14 = stablehlo.broadcast_in_dim %13, dims = [0, 1] : (tensor<1x144xf32>) -> tensor<256x144xf32>
    %15 = stablehlo.add %12, %14 : tensor<256x144xf32>
    %cst_1 = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %16 = stablehlo.broadcast_in_dim %cst_1, dims = [] : (tensor<f32>) -> tensor<256x144xf32>
    %17 = stablehlo.maximum %15, %16 : tensor<256x144xf32>
    %cst_2 = stablehlo.constant dense<7.500000e-01> : tensor<f32>
    %18 = stablehlo.broadcast_in_dim %cst_2, dims = [] : (tensor<f32>) -> tensor<256x144xf32>
    %19 = stablehlo.multiply %17, %18 : tensor<256x144xf32>
    %cst_3 = stablehlo.constant dense<1.250000e-01> : tensor<f32>
    %20 = stablehlo.broadcast_in_dim %cst_3, dims = [] : (tensor<f32>) -> tensor<256x144xf32>
    %21 = stablehlo.add %19, %20 : tensor<256x144xf32>
    %cst_4 = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %22 = stablehlo.broadcast_in_dim %cst_4, dims = [] : (tensor<f32>) -> tensor<256x144xf32>
    %23 = stablehlo.maximum %3, %22 : tensor<256x144xf32>
    %cst_5 = stablehlo.constant dense<2.500000e-01> : tensor<f32>
    %24 = stablehlo.broadcast_in_dim %cst_5, dims = [] : (tensor<f32>) -> tensor<256x144xf32>
    %25 = stablehlo.multiply %24, %23 : tensor<256x144xf32>
    %26 = stablehlo.add %21, %25 : tensor<256x144xf32>
    %27 = stablehlo.multiply %3, %3 : tensor<256x144xf32>
    %28 = stablehlo.multiply %9, %9 : tensor<256x144xf32>
    %cst_6 = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %cst_7 = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %29:2 = stablehlo.reduce(%27 init: %cst_6), (%28 init: %cst_7) across dimensions = [0, 1] : (tensor<256x144xf32>, tensor<256x144xf32>, tensor<f32>, tensor<f32>) -> (tensor<f32>, tensor<f32>)
     reducer(%arg7: tensor<f32>, %arg9: tensor<f32>) (%arg8: tensor<f32>, %arg10: tensor<f32>)  {
      %30 = stablehlo.add %arg7, %arg9 : tensor<f32>
      %31 = stablehlo.add %arg8, %arg10 : tensor<f32>
      stablehlo.return %30, %31 : tensor<f32>, tensor<f32>
    }
    return %26, %29#0, %29#1 : tensor<256x144xf32>, tensor<f32>, tensor<f32>
  }
}
