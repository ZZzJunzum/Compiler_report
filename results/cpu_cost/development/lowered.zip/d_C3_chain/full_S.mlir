module @jit_forward attributes {mhlo.num_partitions = 1 : i32, mhlo.num_replicas = 1 : i32} {
  func.func public @main(%arg0: tensor<8x28x28x24xf32>, %arg1: tensor<3x3x24x24xf32>, %arg2: tensor<24xf32>, %arg3: tensor<3x3x24x24xf32>, %arg4: tensor<24xf32>, %arg5: tensor<3x3x24x24xf32>, %arg6: tensor<24xf32>) -> (tensor<8x28x28x24xf32> {jax.result_info = "result[0]"}, tensor<8x28x28x24xf32> {jax.result_info = "result[1]"}) {
    %0 = stablehlo.convolution(%arg0, %arg1) dim_numbers = [b, 0, 1, f]x[0, 1, i, o]->[b, 0, 1, f], window = {stride = [1, 1], pad = [[1, 1], [1, 1]], lhs_dilate = [1, 1], rhs_dilate = [1, 1], reverse = [false, false]} {batch_group_count = 1 : i64, feature_group_count = 1 : i64, precision_config = [#stablehlo<precision DEFAULT>, #stablehlo<precision DEFAULT>]} : (tensor<8x28x28x24xf32>, tensor<3x3x24x24xf32>) -> tensor<8x28x28x24xf32>
    %1 = stablehlo.broadcast_in_dim %arg2, dims = [3] : (tensor<24xf32>) -> tensor<1x1x1x24xf32>
    %2 = stablehlo.broadcast_in_dim %1, dims = [0, 1, 2, 3] : (tensor<1x1x1x24xf32>) -> tensor<8x28x28x24xf32>
    %3 = stablehlo.add %0, %2 : tensor<8x28x28x24xf32>
    %cst = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %4 = stablehlo.broadcast_in_dim %cst, dims = [] : (tensor<f32>) -> tensor<8x28x28x24xf32>
    %5 = stablehlo.maximum %3, %4 : tensor<8x28x28x24xf32>
    %6 = stablehlo.convolution(%5, %arg3) dim_numbers = [b, 0, 1, f]x[0, 1, i, o]->[b, 0, 1, f], window = {stride = [1, 1], pad = [[1, 1], [1, 1]], lhs_dilate = [1, 1], rhs_dilate = [1, 1], reverse = [false, false]} {batch_group_count = 1 : i64, feature_group_count = 1 : i64, precision_config = [#stablehlo<precision DEFAULT>, #stablehlo<precision DEFAULT>]} : (tensor<8x28x28x24xf32>, tensor<3x3x24x24xf32>) -> tensor<8x28x28x24xf32>
    %7 = stablehlo.broadcast_in_dim %arg4, dims = [3] : (tensor<24xf32>) -> tensor<1x1x1x24xf32>
    %8 = stablehlo.broadcast_in_dim %7, dims = [0, 1, 2, 3] : (tensor<1x1x1x24xf32>) -> tensor<8x28x28x24xf32>
    %9 = stablehlo.add %6, %8 : tensor<8x28x28x24xf32>
    %cst_0 = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %10 = stablehlo.broadcast_in_dim %cst_0, dims = [] : (tensor<f32>) -> tensor<8x28x28x24xf32>
    %11 = stablehlo.maximum %9, %10 : tensor<8x28x28x24xf32>
    %12 = stablehlo.convolution(%11, %arg5) dim_numbers = [b, 0, 1, f]x[0, 1, i, o]->[b, 0, 1, f], window = {stride = [1, 1], pad = [[1, 1], [1, 1]], lhs_dilate = [1, 1], rhs_dilate = [1, 1], reverse = [false, false]} {batch_group_count = 1 : i64, feature_group_count = 1 : i64, precision_config = [#stablehlo<precision DEFAULT>, #stablehlo<precision DEFAULT>]} : (tensor<8x28x28x24xf32>, tensor<3x3x24x24xf32>) -> tensor<8x28x28x24xf32>
    %13 = stablehlo.broadcast_in_dim %arg6, dims = [3] : (tensor<24xf32>) -> tensor<1x1x1x24xf32>
    %14 = stablehlo.broadcast_in_dim %13, dims = [0, 1, 2, 3] : (tensor<1x1x1x24xf32>) -> tensor<8x28x28x24xf32>
    %15 = stablehlo.add %12, %14 : tensor<8x28x28x24xf32>
    %cst_1 = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %16 = stablehlo.broadcast_in_dim %cst_1, dims = [] : (tensor<f32>) -> tensor<8x28x28x24xf32>
    %17 = stablehlo.maximum %15, %16 : tensor<8x28x28x24xf32>
    %cst_2 = stablehlo.constant dense<7.500000e-01> : tensor<f32>
    %18 = stablehlo.broadcast_in_dim %cst_2, dims = [] : (tensor<f32>) -> tensor<8x28x28x24xf32>
    %19 = stablehlo.multiply %17, %18 : tensor<8x28x28x24xf32>
    %cst_3 = stablehlo.constant dense<1.250000e-01> : tensor<f32>
    %20 = stablehlo.broadcast_in_dim %cst_3, dims = [] : (tensor<f32>) -> tensor<8x28x28x24xf32>
    %21 = stablehlo.add %19, %20 : tensor<8x28x28x24xf32>
    return %21, %3 : tensor<8x28x28x24xf32>, tensor<8x28x28x24xf32>
  }
}
