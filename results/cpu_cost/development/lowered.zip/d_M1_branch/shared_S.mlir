module @jit_forward attributes {mhlo.num_partitions = 1 : i32, mhlo.num_replicas = 1 : i32} {
  func.func public @main(%arg0: tensor<64x96xf32>, %arg1: tensor<96x96xf32>, %arg2: tensor<96xf32>, %arg3: tensor<96x96xf32>, %arg4: tensor<96xf32>, %arg5: tensor<96x96xf32>, %arg6: tensor<96xf32>) -> (tensor<64x96xf32> {jax.result_info = "result[0]"}, tensor<f32> {jax.result_info = "result[1]"}, tensor<f32> {jax.result_info = "result[2]"}) {
    %0 = stablehlo.dot_general %arg0, %arg1, contracting_dims = [1] x [0], precision = [DEFAULT, DEFAULT] : (tensor<64x96xf32>, tensor<96x96xf32>) -> tensor<64x96xf32>
    %1 = stablehlo.broadcast_in_dim %arg2, dims = [1] : (tensor<96xf32>) -> tensor<1x96xf32>
    %2 = stablehlo.broadcast_in_dim %1, dims = [0, 1] : (tensor<1x96xf32>) -> tensor<64x96xf32>
    %3 = stablehlo.add %0, %2 : tensor<64x96xf32>
    %cst = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %4 = stablehlo.broadcast_in_dim %cst, dims = [] : (tensor<f32>) -> tensor<64x96xf32>
    %5 = stablehlo.maximum %3, %4 : tensor<64x96xf32>
    %6 = stablehlo.dot_general %5, %arg3, contracting_dims = [1] x [0], precision = [DEFAULT, DEFAULT] : (tensor<64x96xf32>, tensor<96x96xf32>) -> tensor<64x96xf32>
    %7 = stablehlo.broadcast_in_dim %arg4, dims = [1] : (tensor<96xf32>) -> tensor<1x96xf32>
    %8 = stablehlo.broadcast_in_dim %7, dims = [0, 1] : (tensor<1x96xf32>) -> tensor<64x96xf32>
    %9 = stablehlo.add %6, %8 : tensor<64x96xf32>
    %cst_0 = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %10 = stablehlo.broadcast_in_dim %cst_0, dims = [] : (tensor<f32>) -> tensor<64x96xf32>
    %11 = stablehlo.maximum %9, %10 : tensor<64x96xf32>
    %12 = stablehlo.dot_general %11, %arg5, contracting_dims = [1] x [0], precision = [DEFAULT, DEFAULT] : (tensor<64x96xf32>, tensor<96x96xf32>) -> tensor<64x96xf32>
    %13 = stablehlo.broadcast_in_dim %arg6, dims = [1] : (tensor<96xf32>) -> tensor<1x96xf32>
    %14 = stablehlo.broadcast_in_dim %13, dims = [0, 1] : (tensor<1x96xf32>) -> tensor<64x96xf32>
    %15 = stablehlo.add %12, %14 : tensor<64x96xf32>
    %cst_1 = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %16 = stablehlo.broadcast_in_dim %cst_1, dims = [] : (tensor<f32>) -> tensor<64x96xf32>
    %17 = stablehlo.maximum %15, %16 : tensor<64x96xf32>
    %cst_2 = stablehlo.constant dense<7.500000e-01> : tensor<f32>
    %18 = stablehlo.broadcast_in_dim %cst_2, dims = [] : (tensor<f32>) -> tensor<64x96xf32>
    %19 = stablehlo.multiply %17, %18 : tensor<64x96xf32>
    %cst_3 = stablehlo.constant dense<1.250000e-01> : tensor<f32>
    %20 = stablehlo.broadcast_in_dim %cst_3, dims = [] : (tensor<f32>) -> tensor<64x96xf32>
    %21 = stablehlo.add %19, %20 : tensor<64x96xf32>
    %cst_4 = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %22 = stablehlo.broadcast_in_dim %cst_4, dims = [] : (tensor<f32>) -> tensor<64x96xf32>
    %23 = stablehlo.maximum %3, %22 : tensor<64x96xf32>
    %cst_5 = stablehlo.constant dense<2.500000e-01> : tensor<f32>
    %24 = stablehlo.broadcast_in_dim %cst_5, dims = [] : (tensor<f32>) -> tensor<64x96xf32>
    %25 = stablehlo.multiply %24, %23 : tensor<64x96xf32>
    %26 = stablehlo.add %21, %25 : tensor<64x96xf32>
    %27 = stablehlo.multiply %3, %3 : tensor<64x96xf32>
    %cst_6 = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %28 = stablehlo.reduce(%27 init: %cst_6) applies stablehlo.add across dimensions = [0, 1] : (tensor<64x96xf32>, tensor<f32>) -> tensor<f32>
    %cst_7 = stablehlo.constant dense<0xFF800000> : tensor<f32>
    %29 = stablehlo.reduce(%3 init: %cst_7) applies stablehlo.maximum across dimensions = [0, 1] : (tensor<64x96xf32>, tensor<f32>) -> tensor<f32>
    return %26, %28, %29 : tensor<64x96xf32>, tensor<f32>, tensor<f32>
  }
}
