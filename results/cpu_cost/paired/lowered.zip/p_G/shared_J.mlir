module @jit_forward attributes {mhlo.num_partitions = 1 : i32, mhlo.num_replicas = 1 : i32} {
  func.func public @main(%arg0: tensor<112x104xf32>, %arg1: tensor<104x208xf32>, %arg2: tensor<208xf32>, %arg3: tensor<104x208xf32>, %arg4: tensor<208xf32>, %arg5: tensor<208x104xf32>, %arg6: tensor<104xf32>) -> (tensor<112x104xf32> {jax.result_info = "result[0]"}, tensor<f32> {jax.result_info = "result[1]"}, tensor<f32> {jax.result_info = "result[2]"}) {
    %0 = stablehlo.dot_general %arg0, %arg1, contracting_dims = [1] x [0], precision = [DEFAULT, DEFAULT] : (tensor<112x104xf32>, tensor<104x208xf32>) -> tensor<112x208xf32>
    %1 = stablehlo.broadcast_in_dim %arg2, dims = [1] : (tensor<208xf32>) -> tensor<1x208xf32>
    %2 = stablehlo.broadcast_in_dim %1, dims = [0, 1] : (tensor<1x208xf32>) -> tensor<112x208xf32>
    %3 = stablehlo.add %0, %2 : tensor<112x208xf32>
    %4 = call @silu(%3) : (tensor<112x208xf32>) -> tensor<112x208xf32>
    %5 = stablehlo.dot_general %arg0, %arg3, contracting_dims = [1] x [0], precision = [DEFAULT, DEFAULT] : (tensor<112x104xf32>, tensor<104x208xf32>) -> tensor<112x208xf32>
    %6 = stablehlo.broadcast_in_dim %arg4, dims = [1] : (tensor<208xf32>) -> tensor<1x208xf32>
    %7 = stablehlo.broadcast_in_dim %6, dims = [0, 1] : (tensor<1x208xf32>) -> tensor<112x208xf32>
    %8 = stablehlo.add %5, %7 : tensor<112x208xf32>
    %9 = stablehlo.multiply %4, %8 : tensor<112x208xf32>
    %10 = stablehlo.dot_general %9, %arg5, contracting_dims = [1] x [0], precision = [DEFAULT, DEFAULT] : (tensor<112x208xf32>, tensor<208x104xf32>) -> tensor<112x104xf32>
    %11 = stablehlo.broadcast_in_dim %arg6, dims = [1] : (tensor<104xf32>) -> tensor<1x104xf32>
    %12 = stablehlo.broadcast_in_dim %11, dims = [0, 1] : (tensor<1x104xf32>) -> tensor<112x104xf32>
    %13 = stablehlo.add %10, %12 : tensor<112x104xf32>
    %14 = stablehlo.add %arg0, %13 : tensor<112x104xf32>
    %15 = stablehlo.multiply %3, %3 : tensor<112x208xf32>
    %cst = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %cst_0 = stablehlo.constant dense<0xFF800000> : tensor<f32>
    %16:2 = stablehlo.reduce(%15 init: %cst), (%3 init: %cst_0) across dimensions = [0, 1] : (tensor<112x208xf32>, tensor<112x208xf32>, tensor<f32>, tensor<f32>) -> (tensor<f32>, tensor<f32>)
     reducer(%arg7: tensor<f32>, %arg9: tensor<f32>) (%arg8: tensor<f32>, %arg10: tensor<f32>)  {
      %17 = stablehlo.add %arg7, %arg9 : tensor<f32>
      %18 = stablehlo.maximum %arg8, %arg10 : tensor<f32>
      stablehlo.return %17, %18 : tensor<f32>, tensor<f32>
    }
    return %14, %16#0, %16#1 : tensor<112x104xf32>, tensor<f32>, tensor<f32>
  }
  func.func private @silu(%arg0: tensor<112x208xf32>) -> tensor<112x208xf32> {
    %0 = stablehlo.negate %arg0 : tensor<112x208xf32>
    %1 = stablehlo.exponential %0 : tensor<112x208xf32>
    %cst = stablehlo.constant dense<1.000000e+00> : tensor<f32>
    %2 = stablehlo.broadcast_in_dim %cst, dims = [] : (tensor<f32>) -> tensor<112x208xf32>
    %3 = stablehlo.add %2, %1 : tensor<112x208xf32>
    %cst_0 = stablehlo.constant dense<1.000000e+00> : tensor<f32>
    %4 = stablehlo.broadcast_in_dim %cst_0, dims = [] : (tensor<f32>) -> tensor<112x208xf32>
    %5 = stablehlo.divide %4, %3 : tensor<112x208xf32>
    %6 = stablehlo.multiply %arg0, %5 : tensor<112x208xf32>
    return %6 : tensor<112x208xf32>
  }
}
