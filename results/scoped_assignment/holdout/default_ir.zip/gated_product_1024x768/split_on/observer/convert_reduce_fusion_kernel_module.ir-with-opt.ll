; ModuleID = '__compute_module_convert_reduce_fusion_kernel_module'
source_filename = "__compute_module_convert_reduce_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @convert_reduce_fusion(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !5
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !4
  %9 = getelementptr inbounds nuw i8, ptr %3, i64 48
  %10 = load ptr, ptr %9, align 8, !invariant.load !3, !dereferenceable !4
  %11 = getelementptr inbounds nuw i8, ptr %3, i64 64
  %12 = load ptr, ptr %11, align 8, !invariant.load !3, !dereferenceable !4
  %13 = getelementptr inbounds nuw i8, ptr %3, i64 80
  %14 = load ptr, ptr %13, align 8, !invariant.load !3, !dereferenceable !6
  %15 = getelementptr inbounds nuw i8, ptr %3, i64 96
  %16 = load ptr, ptr %15, align 8, !invariant.load !3, !dereferenceable !6
  %17 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %18 = load ptr, ptr %17, align 8
  %19 = load i64, ptr %18, align 4, !invariant.load !3
  tail call void @llvm.experimental.noalias.scope.decl(metadata !7)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !10)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !12)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !14)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !16)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !18)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !20)
  %20 = icmp slt i64 %19, 11
  br i1 %20, label %21, label %103

21:                                               ; preds = %1
  %22 = icmp sgt i64 %19, -1
  br i1 %22, label %23, label %convert_reduce_fusion_wrapped.exit

23:                                               ; preds = %21
  %24 = mul nuw nsw i64 %19, 86
  %.idx1 = mul nuw nsw i64 %19, 264192
  %25 = getelementptr i8, ptr %6, i64 %.idx1
  br label %vector.ph41

vector.ph41:                                      ; preds = %23, %middle.block59
  %26 = phi i64 [ 0, %23 ], [ %102, %middle.block59 ]
  %.idx2 = mul nuw nsw i64 %26, 3072
  %27 = getelementptr i8, ptr %25, i64 %.idx2
  br label %vector.body42

vector.body42:                                    ; preds = %vector.body42, %vector.ph41
  %index43 = phi i64 [ 0, %vector.ph41 ], [ %index.next58, %vector.body42 ]
  %vec.phi44 = phi <8 x i32> [ zeroinitializer, %vector.ph41 ], [ %94, %vector.body42 ]
  %vec.phi45 = phi <8 x i32> [ zeroinitializer, %vector.ph41 ], [ %95, %vector.body42 ]
  %vec.phi46 = phi <8 x i32> [ zeroinitializer, %vector.ph41 ], [ %92, %vector.body42 ]
  %vec.phi47 = phi <8 x i32> [ zeroinitializer, %vector.ph41 ], [ %93, %vector.body42 ]
  %28 = getelementptr float, ptr %27, i64 %index43
  %29 = getelementptr i8, ptr %28, i64 32
  %wide.load48 = load <8 x float>, ptr %28, align 4, !invariant.load !3, !alias.scope !10, !noalias !22
  %wide.load49 = load <8 x float>, ptr %29, align 4, !invariant.load !3, !alias.scope !10, !noalias !22
  %30 = getelementptr inbounds nuw float, ptr %12, i64 %index43
  %31 = getelementptr inbounds nuw i8, ptr %30, i64 32
  %wide.load50 = load <8 x float>, ptr %30, align 4, !invariant.load !3, !alias.scope !16, !noalias !23
  %wide.load51 = load <8 x float>, ptr %31, align 4, !invariant.load !3, !alias.scope !16, !noalias !23
  %32 = fmul <8 x float> %wide.load48, %wide.load50
  %33 = fmul <8 x float> %wide.load49, %wide.load51
  %34 = getelementptr inbounds nuw float, ptr %10, i64 %index43
  %35 = getelementptr inbounds nuw i8, ptr %34, i64 32
  %wide.load52 = load <8 x float>, ptr %34, align 4, !invariant.load !3, !alias.scope !14, !noalias !24
  %wide.load53 = load <8 x float>, ptr %35, align 4, !invariant.load !3, !alias.scope !14, !noalias !24
  %36 = fadd <8 x float> %32, %wide.load52
  %37 = fadd <8 x float> %33, %wide.load53
  %38 = fcmp ogt <8 x float> %36, zeroinitializer
  %39 = fcmp ogt <8 x float> %37, zeroinitializer
  %40 = zext <8 x i1> %38 to <8 x i32>
  %41 = zext <8 x i1> %39 to <8 x i32>
  %42 = fneg <8 x float> %36
  %43 = fneg <8 x float> %37
  %44 = fcmp uge <8 x float> %42, splat (float 0xC055F33340000000)
  %45 = select <8 x i1> %44, <8 x float> %42, <8 x float> splat (float 0xC055F33340000000)
  %46 = fcmp ule <8 x float> %45, splat (float 0x4056333340000000)
  %47 = select <8 x i1> %46, <8 x float> %45, <8 x float> splat (float 0x4056333340000000)
  %exp_f32.i77 = fmul <8 x float> %47, splat (float 0x3FF7154760000000)
  %exp_f321.i78 = fadd <8 x float> splat (float 5.000000e-01), %exp_f32.i77
  %48 = call <8 x float> @llvm.floor.v8f32(<8 x float> %exp_f321.i78)
  %49 = fcmp uge <8 x float> %48, splat (float -1.270000e+02)
  %50 = select <8 x i1> %49, <8 x float> %48, <8 x float> splat (float -1.270000e+02)
  %51 = fcmp ule <8 x float> %50, splat (float 1.270000e+02)
  %52 = select <8 x i1> %51, <8 x float> %50, <8 x float> splat (float 1.270000e+02)
  %exp_f322.i79 = fmul <8 x float> splat (float 0x3FE6300000000000), %52
  %53 = fsub <8 x float> %47, %exp_f322.i79
  %exp_f323.i80 = fmul <8 x float> splat (float 0xBF2BD01060000000), %52
  %54 = fsub <8 x float> %53, %exp_f323.i80
  %exp_f324.i81 = fmul <8 x float> %54, splat (float 0x3F2A0D2CE0000000)
  %exp_f325.i82 = fadd <8 x float> splat (float 0x3F56E879C0000000), %exp_f324.i81
  %exp_f326.i83 = fmul <8 x float> %exp_f325.i82, %54
  %exp_f327.i84 = fadd <8 x float> splat (float 0x3F81112100000000), %exp_f326.i83
  %exp_f328.i85 = fmul <8 x float> %exp_f327.i84, %54
  %exp_f329.i86 = fadd <8 x float> splat (float 0x3FA5553820000000), %exp_f328.i85
  %exp_f3210.i87 = fmul <8 x float> %exp_f329.i86, %54
  %exp_f3211.i88 = fadd <8 x float> splat (float 0x3FC5555540000000), %exp_f3210.i87
  %exp_f3212.i89 = fmul <8 x float> %exp_f3211.i88, %54
  %exp_f3213.i90 = fadd <8 x float> splat (float 5.000000e-01), %exp_f3212.i89
  %exp_f3214.i91 = fmul <8 x float> %54, %54
  %exp_f3215.i92 = fmul <8 x float> %exp_f3213.i90, %exp_f3214.i91
  %exp_f3216.i93 = fadd <8 x float> %54, %exp_f3215.i92
  %exp_f3217.i94 = fadd <8 x float> splat (float 1.000000e+00), %exp_f3216.i93
  %55 = fptosi <8 x float> %52 to <8 x i32>
  %56 = add <8 x i32> %55, splat (i32 127)
  %57 = shl <8 x i32> %56, splat (i32 23)
  %58 = bitcast <8 x i32> %57 to <8 x float>
  %exp_f3218.i95 = fmul <8 x float> %exp_f3217.i94, %58
  %59 = fcmp uge <8 x float> %43, splat (float 0xC055F33340000000)
  %60 = select <8 x i1> %59, <8 x float> %43, <8 x float> splat (float 0xC055F33340000000)
  %61 = fcmp ule <8 x float> %60, splat (float 0x4056333340000000)
  %62 = select <8 x i1> %61, <8 x float> %60, <8 x float> splat (float 0x4056333340000000)
  %exp_f32.i = fmul <8 x float> %62, splat (float 0x3FF7154760000000)
  %exp_f321.i = fadd <8 x float> splat (float 5.000000e-01), %exp_f32.i
  %63 = call <8 x float> @llvm.floor.v8f32(<8 x float> %exp_f321.i)
  %64 = fcmp uge <8 x float> %63, splat (float -1.270000e+02)
  %65 = select <8 x i1> %64, <8 x float> %63, <8 x float> splat (float -1.270000e+02)
  %66 = fcmp ule <8 x float> %65, splat (float 1.270000e+02)
  %67 = select <8 x i1> %66, <8 x float> %65, <8 x float> splat (float 1.270000e+02)
  %exp_f322.i = fmul <8 x float> splat (float 0x3FE6300000000000), %67
  %68 = fsub <8 x float> %62, %exp_f322.i
  %exp_f323.i = fmul <8 x float> splat (float 0xBF2BD01060000000), %67
  %69 = fsub <8 x float> %68, %exp_f323.i
  %exp_f324.i = fmul <8 x float> %69, splat (float 0x3F2A0D2CE0000000)
  %exp_f325.i = fadd <8 x float> splat (float 0x3F56E879C0000000), %exp_f324.i
  %exp_f326.i = fmul <8 x float> %exp_f325.i, %69
  %exp_f327.i = fadd <8 x float> splat (float 0x3F81112100000000), %exp_f326.i
  %exp_f328.i = fmul <8 x float> %exp_f327.i, %69
  %exp_f329.i = fadd <8 x float> splat (float 0x3FA5553820000000), %exp_f328.i
  %exp_f3210.i = fmul <8 x float> %exp_f329.i, %69
  %exp_f3211.i = fadd <8 x float> splat (float 0x3FC5555540000000), %exp_f3210.i
  %exp_f3212.i = fmul <8 x float> %exp_f3211.i, %69
  %exp_f3213.i = fadd <8 x float> splat (float 5.000000e-01), %exp_f3212.i
  %exp_f3214.i = fmul <8 x float> %69, %69
  %exp_f3215.i = fmul <8 x float> %exp_f3213.i, %exp_f3214.i
  %exp_f3216.i = fadd <8 x float> %69, %exp_f3215.i
  %exp_f3217.i = fadd <8 x float> splat (float 1.000000e+00), %exp_f3216.i
  %70 = fptosi <8 x float> %67 to <8 x i32>
  %71 = add <8 x i32> %70, splat (i32 127)
  %72 = shl <8 x i32> %71, splat (i32 23)
  %73 = bitcast <8 x i32> %72 to <8 x float>
  %exp_f3218.i = fmul <8 x float> %exp_f3217.i, %73
  %74 = getelementptr inbounds nuw float, ptr %8, i64 %index43
  %75 = getelementptr inbounds nuw i8, ptr %74, i64 32
  %wide.load54 = load <8 x float>, ptr %74, align 4, !invariant.load !3, !alias.scope !12, !noalias !25
  %wide.load55 = load <8 x float>, ptr %75, align 4, !invariant.load !3, !alias.scope !12, !noalias !25
  %76 = fadd <8 x float> %exp_f3218.i95, splat (float 1.000000e+00)
  %77 = fadd <8 x float> %exp_f3218.i, splat (float 1.000000e+00)
  %78 = fmul <8 x float> %wide.load48, %wide.load54
  %79 = fmul <8 x float> %wide.load49, %wide.load55
  %80 = getelementptr inbounds nuw float, ptr %4, i64 %index43
  %81 = getelementptr inbounds nuw i8, ptr %80, i64 32
  %wide.load56 = load <8 x float>, ptr %80, align 4, !invariant.load !3, !alias.scope !7, !noalias !26
  %wide.load57 = load <8 x float>, ptr %81, align 4, !invariant.load !3, !alias.scope !7, !noalias !26
  %82 = fdiv <8 x float> splat (float 1.000000e+00), %76
  %83 = fdiv <8 x float> splat (float 1.000000e+00), %77
  %84 = fadd <8 x float> %78, %wide.load56
  %85 = fadd <8 x float> %79, %wide.load57
  %86 = fmul <8 x float> %84, %82
  %87 = fmul <8 x float> %85, %83
  %88 = fcmp ogt <8 x float> %86, zeroinitializer
  %89 = fcmp ogt <8 x float> %87, zeroinitializer
  %90 = zext <8 x i1> %88 to <8 x i32>
  %91 = zext <8 x i1> %89 to <8 x i32>
  %92 = add <8 x i32> %vec.phi46, %40
  %93 = add <8 x i32> %vec.phi47, %41
  %94 = add <8 x i32> %vec.phi44, %90
  %95 = add <8 x i32> %vec.phi45, %91
  %index.next58 = add nuw i64 %index43, 16
  %96 = icmp eq i64 %index.next58, 768
  br i1 %96, label %middle.block59, label %vector.body42, !llvm.loop !27

middle.block59:                                   ; preds = %vector.body42
  %bin.rdx61 = add <8 x i32> %93, %92
  %97 = tail call i32 @llvm.vector.reduce.add.v8i32(<8 x i32> %bin.rdx61)
  %bin.rdx60 = add <8 x i32> %95, %94
  %98 = tail call i32 @llvm.vector.reduce.add.v8i32(<8 x i32> %bin.rdx60)
  %99 = add nuw nsw i64 %26, %24
  %100 = getelementptr inbounds nuw i32, ptr %14, i64 %99
  store i32 %97, ptr %100, align 4, !alias.scope !18, !noalias !30
  %101 = getelementptr inbounds nuw i32, ptr %16, i64 %99
  store i32 %98, ptr %101, align 4, !alias.scope !20, !noalias !31
  %102 = add nuw nsw i64 %26, 1
  %exitcond17.not = icmp eq i64 %102, 86
  br i1 %exitcond17.not, label %convert_reduce_fusion_wrapped.exit, label %vector.ph41, !llvm.loop !32

103:                                              ; preds = %1
  %104 = icmp eq i64 %19, 11
  br i1 %104, label %.preheader, label %convert_reduce_fusion_wrapped.exit

.preheader:                                       ; preds = %103, %middle.block
  %105 = phi i64 [ %182, %middle.block ], [ 0, %103 ]
  %.idx = mul nuw nsw i64 %105, 3072
  %106 = getelementptr i8, ptr %6, i64 %.idx
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %.preheader
  %index = phi i64 [ 0, %.preheader ], [ %index.next, %vector.body ]
  %vec.phi = phi <8 x i32> [ zeroinitializer, %.preheader ], [ %174, %vector.body ]
  %vec.phi28 = phi <8 x i32> [ zeroinitializer, %.preheader ], [ %175, %vector.body ]
  %vec.phi29 = phi <8 x i32> [ zeroinitializer, %.preheader ], [ %172, %vector.body ]
  %vec.phi30 = phi <8 x i32> [ zeroinitializer, %.preheader ], [ %173, %vector.body ]
  %107 = getelementptr float, ptr %106, i64 %index
  %108 = getelementptr i8, ptr %107, i64 2906112
  %109 = getelementptr i8, ptr %107, i64 2906144
  %wide.load = load <8 x float>, ptr %108, align 4, !invariant.load !3, !alias.scope !10, !noalias !22
  %wide.load31 = load <8 x float>, ptr %109, align 4, !invariant.load !3, !alias.scope !10, !noalias !22
  %110 = getelementptr inbounds nuw float, ptr %12, i64 %index
  %111 = getelementptr inbounds nuw i8, ptr %110, i64 32
  %wide.load32 = load <8 x float>, ptr %110, align 4, !invariant.load !3, !alias.scope !16, !noalias !23
  %wide.load33 = load <8 x float>, ptr %111, align 4, !invariant.load !3, !alias.scope !16, !noalias !23
  %112 = fmul <8 x float> %wide.load, %wide.load32
  %113 = fmul <8 x float> %wide.load31, %wide.load33
  %114 = getelementptr inbounds nuw float, ptr %10, i64 %index
  %115 = getelementptr inbounds nuw i8, ptr %114, i64 32
  %wide.load34 = load <8 x float>, ptr %114, align 4, !invariant.load !3, !alias.scope !14, !noalias !24
  %wide.load35 = load <8 x float>, ptr %115, align 4, !invariant.load !3, !alias.scope !14, !noalias !24
  %116 = fadd <8 x float> %112, %wide.load34
  %117 = fadd <8 x float> %113, %wide.load35
  %118 = fcmp ogt <8 x float> %116, zeroinitializer
  %119 = fcmp ogt <8 x float> %117, zeroinitializer
  %120 = zext <8 x i1> %118 to <8 x i32>
  %121 = zext <8 x i1> %119 to <8 x i32>
  %122 = fneg <8 x float> %116
  %123 = fneg <8 x float> %117
  %124 = fcmp uge <8 x float> %122, splat (float 0xC055F33340000000)
  %125 = select <8 x i1> %124, <8 x float> %122, <8 x float> splat (float 0xC055F33340000000)
  %126 = fcmp ule <8 x float> %125, splat (float 0x4056333340000000)
  %127 = select <8 x i1> %126, <8 x float> %125, <8 x float> splat (float 0x4056333340000000)
  %exp_f32.i115 = fmul <8 x float> %127, splat (float 0x3FF7154760000000)
  %exp_f321.i116 = fadd <8 x float> splat (float 5.000000e-01), %exp_f32.i115
  %128 = call <8 x float> @llvm.floor.v8f32(<8 x float> %exp_f321.i116)
  %129 = fcmp uge <8 x float> %128, splat (float -1.270000e+02)
  %130 = select <8 x i1> %129, <8 x float> %128, <8 x float> splat (float -1.270000e+02)
  %131 = fcmp ule <8 x float> %130, splat (float 1.270000e+02)
  %132 = select <8 x i1> %131, <8 x float> %130, <8 x float> splat (float 1.270000e+02)
  %exp_f322.i117 = fmul <8 x float> splat (float 0x3FE6300000000000), %132
  %133 = fsub <8 x float> %127, %exp_f322.i117
  %exp_f323.i118 = fmul <8 x float> splat (float 0xBF2BD01060000000), %132
  %134 = fsub <8 x float> %133, %exp_f323.i118
  %exp_f324.i119 = fmul <8 x float> %134, splat (float 0x3F2A0D2CE0000000)
  %exp_f325.i120 = fadd <8 x float> splat (float 0x3F56E879C0000000), %exp_f324.i119
  %exp_f326.i121 = fmul <8 x float> %exp_f325.i120, %134
  %exp_f327.i122 = fadd <8 x float> splat (float 0x3F81112100000000), %exp_f326.i121
  %exp_f328.i123 = fmul <8 x float> %exp_f327.i122, %134
  %exp_f329.i124 = fadd <8 x float> splat (float 0x3FA5553820000000), %exp_f328.i123
  %exp_f3210.i125 = fmul <8 x float> %exp_f329.i124, %134
  %exp_f3211.i126 = fadd <8 x float> splat (float 0x3FC5555540000000), %exp_f3210.i125
  %exp_f3212.i127 = fmul <8 x float> %exp_f3211.i126, %134
  %exp_f3213.i128 = fadd <8 x float> splat (float 5.000000e-01), %exp_f3212.i127
  %exp_f3214.i129 = fmul <8 x float> %134, %134
  %exp_f3215.i130 = fmul <8 x float> %exp_f3213.i128, %exp_f3214.i129
  %exp_f3216.i131 = fadd <8 x float> %134, %exp_f3215.i130
  %exp_f3217.i132 = fadd <8 x float> splat (float 1.000000e+00), %exp_f3216.i131
  %135 = fptosi <8 x float> %132 to <8 x i32>
  %136 = add <8 x i32> %135, splat (i32 127)
  %137 = shl <8 x i32> %136, splat (i32 23)
  %138 = bitcast <8 x i32> %137 to <8 x float>
  %exp_f3218.i133 = fmul <8 x float> %exp_f3217.i132, %138
  %139 = fcmp uge <8 x float> %123, splat (float 0xC055F33340000000)
  %140 = select <8 x i1> %139, <8 x float> %123, <8 x float> splat (float 0xC055F33340000000)
  %141 = fcmp ule <8 x float> %140, splat (float 0x4056333340000000)
  %142 = select <8 x i1> %141, <8 x float> %140, <8 x float> splat (float 0x4056333340000000)
  %exp_f32.i96 = fmul <8 x float> %142, splat (float 0x3FF7154760000000)
  %exp_f321.i97 = fadd <8 x float> splat (float 5.000000e-01), %exp_f32.i96
  %143 = call <8 x float> @llvm.floor.v8f32(<8 x float> %exp_f321.i97)
  %144 = fcmp uge <8 x float> %143, splat (float -1.270000e+02)
  %145 = select <8 x i1> %144, <8 x float> %143, <8 x float> splat (float -1.270000e+02)
  %146 = fcmp ule <8 x float> %145, splat (float 1.270000e+02)
  %147 = select <8 x i1> %146, <8 x float> %145, <8 x float> splat (float 1.270000e+02)
  %exp_f322.i98 = fmul <8 x float> splat (float 0x3FE6300000000000), %147
  %148 = fsub <8 x float> %142, %exp_f322.i98
  %exp_f323.i99 = fmul <8 x float> splat (float 0xBF2BD01060000000), %147
  %149 = fsub <8 x float> %148, %exp_f323.i99
  %exp_f324.i100 = fmul <8 x float> %149, splat (float 0x3F2A0D2CE0000000)
  %exp_f325.i101 = fadd <8 x float> splat (float 0x3F56E879C0000000), %exp_f324.i100
  %exp_f326.i102 = fmul <8 x float> %exp_f325.i101, %149
  %exp_f327.i103 = fadd <8 x float> splat (float 0x3F81112100000000), %exp_f326.i102
  %exp_f328.i104 = fmul <8 x float> %exp_f327.i103, %149
  %exp_f329.i105 = fadd <8 x float> splat (float 0x3FA5553820000000), %exp_f328.i104
  %exp_f3210.i106 = fmul <8 x float> %exp_f329.i105, %149
  %exp_f3211.i107 = fadd <8 x float> splat (float 0x3FC5555540000000), %exp_f3210.i106
  %exp_f3212.i108 = fmul <8 x float> %exp_f3211.i107, %149
  %exp_f3213.i109 = fadd <8 x float> splat (float 5.000000e-01), %exp_f3212.i108
  %exp_f3214.i110 = fmul <8 x float> %149, %149
  %exp_f3215.i111 = fmul <8 x float> %exp_f3213.i109, %exp_f3214.i110
  %exp_f3216.i112 = fadd <8 x float> %149, %exp_f3215.i111
  %exp_f3217.i113 = fadd <8 x float> splat (float 1.000000e+00), %exp_f3216.i112
  %150 = fptosi <8 x float> %147 to <8 x i32>
  %151 = add <8 x i32> %150, splat (i32 127)
  %152 = shl <8 x i32> %151, splat (i32 23)
  %153 = bitcast <8 x i32> %152 to <8 x float>
  %exp_f3218.i114 = fmul <8 x float> %exp_f3217.i113, %153
  %154 = getelementptr inbounds nuw float, ptr %8, i64 %index
  %155 = getelementptr inbounds nuw i8, ptr %154, i64 32
  %wide.load36 = load <8 x float>, ptr %154, align 4, !invariant.load !3, !alias.scope !12, !noalias !25
  %wide.load37 = load <8 x float>, ptr %155, align 4, !invariant.load !3, !alias.scope !12, !noalias !25
  %156 = fadd <8 x float> %exp_f3218.i133, splat (float 1.000000e+00)
  %157 = fadd <8 x float> %exp_f3218.i114, splat (float 1.000000e+00)
  %158 = fmul <8 x float> %wide.load, %wide.load36
  %159 = fmul <8 x float> %wide.load31, %wide.load37
  %160 = getelementptr inbounds nuw float, ptr %4, i64 %index
  %161 = getelementptr inbounds nuw i8, ptr %160, i64 32
  %wide.load38 = load <8 x float>, ptr %160, align 4, !invariant.load !3, !alias.scope !7, !noalias !26
  %wide.load39 = load <8 x float>, ptr %161, align 4, !invariant.load !3, !alias.scope !7, !noalias !26
  %162 = fdiv <8 x float> splat (float 1.000000e+00), %156
  %163 = fdiv <8 x float> splat (float 1.000000e+00), %157
  %164 = fadd <8 x float> %158, %wide.load38
  %165 = fadd <8 x float> %159, %wide.load39
  %166 = fmul <8 x float> %164, %162
  %167 = fmul <8 x float> %165, %163
  %168 = fcmp ogt <8 x float> %166, zeroinitializer
  %169 = fcmp ogt <8 x float> %167, zeroinitializer
  %170 = zext <8 x i1> %168 to <8 x i32>
  %171 = zext <8 x i1> %169 to <8 x i32>
  %172 = add <8 x i32> %vec.phi29, %120
  %173 = add <8 x i32> %vec.phi30, %121
  %174 = add <8 x i32> %vec.phi, %170
  %175 = add <8 x i32> %vec.phi28, %171
  %index.next = add nuw i64 %index, 16
  %176 = icmp eq i64 %index.next, 768
  br i1 %176, label %middle.block, label %vector.body, !llvm.loop !34

middle.block:                                     ; preds = %vector.body
  %bin.rdx40 = add <8 x i32> %173, %172
  %177 = tail call i32 @llvm.vector.reduce.add.v8i32(<8 x i32> %bin.rdx40)
  %bin.rdx = add <8 x i32> %175, %174
  %178 = tail call i32 @llvm.vector.reduce.add.v8i32(<8 x i32> %bin.rdx)
  %179 = add nuw nsw i64 %105, 946
  %180 = getelementptr inbounds nuw i32, ptr %14, i64 %179
  store i32 %177, ptr %180, align 4, !alias.scope !18, !noalias !30
  %181 = getelementptr inbounds nuw i32, ptr %16, i64 %179
  store i32 %178, ptr %181, align 4, !alias.scope !20, !noalias !31
  %182 = add nuw nsw i64 %105, 1
  %exitcond15.not = icmp eq i64 %182, 78
  br i1 %exitcond15.not, label %convert_reduce_fusion_wrapped.exit, label %.preheader, !llvm.loop !32

convert_reduce_fusion_wrapped.exit:               ; preds = %middle.block, %middle.block59, %21, %103
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.vector.reduce.add.v8i32(<8 x i32>) #2

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <4 x float> @llvm.floor.v4f32(<4 x float>) #3

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.floor.v8f32(<8 x float>) #3

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <16 x float> @llvm.floor.v16f32(<16 x float>) #3

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #2 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #3 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 0}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 3072}
!5 = !{i64 3145728}
!6 = !{i64 4096}
!7 = !{!8}
!8 = distinct !{!8, !9, !"convert_reduce_fusion_wrapped: argument 0"}
!9 = distinct !{!9, !"convert_reduce_fusion_wrapped"}
!10 = !{!11}
!11 = distinct !{!11, !9, !"convert_reduce_fusion_wrapped: argument 1"}
!12 = !{!13}
!13 = distinct !{!13, !9, !"convert_reduce_fusion_wrapped: argument 2"}
!14 = !{!15}
!15 = distinct !{!15, !9, !"convert_reduce_fusion_wrapped: argument 3"}
!16 = !{!17}
!17 = distinct !{!17, !9, !"convert_reduce_fusion_wrapped: argument 4"}
!18 = !{!19}
!19 = distinct !{!19, !9, !"convert_reduce_fusion_wrapped: argument 5"}
!20 = !{!21}
!21 = distinct !{!21, !9, !"convert_reduce_fusion_wrapped: argument 6"}
!22 = !{!8, !13, !15, !17, !19, !21}
!23 = !{!8, !11, !13, !15, !19, !21}
!24 = !{!8, !11, !13, !17, !19, !21}
!25 = !{!8, !11, !15, !17, !19, !21}
!26 = !{!11, !13, !15, !17, !19, !21}
!27 = distinct !{!27, !28, !29}
!28 = !{!"llvm.loop.isvectorized", i32 1}
!29 = !{!"llvm.loop.unroll.runtime.disable"}
!30 = !{!8, !11, !13, !15, !17, !21}
!31 = !{!8, !11, !13, !15, !17, !19}
!32 = distinct !{!32, !33}
!33 = !{!"llvm.loop.unroll.disable"}
!34 = distinct !{!34, !28, !29}
