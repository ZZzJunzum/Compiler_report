; ModuleID = '__compute_module_convert_reduce_fusion_kernel_module'
source_filename = "__compute_module_convert_reduce_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @convert_reduce_fusion(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !5
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !4
  %9 = getelementptr inbounds nuw i8, ptr %3, i64 48
  %10 = load ptr, ptr %9, align 8, !invariant.load !3, !dereferenceable !4
  %11 = getelementptr inbounds nuw i8, ptr %3, i64 64
  %12 = load ptr, ptr %11, align 8, !invariant.load !3, !dereferenceable !4
  %13 = getelementptr inbounds nuw i8, ptr %3, i64 80
  %14 = load ptr, ptr %13, align 8, !invariant.load !3, !dereferenceable !6
  %15 = getelementptr inbounds nuw i8, ptr %3, i64 96
  %16 = load ptr, ptr %15, align 8, !invariant.load !3, !dereferenceable !6
  tail call void @llvm.experimental.noalias.scope.decl(metadata !7)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !10)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !12)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !14)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !16)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !18)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !20)
  br label %.preheader

.preheader:                                       ; preds = %1, %middle.block
  %17 = phi i64 [ 0, %1 ], [ %92, %middle.block ]
  %.idx = mul nuw nsw i64 %17, 3072
  %18 = getelementptr i8, ptr %6, i64 %.idx
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %.preheader
  %index = phi i64 [ 0, %.preheader ], [ %index.next, %vector.body ]
  %vec.phi = phi <8 x i32> [ zeroinitializer, %.preheader ], [ %85, %vector.body ]
  %vec.phi6 = phi <8 x i32> [ zeroinitializer, %.preheader ], [ %86, %vector.body ]
  %vec.phi7 = phi <8 x i32> [ zeroinitializer, %.preheader ], [ %83, %vector.body ]
  %vec.phi8 = phi <8 x i32> [ zeroinitializer, %.preheader ], [ %84, %vector.body ]
  %19 = getelementptr float, ptr %18, i64 %index
  %20 = getelementptr i8, ptr %19, i64 32
  %wide.load = load <8 x float>, ptr %19, align 4, !invariant.load !3, !alias.scope !10, !noalias !22
  %wide.load9 = load <8 x float>, ptr %20, align 4, !invariant.load !3, !alias.scope !10, !noalias !22
  %21 = getelementptr inbounds nuw float, ptr %12, i64 %index
  %22 = getelementptr inbounds nuw i8, ptr %21, i64 32
  %wide.load10 = load <8 x float>, ptr %21, align 4, !invariant.load !3, !alias.scope !16, !noalias !23
  %wide.load11 = load <8 x float>, ptr %22, align 4, !invariant.load !3, !alias.scope !16, !noalias !23
  %23 = fmul <8 x float> %wide.load, %wide.load10
  %24 = fmul <8 x float> %wide.load9, %wide.load11
  %25 = getelementptr inbounds nuw float, ptr %10, i64 %index
  %26 = getelementptr inbounds nuw i8, ptr %25, i64 32
  %wide.load12 = load <8 x float>, ptr %25, align 4, !invariant.load !3, !alias.scope !14, !noalias !24
  %wide.load13 = load <8 x float>, ptr %26, align 4, !invariant.load !3, !alias.scope !14, !noalias !24
  %27 = fadd <8 x float> %23, %wide.load12
  %28 = fadd <8 x float> %24, %wide.load13
  %29 = fcmp ogt <8 x float> %27, zeroinitializer
  %30 = fcmp ogt <8 x float> %28, zeroinitializer
  %31 = zext <8 x i1> %29 to <8 x i32>
  %32 = zext <8 x i1> %30 to <8 x i32>
  %33 = fneg <8 x float> %27
  %34 = fneg <8 x float> %28
  %35 = fcmp uge <8 x float> %33, splat (float 0xC055F33340000000)
  %36 = select <8 x i1> %35, <8 x float> %33, <8 x float> splat (float 0xC055F33340000000)
  %37 = fcmp ule <8 x float> %36, splat (float 0x4056333340000000)
  %38 = select <8 x i1> %37, <8 x float> %36, <8 x float> splat (float 0x4056333340000000)
  %exp_f32.i25 = fmul <8 x float> %38, splat (float 0x3FF7154760000000)
  %exp_f321.i26 = fadd <8 x float> splat (float 5.000000e-01), %exp_f32.i25
  %39 = call <8 x float> @llvm.floor.v8f32(<8 x float> %exp_f321.i26)
  %40 = fcmp uge <8 x float> %39, splat (float -1.270000e+02)
  %41 = select <8 x i1> %40, <8 x float> %39, <8 x float> splat (float -1.270000e+02)
  %42 = fcmp ule <8 x float> %41, splat (float 1.270000e+02)
  %43 = select <8 x i1> %42, <8 x float> %41, <8 x float> splat (float 1.270000e+02)
  %exp_f322.i27 = fmul <8 x float> splat (float 0x3FE6300000000000), %43
  %44 = fsub <8 x float> %38, %exp_f322.i27
  %exp_f323.i28 = fmul <8 x float> splat (float 0xBF2BD01060000000), %43
  %45 = fsub <8 x float> %44, %exp_f323.i28
  %exp_f324.i29 = fmul <8 x float> %45, splat (float 0x3F2A0D2CE0000000)
  %exp_f325.i30 = fadd <8 x float> splat (float 0x3F56E879C0000000), %exp_f324.i29
  %exp_f326.i31 = fmul <8 x float> %exp_f325.i30, %45
  %exp_f327.i32 = fadd <8 x float> splat (float 0x3F81112100000000), %exp_f326.i31
  %exp_f328.i33 = fmul <8 x float> %exp_f327.i32, %45
  %exp_f329.i34 = fadd <8 x float> splat (float 0x3FA5553820000000), %exp_f328.i33
  %exp_f3210.i35 = fmul <8 x float> %exp_f329.i34, %45
  %exp_f3211.i36 = fadd <8 x float> splat (float 0x3FC5555540000000), %exp_f3210.i35
  %exp_f3212.i37 = fmul <8 x float> %exp_f3211.i36, %45
  %exp_f3213.i38 = fadd <8 x float> splat (float 5.000000e-01), %exp_f3212.i37
  %exp_f3214.i39 = fmul <8 x float> %45, %45
  %exp_f3215.i40 = fmul <8 x float> %exp_f3213.i38, %exp_f3214.i39
  %exp_f3216.i41 = fadd <8 x float> %45, %exp_f3215.i40
  %exp_f3217.i42 = fadd <8 x float> splat (float 1.000000e+00), %exp_f3216.i41
  %46 = fptosi <8 x float> %43 to <8 x i32>
  %47 = add <8 x i32> %46, splat (i32 127)
  %48 = shl <8 x i32> %47, splat (i32 23)
  %49 = bitcast <8 x i32> %48 to <8 x float>
  %exp_f3218.i43 = fmul <8 x float> %exp_f3217.i42, %49
  %50 = fcmp uge <8 x float> %34, splat (float 0xC055F33340000000)
  %51 = select <8 x i1> %50, <8 x float> %34, <8 x float> splat (float 0xC055F33340000000)
  %52 = fcmp ule <8 x float> %51, splat (float 0x4056333340000000)
  %53 = select <8 x i1> %52, <8 x float> %51, <8 x float> splat (float 0x4056333340000000)
  %exp_f32.i = fmul <8 x float> %53, splat (float 0x3FF7154760000000)
  %exp_f321.i = fadd <8 x float> splat (float 5.000000e-01), %exp_f32.i
  %54 = call <8 x float> @llvm.floor.v8f32(<8 x float> %exp_f321.i)
  %55 = fcmp uge <8 x float> %54, splat (float -1.270000e+02)
  %56 = select <8 x i1> %55, <8 x float> %54, <8 x float> splat (float -1.270000e+02)
  %57 = fcmp ule <8 x float> %56, splat (float 1.270000e+02)
  %58 = select <8 x i1> %57, <8 x float> %56, <8 x float> splat (float 1.270000e+02)
  %exp_f322.i = fmul <8 x float> splat (float 0x3FE6300000000000), %58
  %59 = fsub <8 x float> %53, %exp_f322.i
  %exp_f323.i = fmul <8 x float> splat (float 0xBF2BD01060000000), %58
  %60 = fsub <8 x float> %59, %exp_f323.i
  %exp_f324.i = fmul <8 x float> %60, splat (float 0x3F2A0D2CE0000000)
  %exp_f325.i = fadd <8 x float> splat (float 0x3F56E879C0000000), %exp_f324.i
  %exp_f326.i = fmul <8 x float> %exp_f325.i, %60
  %exp_f327.i = fadd <8 x float> splat (float 0x3F81112100000000), %exp_f326.i
  %exp_f328.i = fmul <8 x float> %exp_f327.i, %60
  %exp_f329.i = fadd <8 x float> splat (float 0x3FA5553820000000), %exp_f328.i
  %exp_f3210.i = fmul <8 x float> %exp_f329.i, %60
  %exp_f3211.i = fadd <8 x float> splat (float 0x3FC5555540000000), %exp_f3210.i
  %exp_f3212.i = fmul <8 x float> %exp_f3211.i, %60
  %exp_f3213.i = fadd <8 x float> splat (float 5.000000e-01), %exp_f3212.i
  %exp_f3214.i = fmul <8 x float> %60, %60
  %exp_f3215.i = fmul <8 x float> %exp_f3213.i, %exp_f3214.i
  %exp_f3216.i = fadd <8 x float> %60, %exp_f3215.i
  %exp_f3217.i = fadd <8 x float> splat (float 1.000000e+00), %exp_f3216.i
  %61 = fptosi <8 x float> %58 to <8 x i32>
  %62 = add <8 x i32> %61, splat (i32 127)
  %63 = shl <8 x i32> %62, splat (i32 23)
  %64 = bitcast <8 x i32> %63 to <8 x float>
  %exp_f3218.i = fmul <8 x float> %exp_f3217.i, %64
  %65 = getelementptr inbounds nuw float, ptr %8, i64 %index
  %66 = getelementptr inbounds nuw i8, ptr %65, i64 32
  %wide.load14 = load <8 x float>, ptr %65, align 4, !invariant.load !3, !alias.scope !12, !noalias !25
  %wide.load15 = load <8 x float>, ptr %66, align 4, !invariant.load !3, !alias.scope !12, !noalias !25
  %67 = fadd <8 x float> %exp_f3218.i43, splat (float 1.000000e+00)
  %68 = fadd <8 x float> %exp_f3218.i, splat (float 1.000000e+00)
  %69 = fmul <8 x float> %wide.load, %wide.load14
  %70 = fmul <8 x float> %wide.load9, %wide.load15
  %71 = getelementptr inbounds nuw float, ptr %4, i64 %index
  %72 = getelementptr inbounds nuw i8, ptr %71, i64 32
  %wide.load16 = load <8 x float>, ptr %71, align 4, !invariant.load !3, !alias.scope !7, !noalias !26
  %wide.load17 = load <8 x float>, ptr %72, align 4, !invariant.load !3, !alias.scope !7, !noalias !26
  %73 = fdiv <8 x float> splat (float 1.000000e+00), %67
  %74 = fdiv <8 x float> splat (float 1.000000e+00), %68
  %75 = fadd <8 x float> %69, %wide.load16
  %76 = fadd <8 x float> %70, %wide.load17
  %77 = fmul <8 x float> %75, %73
  %78 = fmul <8 x float> %76, %74
  %79 = fcmp ogt <8 x float> %77, zeroinitializer
  %80 = fcmp ogt <8 x float> %78, zeroinitializer
  %81 = zext <8 x i1> %79 to <8 x i32>
  %82 = zext <8 x i1> %80 to <8 x i32>
  %83 = add <8 x i32> %vec.phi7, %31
  %84 = add <8 x i32> %vec.phi8, %32
  %85 = add <8 x i32> %vec.phi, %81
  %86 = add <8 x i32> %vec.phi6, %82
  %index.next = add nuw i64 %index, 16
  %87 = icmp eq i64 %index.next, 768
  br i1 %87, label %middle.block, label %vector.body, !llvm.loop !27

middle.block:                                     ; preds = %vector.body
  %bin.rdx18 = add <8 x i32> %84, %83
  %88 = tail call i32 @llvm.vector.reduce.add.v8i32(<8 x i32> %bin.rdx18)
  %bin.rdx = add <8 x i32> %86, %85
  %89 = tail call i32 @llvm.vector.reduce.add.v8i32(<8 x i32> %bin.rdx)
  %90 = getelementptr inbounds nuw i32, ptr %14, i64 %17
  store i32 %88, ptr %90, align 4, !alias.scope !18, !noalias !30
  %91 = getelementptr inbounds nuw i32, ptr %16, i64 %17
  store i32 %89, ptr %91, align 4, !alias.scope !20, !noalias !31
  %92 = add nuw nsw i64 %17, 1
  %exitcond3.not = icmp eq i64 %92, 1024
  br i1 %exitcond3.not, label %convert_reduce_fusion_wrapped.exit, label %.preheader, !llvm.loop !32

convert_reduce_fusion_wrapped.exit:               ; preds = %middle.block
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.vector.reduce.add.v8i32(<8 x i32>) #2

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <4 x float> @llvm.floor.v4f32(<4 x float>) #3

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.floor.v8f32(<8 x float>) #3

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <16 x float> @llvm.floor.v16f32(<16 x float>) #3

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #2 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #3 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 0}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 3072}
!5 = !{i64 3145728}
!6 = !{i64 4096}
!7 = !{!8}
!8 = distinct !{!8, !9, !"convert_reduce_fusion_wrapped: argument 0"}
!9 = distinct !{!9, !"convert_reduce_fusion_wrapped"}
!10 = !{!11}
!11 = distinct !{!11, !9, !"convert_reduce_fusion_wrapped: argument 1"}
!12 = !{!13}
!13 = distinct !{!13, !9, !"convert_reduce_fusion_wrapped: argument 2"}
!14 = !{!15}
!15 = distinct !{!15, !9, !"convert_reduce_fusion_wrapped: argument 3"}
!16 = !{!17}
!17 = distinct !{!17, !9, !"convert_reduce_fusion_wrapped: argument 4"}
!18 = !{!19}
!19 = distinct !{!19, !9, !"convert_reduce_fusion_wrapped: argument 5"}
!20 = !{!21}
!21 = distinct !{!21, !9, !"convert_reduce_fusion_wrapped: argument 6"}
!22 = !{!8, !13, !15, !17, !19, !21}
!23 = !{!8, !11, !13, !15, !19, !21}
!24 = !{!8, !11, !13, !17, !19, !21}
!25 = !{!8, !11, !15, !17, !19, !21}
!26 = !{!11, !13, !15, !17, !19, !21}
!27 = distinct !{!27, !28, !29}
!28 = !{!"llvm.loop.isvectorized", i32 1}
!29 = !{!"llvm.loop.unroll.runtime.disable"}
!30 = !{!8, !11, !13, !15, !17, !21}
!31 = !{!8, !11, !13, !15, !17, !19}
!32 = distinct !{!32, !33}
!33 = !{!"llvm.loop.unroll.disable"}
