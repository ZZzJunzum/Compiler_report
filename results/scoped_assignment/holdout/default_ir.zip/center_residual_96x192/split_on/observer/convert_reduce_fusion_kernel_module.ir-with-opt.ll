; ModuleID = '__compute_module_convert_reduce_fusion_kernel_module'
source_filename = "__compute_module_convert_reduce_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @convert_reduce_fusion(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !5
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !5
  %9 = getelementptr inbounds nuw i8, ptr %3, i64 48
  %10 = load ptr, ptr %9, align 8, !invariant.load !3, !dereferenceable !6
  %11 = getelementptr inbounds nuw i8, ptr %3, i64 64
  %12 = load ptr, ptr %11, align 8, !invariant.load !3, !dereferenceable !5
  %13 = getelementptr inbounds nuw i8, ptr %3, i64 80
  %14 = load ptr, ptr %13, align 8, !invariant.load !3, !dereferenceable !5
  %15 = getelementptr inbounds nuw i8, ptr %3, i64 96
  %16 = load ptr, ptr %15, align 8, !invariant.load !3, !dereferenceable !6
  %17 = getelementptr inbounds nuw i8, ptr %3, i64 112
  %18 = load ptr, ptr %17, align 8, !invariant.load !3, !dereferenceable !6
  %19 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %20 = load ptr, ptr %19, align 8
  %21 = load i64, ptr %20, align 4, !invariant.load !3
  tail call void @llvm.experimental.noalias.scope.decl(metadata !7)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !10)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !12)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !14)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !16)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !18)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !20)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !22)
  %22 = icmp slt i64 %21, 9
  br i1 %22, label %23, label %76

23:                                               ; preds = %1
  %24 = icmp sgt i64 %21, -1
  br i1 %24, label %25, label %convert_reduce_fusion_wrapped.exit

25:                                               ; preds = %23
  %26 = mul nuw nsw i64 %21, 10
  %.idx1 = mul nuw nsw i64 %21, 7680
  %27 = getelementptr i8, ptr %4, i64 %.idx1
  br label %vector.ph41

vector.ph41:                                      ; preds = %25, %middle.block61
  %28 = phi i64 [ 0, %25 ], [ %75, %middle.block61 ]
  %29 = add nuw nsw i64 %28, %26
  %.idx2 = mul nuw nsw i64 %28, 768
  %30 = getelementptr i8, ptr %27, i64 %.idx2
  %31 = getelementptr inbounds nuw float, ptr %10, i64 %29
  %32 = load float, ptr %31, align 4, !invariant.load !3, !alias.scope !14, !noalias !24
  %33 = fmul float %32, 0x3F75555560000000
  %broadcast.splatinsert42 = insertelement <8 x float> poison, float %33, i64 0
  %broadcast.splat43 = shufflevector <8 x float> %broadcast.splatinsert42, <8 x float> poison, <8 x i32> zeroinitializer
  br label %vector.body44

vector.body44:                                    ; preds = %vector.body44, %vector.ph41
  %index45 = phi i64 [ 0, %vector.ph41 ], [ %index.next60, %vector.body44 ]
  %vec.phi46 = phi <8 x i32> [ zeroinitializer, %vector.ph41 ], [ %68, %vector.body44 ]
  %vec.phi47 = phi <8 x i32> [ zeroinitializer, %vector.ph41 ], [ %69, %vector.body44 ]
  %vec.phi48 = phi <8 x i32> [ zeroinitializer, %vector.ph41 ], [ %66, %vector.body44 ]
  %vec.phi49 = phi <8 x i32> [ zeroinitializer, %vector.ph41 ], [ %67, %vector.body44 ]
  %34 = getelementptr float, ptr %30, i64 %index45
  %35 = getelementptr i8, ptr %34, i64 32
  %wide.load50 = load <8 x float>, ptr %34, align 4, !invariant.load !3, !alias.scope !7, !noalias !25
  %wide.load51 = load <8 x float>, ptr %35, align 4, !invariant.load !3, !alias.scope !7, !noalias !25
  %36 = getelementptr inbounds nuw float, ptr %14, i64 %index45
  %37 = getelementptr inbounds nuw i8, ptr %36, i64 32
  %wide.load52 = load <8 x float>, ptr %36, align 4, !invariant.load !3, !alias.scope !18, !noalias !26
  %wide.load53 = load <8 x float>, ptr %37, align 4, !invariant.load !3, !alias.scope !18, !noalias !26
  %38 = fmul <8 x float> %wide.load50, %wide.load52
  %39 = fmul <8 x float> %wide.load51, %wide.load53
  %40 = getelementptr inbounds nuw float, ptr %12, i64 %index45
  %41 = getelementptr inbounds nuw i8, ptr %40, i64 32
  %wide.load54 = load <8 x float>, ptr %40, align 4, !invariant.load !3, !alias.scope !16, !noalias !27
  %wide.load55 = load <8 x float>, ptr %41, align 4, !invariant.load !3, !alias.scope !16, !noalias !27
  %42 = fadd <8 x float> %38, %wide.load54
  %43 = fadd <8 x float> %39, %wide.load55
  %44 = fsub <8 x float> %42, %broadcast.splat43
  %45 = fsub <8 x float> %43, %broadcast.splat43
  %46 = fcmp ogt <8 x float> %44, zeroinitializer
  %47 = fcmp ogt <8 x float> %45, zeroinitializer
  %48 = zext <8 x i1> %46 to <8 x i32>
  %49 = zext <8 x i1> %47 to <8 x i32>
  %50 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %44, <8 x float> zeroinitializer)
  %51 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %45, <8 x float> zeroinitializer)
  %52 = getelementptr inbounds nuw float, ptr %8, i64 %index45
  %53 = getelementptr inbounds nuw i8, ptr %52, i64 32
  %wide.load56 = load <8 x float>, ptr %52, align 4, !invariant.load !3, !alias.scope !12, !noalias !28
  %wide.load57 = load <8 x float>, ptr %53, align 4, !invariant.load !3, !alias.scope !12, !noalias !28
  %54 = fmul <8 x float> %wide.load56, %50
  %55 = fmul <8 x float> %wide.load57, %51
  %56 = getelementptr inbounds nuw float, ptr %6, i64 %index45
  %57 = getelementptr inbounds nuw i8, ptr %56, i64 32
  %wide.load58 = load <8 x float>, ptr %56, align 4, !invariant.load !3, !alias.scope !10, !noalias !29
  %wide.load59 = load <8 x float>, ptr %57, align 4, !invariant.load !3, !alias.scope !10, !noalias !29
  %58 = fadd <8 x float> %wide.load58, %54
  %59 = fadd <8 x float> %wide.load59, %55
  %60 = fadd <8 x float> %wide.load50, %58
  %61 = fadd <8 x float> %wide.load51, %59
  %62 = fcmp ogt <8 x float> %60, zeroinitializer
  %63 = fcmp ogt <8 x float> %61, zeroinitializer
  %64 = zext <8 x i1> %62 to <8 x i32>
  %65 = zext <8 x i1> %63 to <8 x i32>
  %66 = add <8 x i32> %vec.phi48, %48
  %67 = add <8 x i32> %vec.phi49, %49
  %68 = add <8 x i32> %vec.phi46, %64
  %69 = add <8 x i32> %vec.phi47, %65
  %index.next60 = add nuw i64 %index45, 16
  %70 = icmp eq i64 %index.next60, 192
  br i1 %70, label %middle.block61, label %vector.body44, !llvm.loop !30

middle.block61:                                   ; preds = %vector.body44
  %bin.rdx63 = add <8 x i32> %67, %66
  %71 = tail call i32 @llvm.vector.reduce.add.v8i32(<8 x i32> %bin.rdx63)
  %bin.rdx62 = add <8 x i32> %69, %68
  %72 = tail call i32 @llvm.vector.reduce.add.v8i32(<8 x i32> %bin.rdx62)
  %73 = getelementptr inbounds nuw i32, ptr %16, i64 %29
  store i32 %71, ptr %73, align 4, !alias.scope !20, !noalias !33
  %74 = getelementptr inbounds nuw i32, ptr %18, i64 %29
  store i32 %72, ptr %74, align 4, !alias.scope !22, !noalias !34
  %75 = add nuw nsw i64 %28, 1
  %exitcond17.not = icmp eq i64 %75, 10
  br i1 %exitcond17.not, label %convert_reduce_fusion_wrapped.exit, label %vector.ph41, !llvm.loop !35

76:                                               ; preds = %1
  %77 = icmp eq i64 %21, 9
  br i1 %77, label %.preheader, label %convert_reduce_fusion_wrapped.exit

.preheader:                                       ; preds = %76, %middle.block
  %78 = phi i64 [ %126, %middle.block ], [ 0, %76 ]
  %79 = add nuw nsw i64 %78, 90
  %.idx = mul nuw nsw i64 %78, 768
  %80 = getelementptr i8, ptr %4, i64 %.idx
  %81 = getelementptr inbounds nuw float, ptr %10, i64 %79
  %82 = load float, ptr %81, align 4, !invariant.load !3, !alias.scope !14, !noalias !24
  %83 = fmul float %82, 0x3F75555560000000
  %broadcast.splatinsert = insertelement <8 x float> poison, float %83, i64 0
  %broadcast.splat = shufflevector <8 x float> %broadcast.splatinsert, <8 x float> poison, <8 x i32> zeroinitializer
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %.preheader
  %index = phi i64 [ 0, %.preheader ], [ %index.next, %vector.body ]
  %vec.phi = phi <8 x i32> [ zeroinitializer, %.preheader ], [ %119, %vector.body ]
  %vec.phi28 = phi <8 x i32> [ zeroinitializer, %.preheader ], [ %120, %vector.body ]
  %vec.phi29 = phi <8 x i32> [ zeroinitializer, %.preheader ], [ %117, %vector.body ]
  %vec.phi30 = phi <8 x i32> [ zeroinitializer, %.preheader ], [ %118, %vector.body ]
  %84 = getelementptr float, ptr %80, i64 %index
  %85 = getelementptr i8, ptr %84, i64 69120
  %86 = getelementptr i8, ptr %84, i64 69152
  %wide.load = load <8 x float>, ptr %85, align 4, !invariant.load !3, !alias.scope !7, !noalias !25
  %wide.load31 = load <8 x float>, ptr %86, align 4, !invariant.load !3, !alias.scope !7, !noalias !25
  %87 = getelementptr inbounds nuw float, ptr %14, i64 %index
  %88 = getelementptr inbounds nuw i8, ptr %87, i64 32
  %wide.load32 = load <8 x float>, ptr %87, align 4, !invariant.load !3, !alias.scope !18, !noalias !26
  %wide.load33 = load <8 x float>, ptr %88, align 4, !invariant.load !3, !alias.scope !18, !noalias !26
  %89 = fmul <8 x float> %wide.load, %wide.load32
  %90 = fmul <8 x float> %wide.load31, %wide.load33
  %91 = getelementptr inbounds nuw float, ptr %12, i64 %index
  %92 = getelementptr inbounds nuw i8, ptr %91, i64 32
  %wide.load34 = load <8 x float>, ptr %91, align 4, !invariant.load !3, !alias.scope !16, !noalias !27
  %wide.load35 = load <8 x float>, ptr %92, align 4, !invariant.load !3, !alias.scope !16, !noalias !27
  %93 = fadd <8 x float> %89, %wide.load34
  %94 = fadd <8 x float> %90, %wide.load35
  %95 = fsub <8 x float> %93, %broadcast.splat
  %96 = fsub <8 x float> %94, %broadcast.splat
  %97 = fcmp ogt <8 x float> %95, zeroinitializer
  %98 = fcmp ogt <8 x float> %96, zeroinitializer
  %99 = zext <8 x i1> %97 to <8 x i32>
  %100 = zext <8 x i1> %98 to <8 x i32>
  %101 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %95, <8 x float> zeroinitializer)
  %102 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %96, <8 x float> zeroinitializer)
  %103 = getelementptr inbounds nuw float, ptr %8, i64 %index
  %104 = getelementptr inbounds nuw i8, ptr %103, i64 32
  %wide.load36 = load <8 x float>, ptr %103, align 4, !invariant.load !3, !alias.scope !12, !noalias !28
  %wide.load37 = load <8 x float>, ptr %104, align 4, !invariant.load !3, !alias.scope !12, !noalias !28
  %105 = fmul <8 x float> %wide.load36, %101
  %106 = fmul <8 x float> %wide.load37, %102
  %107 = getelementptr inbounds nuw float, ptr %6, i64 %index
  %108 = getelementptr inbounds nuw i8, ptr %107, i64 32
  %wide.load38 = load <8 x float>, ptr %107, align 4, !invariant.load !3, !alias.scope !10, !noalias !29
  %wide.load39 = load <8 x float>, ptr %108, align 4, !invariant.load !3, !alias.scope !10, !noalias !29
  %109 = fadd <8 x float> %wide.load38, %105
  %110 = fadd <8 x float> %wide.load39, %106
  %111 = fadd <8 x float> %wide.load, %109
  %112 = fadd <8 x float> %wide.load31, %110
  %113 = fcmp ogt <8 x float> %111, zeroinitializer
  %114 = fcmp ogt <8 x float> %112, zeroinitializer
  %115 = zext <8 x i1> %113 to <8 x i32>
  %116 = zext <8 x i1> %114 to <8 x i32>
  %117 = add <8 x i32> %vec.phi29, %99
  %118 = add <8 x i32> %vec.phi30, %100
  %119 = add <8 x i32> %vec.phi, %115
  %120 = add <8 x i32> %vec.phi28, %116
  %index.next = add nuw i64 %index, 16
  %121 = icmp eq i64 %index.next, 192
  br i1 %121, label %middle.block, label %vector.body, !llvm.loop !37

middle.block:                                     ; preds = %vector.body
  %bin.rdx40 = add <8 x i32> %118, %117
  %122 = tail call i32 @llvm.vector.reduce.add.v8i32(<8 x i32> %bin.rdx40)
  %bin.rdx = add <8 x i32> %120, %119
  %123 = tail call i32 @llvm.vector.reduce.add.v8i32(<8 x i32> %bin.rdx)
  %124 = getelementptr inbounds nuw i32, ptr %16, i64 %79
  store i32 %122, ptr %124, align 4, !alias.scope !20, !noalias !33
  %125 = getelementptr inbounds nuw i32, ptr %18, i64 %79
  store i32 %123, ptr %125, align 4, !alias.scope !22, !noalias !34
  %126 = add nuw nsw i64 %78, 1
  %exitcond15.not = icmp eq i64 %126, 6
  br i1 %exitcond15.not, label %convert_reduce_fusion_wrapped.exit, label %.preheader, !llvm.loop !35

convert_reduce_fusion_wrapped.exit:               ; preds = %middle.block, %middle.block61, %23, %76
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.maximum.v8f32(<8 x float>, <8 x float>) #2

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.vector.reduce.add.v8i32(<8 x i32>) #3

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #3 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 1}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 73728}
!5 = !{i64 768}
!6 = !{i64 384}
!7 = !{!8}
!8 = distinct !{!8, !9, !"convert_reduce_fusion_wrapped: argument 0"}
!9 = distinct !{!9, !"convert_reduce_fusion_wrapped"}
!10 = !{!11}
!11 = distinct !{!11, !9, !"convert_reduce_fusion_wrapped: argument 1"}
!12 = !{!13}
!13 = distinct !{!13, !9, !"convert_reduce_fusion_wrapped: argument 2"}
!14 = !{!15}
!15 = distinct !{!15, !9, !"convert_reduce_fusion_wrapped: argument 3"}
!16 = !{!17}
!17 = distinct !{!17, !9, !"convert_reduce_fusion_wrapped: argument 4"}
!18 = !{!19}
!19 = distinct !{!19, !9, !"convert_reduce_fusion_wrapped: argument 5"}
!20 = !{!21}
!21 = distinct !{!21, !9, !"convert_reduce_fusion_wrapped: argument 6"}
!22 = !{!23}
!23 = distinct !{!23, !9, !"convert_reduce_fusion_wrapped: argument 7"}
!24 = !{!8, !11, !13, !17, !19, !21, !23}
!25 = !{!11, !13, !15, !17, !19, !21, !23}
!26 = !{!8, !11, !13, !15, !17, !21, !23}
!27 = !{!8, !11, !13, !15, !19, !21, !23}
!28 = !{!8, !11, !15, !17, !19, !21, !23}
!29 = !{!8, !13, !15, !17, !19, !21, !23}
!30 = distinct !{!30, !31, !32}
!31 = !{!"llvm.loop.isvectorized", i32 1}
!32 = !{!"llvm.loop.unroll.runtime.disable"}
!33 = !{!8, !11, !13, !15, !17, !19, !23}
!34 = !{!8, !11, !13, !15, !17, !19, !21}
!35 = distinct !{!35, !36}
!36 = !{!"llvm.loop.unroll.disable"}
!37 = distinct !{!37, !31, !32}
