; ModuleID = '__compute_module_convert_reduce_fusion_kernel_module'
source_filename = "__compute_module_convert_reduce_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @convert_reduce_fusion(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !5
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !4
  %9 = getelementptr inbounds nuw i8, ptr %3, i64 48
  %10 = load ptr, ptr %9, align 8, !invariant.load !3, !dereferenceable !4
  %11 = getelementptr inbounds nuw i8, ptr %3, i64 64
  %12 = load ptr, ptr %11, align 8, !invariant.load !3, !dereferenceable !5
  %13 = getelementptr inbounds nuw i8, ptr %3, i64 80
  %14 = load ptr, ptr %13, align 8, !invariant.load !3, !dereferenceable !4
  %15 = getelementptr inbounds nuw i8, ptr %3, i64 96
  %16 = load ptr, ptr %15, align 8, !invariant.load !3, !dereferenceable !6
  %17 = getelementptr inbounds nuw i8, ptr %3, i64 112
  %18 = load ptr, ptr %17, align 8, !invariant.load !3, !dereferenceable !6
  %19 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %20 = load ptr, ptr %19, align 8
  %21 = load i64, ptr %20, align 4, !invariant.load !3
  tail call void @llvm.experimental.noalias.scope.decl(metadata !7)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !10)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !12)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !14)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !16)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !18)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !20)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !22)
  %22 = icmp ult i64 %21, 12
  br i1 %22, label %23, label %convert_reduce_fusion_wrapped.exit

23:                                               ; preds = %1
  %24 = shl nuw nsw i64 %21, 3
  %25 = mul nuw nsw i64 %21, 1536
  br label %vector.ph

vector.ph:                                        ; preds = %23, %middle.block
  %26 = phi i64 [ 0, %23 ], [ %101, %middle.block ]
  %27 = mul nuw nsw i64 %26, 192
  %28 = add nuw nsw i64 %27, %25
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %vector.ph
  %index = phi i64 [ 0, %vector.ph ], [ %index.next.1, %vector.body ]
  %vec.phi = phi <8 x i32> [ zeroinitializer, %vector.ph ], [ %93, %vector.body ]
  %vec.phi9 = phi <8 x i32> [ zeroinitializer, %vector.ph ], [ %94, %vector.body ]
  %vec.phi10 = phi <8 x i32> [ zeroinitializer, %vector.ph ], [ %91, %vector.body ]
  %vec.phi11 = phi <8 x i32> [ zeroinitializer, %vector.ph ], [ %92, %vector.body ]
  %29 = add nuw nsw i64 %28, %index
  %30 = getelementptr inbounds nuw float, ptr %12, i64 %29
  %31 = getelementptr inbounds nuw i8, ptr %30, i64 32
  %wide.load = load <8 x float>, ptr %30, align 4, !invariant.load !3, !alias.scope !16, !noalias !24
  %wide.load12 = load <8 x float>, ptr %31, align 4, !invariant.load !3, !alias.scope !16, !noalias !24
  %32 = getelementptr inbounds nuw float, ptr %14, i64 %index
  %33 = getelementptr inbounds nuw i8, ptr %32, i64 32
  %wide.load13 = load <8 x float>, ptr %32, align 4, !invariant.load !3, !alias.scope !18, !noalias !25
  %wide.load14 = load <8 x float>, ptr %33, align 4, !invariant.load !3, !alias.scope !18, !noalias !25
  %34 = fmul <8 x float> %wide.load, %wide.load13
  %35 = fmul <8 x float> %wide.load12, %wide.load14
  %36 = getelementptr inbounds nuw float, ptr %10, i64 %index
  %37 = getelementptr inbounds nuw i8, ptr %36, i64 32
  %wide.load15 = load <8 x float>, ptr %36, align 4, !invariant.load !3, !alias.scope !14, !noalias !26
  %wide.load16 = load <8 x float>, ptr %37, align 4, !invariant.load !3, !alias.scope !14, !noalias !26
  %38 = fadd <8 x float> %34, %wide.load15
  %39 = fadd <8 x float> %35, %wide.load16
  %40 = fcmp ogt <8 x float> %38, zeroinitializer
  %41 = fcmp ogt <8 x float> %39, zeroinitializer
  %42 = zext <8 x i1> %40 to <8 x i32>
  %43 = zext <8 x i1> %41 to <8 x i32>
  %44 = getelementptr inbounds nuw float, ptr %6, i64 %29
  %45 = getelementptr inbounds nuw i8, ptr %44, i64 32
  %wide.load17 = load <8 x float>, ptr %44, align 4, !invariant.load !3, !alias.scope !10, !noalias !27
  %wide.load18 = load <8 x float>, ptr %45, align 4, !invariant.load !3, !alias.scope !10, !noalias !27
  %46 = getelementptr inbounds nuw float, ptr %8, i64 %index
  %47 = getelementptr inbounds nuw i8, ptr %46, i64 32
  %wide.load19 = load <8 x float>, ptr %46, align 4, !invariant.load !3, !alias.scope !12, !noalias !28
  %wide.load20 = load <8 x float>, ptr %47, align 4, !invariant.load !3, !alias.scope !12, !noalias !28
  %48 = fmul <8 x float> %wide.load17, %wide.load19
  %49 = fmul <8 x float> %wide.load18, %wide.load20
  %50 = getelementptr inbounds nuw float, ptr %4, i64 %index
  %51 = getelementptr inbounds nuw i8, ptr %50, i64 32
  %wide.load21 = load <8 x float>, ptr %50, align 4, !invariant.load !3, !alias.scope !7, !noalias !29
  %wide.load22 = load <8 x float>, ptr %51, align 4, !invariant.load !3, !alias.scope !7, !noalias !29
  %52 = fadd <8 x float> %48, %wide.load21
  %53 = fadd <8 x float> %49, %wide.load22
  %54 = fcmp ogt <8 x float> %52, zeroinitializer
  %55 = fcmp ogt <8 x float> %53, zeroinitializer
  %56 = zext <8 x i1> %54 to <8 x i32>
  %57 = zext <8 x i1> %55 to <8 x i32>
  %58 = add <8 x i32> %vec.phi10, %42
  %59 = add <8 x i32> %vec.phi11, %43
  %60 = add <8 x i32> %vec.phi, %56
  %61 = add <8 x i32> %vec.phi9, %57
  %index.next = or disjoint i64 %index, 16
  %62 = add nuw nsw i64 %28, %index.next
  %63 = getelementptr inbounds nuw float, ptr %12, i64 %62
  %64 = getelementptr inbounds nuw i8, ptr %63, i64 32
  %wide.load.1 = load <8 x float>, ptr %63, align 4, !invariant.load !3, !alias.scope !16, !noalias !24
  %wide.load12.1 = load <8 x float>, ptr %64, align 4, !invariant.load !3, !alias.scope !16, !noalias !24
  %65 = getelementptr inbounds nuw float, ptr %14, i64 %index.next
  %66 = getelementptr inbounds nuw i8, ptr %65, i64 32
  %wide.load13.1 = load <8 x float>, ptr %65, align 4, !invariant.load !3, !alias.scope !18, !noalias !25
  %wide.load14.1 = load <8 x float>, ptr %66, align 4, !invariant.load !3, !alias.scope !18, !noalias !25
  %67 = fmul <8 x float> %wide.load.1, %wide.load13.1
  %68 = fmul <8 x float> %wide.load12.1, %wide.load14.1
  %69 = getelementptr inbounds nuw float, ptr %10, i64 %index.next
  %70 = getelementptr inbounds nuw i8, ptr %69, i64 32
  %wide.load15.1 = load <8 x float>, ptr %69, align 4, !invariant.load !3, !alias.scope !14, !noalias !26
  %wide.load16.1 = load <8 x float>, ptr %70, align 4, !invariant.load !3, !alias.scope !14, !noalias !26
  %71 = fadd <8 x float> %67, %wide.load15.1
  %72 = fadd <8 x float> %68, %wide.load16.1
  %73 = fcmp ogt <8 x float> %71, zeroinitializer
  %74 = fcmp ogt <8 x float> %72, zeroinitializer
  %75 = zext <8 x i1> %73 to <8 x i32>
  %76 = zext <8 x i1> %74 to <8 x i32>
  %77 = getelementptr inbounds nuw float, ptr %6, i64 %62
  %78 = getelementptr inbounds nuw i8, ptr %77, i64 32
  %wide.load17.1 = load <8 x float>, ptr %77, align 4, !invariant.load !3, !alias.scope !10, !noalias !27
  %wide.load18.1 = load <8 x float>, ptr %78, align 4, !invariant.load !3, !alias.scope !10, !noalias !27
  %79 = getelementptr inbounds nuw float, ptr %8, i64 %index.next
  %80 = getelementptr inbounds nuw i8, ptr %79, i64 32
  %wide.load19.1 = load <8 x float>, ptr %79, align 4, !invariant.load !3, !alias.scope !12, !noalias !28
  %wide.load20.1 = load <8 x float>, ptr %80, align 4, !invariant.load !3, !alias.scope !12, !noalias !28
  %81 = fmul <8 x float> %wide.load17.1, %wide.load19.1
  %82 = fmul <8 x float> %wide.load18.1, %wide.load20.1
  %83 = getelementptr inbounds nuw float, ptr %4, i64 %index.next
  %84 = getelementptr inbounds nuw i8, ptr %83, i64 32
  %wide.load21.1 = load <8 x float>, ptr %83, align 4, !invariant.load !3, !alias.scope !7, !noalias !29
  %wide.load22.1 = load <8 x float>, ptr %84, align 4, !invariant.load !3, !alias.scope !7, !noalias !29
  %85 = fadd <8 x float> %81, %wide.load21.1
  %86 = fadd <8 x float> %82, %wide.load22.1
  %87 = fcmp ogt <8 x float> %85, zeroinitializer
  %88 = fcmp ogt <8 x float> %86, zeroinitializer
  %89 = zext <8 x i1> %87 to <8 x i32>
  %90 = zext <8 x i1> %88 to <8 x i32>
  %91 = add <8 x i32> %58, %75
  %92 = add <8 x i32> %59, %76
  %93 = add <8 x i32> %60, %89
  %94 = add <8 x i32> %61, %90
  %index.next.1 = add nuw nsw i64 %index, 32
  %95 = icmp eq i64 %index.next.1, 192
  br i1 %95, label %middle.block, label %vector.body, !llvm.loop !30

middle.block:                                     ; preds = %vector.body
  %bin.rdx23 = add <8 x i32> %92, %91
  %96 = tail call i32 @llvm.vector.reduce.add.v8i32(<8 x i32> %bin.rdx23)
  %bin.rdx = add <8 x i32> %94, %93
  %97 = tail call i32 @llvm.vector.reduce.add.v8i32(<8 x i32> %bin.rdx)
  %98 = add nuw nsw i64 %26, %24
  %99 = getelementptr inbounds nuw i32, ptr %16, i64 %98
  store i32 %96, ptr %99, align 4, !alias.scope !20, !noalias !33
  %100 = getelementptr inbounds nuw i32, ptr %18, i64 %98
  store i32 %97, ptr %100, align 4, !alias.scope !22, !noalias !34
  %101 = add nuw nsw i64 %26, 1
  %exitcond5.not = icmp eq i64 %101, 8
  br i1 %exitcond5.not, label %convert_reduce_fusion_wrapped.exit, label %vector.ph, !llvm.loop !35

convert_reduce_fusion_wrapped.exit:               ; preds = %middle.block, %1
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.vector.reduce.add.v8i32(<8 x i32>) #2

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #2 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 0}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 768}
!5 = !{i64 73728}
!6 = !{i64 384}
!7 = !{!8}
!8 = distinct !{!8, !9, !"convert_reduce_fusion_wrapped: argument 0"}
!9 = distinct !{!9, !"convert_reduce_fusion_wrapped"}
!10 = !{!11}
!11 = distinct !{!11, !9, !"convert_reduce_fusion_wrapped: argument 1"}
!12 = !{!13}
!13 = distinct !{!13, !9, !"convert_reduce_fusion_wrapped: argument 2"}
!14 = !{!15}
!15 = distinct !{!15, !9, !"convert_reduce_fusion_wrapped: argument 3"}
!16 = !{!17}
!17 = distinct !{!17, !9, !"convert_reduce_fusion_wrapped: argument 4"}
!18 = !{!19}
!19 = distinct !{!19, !9, !"convert_reduce_fusion_wrapped: argument 5"}
!20 = !{!21}
!21 = distinct !{!21, !9, !"convert_reduce_fusion_wrapped: argument 6"}
!22 = !{!23}
!23 = distinct !{!23, !9, !"convert_reduce_fusion_wrapped: argument 7"}
!24 = !{!8, !11, !13, !15, !19, !21, !23}
!25 = !{!8, !11, !13, !15, !17, !21, !23}
!26 = !{!8, !11, !13, !17, !19, !21, !23}
!27 = !{!8, !13, !15, !17, !19, !21, !23}
!28 = !{!8, !11, !15, !17, !19, !21, !23}
!29 = !{!11, !13, !15, !17, !19, !21, !23}
!30 = distinct !{!30, !31, !32}
!31 = !{!"llvm.loop.isvectorized", i32 1}
!32 = !{!"llvm.loop.unroll.runtime.disable"}
!33 = !{!8, !11, !13, !15, !17, !19, !23}
!34 = !{!8, !11, !13, !15, !17, !19, !21}
!35 = distinct !{!35, !36}
!36 = !{!"llvm.loop.unroll.disable"}
