; ModuleID = '__compute_module_wrapped_reduce-window_kernel_module'
source_filename = "__compute_module_wrapped_reduce-window_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @wrapped_reduce-window(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !5
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !6
  tail call void @llvm.experimental.noalias.scope.decl(metadata !7)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !10)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !12)
  %9 = load float, ptr %6, align 4, !invariant.load !3, !alias.scope !10, !noalias !14
  %broadcast.splatinsert = insertelement <8 x float> poison, float %9, i64 0
  %broadcast.splat = shufflevector <8 x float> %broadcast.splatinsert, <8 x float> poison, <8 x i32> zeroinitializer
  br label %.preheader3

.preheader3:                                      ; preds = %1, %middle.block
  %10 = phi i64 [ 0, %1 ], [ %80, %middle.block ]
  %.idx1 = mul nuw nsw i64 %10, 3072
  %11 = getelementptr i8, ptr %4, i64 %.idx1
  %.idx = mul nuw nsw i64 %10, 96
  %12 = getelementptr i8, ptr %8, i64 %.idx
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %.preheader3
  %index = phi i64 [ 0, %.preheader3 ], [ %index.next, %vector.body ]
  %vec.ind = phi <8 x i64> [ <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>, %.preheader3 ], [ %vec.ind.next, %vector.body ]
  %13 = shl <8 x i64> %vec.ind, splat (i64 7)
  %14 = getelementptr i8, ptr %11, <8 x i64> %13
  %wide.masked.gather = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %14, <8 x i1> splat (i1 true), <8 x float> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %15 = fadd reassoc <8 x float> %broadcast.splat, %wide.masked.gather
  %16 = getelementptr i8, <8 x ptr> %14, i64 4
  %wide.masked.gather5 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %16, <8 x i1> splat (i1 true), <8 x float> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %17 = fadd reassoc <8 x float> %15, %wide.masked.gather5
  %18 = getelementptr i8, <8 x ptr> %14, i64 8
  %wide.masked.gather6 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %18, <8 x i1> splat (i1 true), <8 x float> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %19 = fadd reassoc <8 x float> %17, %wide.masked.gather6
  %20 = getelementptr i8, <8 x ptr> %14, i64 12
  %wide.masked.gather7 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %20, <8 x i1> splat (i1 true), <8 x float> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %21 = fadd reassoc <8 x float> %19, %wide.masked.gather7
  %22 = getelementptr i8, <8 x ptr> %14, i64 16
  %wide.masked.gather8 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %22, <8 x i1> splat (i1 true), <8 x float> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %23 = fadd reassoc <8 x float> %21, %wide.masked.gather8
  %24 = getelementptr i8, <8 x ptr> %14, i64 20
  %wide.masked.gather9 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %24, <8 x i1> splat (i1 true), <8 x float> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %25 = fadd reassoc <8 x float> %23, %wide.masked.gather9
  %26 = getelementptr i8, <8 x ptr> %14, i64 24
  %wide.masked.gather10 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %26, <8 x i1> splat (i1 true), <8 x float> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %27 = fadd reassoc <8 x float> %25, %wide.masked.gather10
  %28 = getelementptr i8, <8 x ptr> %14, i64 28
  %wide.masked.gather11 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %28, <8 x i1> splat (i1 true), <8 x float> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %29 = fadd reassoc <8 x float> %27, %wide.masked.gather11
  %30 = getelementptr i8, <8 x ptr> %14, i64 32
  %wide.masked.gather12 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %30, <8 x i1> splat (i1 true), <8 x float> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %31 = fadd reassoc <8 x float> %29, %wide.masked.gather12
  %32 = getelementptr i8, <8 x ptr> %14, i64 36
  %wide.masked.gather13 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %32, <8 x i1> splat (i1 true), <8 x float> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %33 = fadd reassoc <8 x float> %31, %wide.masked.gather13
  %34 = getelementptr i8, <8 x ptr> %14, i64 40
  %wide.masked.gather14 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %34, <8 x i1> splat (i1 true), <8 x float> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %35 = fadd reassoc <8 x float> %33, %wide.masked.gather14
  %36 = getelementptr i8, <8 x ptr> %14, i64 44
  %wide.masked.gather15 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %36, <8 x i1> splat (i1 true), <8 x float> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %37 = fadd reassoc <8 x float> %35, %wide.masked.gather15
  %38 = getelementptr i8, <8 x ptr> %14, i64 48
  %wide.masked.gather16 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %38, <8 x i1> splat (i1 true), <8 x float> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %39 = fadd reassoc <8 x float> %37, %wide.masked.gather16
  %40 = getelementptr i8, <8 x ptr> %14, i64 52
  %wide.masked.gather17 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %40, <8 x i1> splat (i1 true), <8 x float> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %41 = fadd reassoc <8 x float> %39, %wide.masked.gather17
  %42 = getelementptr i8, <8 x ptr> %14, i64 56
  %wide.masked.gather18 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %42, <8 x i1> splat (i1 true), <8 x float> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %43 = fadd reassoc <8 x float> %41, %wide.masked.gather18
  %44 = getelementptr i8, <8 x ptr> %14, i64 60
  %wide.masked.gather19 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %44, <8 x i1> splat (i1 true), <8 x float> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %45 = fadd reassoc <8 x float> %43, %wide.masked.gather19
  %46 = getelementptr i8, <8 x ptr> %14, i64 64
  %wide.masked.gather20 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %46, <8 x i1> splat (i1 true), <8 x float> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %47 = fadd reassoc <8 x float> %45, %wide.masked.gather20
  %48 = getelementptr i8, <8 x ptr> %14, i64 68
  %wide.masked.gather21 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %48, <8 x i1> splat (i1 true), <8 x float> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %49 = fadd reassoc <8 x float> %47, %wide.masked.gather21
  %50 = getelementptr i8, <8 x ptr> %14, i64 72
  %wide.masked.gather22 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %50, <8 x i1> splat (i1 true), <8 x float> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %51 = fadd reassoc <8 x float> %49, %wide.masked.gather22
  %52 = getelementptr i8, <8 x ptr> %14, i64 76
  %wide.masked.gather23 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %52, <8 x i1> splat (i1 true), <8 x float> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %53 = fadd reassoc <8 x float> %51, %wide.masked.gather23
  %54 = getelementptr i8, <8 x ptr> %14, i64 80
  %wide.masked.gather24 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %54, <8 x i1> splat (i1 true), <8 x float> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %55 = fadd reassoc <8 x float> %53, %wide.masked.gather24
  %56 = getelementptr i8, <8 x ptr> %14, i64 84
  %wide.masked.gather25 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %56, <8 x i1> splat (i1 true), <8 x float> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %57 = fadd reassoc <8 x float> %55, %wide.masked.gather25
  %58 = getelementptr i8, <8 x ptr> %14, i64 88
  %wide.masked.gather26 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %58, <8 x i1> splat (i1 true), <8 x float> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %59 = fadd reassoc <8 x float> %57, %wide.masked.gather26
  %60 = getelementptr i8, <8 x ptr> %14, i64 92
  %wide.masked.gather27 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %60, <8 x i1> splat (i1 true), <8 x float> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %61 = fadd reassoc <8 x float> %59, %wide.masked.gather27
  %62 = getelementptr i8, <8 x ptr> %14, i64 96
  %wide.masked.gather28 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %62, <8 x i1> splat (i1 true), <8 x float> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %63 = fadd reassoc <8 x float> %61, %wide.masked.gather28
  %64 = getelementptr i8, <8 x ptr> %14, i64 100
  %wide.masked.gather29 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %64, <8 x i1> splat (i1 true), <8 x float> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %65 = fadd reassoc <8 x float> %63, %wide.masked.gather29
  %66 = getelementptr i8, <8 x ptr> %14, i64 104
  %wide.masked.gather30 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %66, <8 x i1> splat (i1 true), <8 x float> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %67 = fadd reassoc <8 x float> %65, %wide.masked.gather30
  %68 = getelementptr i8, <8 x ptr> %14, i64 108
  %wide.masked.gather31 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %68, <8 x i1> splat (i1 true), <8 x float> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %69 = fadd reassoc <8 x float> %67, %wide.masked.gather31
  %70 = getelementptr i8, <8 x ptr> %14, i64 112
  %wide.masked.gather32 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %70, <8 x i1> splat (i1 true), <8 x float> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %71 = fadd reassoc <8 x float> %69, %wide.masked.gather32
  %72 = getelementptr i8, <8 x ptr> %14, i64 116
  %wide.masked.gather33 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %72, <8 x i1> splat (i1 true), <8 x float> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %73 = fadd reassoc <8 x float> %71, %wide.masked.gather33
  %74 = getelementptr i8, <8 x ptr> %14, i64 120
  %wide.masked.gather34 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %74, <8 x i1> splat (i1 true), <8 x float> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %75 = fadd reassoc <8 x float> %73, %wide.masked.gather34
  %76 = getelementptr i8, <8 x ptr> %14, i64 124
  %wide.masked.gather35 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %76, <8 x i1> splat (i1 true), <8 x float> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %77 = fadd reassoc <8 x float> %75, %wide.masked.gather35
  %78 = getelementptr float, ptr %12, i64 %index
  store <8 x float> %77, ptr %78, align 4, !alias.scope !12, !noalias !16
  %index.next = add nuw i64 %index, 8
  %vec.ind.next = add nuw nsw <8 x i64> %vec.ind, splat (i64 8)
  %79 = icmp eq i64 %index.next, 24
  br i1 %79, label %middle.block, label %vector.body, !llvm.loop !17

middle.block:                                     ; preds = %vector.body
  %80 = add nuw nsw i64 %10, 1
  %exitcond4.not = icmp eq i64 %80, 1024
  br i1 %exitcond4.not, label %wrapped_reduce-window_wrapped.exit, label %.preheader3, !llvm.loop !21

wrapped_reduce-window_wrapped.exit:               ; preds = %middle.block
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr>, <8 x i1>, <8 x float>) #2

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(read) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 3}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 3145728}
!5 = !{i64 4}
!6 = !{i64 98304}
!7 = !{!8}
!8 = distinct !{!8, !9, !"wrapped_reduce-window_wrapped: argument 0"}
!9 = distinct !{!9, !"wrapped_reduce-window_wrapped"}
!10 = !{!11}
!11 = distinct !{!11, !9, !"wrapped_reduce-window_wrapped: argument 1"}
!12 = !{!13}
!13 = distinct !{!13, !9, !"wrapped_reduce-window_wrapped: argument 2"}
!14 = !{!8, !13}
!15 = !{!11, !13}
!16 = !{!8, !11}
!17 = distinct !{!17, !18, !19, !20}
!18 = !{!"llvm.loop.unroll.disable"}
!19 = !{!"llvm.loop.isvectorized", i32 1}
!20 = !{!"llvm.loop.unroll.runtime.disable"}
!21 = distinct !{!21, !18}
