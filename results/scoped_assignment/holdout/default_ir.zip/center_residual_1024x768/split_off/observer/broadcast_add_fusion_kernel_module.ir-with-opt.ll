; ModuleID = '__compute_module_broadcast_add_fusion_kernel_module'
source_filename = "__compute_module_broadcast_add_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @broadcast_add_fusion(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !5
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !4
  %9 = getelementptr inbounds nuw i8, ptr %3, i64 48
  %10 = load ptr, ptr %9, align 8, !invariant.load !3, !dereferenceable !5
  tail call void @llvm.experimental.noalias.scope.decl(metadata !6)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !11)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !13)
  br label %vector.ph

vector.ph:                                        ; preds = %1, %middle.block
  %11 = phi i64 [ 0, %1 ], [ %66, %middle.block ]
  %12 = mul nuw nsw i64 %11, 768
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %vector.ph
  %index = phi i64 [ 0, %vector.ph ], [ %index.next.3, %vector.body ]
  %13 = add nuw nsw i64 %index, %12
  %14 = getelementptr inbounds nuw float, ptr %6, i64 %13
  %15 = getelementptr inbounds nuw i8, ptr %14, i64 32
  %wide.load = load <8 x float>, ptr %14, align 4, !invariant.load !3, !alias.scope !9, !noalias !15
  %wide.load3 = load <8 x float>, ptr %15, align 4, !invariant.load !3, !alias.scope !9, !noalias !15
  %16 = getelementptr inbounds nuw float, ptr %8, i64 %index
  %17 = getelementptr inbounds nuw i8, ptr %16, i64 32
  %wide.load4 = load <8 x float>, ptr %16, align 4, !invariant.load !3, !alias.scope !11, !noalias !16
  %wide.load5 = load <8 x float>, ptr %17, align 4, !invariant.load !3, !alias.scope !11, !noalias !16
  %18 = fmul <8 x float> %wide.load, %wide.load4
  %19 = fmul <8 x float> %wide.load3, %wide.load5
  %20 = getelementptr inbounds nuw float, ptr %4, i64 %index
  %21 = getelementptr inbounds nuw i8, ptr %20, i64 32
  %wide.load6 = load <8 x float>, ptr %20, align 4, !invariant.load !3, !alias.scope !6, !noalias !17
  %wide.load7 = load <8 x float>, ptr %21, align 4, !invariant.load !3, !alias.scope !6, !noalias !17
  %22 = fadd <8 x float> %18, %wide.load6
  %23 = fadd <8 x float> %19, %wide.load7
  %24 = getelementptr inbounds nuw float, ptr %10, i64 %13
  %25 = getelementptr inbounds nuw i8, ptr %24, i64 32
  store <8 x float> %22, ptr %24, align 4, !alias.scope !13, !noalias !18
  store <8 x float> %23, ptr %25, align 4, !alias.scope !13, !noalias !18
  %index.next = or disjoint i64 %index, 16
  %26 = add nuw nsw i64 %index.next, %12
  %27 = getelementptr inbounds nuw float, ptr %6, i64 %26
  %28 = getelementptr inbounds nuw i8, ptr %27, i64 32
  %wide.load.1 = load <8 x float>, ptr %27, align 4, !invariant.load !3, !alias.scope !9, !noalias !15
  %wide.load3.1 = load <8 x float>, ptr %28, align 4, !invariant.load !3, !alias.scope !9, !noalias !15
  %29 = getelementptr inbounds nuw float, ptr %8, i64 %index.next
  %30 = getelementptr inbounds nuw i8, ptr %29, i64 32
  %wide.load4.1 = load <8 x float>, ptr %29, align 4, !invariant.load !3, !alias.scope !11, !noalias !16
  %wide.load5.1 = load <8 x float>, ptr %30, align 4, !invariant.load !3, !alias.scope !11, !noalias !16
  %31 = fmul <8 x float> %wide.load.1, %wide.load4.1
  %32 = fmul <8 x float> %wide.load3.1, %wide.load5.1
  %33 = getelementptr inbounds nuw float, ptr %4, i64 %index.next
  %34 = getelementptr inbounds nuw i8, ptr %33, i64 32
  %wide.load6.1 = load <8 x float>, ptr %33, align 4, !invariant.load !3, !alias.scope !6, !noalias !17
  %wide.load7.1 = load <8 x float>, ptr %34, align 4, !invariant.load !3, !alias.scope !6, !noalias !17
  %35 = fadd <8 x float> %31, %wide.load6.1
  %36 = fadd <8 x float> %32, %wide.load7.1
  %37 = getelementptr inbounds nuw float, ptr %10, i64 %26
  %38 = getelementptr inbounds nuw i8, ptr %37, i64 32
  store <8 x float> %35, ptr %37, align 4, !alias.scope !13, !noalias !18
  store <8 x float> %36, ptr %38, align 4, !alias.scope !13, !noalias !18
  %index.next.1 = or disjoint i64 %index, 32
  %39 = add nuw nsw i64 %index.next.1, %12
  %40 = getelementptr inbounds nuw float, ptr %6, i64 %39
  %41 = getelementptr inbounds nuw i8, ptr %40, i64 32
  %wide.load.2 = load <8 x float>, ptr %40, align 4, !invariant.load !3, !alias.scope !9, !noalias !15
  %wide.load3.2 = load <8 x float>, ptr %41, align 4, !invariant.load !3, !alias.scope !9, !noalias !15
  %42 = getelementptr inbounds nuw float, ptr %8, i64 %index.next.1
  %43 = getelementptr inbounds nuw i8, ptr %42, i64 32
  %wide.load4.2 = load <8 x float>, ptr %42, align 4, !invariant.load !3, !alias.scope !11, !noalias !16
  %wide.load5.2 = load <8 x float>, ptr %43, align 4, !invariant.load !3, !alias.scope !11, !noalias !16
  %44 = fmul <8 x float> %wide.load.2, %wide.load4.2
  %45 = fmul <8 x float> %wide.load3.2, %wide.load5.2
  %46 = getelementptr inbounds nuw float, ptr %4, i64 %index.next.1
  %47 = getelementptr inbounds nuw i8, ptr %46, i64 32
  %wide.load6.2 = load <8 x float>, ptr %46, align 4, !invariant.load !3, !alias.scope !6, !noalias !17
  %wide.load7.2 = load <8 x float>, ptr %47, align 4, !invariant.load !3, !alias.scope !6, !noalias !17
  %48 = fadd <8 x float> %44, %wide.load6.2
  %49 = fadd <8 x float> %45, %wide.load7.2
  %50 = getelementptr inbounds nuw float, ptr %10, i64 %39
  %51 = getelementptr inbounds nuw i8, ptr %50, i64 32
  store <8 x float> %48, ptr %50, align 4, !alias.scope !13, !noalias !18
  store <8 x float> %49, ptr %51, align 4, !alias.scope !13, !noalias !18
  %index.next.2 = or disjoint i64 %index, 48
  %52 = add nuw nsw i64 %index.next.2, %12
  %53 = getelementptr inbounds nuw float, ptr %6, i64 %52
  %54 = getelementptr inbounds nuw i8, ptr %53, i64 32
  %wide.load.3 = load <8 x float>, ptr %53, align 4, !invariant.load !3, !alias.scope !9, !noalias !15
  %wide.load3.3 = load <8 x float>, ptr %54, align 4, !invariant.load !3, !alias.scope !9, !noalias !15
  %55 = getelementptr inbounds nuw float, ptr %8, i64 %index.next.2
  %56 = getelementptr inbounds nuw i8, ptr %55, i64 32
  %wide.load4.3 = load <8 x float>, ptr %55, align 4, !invariant.load !3, !alias.scope !11, !noalias !16
  %wide.load5.3 = load <8 x float>, ptr %56, align 4, !invariant.load !3, !alias.scope !11, !noalias !16
  %57 = fmul <8 x float> %wide.load.3, %wide.load4.3
  %58 = fmul <8 x float> %wide.load3.3, %wide.load5.3
  %59 = getelementptr inbounds nuw float, ptr %4, i64 %index.next.2
  %60 = getelementptr inbounds nuw i8, ptr %59, i64 32
  %wide.load6.3 = load <8 x float>, ptr %59, align 4, !invariant.load !3, !alias.scope !6, !noalias !17
  %wide.load7.3 = load <8 x float>, ptr %60, align 4, !invariant.load !3, !alias.scope !6, !noalias !17
  %61 = fadd <8 x float> %57, %wide.load6.3
  %62 = fadd <8 x float> %58, %wide.load7.3
  %63 = getelementptr inbounds nuw float, ptr %10, i64 %52
  %64 = getelementptr inbounds nuw i8, ptr %63, i64 32
  store <8 x float> %61, ptr %63, align 4, !alias.scope !13, !noalias !18
  store <8 x float> %62, ptr %64, align 4, !alias.scope !13, !noalias !18
  %index.next.3 = add nuw nsw i64 %index, 64
  %65 = icmp eq i64 %index.next.3, 768
  br i1 %65, label %middle.block, label %vector.body, !llvm.loop !19

middle.block:                                     ; preds = %vector.body
  %66 = add nuw nsw i64 %11, 1
  %exitcond2.not = icmp eq i64 %66, 1024
  br i1 %exitcond2.not, label %broadcast_add_fusion_wrapped.exit, label %vector.ph, !llvm.loop !22

broadcast_add_fusion_wrapped.exit:                ; preds = %middle.block
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 0}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 3072}
!5 = !{i64 3145728}
!6 = !{!7}
!7 = distinct !{!7, !8, !"broadcast_add_fusion_wrapped: argument 0"}
!8 = distinct !{!8, !"broadcast_add_fusion_wrapped"}
!9 = !{!10}
!10 = distinct !{!10, !8, !"broadcast_add_fusion_wrapped: argument 1"}
!11 = !{!12}
!12 = distinct !{!12, !8, !"broadcast_add_fusion_wrapped: argument 2"}
!13 = !{!14}
!14 = distinct !{!14, !8, !"broadcast_add_fusion_wrapped: argument 3"}
!15 = !{!7, !12, !14}
!16 = !{!7, !10, !14}
!17 = !{!10, !12, !14}
!18 = !{!7, !10, !12}
!19 = distinct !{!19, !20, !21}
!20 = !{!"llvm.loop.isvectorized", i32 1}
!21 = !{!"llvm.loop.unroll.runtime.disable"}
!22 = distinct !{!22, !23}
!23 = !{!"llvm.loop.unroll.disable"}
