; ModuleID = '__compute_module_add_maximum_fusion_kernel_module'
source_filename = "__compute_module_add_maximum_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @add_maximum_fusion(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !5
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !5
  %9 = getelementptr inbounds nuw i8, ptr %3, i64 64
  %10 = load ptr, ptr %9, align 8, !invariant.load !3, !dereferenceable !5
  %11 = getelementptr inbounds nuw i8, ptr %3, i64 80
  %12 = load ptr, ptr %11, align 8, !invariant.load !3, !dereferenceable !5
  %13 = getelementptr inbounds nuw i8, ptr %3, i64 96
  %14 = load ptr, ptr %13, align 8, !invariant.load !3, !dereferenceable !4
  %15 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %16 = load ptr, ptr %15, align 8
  %17 = load i64, ptr %16, align 4, !invariant.load !3
  tail call void @llvm.experimental.noalias.scope.decl(metadata !6)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !11)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !13)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !15)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !17)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !19)
  %18 = icmp ult i64 %17, 4
  br i1 %18, label %19, label %add_maximum_fusion_wrapped.exit

19:                                               ; preds = %1
  %20 = getelementptr inbounds nuw i8, ptr %3, i64 48
  %21 = load ptr, ptr %20, align 8, !invariant.load !3, !dereferenceable !21
  %22 = mul nuw nsw i64 %17, 196608
  %.idx = shl nuw nsw i64 %17, 10
  %23 = getelementptr i8, ptr %21, i64 %.idx
  br label %vector.ph

vector.ph:                                        ; preds = %19, %middle.block
  %24 = phi i64 [ 0, %19 ], [ %89, %middle.block ]
  %25 = mul nuw nsw i64 %24, 768
  %26 = add nuw nsw i64 %25, %22
  %27 = getelementptr float, ptr %23, i64 %24
  %28 = load float, ptr %27, align 4, !invariant.load !3, !alias.scope !13, !noalias !22
  %29 = fmul float %28, 0x3F55555560000000
  %broadcast.splatinsert = insertelement <8 x float> poison, float %29, i64 0
  %broadcast.splat = shufflevector <8 x float> %broadcast.splatinsert, <8 x float> poison, <8 x i32> zeroinitializer
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %vector.ph
  %index = phi i64 [ 0, %vector.ph ], [ %index.next.1, %vector.body ]
  %30 = getelementptr inbounds nuw float, ptr %12, i64 %index
  %31 = getelementptr inbounds nuw i8, ptr %30, i64 32
  %wide.load = load <8 x float>, ptr %30, align 4, !invariant.load !3, !alias.scope !17, !noalias !23
  %wide.load5 = load <8 x float>, ptr %31, align 4, !invariant.load !3, !alias.scope !17, !noalias !23
  %32 = add nuw nsw i64 %26, %index
  %33 = getelementptr inbounds nuw float, ptr %4, i64 %32
  %34 = getelementptr inbounds nuw i8, ptr %33, i64 32
  %wide.load6 = load <8 x float>, ptr %33, align 4, !invariant.load !3, !alias.scope !6, !noalias !24
  %wide.load7 = load <8 x float>, ptr %34, align 4, !invariant.load !3, !alias.scope !6, !noalias !24
  %35 = fmul <8 x float> %wide.load, %wide.load6
  %36 = fmul <8 x float> %wide.load5, %wide.load7
  %37 = getelementptr inbounds nuw float, ptr %10, i64 %index
  %38 = getelementptr inbounds nuw i8, ptr %37, i64 32
  %wide.load8 = load <8 x float>, ptr %37, align 4, !invariant.load !3, !alias.scope !15, !noalias !25
  %wide.load9 = load <8 x float>, ptr %38, align 4, !invariant.load !3, !alias.scope !15, !noalias !25
  %39 = fadd <8 x float> %35, %wide.load8
  %40 = fadd <8 x float> %36, %wide.load9
  %41 = fsub <8 x float> %39, %broadcast.splat
  %42 = fsub <8 x float> %40, %broadcast.splat
  %43 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %41, <8 x float> zeroinitializer)
  %44 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %42, <8 x float> zeroinitializer)
  %45 = getelementptr inbounds nuw float, ptr %8, i64 %index
  %46 = getelementptr inbounds nuw i8, ptr %45, i64 32
  %wide.load10 = load <8 x float>, ptr %45, align 4, !invariant.load !3, !alias.scope !11, !noalias !26
  %wide.load11 = load <8 x float>, ptr %46, align 4, !invariant.load !3, !alias.scope !11, !noalias !26
  %47 = fmul <8 x float> %wide.load10, %43
  %48 = fmul <8 x float> %wide.load11, %44
  %49 = getelementptr inbounds nuw float, ptr %6, i64 %index
  %50 = getelementptr inbounds nuw i8, ptr %49, i64 32
  %wide.load12 = load <8 x float>, ptr %49, align 4, !invariant.load !3, !alias.scope !9, !noalias !27
  %wide.load13 = load <8 x float>, ptr %50, align 4, !invariant.load !3, !alias.scope !9, !noalias !27
  %51 = fadd <8 x float> %wide.load12, %47
  %52 = fadd <8 x float> %wide.load13, %48
  %53 = fadd <8 x float> %wide.load6, %51
  %54 = fadd <8 x float> %wide.load7, %52
  %55 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %53, <8 x float> zeroinitializer)
  %56 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %54, <8 x float> zeroinitializer)
  %57 = getelementptr inbounds nuw float, ptr %14, i64 %32
  %58 = getelementptr inbounds nuw i8, ptr %57, i64 32
  store <8 x float> %55, ptr %57, align 4, !alias.scope !19, !noalias !28
  store <8 x float> %56, ptr %58, align 4, !alias.scope !19, !noalias !28
  %index.next = or disjoint i64 %index, 16
  %59 = getelementptr inbounds nuw float, ptr %12, i64 %index.next
  %60 = getelementptr inbounds nuw i8, ptr %59, i64 32
  %wide.load.1 = load <8 x float>, ptr %59, align 4, !invariant.load !3, !alias.scope !17, !noalias !23
  %wide.load5.1 = load <8 x float>, ptr %60, align 4, !invariant.load !3, !alias.scope !17, !noalias !23
  %61 = add nuw nsw i64 %26, %index.next
  %62 = getelementptr inbounds nuw float, ptr %4, i64 %61
  %63 = getelementptr inbounds nuw i8, ptr %62, i64 32
  %wide.load6.1 = load <8 x float>, ptr %62, align 4, !invariant.load !3, !alias.scope !6, !noalias !24
  %wide.load7.1 = load <8 x float>, ptr %63, align 4, !invariant.load !3, !alias.scope !6, !noalias !24
  %64 = fmul <8 x float> %wide.load.1, %wide.load6.1
  %65 = fmul <8 x float> %wide.load5.1, %wide.load7.1
  %66 = getelementptr inbounds nuw float, ptr %10, i64 %index.next
  %67 = getelementptr inbounds nuw i8, ptr %66, i64 32
  %wide.load8.1 = load <8 x float>, ptr %66, align 4, !invariant.load !3, !alias.scope !15, !noalias !25
  %wide.load9.1 = load <8 x float>, ptr %67, align 4, !invariant.load !3, !alias.scope !15, !noalias !25
  %68 = fadd <8 x float> %64, %wide.load8.1
  %69 = fadd <8 x float> %65, %wide.load9.1
  %70 = fsub <8 x float> %68, %broadcast.splat
  %71 = fsub <8 x float> %69, %broadcast.splat
  %72 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %70, <8 x float> zeroinitializer)
  %73 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %71, <8 x float> zeroinitializer)
  %74 = getelementptr inbounds nuw float, ptr %8, i64 %index.next
  %75 = getelementptr inbounds nuw i8, ptr %74, i64 32
  %wide.load10.1 = load <8 x float>, ptr %74, align 4, !invariant.load !3, !alias.scope !11, !noalias !26
  %wide.load11.1 = load <8 x float>, ptr %75, align 4, !invariant.load !3, !alias.scope !11, !noalias !26
  %76 = fmul <8 x float> %wide.load10.1, %72
  %77 = fmul <8 x float> %wide.load11.1, %73
  %78 = getelementptr inbounds nuw float, ptr %6, i64 %index.next
  %79 = getelementptr inbounds nuw i8, ptr %78, i64 32
  %wide.load12.1 = load <8 x float>, ptr %78, align 4, !invariant.load !3, !alias.scope !9, !noalias !27
  %wide.load13.1 = load <8 x float>, ptr %79, align 4, !invariant.load !3, !alias.scope !9, !noalias !27
  %80 = fadd <8 x float> %wide.load12.1, %76
  %81 = fadd <8 x float> %wide.load13.1, %77
  %82 = fadd <8 x float> %wide.load6.1, %80
  %83 = fadd <8 x float> %wide.load7.1, %81
  %84 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %82, <8 x float> zeroinitializer)
  %85 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %83, <8 x float> zeroinitializer)
  %86 = getelementptr inbounds nuw float, ptr %14, i64 %61
  %87 = getelementptr inbounds nuw i8, ptr %86, i64 32
  store <8 x float> %84, ptr %86, align 4, !alias.scope !19, !noalias !28
  store <8 x float> %85, ptr %87, align 4, !alias.scope !19, !noalias !28
  %index.next.1 = add nuw nsw i64 %index, 32
  %88 = icmp eq i64 %index.next.1, 768
  br i1 %88, label %middle.block, label %vector.body, !llvm.loop !29

middle.block:                                     ; preds = %vector.body
  %89 = add nuw nsw i64 %24, 1
  %exitcond3.not = icmp eq i64 %89, 256
  br i1 %exitcond3.not, label %add_maximum_fusion_wrapped.exit, label %vector.ph, !llvm.loop !32

add_maximum_fusion_wrapped.exit:                  ; preds = %middle.block, %1
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.maximum.v8f32(<8 x float>, <8 x float>) #2

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 0}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 3145728}
!5 = !{i64 3072}
!6 = !{!7}
!7 = distinct !{!7, !8, !"add_maximum_fusion_wrapped: argument 0"}
!8 = distinct !{!8, !"add_maximum_fusion_wrapped"}
!9 = !{!10}
!10 = distinct !{!10, !8, !"add_maximum_fusion_wrapped: argument 1"}
!11 = !{!12}
!12 = distinct !{!12, !8, !"add_maximum_fusion_wrapped: argument 2"}
!13 = !{!14}
!14 = distinct !{!14, !8, !"add_maximum_fusion_wrapped: argument 3"}
!15 = !{!16}
!16 = distinct !{!16, !8, !"add_maximum_fusion_wrapped: argument 4"}
!17 = !{!18}
!18 = distinct !{!18, !8, !"add_maximum_fusion_wrapped: argument 5"}
!19 = !{!20}
!20 = distinct !{!20, !8, !"add_maximum_fusion_wrapped: argument 6"}
!21 = !{i64 4096}
!22 = !{!7, !10, !12, !16, !18, !20}
!23 = !{!7, !10, !12, !14, !16, !20}
!24 = !{!10, !12, !14, !16, !18, !20}
!25 = !{!7, !10, !12, !14, !18, !20}
!26 = !{!7, !10, !14, !16, !18, !20}
!27 = !{!7, !12, !14, !16, !18, !20}
!28 = !{!7, !10, !12, !14, !16, !18}
!29 = distinct !{!29, !30, !31}
!30 = !{!"llvm.loop.isvectorized", i32 1}
!31 = !{!"llvm.loop.unroll.runtime.disable"}
!32 = distinct !{!32, !33}
!33 = !{!"llvm.loop.unroll.disable"}
