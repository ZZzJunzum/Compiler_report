; ModuleID = '__compute_module_broadcast_add_fusion_kernel_module'
source_filename = "__compute_module_broadcast_add_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @broadcast_add_fusion(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !5
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !4
  %9 = getelementptr inbounds nuw i8, ptr %3, i64 48
  %10 = load ptr, ptr %9, align 8, !invariant.load !3, !dereferenceable !5
  %11 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %12 = load ptr, ptr %11, align 8
  %13 = load i64, ptr %12, align 4, !invariant.load !3
  tail call void @llvm.experimental.noalias.scope.decl(metadata !6)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !11)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !13)
  %14 = icmp ult i64 %13, 4
  br i1 %14, label %15, label %broadcast_add_fusion_wrapped.exit

15:                                               ; preds = %1
  %16 = mul nuw nsw i64 %13, 196608
  br label %vector.ph

vector.ph:                                        ; preds = %15, %middle.block
  %17 = phi i64 [ 0, %15 ], [ %73, %middle.block ]
  %18 = mul nuw nsw i64 %17, 768
  %19 = add nuw nsw i64 %18, %16
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %vector.ph
  %index = phi i64 [ 0, %vector.ph ], [ %index.next.3, %vector.body ]
  %20 = add nuw nsw i64 %19, %index
  %21 = getelementptr inbounds nuw float, ptr %6, i64 %20
  %22 = getelementptr inbounds nuw i8, ptr %21, i64 32
  %wide.load = load <8 x float>, ptr %21, align 4, !invariant.load !3, !alias.scope !9, !noalias !15
  %wide.load5 = load <8 x float>, ptr %22, align 4, !invariant.load !3, !alias.scope !9, !noalias !15
  %23 = getelementptr inbounds nuw float, ptr %8, i64 %index
  %24 = getelementptr inbounds nuw i8, ptr %23, i64 32
  %wide.load6 = load <8 x float>, ptr %23, align 4, !invariant.load !3, !alias.scope !11, !noalias !16
  %wide.load7 = load <8 x float>, ptr %24, align 4, !invariant.load !3, !alias.scope !11, !noalias !16
  %25 = fmul <8 x float> %wide.load, %wide.load6
  %26 = fmul <8 x float> %wide.load5, %wide.load7
  %27 = getelementptr inbounds nuw float, ptr %4, i64 %index
  %28 = getelementptr inbounds nuw i8, ptr %27, i64 32
  %wide.load8 = load <8 x float>, ptr %27, align 4, !invariant.load !3, !alias.scope !6, !noalias !17
  %wide.load9 = load <8 x float>, ptr %28, align 4, !invariant.load !3, !alias.scope !6, !noalias !17
  %29 = fadd <8 x float> %25, %wide.load8
  %30 = fadd <8 x float> %26, %wide.load9
  %31 = getelementptr inbounds nuw float, ptr %10, i64 %20
  %32 = getelementptr inbounds nuw i8, ptr %31, i64 32
  store <8 x float> %29, ptr %31, align 4, !alias.scope !13, !noalias !18
  store <8 x float> %30, ptr %32, align 4, !alias.scope !13, !noalias !18
  %index.next = or disjoint i64 %index, 16
  %33 = add nuw nsw i64 %19, %index.next
  %34 = getelementptr inbounds nuw float, ptr %6, i64 %33
  %35 = getelementptr inbounds nuw i8, ptr %34, i64 32
  %wide.load.1 = load <8 x float>, ptr %34, align 4, !invariant.load !3, !alias.scope !9, !noalias !15
  %wide.load5.1 = load <8 x float>, ptr %35, align 4, !invariant.load !3, !alias.scope !9, !noalias !15
  %36 = getelementptr inbounds nuw float, ptr %8, i64 %index.next
  %37 = getelementptr inbounds nuw i8, ptr %36, i64 32
  %wide.load6.1 = load <8 x float>, ptr %36, align 4, !invariant.load !3, !alias.scope !11, !noalias !16
  %wide.load7.1 = load <8 x float>, ptr %37, align 4, !invariant.load !3, !alias.scope !11, !noalias !16
  %38 = fmul <8 x float> %wide.load.1, %wide.load6.1
  %39 = fmul <8 x float> %wide.load5.1, %wide.load7.1
  %40 = getelementptr inbounds nuw float, ptr %4, i64 %index.next
  %41 = getelementptr inbounds nuw i8, ptr %40, i64 32
  %wide.load8.1 = load <8 x float>, ptr %40, align 4, !invariant.load !3, !alias.scope !6, !noalias !17
  %wide.load9.1 = load <8 x float>, ptr %41, align 4, !invariant.load !3, !alias.scope !6, !noalias !17
  %42 = fadd <8 x float> %38, %wide.load8.1
  %43 = fadd <8 x float> %39, %wide.load9.1
  %44 = getelementptr inbounds nuw float, ptr %10, i64 %33
  %45 = getelementptr inbounds nuw i8, ptr %44, i64 32
  store <8 x float> %42, ptr %44, align 4, !alias.scope !13, !noalias !18
  store <8 x float> %43, ptr %45, align 4, !alias.scope !13, !noalias !18
  %index.next.1 = or disjoint i64 %index, 32
  %46 = add nuw nsw i64 %19, %index.next.1
  %47 = getelementptr inbounds nuw float, ptr %6, i64 %46
  %48 = getelementptr inbounds nuw i8, ptr %47, i64 32
  %wide.load.2 = load <8 x float>, ptr %47, align 4, !invariant.load !3, !alias.scope !9, !noalias !15
  %wide.load5.2 = load <8 x float>, ptr %48, align 4, !invariant.load !3, !alias.scope !9, !noalias !15
  %49 = getelementptr inbounds nuw float, ptr %8, i64 %index.next.1
  %50 = getelementptr inbounds nuw i8, ptr %49, i64 32
  %wide.load6.2 = load <8 x float>, ptr %49, align 4, !invariant.load !3, !alias.scope !11, !noalias !16
  %wide.load7.2 = load <8 x float>, ptr %50, align 4, !invariant.load !3, !alias.scope !11, !noalias !16
  %51 = fmul <8 x float> %wide.load.2, %wide.load6.2
  %52 = fmul <8 x float> %wide.load5.2, %wide.load7.2
  %53 = getelementptr inbounds nuw float, ptr %4, i64 %index.next.1
  %54 = getelementptr inbounds nuw i8, ptr %53, i64 32
  %wide.load8.2 = load <8 x float>, ptr %53, align 4, !invariant.load !3, !alias.scope !6, !noalias !17
  %wide.load9.2 = load <8 x float>, ptr %54, align 4, !invariant.load !3, !alias.scope !6, !noalias !17
  %55 = fadd <8 x float> %51, %wide.load8.2
  %56 = fadd <8 x float> %52, %wide.load9.2
  %57 = getelementptr inbounds nuw float, ptr %10, i64 %46
  %58 = getelementptr inbounds nuw i8, ptr %57, i64 32
  store <8 x float> %55, ptr %57, align 4, !alias.scope !13, !noalias !18
  store <8 x float> %56, ptr %58, align 4, !alias.scope !13, !noalias !18
  %index.next.2 = or disjoint i64 %index, 48
  %59 = add nuw nsw i64 %19, %index.next.2
  %60 = getelementptr inbounds nuw float, ptr %6, i64 %59
  %61 = getelementptr inbounds nuw i8, ptr %60, i64 32
  %wide.load.3 = load <8 x float>, ptr %60, align 4, !invariant.load !3, !alias.scope !9, !noalias !15
  %wide.load5.3 = load <8 x float>, ptr %61, align 4, !invariant.load !3, !alias.scope !9, !noalias !15
  %62 = getelementptr inbounds nuw float, ptr %8, i64 %index.next.2
  %63 = getelementptr inbounds nuw i8, ptr %62, i64 32
  %wide.load6.3 = load <8 x float>, ptr %62, align 4, !invariant.load !3, !alias.scope !11, !noalias !16
  %wide.load7.3 = load <8 x float>, ptr %63, align 4, !invariant.load !3, !alias.scope !11, !noalias !16
  %64 = fmul <8 x float> %wide.load.3, %wide.load6.3
  %65 = fmul <8 x float> %wide.load5.3, %wide.load7.3
  %66 = getelementptr inbounds nuw float, ptr %4, i64 %index.next.2
  %67 = getelementptr inbounds nuw i8, ptr %66, i64 32
  %wide.load8.3 = load <8 x float>, ptr %66, align 4, !invariant.load !3, !alias.scope !6, !noalias !17
  %wide.load9.3 = load <8 x float>, ptr %67, align 4, !invariant.load !3, !alias.scope !6, !noalias !17
  %68 = fadd <8 x float> %64, %wide.load8.3
  %69 = fadd <8 x float> %65, %wide.load9.3
  %70 = getelementptr inbounds nuw float, ptr %10, i64 %59
  %71 = getelementptr inbounds nuw i8, ptr %70, i64 32
  store <8 x float> %68, ptr %70, align 4, !alias.scope !13, !noalias !18
  store <8 x float> %69, ptr %71, align 4, !alias.scope !13, !noalias !18
  %index.next.3 = add nuw nsw i64 %index, 64
  %72 = icmp eq i64 %index.next.3, 768
  br i1 %72, label %middle.block, label %vector.body, !llvm.loop !19

middle.block:                                     ; preds = %vector.body
  %73 = add nuw nsw i64 %17, 1
  %exitcond3.not = icmp eq i64 %73, 256
  br i1 %exitcond3.not, label %broadcast_add_fusion_wrapped.exit, label %vector.ph, !llvm.loop !22

broadcast_add_fusion_wrapped.exit:                ; preds = %middle.block, %1
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 1}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 3072}
!5 = !{i64 3145728}
!6 = !{!7}
!7 = distinct !{!7, !8, !"broadcast_add_fusion_wrapped: argument 0"}
!8 = distinct !{!8, !"broadcast_add_fusion_wrapped"}
!9 = !{!10}
!10 = distinct !{!10, !8, !"broadcast_add_fusion_wrapped: argument 1"}
!11 = !{!12}
!12 = distinct !{!12, !8, !"broadcast_add_fusion_wrapped: argument 2"}
!13 = !{!14}
!14 = distinct !{!14, !8, !"broadcast_add_fusion_wrapped: argument 3"}
!15 = !{!7, !12, !14}
!16 = !{!7, !10, !14}
!17 = !{!10, !12, !14}
!18 = !{!7, !10, !12}
!19 = distinct !{!19, !20, !21}
!20 = !{!"llvm.loop.isvectorized", i32 1}
!21 = !{!"llvm.loop.unroll.runtime.disable"}
!22 = distinct !{!22, !23}
!23 = !{!"llvm.loop.unroll.disable"}
