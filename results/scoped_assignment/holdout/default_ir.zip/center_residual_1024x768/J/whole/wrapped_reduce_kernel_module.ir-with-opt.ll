; ModuleID = '__compute_module_wrapped_reduce_kernel_module'
source_filename = "__compute_module_wrapped_reduce_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @wrapped_reduce(ptr readonly captures(none) %0) local_unnamed_addr #0 {
vector.ph:
  %1 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %2 = load ptr, ptr %1, align 8, !invariant.load !3
  %3 = load ptr, ptr %2, align 8, !invariant.load !3, !dereferenceable !4
  %4 = getelementptr inbounds nuw i8, ptr %2, i64 32
  %5 = load ptr, ptr %4, align 8, !invariant.load !3, !dereferenceable !5
  tail call void @llvm.experimental.noalias.scope.decl(metadata !6)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !11)
  %6 = getelementptr inbounds nuw i8, ptr %2, i64 16
  %7 = load ptr, ptr %6, align 8, !invariant.load !3, !dereferenceable !13
  %8 = load float, ptr %7, align 4, !invariant.load !3, !alias.scope !9, !noalias !14
  %broadcast.splatinsert = insertelement <8 x float> poison, float %8, i64 0
  %broadcast.splat = shufflevector <8 x float> %broadcast.splatinsert, <8 x float> poison, <8 x i32> zeroinitializer
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %vector.ph
  %index = phi i64 [ 0, %vector.ph ], [ %index.next, %vector.body ]
  %vec.ind = phi <8 x i64> [ <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>, %vector.ph ], [ %vec.ind.next, %vector.body ]
  %9 = mul nuw nsw <8 x i64> %vec.ind, splat (i64 96)
  %10 = getelementptr i8, ptr %3, <8 x i64> %9
  %wide.masked.gather = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %10, <8 x i1> splat (i1 true), <8 x float> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %11 = fadd reassoc <8 x float> %broadcast.splat, %wide.masked.gather
  %12 = getelementptr i8, <8 x ptr> %10, i64 4
  %wide.masked.gather1 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %12, <8 x i1> splat (i1 true), <8 x float> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %13 = fadd reassoc <8 x float> %11, %wide.masked.gather1
  %14 = getelementptr i8, <8 x ptr> %10, i64 8
  %wide.masked.gather2 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %14, <8 x i1> splat (i1 true), <8 x float> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %15 = fadd reassoc <8 x float> %13, %wide.masked.gather2
  %16 = getelementptr i8, <8 x ptr> %10, i64 12
  %wide.masked.gather3 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %16, <8 x i1> splat (i1 true), <8 x float> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %17 = fadd reassoc <8 x float> %15, %wide.masked.gather3
  %18 = getelementptr i8, <8 x ptr> %10, i64 16
  %wide.masked.gather4 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %18, <8 x i1> splat (i1 true), <8 x float> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %19 = fadd reassoc <8 x float> %17, %wide.masked.gather4
  %20 = getelementptr i8, <8 x ptr> %10, i64 20
  %wide.masked.gather5 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %20, <8 x i1> splat (i1 true), <8 x float> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %21 = fadd reassoc <8 x float> %19, %wide.masked.gather5
  %22 = getelementptr i8, <8 x ptr> %10, i64 24
  %wide.masked.gather6 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %22, <8 x i1> splat (i1 true), <8 x float> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %23 = fadd reassoc <8 x float> %21, %wide.masked.gather6
  %24 = getelementptr i8, <8 x ptr> %10, i64 28
  %wide.masked.gather7 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %24, <8 x i1> splat (i1 true), <8 x float> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %25 = fadd reassoc <8 x float> %23, %wide.masked.gather7
  %26 = getelementptr i8, <8 x ptr> %10, i64 32
  %wide.masked.gather8 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %26, <8 x i1> splat (i1 true), <8 x float> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %27 = fadd reassoc <8 x float> %25, %wide.masked.gather8
  %28 = getelementptr i8, <8 x ptr> %10, i64 36
  %wide.masked.gather9 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %28, <8 x i1> splat (i1 true), <8 x float> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %29 = fadd reassoc <8 x float> %27, %wide.masked.gather9
  %30 = getelementptr i8, <8 x ptr> %10, i64 40
  %wide.masked.gather10 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %30, <8 x i1> splat (i1 true), <8 x float> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %31 = fadd reassoc <8 x float> %29, %wide.masked.gather10
  %32 = getelementptr i8, <8 x ptr> %10, i64 44
  %wide.masked.gather11 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %32, <8 x i1> splat (i1 true), <8 x float> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %33 = fadd reassoc <8 x float> %31, %wide.masked.gather11
  %34 = getelementptr i8, <8 x ptr> %10, i64 48
  %wide.masked.gather12 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %34, <8 x i1> splat (i1 true), <8 x float> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %35 = fadd reassoc <8 x float> %33, %wide.masked.gather12
  %36 = getelementptr i8, <8 x ptr> %10, i64 52
  %wide.masked.gather13 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %36, <8 x i1> splat (i1 true), <8 x float> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %37 = fadd reassoc <8 x float> %35, %wide.masked.gather13
  %38 = getelementptr i8, <8 x ptr> %10, i64 56
  %wide.masked.gather14 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %38, <8 x i1> splat (i1 true), <8 x float> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %39 = fadd reassoc <8 x float> %37, %wide.masked.gather14
  %40 = getelementptr i8, <8 x ptr> %10, i64 60
  %wide.masked.gather15 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %40, <8 x i1> splat (i1 true), <8 x float> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %41 = fadd reassoc <8 x float> %39, %wide.masked.gather15
  %42 = getelementptr i8, <8 x ptr> %10, i64 64
  %wide.masked.gather16 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %42, <8 x i1> splat (i1 true), <8 x float> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %43 = fadd reassoc <8 x float> %41, %wide.masked.gather16
  %44 = getelementptr i8, <8 x ptr> %10, i64 68
  %wide.masked.gather17 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %44, <8 x i1> splat (i1 true), <8 x float> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %45 = fadd reassoc <8 x float> %43, %wide.masked.gather17
  %46 = getelementptr i8, <8 x ptr> %10, i64 72
  %wide.masked.gather18 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %46, <8 x i1> splat (i1 true), <8 x float> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %47 = fadd reassoc <8 x float> %45, %wide.masked.gather18
  %48 = getelementptr i8, <8 x ptr> %10, i64 76
  %wide.masked.gather19 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %48, <8 x i1> splat (i1 true), <8 x float> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %49 = fadd reassoc <8 x float> %47, %wide.masked.gather19
  %50 = getelementptr i8, <8 x ptr> %10, i64 80
  %wide.masked.gather20 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %50, <8 x i1> splat (i1 true), <8 x float> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %51 = fadd reassoc <8 x float> %49, %wide.masked.gather20
  %52 = getelementptr i8, <8 x ptr> %10, i64 84
  %wide.masked.gather21 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %52, <8 x i1> splat (i1 true), <8 x float> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %53 = fadd reassoc <8 x float> %51, %wide.masked.gather21
  %54 = getelementptr i8, <8 x ptr> %10, i64 88
  %wide.masked.gather22 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %54, <8 x i1> splat (i1 true), <8 x float> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %55 = fadd reassoc <8 x float> %53, %wide.masked.gather22
  %56 = getelementptr i8, <8 x ptr> %10, i64 92
  %wide.masked.gather23 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %56, <8 x i1> splat (i1 true), <8 x float> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %57 = fadd reassoc <8 x float> %55, %wide.masked.gather23
  %58 = getelementptr inbounds nuw float, ptr %5, i64 %index
  store <8 x float> %57, ptr %58, align 4, !alias.scope !11, !noalias !16
  %index.next = add nuw i64 %index, 8
  %vec.ind.next = add nuw nsw <8 x i64> %vec.ind, splat (i64 8)
  %59 = icmp eq i64 %index.next, 1024
  br i1 %59, label %wrapped_reduce_wrapped.exit, label %vector.body, !llvm.loop !17

wrapped_reduce_wrapped.exit:                      ; preds = %vector.body
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr>, <8 x i1>, <8 x float>) #2

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(read) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 3}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 98304}
!5 = !{i64 4096}
!6 = !{!7}
!7 = distinct !{!7, !8, !"wrapped_reduce_wrapped: argument 0"}
!8 = distinct !{!8, !"wrapped_reduce_wrapped"}
!9 = !{!10}
!10 = distinct !{!10, !8, !"wrapped_reduce_wrapped: argument 1"}
!11 = !{!12}
!12 = distinct !{!12, !8, !"wrapped_reduce_wrapped: argument 2"}
!13 = !{i64 4}
!14 = !{!7, !12}
!15 = !{!10, !12}
!16 = !{!7, !10}
!17 = distinct !{!17, !18, !19, !20}
!18 = !{!"llvm.loop.unroll.disable"}
!19 = !{!"llvm.loop.isvectorized", i32 1}
!20 = !{!"llvm.loop.unroll.runtime.disable"}
