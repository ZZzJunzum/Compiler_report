; ModuleID = '__compute_module_compare_convert_fusion.1_kernel_module'
source_filename = "__compute_module_compare_convert_fusion.1_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @compare_convert_fusion.1(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %5 = load ptr, ptr %4, align 8, !invariant.load !3, !dereferenceable !4
  %6 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %7 = load ptr, ptr %6, align 8, !invariant.load !3, !dereferenceable !5
  %8 = getelementptr inbounds nuw i8, ptr %3, i64 48
  %9 = load ptr, ptr %8, align 8, !invariant.load !3, !dereferenceable !4
  %10 = getelementptr inbounds nuw i8, ptr %3, i64 64
  %11 = load ptr, ptr %10, align 8, !invariant.load !3, !dereferenceable !5
  %12 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %13 = load ptr, ptr %12, align 8
  %14 = load i64, ptr %13, align 4, !invariant.load !3
  tail call void @llvm.experimental.noalias.scope.decl(metadata !6)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !11)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !13)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !15)
  %15 = icmp ult i64 %14, 4
  br i1 %15, label %16, label %compare_convert_fusion.1_wrapped.exit

16:                                               ; preds = %1
  %17 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !17
  %18 = mul nuw nsw i64 %14, 196608
  %.idx = shl nuw nsw i64 %14, 10
  %19 = getelementptr i8, ptr %17, i64 %.idx
  br label %vector.ph

vector.ph:                                        ; preds = %16, %middle.block
  %20 = phi i64 [ 0, %16 ], [ %78, %middle.block ]
  %21 = mul nuw nsw i64 %20, 768
  %22 = add nuw nsw i64 %21, %18
  %23 = getelementptr float, ptr %19, i64 %20
  %24 = load float, ptr %23, align 4, !invariant.load !3, !alias.scope !6, !noalias !18
  %25 = fmul float %24, 0x3F55555560000000
  %broadcast.splatinsert = insertelement <8 x float> poison, float %25, i64 0
  %broadcast.splat = shufflevector <8 x float> %broadcast.splatinsert, <8 x float> poison, <8 x i32> zeroinitializer
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %vector.ph
  %index = phi i64 [ 0, %vector.ph ], [ %index.next.2, %vector.body ]
  %26 = add nuw nsw i64 %22, %index
  %27 = getelementptr inbounds nuw float, ptr %7, i64 %26
  %28 = getelementptr inbounds nuw i8, ptr %27, i64 32
  %wide.load = load <8 x float>, ptr %27, align 4, !invariant.load !3, !alias.scope !11, !noalias !19
  %wide.load5 = load <8 x float>, ptr %28, align 4, !invariant.load !3, !alias.scope !11, !noalias !19
  %29 = getelementptr inbounds nuw float, ptr %9, i64 %index
  %30 = getelementptr inbounds nuw i8, ptr %29, i64 32
  %wide.load6 = load <8 x float>, ptr %29, align 4, !invariant.load !3, !alias.scope !13, !noalias !20
  %wide.load7 = load <8 x float>, ptr %30, align 4, !invariant.load !3, !alias.scope !13, !noalias !20
  %31 = fmul <8 x float> %wide.load, %wide.load6
  %32 = fmul <8 x float> %wide.load5, %wide.load7
  %33 = getelementptr inbounds nuw float, ptr %5, i64 %index
  %34 = getelementptr inbounds nuw i8, ptr %33, i64 32
  %wide.load8 = load <8 x float>, ptr %33, align 4, !invariant.load !3, !alias.scope !9, !noalias !21
  %wide.load9 = load <8 x float>, ptr %34, align 4, !invariant.load !3, !alias.scope !9, !noalias !21
  %35 = fadd <8 x float> %31, %wide.load8
  %36 = fadd <8 x float> %32, %wide.load9
  %37 = fcmp ogt <8 x float> %35, %broadcast.splat
  %38 = fcmp ogt <8 x float> %36, %broadcast.splat
  %39 = zext <8 x i1> %37 to <8 x i32>
  %40 = zext <8 x i1> %38 to <8 x i32>
  %41 = getelementptr inbounds nuw i32, ptr %11, i64 %26
  %42 = getelementptr inbounds nuw i8, ptr %41, i64 32
  store <8 x i32> %39, ptr %41, align 4, !alias.scope !15, !noalias !22
  store <8 x i32> %40, ptr %42, align 4, !alias.scope !15, !noalias !22
  %index.next = add nuw nsw i64 %index, 16
  %43 = add nuw nsw i64 %22, %index.next
  %44 = getelementptr inbounds nuw float, ptr %7, i64 %43
  %45 = getelementptr inbounds nuw i8, ptr %44, i64 32
  %wide.load.1 = load <8 x float>, ptr %44, align 4, !invariant.load !3, !alias.scope !11, !noalias !19
  %wide.load5.1 = load <8 x float>, ptr %45, align 4, !invariant.load !3, !alias.scope !11, !noalias !19
  %46 = getelementptr inbounds nuw float, ptr %9, i64 %index.next
  %47 = getelementptr inbounds nuw i8, ptr %46, i64 32
  %wide.load6.1 = load <8 x float>, ptr %46, align 4, !invariant.load !3, !alias.scope !13, !noalias !20
  %wide.load7.1 = load <8 x float>, ptr %47, align 4, !invariant.load !3, !alias.scope !13, !noalias !20
  %48 = fmul <8 x float> %wide.load.1, %wide.load6.1
  %49 = fmul <8 x float> %wide.load5.1, %wide.load7.1
  %50 = getelementptr inbounds nuw float, ptr %5, i64 %index.next
  %51 = getelementptr inbounds nuw i8, ptr %50, i64 32
  %wide.load8.1 = load <8 x float>, ptr %50, align 4, !invariant.load !3, !alias.scope !9, !noalias !21
  %wide.load9.1 = load <8 x float>, ptr %51, align 4, !invariant.load !3, !alias.scope !9, !noalias !21
  %52 = fadd <8 x float> %48, %wide.load8.1
  %53 = fadd <8 x float> %49, %wide.load9.1
  %54 = fcmp ogt <8 x float> %52, %broadcast.splat
  %55 = fcmp ogt <8 x float> %53, %broadcast.splat
  %56 = zext <8 x i1> %54 to <8 x i32>
  %57 = zext <8 x i1> %55 to <8 x i32>
  %58 = getelementptr inbounds nuw i32, ptr %11, i64 %43
  %59 = getelementptr inbounds nuw i8, ptr %58, i64 32
  store <8 x i32> %56, ptr %58, align 4, !alias.scope !15, !noalias !22
  store <8 x i32> %57, ptr %59, align 4, !alias.scope !15, !noalias !22
  %index.next.1 = add nuw nsw i64 %index, 32
  %60 = add nuw nsw i64 %22, %index.next.1
  %61 = getelementptr inbounds nuw float, ptr %7, i64 %60
  %62 = getelementptr inbounds nuw i8, ptr %61, i64 32
  %wide.load.2 = load <8 x float>, ptr %61, align 4, !invariant.load !3, !alias.scope !11, !noalias !19
  %wide.load5.2 = load <8 x float>, ptr %62, align 4, !invariant.load !3, !alias.scope !11, !noalias !19
  %63 = getelementptr inbounds nuw float, ptr %9, i64 %index.next.1
  %64 = getelementptr inbounds nuw i8, ptr %63, i64 32
  %wide.load6.2 = load <8 x float>, ptr %63, align 4, !invariant.load !3, !alias.scope !13, !noalias !20
  %wide.load7.2 = load <8 x float>, ptr %64, align 4, !invariant.load !3, !alias.scope !13, !noalias !20
  %65 = fmul <8 x float> %wide.load.2, %wide.load6.2
  %66 = fmul <8 x float> %wide.load5.2, %wide.load7.2
  %67 = getelementptr inbounds nuw float, ptr %5, i64 %index.next.1
  %68 = getelementptr inbounds nuw i8, ptr %67, i64 32
  %wide.load8.2 = load <8 x float>, ptr %67, align 4, !invariant.load !3, !alias.scope !9, !noalias !21
  %wide.load9.2 = load <8 x float>, ptr %68, align 4, !invariant.load !3, !alias.scope !9, !noalias !21
  %69 = fadd <8 x float> %65, %wide.load8.2
  %70 = fadd <8 x float> %66, %wide.load9.2
  %71 = fcmp ogt <8 x float> %69, %broadcast.splat
  %72 = fcmp ogt <8 x float> %70, %broadcast.splat
  %73 = zext <8 x i1> %71 to <8 x i32>
  %74 = zext <8 x i1> %72 to <8 x i32>
  %75 = getelementptr inbounds nuw i32, ptr %11, i64 %60
  %76 = getelementptr inbounds nuw i8, ptr %75, i64 32
  store <8 x i32> %73, ptr %75, align 4, !alias.scope !15, !noalias !22
  store <8 x i32> %74, ptr %76, align 4, !alias.scope !15, !noalias !22
  %index.next.2 = add nuw nsw i64 %index, 48
  %77 = icmp eq i64 %index.next.2, 768
  br i1 %77, label %middle.block, label %vector.body, !llvm.loop !23

middle.block:                                     ; preds = %vector.body
  %78 = add nuw nsw i64 %20, 1
  %exitcond3.not = icmp eq i64 %78, 256
  br i1 %exitcond3.not, label %compare_convert_fusion.1_wrapped.exit, label %vector.ph, !llvm.loop !26

compare_convert_fusion.1_wrapped.exit:            ; preds = %middle.block, %1
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 3}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 3072}
!5 = !{i64 3145728}
!6 = !{!7}
!7 = distinct !{!7, !8, !"compare_convert_fusion.1_wrapped: argument 0"}
!8 = distinct !{!8, !"compare_convert_fusion.1_wrapped"}
!9 = !{!10}
!10 = distinct !{!10, !8, !"compare_convert_fusion.1_wrapped: argument 1"}
!11 = !{!12}
!12 = distinct !{!12, !8, !"compare_convert_fusion.1_wrapped: argument 2"}
!13 = !{!14}
!14 = distinct !{!14, !8, !"compare_convert_fusion.1_wrapped: argument 3"}
!15 = !{!16}
!16 = distinct !{!16, !8, !"compare_convert_fusion.1_wrapped: argument 4"}
!17 = !{i64 4096}
!18 = !{!10, !12, !14, !16}
!19 = !{!7, !10, !14, !16}
!20 = !{!7, !10, !12, !16}
!21 = !{!7, !12, !14, !16}
!22 = !{!7, !10, !12, !14}
!23 = distinct !{!23, !24, !25}
!24 = !{!"llvm.loop.isvectorized", i32 1}
!25 = !{!"llvm.loop.unroll.runtime.disable"}
!26 = distinct !{!26, !27}
!27 = !{!"llvm.loop.unroll.disable"}
