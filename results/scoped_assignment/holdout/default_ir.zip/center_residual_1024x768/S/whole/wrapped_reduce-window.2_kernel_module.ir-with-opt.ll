; ModuleID = '__compute_module_wrapped_reduce-window.2_kernel_module'
source_filename = "__compute_module_wrapped_reduce-window.2_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @wrapped_reduce-window.2(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %3 = load ptr, ptr %2, align 8
  %4 = load i64, ptr %3, align 4, !invariant.load !3
  tail call void @llvm.experimental.noalias.scope.decl(metadata !4)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !7)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9)
  %5 = icmp ult i64 %4, 4
  br i1 %5, label %6, label %wrapped_reduce-window.2_wrapped.exit

6:                                                ; preds = %1
  %7 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %8 = load ptr, ptr %7, align 8, !invariant.load !3
  %9 = getelementptr inbounds nuw i8, ptr %8, i64 32
  %10 = load ptr, ptr %9, align 8, !invariant.load !3, !dereferenceable !11
  %11 = load ptr, ptr %8, align 8, !invariant.load !3, !dereferenceable !12
  %12 = getelementptr inbounds nuw i8, ptr %8, i64 16
  %13 = load ptr, ptr %12, align 8, !invariant.load !3, !dereferenceable !13
  %14 = load i32, ptr %13, align 4, !invariant.load !3, !alias.scope !7, !noalias !14
  %.idx2 = mul nuw nsw i64 %4, 786432
  %15 = getelementptr i8, ptr %11, i64 %.idx2
  %.idx = mul nuw nsw i64 %4, 24576
  %16 = getelementptr i8, ptr %10, i64 %.idx
  %broadcast.splatinsert = insertelement <8 x i32> poison, i32 %14, i64 0
  %broadcast.splat = shufflevector <8 x i32> %broadcast.splatinsert, <8 x i32> poison, <8 x i32> zeroinitializer
  br label %.preheader6

.preheader6:                                      ; preds = %6, %middle.block
  %17 = phi i64 [ 0, %6 ], [ %87, %middle.block ]
  %.idx3 = mul nuw nsw i64 %17, 3072
  %18 = getelementptr i8, ptr %15, i64 %.idx3
  %.idx1 = mul nuw nsw i64 %17, 96
  %19 = getelementptr i8, ptr %16, i64 %.idx1
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %.preheader6
  %index = phi i64 [ 0, %.preheader6 ], [ %index.next, %vector.body ]
  %vec.ind = phi <8 x i64> [ <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>, %.preheader6 ], [ %vec.ind.next, %vector.body ]
  %20 = shl <8 x i64> %vec.ind, splat (i64 7)
  %21 = getelementptr i8, ptr %18, <8 x i64> %20
  %wide.masked.gather = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %21, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !4, !noalias !15
  %22 = add <8 x i32> %wide.masked.gather, %broadcast.splat
  %23 = getelementptr i8, <8 x ptr> %21, i64 4
  %wide.masked.gather9 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %23, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !4, !noalias !15
  %24 = add <8 x i32> %wide.masked.gather9, %22
  %25 = getelementptr i8, <8 x ptr> %21, i64 8
  %wide.masked.gather10 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %25, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !4, !noalias !15
  %26 = add <8 x i32> %wide.masked.gather10, %24
  %27 = getelementptr i8, <8 x ptr> %21, i64 12
  %wide.masked.gather11 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %27, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !4, !noalias !15
  %28 = add <8 x i32> %wide.masked.gather11, %26
  %29 = getelementptr i8, <8 x ptr> %21, i64 16
  %wide.masked.gather12 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %29, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !4, !noalias !15
  %30 = add <8 x i32> %wide.masked.gather12, %28
  %31 = getelementptr i8, <8 x ptr> %21, i64 20
  %wide.masked.gather13 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %31, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !4, !noalias !15
  %32 = add <8 x i32> %wide.masked.gather13, %30
  %33 = getelementptr i8, <8 x ptr> %21, i64 24
  %wide.masked.gather14 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %33, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !4, !noalias !15
  %34 = add <8 x i32> %wide.masked.gather14, %32
  %35 = getelementptr i8, <8 x ptr> %21, i64 28
  %wide.masked.gather15 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %35, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !4, !noalias !15
  %36 = add <8 x i32> %wide.masked.gather15, %34
  %37 = getelementptr i8, <8 x ptr> %21, i64 32
  %wide.masked.gather16 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %37, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !4, !noalias !15
  %38 = add <8 x i32> %wide.masked.gather16, %36
  %39 = getelementptr i8, <8 x ptr> %21, i64 36
  %wide.masked.gather17 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %39, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !4, !noalias !15
  %40 = add <8 x i32> %wide.masked.gather17, %38
  %41 = getelementptr i8, <8 x ptr> %21, i64 40
  %wide.masked.gather18 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %41, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !4, !noalias !15
  %42 = add <8 x i32> %wide.masked.gather18, %40
  %43 = getelementptr i8, <8 x ptr> %21, i64 44
  %wide.masked.gather19 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %43, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !4, !noalias !15
  %44 = add <8 x i32> %wide.masked.gather19, %42
  %45 = getelementptr i8, <8 x ptr> %21, i64 48
  %wide.masked.gather20 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %45, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !4, !noalias !15
  %46 = add <8 x i32> %wide.masked.gather20, %44
  %47 = getelementptr i8, <8 x ptr> %21, i64 52
  %wide.masked.gather21 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %47, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !4, !noalias !15
  %48 = add <8 x i32> %wide.masked.gather21, %46
  %49 = getelementptr i8, <8 x ptr> %21, i64 56
  %wide.masked.gather22 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %49, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !4, !noalias !15
  %50 = add <8 x i32> %wide.masked.gather22, %48
  %51 = getelementptr i8, <8 x ptr> %21, i64 60
  %wide.masked.gather23 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %51, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !4, !noalias !15
  %52 = add <8 x i32> %wide.masked.gather23, %50
  %53 = getelementptr i8, <8 x ptr> %21, i64 64
  %wide.masked.gather24 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %53, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !4, !noalias !15
  %54 = add <8 x i32> %wide.masked.gather24, %52
  %55 = getelementptr i8, <8 x ptr> %21, i64 68
  %wide.masked.gather25 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %55, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !4, !noalias !15
  %56 = add <8 x i32> %wide.masked.gather25, %54
  %57 = getelementptr i8, <8 x ptr> %21, i64 72
  %wide.masked.gather26 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %57, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !4, !noalias !15
  %58 = add <8 x i32> %wide.masked.gather26, %56
  %59 = getelementptr i8, <8 x ptr> %21, i64 76
  %wide.masked.gather27 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %59, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !4, !noalias !15
  %60 = add <8 x i32> %wide.masked.gather27, %58
  %61 = getelementptr i8, <8 x ptr> %21, i64 80
  %wide.masked.gather28 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %61, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !4, !noalias !15
  %62 = add <8 x i32> %wide.masked.gather28, %60
  %63 = getelementptr i8, <8 x ptr> %21, i64 84
  %wide.masked.gather29 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %63, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !4, !noalias !15
  %64 = add <8 x i32> %wide.masked.gather29, %62
  %65 = getelementptr i8, <8 x ptr> %21, i64 88
  %wide.masked.gather30 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %65, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !4, !noalias !15
  %66 = add <8 x i32> %wide.masked.gather30, %64
  %67 = getelementptr i8, <8 x ptr> %21, i64 92
  %wide.masked.gather31 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %67, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !4, !noalias !15
  %68 = add <8 x i32> %wide.masked.gather31, %66
  %69 = getelementptr i8, <8 x ptr> %21, i64 96
  %wide.masked.gather32 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %69, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !4, !noalias !15
  %70 = add <8 x i32> %wide.masked.gather32, %68
  %71 = getelementptr i8, <8 x ptr> %21, i64 100
  %wide.masked.gather33 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %71, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !4, !noalias !15
  %72 = add <8 x i32> %wide.masked.gather33, %70
  %73 = getelementptr i8, <8 x ptr> %21, i64 104
  %wide.masked.gather34 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %73, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !4, !noalias !15
  %74 = add <8 x i32> %wide.masked.gather34, %72
  %75 = getelementptr i8, <8 x ptr> %21, i64 108
  %wide.masked.gather35 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %75, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !4, !noalias !15
  %76 = add <8 x i32> %wide.masked.gather35, %74
  %77 = getelementptr i8, <8 x ptr> %21, i64 112
  %wide.masked.gather36 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %77, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !4, !noalias !15
  %78 = add <8 x i32> %wide.masked.gather36, %76
  %79 = getelementptr i8, <8 x ptr> %21, i64 116
  %wide.masked.gather37 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %79, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !4, !noalias !15
  %80 = add <8 x i32> %wide.masked.gather37, %78
  %81 = getelementptr i8, <8 x ptr> %21, i64 120
  %wide.masked.gather38 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %81, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !4, !noalias !15
  %82 = add <8 x i32> %wide.masked.gather38, %80
  %83 = getelementptr i8, <8 x ptr> %21, i64 124
  %wide.masked.gather39 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %83, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !4, !noalias !15
  %84 = add <8 x i32> %wide.masked.gather39, %82
  %85 = getelementptr i32, ptr %19, i64 %index
  store <8 x i32> %84, ptr %85, align 4, !alias.scope !9, !noalias !16
  %index.next = add nuw i64 %index, 8
  %vec.ind.next = add nuw nsw <8 x i64> %vec.ind, splat (i64 8)
  %86 = icmp eq i64 %index.next, 24
  br i1 %86, label %middle.block, label %vector.body, !llvm.loop !17

middle.block:                                     ; preds = %vector.body
  %87 = add nuw nsw i64 %17, 1
  %exitcond7.not = icmp eq i64 %87, 256
  br i1 %exitcond7.not, label %wrapped_reduce-window.2_wrapped.exit, label %.preheader6, !llvm.loop !21

wrapped_reduce-window.2_wrapped.exit:             ; preds = %middle.block, %1
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr>, <8 x i1>, <8 x i32>) #2

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(read) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 6}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{!5}
!5 = distinct !{!5, !6, !"wrapped_reduce-window.2_wrapped: argument 0"}
!6 = distinct !{!6, !"wrapped_reduce-window.2_wrapped"}
!7 = !{!8}
!8 = distinct !{!8, !6, !"wrapped_reduce-window.2_wrapped: argument 1"}
!9 = !{!10}
!10 = distinct !{!10, !6, !"wrapped_reduce-window.2_wrapped: argument 2"}
!11 = !{i64 98304}
!12 = !{i64 3145728}
!13 = !{i64 4}
!14 = !{!5, !10}
!15 = !{!8, !10}
!16 = !{!5, !8}
!17 = distinct !{!17, !18, !19, !20}
!18 = !{!"llvm.loop.unroll.disable"}
!19 = !{!"llvm.loop.isvectorized", i32 1}
!20 = !{!"llvm.loop.unroll.runtime.disable"}
!21 = distinct !{!21, !18}
