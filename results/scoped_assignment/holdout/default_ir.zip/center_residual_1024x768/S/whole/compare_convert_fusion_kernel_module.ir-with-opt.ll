; ModuleID = '__compute_module_compare_convert_fusion_kernel_module'
source_filename = "__compute_module_compare_convert_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @compare_convert_fusion(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !5
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !5
  %9 = getelementptr inbounds nuw i8, ptr %3, i64 48
  %10 = load ptr, ptr %9, align 8, !invariant.load !3, !dereferenceable !6
  %11 = getelementptr inbounds nuw i8, ptr %3, i64 64
  %12 = load ptr, ptr %11, align 8, !invariant.load !3, !dereferenceable !5
  %13 = getelementptr inbounds nuw i8, ptr %3, i64 80
  %14 = load ptr, ptr %13, align 8, !invariant.load !3, !dereferenceable !5
  %15 = getelementptr inbounds nuw i8, ptr %3, i64 96
  %16 = load ptr, ptr %15, align 8, !invariant.load !3, !dereferenceable !4
  %17 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %18 = load ptr, ptr %17, align 8
  %19 = load i64, ptr %18, align 4, !invariant.load !3
  tail call void @llvm.experimental.noalias.scope.decl(metadata !7)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !10)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !12)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !14)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !16)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !18)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !20)
  %20 = icmp slt i64 %19, 11
  br i1 %20, label %21, label %82

21:                                               ; preds = %1
  %22 = icmp sgt i64 %19, -1
  br i1 %22, label %23, label %compare_convert_fusion_wrapped.exit

23:                                               ; preds = %21
  %24 = mul nuw nsw i64 %19, 66048
  %.idx = mul nuw nsw i64 %19, 344
  %25 = getelementptr i8, ptr %10, i64 %.idx
  br label %vector.ph18

vector.ph18:                                      ; preds = %23, %middle.block29
  %26 = phi i64 [ 0, %23 ], [ %81, %middle.block29 ]
  %27 = mul nuw nsw i64 %26, 768
  %28 = add nuw nsw i64 %27, %24
  %29 = getelementptr float, ptr %25, i64 %26
  %30 = load float, ptr %29, align 4, !invariant.load !3, !alias.scope !14, !noalias !22
  %31 = fmul float %30, 0x3F55555560000000
  %broadcast.splatinsert19 = insertelement <8 x float> poison, float %31, i64 0
  %broadcast.splat20 = shufflevector <8 x float> %broadcast.splatinsert19, <8 x float> poison, <8 x i32> zeroinitializer
  br label %vector.body21

vector.body21:                                    ; preds = %vector.body21, %vector.ph18
  %index22 = phi i64 [ 0, %vector.ph18 ], [ %index.next28.2, %vector.body21 ]
  %32 = getelementptr inbounds nuw float, ptr %14, i64 %index22
  %wide.load23 = load <8 x float>, ptr %32, align 4, !invariant.load !3, !alias.scope !18, !noalias !23
  %33 = add nuw nsw i64 %28, %index22
  %34 = getelementptr inbounds nuw float, ptr %4, i64 %33
  %wide.load24 = load <8 x float>, ptr %34, align 4, !invariant.load !3, !alias.scope !7, !noalias !24
  %35 = fmul <8 x float> %wide.load23, %wide.load24
  %36 = getelementptr inbounds nuw float, ptr %12, i64 %index22
  %wide.load25 = load <8 x float>, ptr %36, align 4, !invariant.load !3, !alias.scope !16, !noalias !25
  %37 = fadd <8 x float> %35, %wide.load25
  %38 = fsub <8 x float> %37, %broadcast.splat20
  %39 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %38, <8 x float> zeroinitializer)
  %40 = getelementptr inbounds nuw float, ptr %8, i64 %index22
  %wide.load26 = load <8 x float>, ptr %40, align 4, !invariant.load !3, !alias.scope !12, !noalias !26
  %41 = fmul <8 x float> %wide.load26, %39
  %42 = getelementptr inbounds nuw float, ptr %6, i64 %index22
  %wide.load27 = load <8 x float>, ptr %42, align 4, !invariant.load !3, !alias.scope !10, !noalias !27
  %43 = fadd <8 x float> %wide.load27, %41
  %44 = fadd <8 x float> %wide.load24, %43
  %45 = fcmp ogt <8 x float> %44, zeroinitializer
  %46 = zext <8 x i1> %45 to <8 x i32>
  %47 = getelementptr inbounds nuw i32, ptr %16, i64 %33
  store <8 x i32> %46, ptr %47, align 4, !alias.scope !20, !noalias !28
  %index.next28 = add nuw nsw i64 %index22, 8
  %48 = getelementptr inbounds nuw float, ptr %14, i64 %index.next28
  %wide.load23.1 = load <8 x float>, ptr %48, align 4, !invariant.load !3, !alias.scope !18, !noalias !23
  %49 = add nuw nsw i64 %28, %index.next28
  %50 = getelementptr inbounds nuw float, ptr %4, i64 %49
  %wide.load24.1 = load <8 x float>, ptr %50, align 4, !invariant.load !3, !alias.scope !7, !noalias !24
  %51 = fmul <8 x float> %wide.load23.1, %wide.load24.1
  %52 = getelementptr inbounds nuw float, ptr %12, i64 %index.next28
  %wide.load25.1 = load <8 x float>, ptr %52, align 4, !invariant.load !3, !alias.scope !16, !noalias !25
  %53 = fadd <8 x float> %51, %wide.load25.1
  %54 = fsub <8 x float> %53, %broadcast.splat20
  %55 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %54, <8 x float> zeroinitializer)
  %56 = getelementptr inbounds nuw float, ptr %8, i64 %index.next28
  %wide.load26.1 = load <8 x float>, ptr %56, align 4, !invariant.load !3, !alias.scope !12, !noalias !26
  %57 = fmul <8 x float> %wide.load26.1, %55
  %58 = getelementptr inbounds nuw float, ptr %6, i64 %index.next28
  %wide.load27.1 = load <8 x float>, ptr %58, align 4, !invariant.load !3, !alias.scope !10, !noalias !27
  %59 = fadd <8 x float> %wide.load27.1, %57
  %60 = fadd <8 x float> %wide.load24.1, %59
  %61 = fcmp ogt <8 x float> %60, zeroinitializer
  %62 = zext <8 x i1> %61 to <8 x i32>
  %63 = getelementptr inbounds nuw i32, ptr %16, i64 %49
  store <8 x i32> %62, ptr %63, align 4, !alias.scope !20, !noalias !28
  %index.next28.1 = add nuw nsw i64 %index22, 16
  %64 = getelementptr inbounds nuw float, ptr %14, i64 %index.next28.1
  %wide.load23.2 = load <8 x float>, ptr %64, align 4, !invariant.load !3, !alias.scope !18, !noalias !23
  %65 = add nuw nsw i64 %28, %index.next28.1
  %66 = getelementptr inbounds nuw float, ptr %4, i64 %65
  %wide.load24.2 = load <8 x float>, ptr %66, align 4, !invariant.load !3, !alias.scope !7, !noalias !24
  %67 = fmul <8 x float> %wide.load23.2, %wide.load24.2
  %68 = getelementptr inbounds nuw float, ptr %12, i64 %index.next28.1
  %wide.load25.2 = load <8 x float>, ptr %68, align 4, !invariant.load !3, !alias.scope !16, !noalias !25
  %69 = fadd <8 x float> %67, %wide.load25.2
  %70 = fsub <8 x float> %69, %broadcast.splat20
  %71 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %70, <8 x float> zeroinitializer)
  %72 = getelementptr inbounds nuw float, ptr %8, i64 %index.next28.1
  %wide.load26.2 = load <8 x float>, ptr %72, align 4, !invariant.load !3, !alias.scope !12, !noalias !26
  %73 = fmul <8 x float> %wide.load26.2, %71
  %74 = getelementptr inbounds nuw float, ptr %6, i64 %index.next28.1
  %wide.load27.2 = load <8 x float>, ptr %74, align 4, !invariant.load !3, !alias.scope !10, !noalias !27
  %75 = fadd <8 x float> %wide.load27.2, %73
  %76 = fadd <8 x float> %wide.load24.2, %75
  %77 = fcmp ogt <8 x float> %76, zeroinitializer
  %78 = zext <8 x i1> %77 to <8 x i32>
  %79 = getelementptr inbounds nuw i32, ptr %16, i64 %65
  store <8 x i32> %78, ptr %79, align 4, !alias.scope !20, !noalias !28
  %index.next28.2 = add nuw nsw i64 %index22, 24
  %80 = icmp eq i64 %index.next28.2, 768
  br i1 %80, label %middle.block29, label %vector.body21, !llvm.loop !29

middle.block29:                                   ; preds = %vector.body21
  %81 = add nuw nsw i64 %26, 1
  %exitcond9.not = icmp eq i64 %81, 86
  br i1 %exitcond9.not, label %compare_convert_fusion_wrapped.exit, label %vector.ph18, !llvm.loop !32

82:                                               ; preds = %1
  %83 = icmp eq i64 %19, 11
  br i1 %83, label %.preheader, label %compare_convert_fusion_wrapped.exit

.preheader:                                       ; preds = %82, %middle.block
  %84 = phi i64 [ %140, %middle.block ], [ 0, %82 ]
  %85 = mul nuw nsw i64 %84, 768
  %86 = add nuw nsw i64 %85, 726528
  %87 = getelementptr float, ptr %10, i64 %84
  %88 = getelementptr i8, ptr %87, i64 3784
  %89 = load float, ptr %88, align 4, !invariant.load !3, !alias.scope !14, !noalias !22
  %90 = fmul float %89, 0x3F55555560000000
  %broadcast.splatinsert = insertelement <8 x float> poison, float %90, i64 0
  %broadcast.splat = shufflevector <8 x float> %broadcast.splatinsert, <8 x float> poison, <8 x i32> zeroinitializer
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %.preheader
  %index = phi i64 [ 0, %.preheader ], [ %index.next.2, %vector.body ]
  %91 = getelementptr inbounds nuw float, ptr %14, i64 %index
  %wide.load = load <8 x float>, ptr %91, align 4, !invariant.load !3, !alias.scope !18, !noalias !23
  %92 = add nuw nsw i64 %86, %index
  %93 = getelementptr inbounds nuw float, ptr %4, i64 %92
  %wide.load14 = load <8 x float>, ptr %93, align 4, !invariant.load !3, !alias.scope !7, !noalias !24
  %94 = fmul <8 x float> %wide.load, %wide.load14
  %95 = getelementptr inbounds nuw float, ptr %12, i64 %index
  %wide.load15 = load <8 x float>, ptr %95, align 4, !invariant.load !3, !alias.scope !16, !noalias !25
  %96 = fadd <8 x float> %94, %wide.load15
  %97 = fsub <8 x float> %96, %broadcast.splat
  %98 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %97, <8 x float> zeroinitializer)
  %99 = getelementptr inbounds nuw float, ptr %8, i64 %index
  %wide.load16 = load <8 x float>, ptr %99, align 4, !invariant.load !3, !alias.scope !12, !noalias !26
  %100 = fmul <8 x float> %wide.load16, %98
  %101 = getelementptr inbounds nuw float, ptr %6, i64 %index
  %wide.load17 = load <8 x float>, ptr %101, align 4, !invariant.load !3, !alias.scope !10, !noalias !27
  %102 = fadd <8 x float> %wide.load17, %100
  %103 = fadd <8 x float> %wide.load14, %102
  %104 = fcmp ogt <8 x float> %103, zeroinitializer
  %105 = zext <8 x i1> %104 to <8 x i32>
  %106 = getelementptr inbounds nuw i32, ptr %16, i64 %92
  store <8 x i32> %105, ptr %106, align 4, !alias.scope !20, !noalias !28
  %index.next = add nuw nsw i64 %index, 8
  %107 = getelementptr inbounds nuw float, ptr %14, i64 %index.next
  %wide.load.1 = load <8 x float>, ptr %107, align 4, !invariant.load !3, !alias.scope !18, !noalias !23
  %108 = add nuw nsw i64 %86, %index.next
  %109 = getelementptr inbounds nuw float, ptr %4, i64 %108
  %wide.load14.1 = load <8 x float>, ptr %109, align 4, !invariant.load !3, !alias.scope !7, !noalias !24
  %110 = fmul <8 x float> %wide.load.1, %wide.load14.1
  %111 = getelementptr inbounds nuw float, ptr %12, i64 %index.next
  %wide.load15.1 = load <8 x float>, ptr %111, align 4, !invariant.load !3, !alias.scope !16, !noalias !25
  %112 = fadd <8 x float> %110, %wide.load15.1
  %113 = fsub <8 x float> %112, %broadcast.splat
  %114 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %113, <8 x float> zeroinitializer)
  %115 = getelementptr inbounds nuw float, ptr %8, i64 %index.next
  %wide.load16.1 = load <8 x float>, ptr %115, align 4, !invariant.load !3, !alias.scope !12, !noalias !26
  %116 = fmul <8 x float> %wide.load16.1, %114
  %117 = getelementptr inbounds nuw float, ptr %6, i64 %index.next
  %wide.load17.1 = load <8 x float>, ptr %117, align 4, !invariant.load !3, !alias.scope !10, !noalias !27
  %118 = fadd <8 x float> %wide.load17.1, %116
  %119 = fadd <8 x float> %wide.load14.1, %118
  %120 = fcmp ogt <8 x float> %119, zeroinitializer
  %121 = zext <8 x i1> %120 to <8 x i32>
  %122 = getelementptr inbounds nuw i32, ptr %16, i64 %108
  store <8 x i32> %121, ptr %122, align 4, !alias.scope !20, !noalias !28
  %index.next.1 = add nuw nsw i64 %index, 16
  %123 = getelementptr inbounds nuw float, ptr %14, i64 %index.next.1
  %wide.load.2 = load <8 x float>, ptr %123, align 4, !invariant.load !3, !alias.scope !18, !noalias !23
  %124 = add nuw nsw i64 %86, %index.next.1
  %125 = getelementptr inbounds nuw float, ptr %4, i64 %124
  %wide.load14.2 = load <8 x float>, ptr %125, align 4, !invariant.load !3, !alias.scope !7, !noalias !24
  %126 = fmul <8 x float> %wide.load.2, %wide.load14.2
  %127 = getelementptr inbounds nuw float, ptr %12, i64 %index.next.1
  %wide.load15.2 = load <8 x float>, ptr %127, align 4, !invariant.load !3, !alias.scope !16, !noalias !25
  %128 = fadd <8 x float> %126, %wide.load15.2
  %129 = fsub <8 x float> %128, %broadcast.splat
  %130 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %129, <8 x float> zeroinitializer)
  %131 = getelementptr inbounds nuw float, ptr %8, i64 %index.next.1
  %wide.load16.2 = load <8 x float>, ptr %131, align 4, !invariant.load !3, !alias.scope !12, !noalias !26
  %132 = fmul <8 x float> %wide.load16.2, %130
  %133 = getelementptr inbounds nuw float, ptr %6, i64 %index.next.1
  %wide.load17.2 = load <8 x float>, ptr %133, align 4, !invariant.load !3, !alias.scope !10, !noalias !27
  %134 = fadd <8 x float> %wide.load17.2, %132
  %135 = fadd <8 x float> %wide.load14.2, %134
  %136 = fcmp ogt <8 x float> %135, zeroinitializer
  %137 = zext <8 x i1> %136 to <8 x i32>
  %138 = getelementptr inbounds nuw i32, ptr %16, i64 %124
  store <8 x i32> %137, ptr %138, align 4, !alias.scope !20, !noalias !28
  %index.next.2 = add nuw nsw i64 %index, 24
  %139 = icmp eq i64 %index.next.2, 768
  br i1 %139, label %middle.block, label %vector.body, !llvm.loop !34

middle.block:                                     ; preds = %vector.body
  %140 = add nuw nsw i64 %84, 1
  %exitcond7.not = icmp eq i64 %140, 78
  br i1 %exitcond7.not, label %compare_convert_fusion_wrapped.exit, label %.preheader, !llvm.loop !32

compare_convert_fusion_wrapped.exit:              ; preds = %middle.block, %middle.block29, %21, %82
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.maximum.v8f32(<8 x float>, <8 x float>) #2

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 2}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 3145728}
!5 = !{i64 3072}
!6 = !{i64 4096}
!7 = !{!8}
!8 = distinct !{!8, !9, !"compare_convert_fusion_wrapped: argument 0"}
!9 = distinct !{!9, !"compare_convert_fusion_wrapped"}
!10 = !{!11}
!11 = distinct !{!11, !9, !"compare_convert_fusion_wrapped: argument 1"}
!12 = !{!13}
!13 = distinct !{!13, !9, !"compare_convert_fusion_wrapped: argument 2"}
!14 = !{!15}
!15 = distinct !{!15, !9, !"compare_convert_fusion_wrapped: argument 3"}
!16 = !{!17}
!17 = distinct !{!17, !9, !"compare_convert_fusion_wrapped: argument 4"}
!18 = !{!19}
!19 = distinct !{!19, !9, !"compare_convert_fusion_wrapped: argument 5"}
!20 = !{!21}
!21 = distinct !{!21, !9, !"compare_convert_fusion_wrapped: argument 6"}
!22 = !{!8, !11, !13, !17, !19, !21}
!23 = !{!8, !11, !13, !15, !17, !21}
!24 = !{!11, !13, !15, !17, !19, !21}
!25 = !{!8, !11, !13, !15, !19, !21}
!26 = !{!8, !11, !15, !17, !19, !21}
!27 = !{!8, !13, !15, !17, !19, !21}
!28 = !{!8, !11, !13, !15, !17, !19}
!29 = distinct !{!29, !30, !31}
!30 = !{!"llvm.loop.isvectorized", i32 1}
!31 = !{!"llvm.loop.unroll.runtime.disable"}
!32 = distinct !{!32, !33}
!33 = !{!"llvm.loop.unroll.disable"}
!34 = distinct !{!34, !30, !31}
