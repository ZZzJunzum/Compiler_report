; ModuleID = '__compute_module_add_maximum_fusion_kernel_module'
source_filename = "__compute_module_add_maximum_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @add_maximum_fusion(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !5
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !5
  %9 = getelementptr inbounds nuw i8, ptr %3, i64 48
  %10 = load ptr, ptr %9, align 8, !invariant.load !3, !dereferenceable !6
  %11 = getelementptr inbounds nuw i8, ptr %3, i64 64
  %12 = load ptr, ptr %11, align 8, !invariant.load !3, !dereferenceable !5
  %13 = getelementptr inbounds nuw i8, ptr %3, i64 80
  %14 = load ptr, ptr %13, align 8, !invariant.load !3, !dereferenceable !5
  %15 = getelementptr inbounds nuw i8, ptr %3, i64 96
  %16 = load ptr, ptr %15, align 8, !invariant.load !3, !dereferenceable !4
  tail call void @llvm.experimental.noalias.scope.decl(metadata !7)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !10)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !12)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !14)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !16)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !18)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !20)
  br label %vector.ph

vector.ph:                                        ; preds = %1, %middle.block
  %17 = phi i64 [ 0, %1 ], [ %81, %middle.block ]
  %18 = mul nuw nsw i64 %17, 768
  %19 = getelementptr inbounds nuw float, ptr %10, i64 %17
  %20 = load float, ptr %19, align 4, !invariant.load !3, !alias.scope !14, !noalias !22
  %21 = fmul float %20, 0x3F55555560000000
  %broadcast.splatinsert = insertelement <8 x float> poison, float %21, i64 0
  %broadcast.splat = shufflevector <8 x float> %broadcast.splatinsert, <8 x float> poison, <8 x i32> zeroinitializer
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %vector.ph
  %index = phi i64 [ 0, %vector.ph ], [ %index.next.1, %vector.body ]
  %22 = getelementptr inbounds nuw float, ptr %14, i64 %index
  %23 = getelementptr inbounds nuw i8, ptr %22, i64 32
  %wide.load = load <8 x float>, ptr %22, align 4, !invariant.load !3, !alias.scope !18, !noalias !23
  %wide.load3 = load <8 x float>, ptr %23, align 4, !invariant.load !3, !alias.scope !18, !noalias !23
  %24 = add nuw nsw i64 %index, %18
  %25 = getelementptr inbounds nuw float, ptr %4, i64 %24
  %26 = getelementptr inbounds nuw i8, ptr %25, i64 32
  %wide.load4 = load <8 x float>, ptr %25, align 4, !invariant.load !3, !alias.scope !7, !noalias !24
  %wide.load5 = load <8 x float>, ptr %26, align 4, !invariant.load !3, !alias.scope !7, !noalias !24
  %27 = fmul <8 x float> %wide.load, %wide.load4
  %28 = fmul <8 x float> %wide.load3, %wide.load5
  %29 = getelementptr inbounds nuw float, ptr %12, i64 %index
  %30 = getelementptr inbounds nuw i8, ptr %29, i64 32
  %wide.load6 = load <8 x float>, ptr %29, align 4, !invariant.load !3, !alias.scope !16, !noalias !25
  %wide.load7 = load <8 x float>, ptr %30, align 4, !invariant.load !3, !alias.scope !16, !noalias !25
  %31 = fadd <8 x float> %27, %wide.load6
  %32 = fadd <8 x float> %28, %wide.load7
  %33 = fsub <8 x float> %31, %broadcast.splat
  %34 = fsub <8 x float> %32, %broadcast.splat
  %35 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %33, <8 x float> zeroinitializer)
  %36 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %34, <8 x float> zeroinitializer)
  %37 = getelementptr inbounds nuw float, ptr %8, i64 %index
  %38 = getelementptr inbounds nuw i8, ptr %37, i64 32
  %wide.load8 = load <8 x float>, ptr %37, align 4, !invariant.load !3, !alias.scope !12, !noalias !26
  %wide.load9 = load <8 x float>, ptr %38, align 4, !invariant.load !3, !alias.scope !12, !noalias !26
  %39 = fmul <8 x float> %wide.load8, %35
  %40 = fmul <8 x float> %wide.load9, %36
  %41 = getelementptr inbounds nuw float, ptr %6, i64 %index
  %42 = getelementptr inbounds nuw i8, ptr %41, i64 32
  %wide.load10 = load <8 x float>, ptr %41, align 4, !invariant.load !3, !alias.scope !10, !noalias !27
  %wide.load11 = load <8 x float>, ptr %42, align 4, !invariant.load !3, !alias.scope !10, !noalias !27
  %43 = fadd <8 x float> %wide.load10, %39
  %44 = fadd <8 x float> %wide.load11, %40
  %45 = fadd <8 x float> %wide.load4, %43
  %46 = fadd <8 x float> %wide.load5, %44
  %47 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %45, <8 x float> zeroinitializer)
  %48 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %46, <8 x float> zeroinitializer)
  %49 = getelementptr inbounds nuw float, ptr %16, i64 %24
  %50 = getelementptr inbounds nuw i8, ptr %49, i64 32
  store <8 x float> %47, ptr %49, align 4, !alias.scope !20, !noalias !28
  store <8 x float> %48, ptr %50, align 4, !alias.scope !20, !noalias !28
  %index.next = or disjoint i64 %index, 16
  %51 = getelementptr inbounds nuw float, ptr %14, i64 %index.next
  %52 = getelementptr inbounds nuw i8, ptr %51, i64 32
  %wide.load.1 = load <8 x float>, ptr %51, align 4, !invariant.load !3, !alias.scope !18, !noalias !23
  %wide.load3.1 = load <8 x float>, ptr %52, align 4, !invariant.load !3, !alias.scope !18, !noalias !23
  %53 = add nuw nsw i64 %index.next, %18
  %54 = getelementptr inbounds nuw float, ptr %4, i64 %53
  %55 = getelementptr inbounds nuw i8, ptr %54, i64 32
  %wide.load4.1 = load <8 x float>, ptr %54, align 4, !invariant.load !3, !alias.scope !7, !noalias !24
  %wide.load5.1 = load <8 x float>, ptr %55, align 4, !invariant.load !3, !alias.scope !7, !noalias !24
  %56 = fmul <8 x float> %wide.load.1, %wide.load4.1
  %57 = fmul <8 x float> %wide.load3.1, %wide.load5.1
  %58 = getelementptr inbounds nuw float, ptr %12, i64 %index.next
  %59 = getelementptr inbounds nuw i8, ptr %58, i64 32
  %wide.load6.1 = load <8 x float>, ptr %58, align 4, !invariant.load !3, !alias.scope !16, !noalias !25
  %wide.load7.1 = load <8 x float>, ptr %59, align 4, !invariant.load !3, !alias.scope !16, !noalias !25
  %60 = fadd <8 x float> %56, %wide.load6.1
  %61 = fadd <8 x float> %57, %wide.load7.1
  %62 = fsub <8 x float> %60, %broadcast.splat
  %63 = fsub <8 x float> %61, %broadcast.splat
  %64 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %62, <8 x float> zeroinitializer)
  %65 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %63, <8 x float> zeroinitializer)
  %66 = getelementptr inbounds nuw float, ptr %8, i64 %index.next
  %67 = getelementptr inbounds nuw i8, ptr %66, i64 32
  %wide.load8.1 = load <8 x float>, ptr %66, align 4, !invariant.load !3, !alias.scope !12, !noalias !26
  %wide.load9.1 = load <8 x float>, ptr %67, align 4, !invariant.load !3, !alias.scope !12, !noalias !26
  %68 = fmul <8 x float> %wide.load8.1, %64
  %69 = fmul <8 x float> %wide.load9.1, %65
  %70 = getelementptr inbounds nuw float, ptr %6, i64 %index.next
  %71 = getelementptr inbounds nuw i8, ptr %70, i64 32
  %wide.load10.1 = load <8 x float>, ptr %70, align 4, !invariant.load !3, !alias.scope !10, !noalias !27
  %wide.load11.1 = load <8 x float>, ptr %71, align 4, !invariant.load !3, !alias.scope !10, !noalias !27
  %72 = fadd <8 x float> %wide.load10.1, %68
  %73 = fadd <8 x float> %wide.load11.1, %69
  %74 = fadd <8 x float> %wide.load4.1, %72
  %75 = fadd <8 x float> %wide.load5.1, %73
  %76 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %74, <8 x float> zeroinitializer)
  %77 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %75, <8 x float> zeroinitializer)
  %78 = getelementptr inbounds nuw float, ptr %16, i64 %53
  %79 = getelementptr inbounds nuw i8, ptr %78, i64 32
  store <8 x float> %76, ptr %78, align 4, !alias.scope !20, !noalias !28
  store <8 x float> %77, ptr %79, align 4, !alias.scope !20, !noalias !28
  %index.next.1 = add nuw nsw i64 %index, 32
  %80 = icmp eq i64 %index.next.1, 768
  br i1 %80, label %middle.block, label %vector.body, !llvm.loop !29

middle.block:                                     ; preds = %vector.body
  %81 = add nuw nsw i64 %17, 1
  %exitcond2.not = icmp eq i64 %81, 1024
  br i1 %exitcond2.not, label %add_maximum_fusion_wrapped.exit, label %vector.ph, !llvm.loop !32

add_maximum_fusion_wrapped.exit:                  ; preds = %middle.block
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.maximum.v8f32(<8 x float>, <8 x float>) #2

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 0}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 3145728}
!5 = !{i64 3072}
!6 = !{i64 4096}
!7 = !{!8}
!8 = distinct !{!8, !9, !"add_maximum_fusion_wrapped: argument 0"}
!9 = distinct !{!9, !"add_maximum_fusion_wrapped"}
!10 = !{!11}
!11 = distinct !{!11, !9, !"add_maximum_fusion_wrapped: argument 1"}
!12 = !{!13}
!13 = distinct !{!13, !9, !"add_maximum_fusion_wrapped: argument 2"}
!14 = !{!15}
!15 = distinct !{!15, !9, !"add_maximum_fusion_wrapped: argument 3"}
!16 = !{!17}
!17 = distinct !{!17, !9, !"add_maximum_fusion_wrapped: argument 4"}
!18 = !{!19}
!19 = distinct !{!19, !9, !"add_maximum_fusion_wrapped: argument 5"}
!20 = !{!21}
!21 = distinct !{!21, !9, !"add_maximum_fusion_wrapped: argument 6"}
!22 = !{!8, !11, !13, !17, !19, !21}
!23 = !{!8, !11, !13, !15, !17, !21}
!24 = !{!11, !13, !15, !17, !19, !21}
!25 = !{!8, !11, !13, !15, !19, !21}
!26 = !{!8, !11, !15, !17, !19, !21}
!27 = !{!8, !13, !15, !17, !19, !21}
!28 = !{!8, !11, !13, !15, !17, !19}
!29 = distinct !{!29, !30, !31}
!30 = !{!"llvm.loop.isvectorized", i32 1}
!31 = !{!"llvm.loop.unroll.runtime.disable"}
!32 = distinct !{!32, !33}
!33 = !{!"llvm.loop.unroll.disable"}
