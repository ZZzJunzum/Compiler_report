; ModuleID = '__compute_module_convert_reduce_fusion_kernel_module'
source_filename = "__compute_module_convert_reduce_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @convert_reduce_fusion(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !5
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !4
  %9 = getelementptr inbounds nuw i8, ptr %3, i64 48
  %10 = load ptr, ptr %9, align 8, !invariant.load !3, !dereferenceable !4
  %11 = getelementptr inbounds nuw i8, ptr %3, i64 64
  %12 = load ptr, ptr %11, align 8, !invariant.load !3, !dereferenceable !5
  %13 = getelementptr inbounds nuw i8, ptr %3, i64 80
  %14 = load ptr, ptr %13, align 8, !invariant.load !3, !dereferenceable !4
  %15 = getelementptr inbounds nuw i8, ptr %3, i64 96
  %16 = load ptr, ptr %15, align 8, !invariant.load !3, !dereferenceable !6
  %17 = getelementptr inbounds nuw i8, ptr %3, i64 112
  %18 = load ptr, ptr %17, align 8, !invariant.load !3, !dereferenceable !6
  %19 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %20 = load ptr, ptr %19, align 8
  %21 = load i64, ptr %20, align 4, !invariant.load !3
  tail call void @llvm.experimental.noalias.scope.decl(metadata !7)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !10)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !12)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !14)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !16)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !18)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !20)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !22)
  %22 = icmp slt i64 %21, 11
  br i1 %22, label %23, label %104

23:                                               ; preds = %1
  %24 = icmp sgt i64 %21, -1
  br i1 %24, label %25, label %convert_reduce_fusion_wrapped.exit

25:                                               ; preds = %23
  %26 = mul nuw nsw i64 %21, 86
  %27 = mul nuw nsw i64 %21, 66048
  br label %vector.ph41

vector.ph41:                                      ; preds = %25, %middle.block61
  %28 = phi i64 [ 0, %25 ], [ %103, %middle.block61 ]
  %29 = mul nuw nsw i64 %28, 768
  %30 = add nuw nsw i64 %29, %27
  br label %vector.body42

vector.body42:                                    ; preds = %vector.body42, %vector.ph41
  %index43 = phi i64 [ 0, %vector.ph41 ], [ %index.next60.1, %vector.body42 ]
  %vec.phi44 = phi <8 x i32> [ zeroinitializer, %vector.ph41 ], [ %95, %vector.body42 ]
  %vec.phi45 = phi <8 x i32> [ zeroinitializer, %vector.ph41 ], [ %96, %vector.body42 ]
  %vec.phi46 = phi <8 x i32> [ zeroinitializer, %vector.ph41 ], [ %93, %vector.body42 ]
  %vec.phi47 = phi <8 x i32> [ zeroinitializer, %vector.ph41 ], [ %94, %vector.body42 ]
  %31 = add nuw nsw i64 %30, %index43
  %32 = getelementptr inbounds nuw float, ptr %12, i64 %31
  %33 = getelementptr inbounds nuw i8, ptr %32, i64 32
  %wide.load48 = load <8 x float>, ptr %32, align 4, !invariant.load !3, !alias.scope !16, !noalias !24
  %wide.load49 = load <8 x float>, ptr %33, align 4, !invariant.load !3, !alias.scope !16, !noalias !24
  %34 = getelementptr inbounds nuw float, ptr %14, i64 %index43
  %35 = getelementptr inbounds nuw i8, ptr %34, i64 32
  %wide.load50 = load <8 x float>, ptr %34, align 4, !invariant.load !3, !alias.scope !18, !noalias !25
  %wide.load51 = load <8 x float>, ptr %35, align 4, !invariant.load !3, !alias.scope !18, !noalias !25
  %36 = fmul <8 x float> %wide.load48, %wide.load50
  %37 = fmul <8 x float> %wide.load49, %wide.load51
  %38 = getelementptr inbounds nuw float, ptr %10, i64 %index43
  %39 = getelementptr inbounds nuw i8, ptr %38, i64 32
  %wide.load52 = load <8 x float>, ptr %38, align 4, !invariant.load !3, !alias.scope !14, !noalias !26
  %wide.load53 = load <8 x float>, ptr %39, align 4, !invariant.load !3, !alias.scope !14, !noalias !26
  %40 = fadd <8 x float> %36, %wide.load52
  %41 = fadd <8 x float> %37, %wide.load53
  %42 = fcmp ogt <8 x float> %40, zeroinitializer
  %43 = fcmp ogt <8 x float> %41, zeroinitializer
  %44 = zext <8 x i1> %42 to <8 x i32>
  %45 = zext <8 x i1> %43 to <8 x i32>
  %46 = getelementptr inbounds nuw float, ptr %6, i64 %31
  %47 = getelementptr inbounds nuw i8, ptr %46, i64 32
  %wide.load54 = load <8 x float>, ptr %46, align 4, !invariant.load !3, !alias.scope !10, !noalias !27
  %wide.load55 = load <8 x float>, ptr %47, align 4, !invariant.load !3, !alias.scope !10, !noalias !27
  %48 = getelementptr inbounds nuw float, ptr %8, i64 %index43
  %49 = getelementptr inbounds nuw i8, ptr %48, i64 32
  %wide.load56 = load <8 x float>, ptr %48, align 4, !invariant.load !3, !alias.scope !12, !noalias !28
  %wide.load57 = load <8 x float>, ptr %49, align 4, !invariant.load !3, !alias.scope !12, !noalias !28
  %50 = fmul <8 x float> %wide.load54, %wide.load56
  %51 = fmul <8 x float> %wide.load55, %wide.load57
  %52 = getelementptr inbounds nuw float, ptr %4, i64 %index43
  %53 = getelementptr inbounds nuw i8, ptr %52, i64 32
  %wide.load58 = load <8 x float>, ptr %52, align 4, !invariant.load !3, !alias.scope !7, !noalias !29
  %wide.load59 = load <8 x float>, ptr %53, align 4, !invariant.load !3, !alias.scope !7, !noalias !29
  %54 = fadd <8 x float> %50, %wide.load58
  %55 = fadd <8 x float> %51, %wide.load59
  %56 = fcmp ogt <8 x float> %54, zeroinitializer
  %57 = fcmp ogt <8 x float> %55, zeroinitializer
  %58 = zext <8 x i1> %56 to <8 x i32>
  %59 = zext <8 x i1> %57 to <8 x i32>
  %60 = add <8 x i32> %vec.phi46, %44
  %61 = add <8 x i32> %vec.phi47, %45
  %62 = add <8 x i32> %vec.phi44, %58
  %63 = add <8 x i32> %vec.phi45, %59
  %index.next60 = or disjoint i64 %index43, 16
  %64 = add nuw nsw i64 %30, %index.next60
  %65 = getelementptr inbounds nuw float, ptr %12, i64 %64
  %66 = getelementptr inbounds nuw i8, ptr %65, i64 32
  %wide.load48.1 = load <8 x float>, ptr %65, align 4, !invariant.load !3, !alias.scope !16, !noalias !24
  %wide.load49.1 = load <8 x float>, ptr %66, align 4, !invariant.load !3, !alias.scope !16, !noalias !24
  %67 = getelementptr inbounds nuw float, ptr %14, i64 %index.next60
  %68 = getelementptr inbounds nuw i8, ptr %67, i64 32
  %wide.load50.1 = load <8 x float>, ptr %67, align 4, !invariant.load !3, !alias.scope !18, !noalias !25
  %wide.load51.1 = load <8 x float>, ptr %68, align 4, !invariant.load !3, !alias.scope !18, !noalias !25
  %69 = fmul <8 x float> %wide.load48.1, %wide.load50.1
  %70 = fmul <8 x float> %wide.load49.1, %wide.load51.1
  %71 = getelementptr inbounds nuw float, ptr %10, i64 %index.next60
  %72 = getelementptr inbounds nuw i8, ptr %71, i64 32
  %wide.load52.1 = load <8 x float>, ptr %71, align 4, !invariant.load !3, !alias.scope !14, !noalias !26
  %wide.load53.1 = load <8 x float>, ptr %72, align 4, !invariant.load !3, !alias.scope !14, !noalias !26
  %73 = fadd <8 x float> %69, %wide.load52.1
  %74 = fadd <8 x float> %70, %wide.load53.1
  %75 = fcmp ogt <8 x float> %73, zeroinitializer
  %76 = fcmp ogt <8 x float> %74, zeroinitializer
  %77 = zext <8 x i1> %75 to <8 x i32>
  %78 = zext <8 x i1> %76 to <8 x i32>
  %79 = getelementptr inbounds nuw float, ptr %6, i64 %64
  %80 = getelementptr inbounds nuw i8, ptr %79, i64 32
  %wide.load54.1 = load <8 x float>, ptr %79, align 4, !invariant.load !3, !alias.scope !10, !noalias !27
  %wide.load55.1 = load <8 x float>, ptr %80, align 4, !invariant.load !3, !alias.scope !10, !noalias !27
  %81 = getelementptr inbounds nuw float, ptr %8, i64 %index.next60
  %82 = getelementptr inbounds nuw i8, ptr %81, i64 32
  %wide.load56.1 = load <8 x float>, ptr %81, align 4, !invariant.load !3, !alias.scope !12, !noalias !28
  %wide.load57.1 = load <8 x float>, ptr %82, align 4, !invariant.load !3, !alias.scope !12, !noalias !28
  %83 = fmul <8 x float> %wide.load54.1, %wide.load56.1
  %84 = fmul <8 x float> %wide.load55.1, %wide.load57.1
  %85 = getelementptr inbounds nuw float, ptr %4, i64 %index.next60
  %86 = getelementptr inbounds nuw i8, ptr %85, i64 32
  %wide.load58.1 = load <8 x float>, ptr %85, align 4, !invariant.load !3, !alias.scope !7, !noalias !29
  %wide.load59.1 = load <8 x float>, ptr %86, align 4, !invariant.load !3, !alias.scope !7, !noalias !29
  %87 = fadd <8 x float> %83, %wide.load58.1
  %88 = fadd <8 x float> %84, %wide.load59.1
  %89 = fcmp ogt <8 x float> %87, zeroinitializer
  %90 = fcmp ogt <8 x float> %88, zeroinitializer
  %91 = zext <8 x i1> %89 to <8 x i32>
  %92 = zext <8 x i1> %90 to <8 x i32>
  %93 = add <8 x i32> %60, %77
  %94 = add <8 x i32> %61, %78
  %95 = add <8 x i32> %62, %91
  %96 = add <8 x i32> %63, %92
  %index.next60.1 = add nuw nsw i64 %index43, 32
  %97 = icmp eq i64 %index.next60.1, 768
  br i1 %97, label %middle.block61, label %vector.body42, !llvm.loop !30

middle.block61:                                   ; preds = %vector.body42
  %bin.rdx63 = add <8 x i32> %94, %93
  %98 = tail call i32 @llvm.vector.reduce.add.v8i32(<8 x i32> %bin.rdx63)
  %bin.rdx62 = add <8 x i32> %96, %95
  %99 = tail call i32 @llvm.vector.reduce.add.v8i32(<8 x i32> %bin.rdx62)
  %100 = add nuw nsw i64 %28, %26
  %101 = getelementptr inbounds nuw i32, ptr %16, i64 %100
  store i32 %98, ptr %101, align 4, !alias.scope !20, !noalias !33
  %102 = getelementptr inbounds nuw i32, ptr %18, i64 %100
  store i32 %99, ptr %102, align 4, !alias.scope !22, !noalias !34
  %103 = add nuw nsw i64 %28, 1
  %exitcond15.not = icmp eq i64 %103, 86
  br i1 %exitcond15.not, label %convert_reduce_fusion_wrapped.exit, label %vector.ph41, !llvm.loop !35

104:                                              ; preds = %1
  %105 = icmp eq i64 %21, 11
  br i1 %105, label %.preheader, label %convert_reduce_fusion_wrapped.exit

.preheader:                                       ; preds = %104, %middle.block
  %106 = phi i64 [ %181, %middle.block ], [ 0, %104 ]
  %107 = mul nuw nsw i64 %106, 768
  %108 = add nuw nsw i64 %107, 726528
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %.preheader
  %index = phi i64 [ 0, %.preheader ], [ %index.next.1, %vector.body ]
  %vec.phi = phi <8 x i32> [ zeroinitializer, %.preheader ], [ %173, %vector.body ]
  %vec.phi26 = phi <8 x i32> [ zeroinitializer, %.preheader ], [ %174, %vector.body ]
  %vec.phi27 = phi <8 x i32> [ zeroinitializer, %.preheader ], [ %171, %vector.body ]
  %vec.phi28 = phi <8 x i32> [ zeroinitializer, %.preheader ], [ %172, %vector.body ]
  %109 = add nuw nsw i64 %108, %index
  %110 = getelementptr inbounds nuw float, ptr %12, i64 %109
  %111 = getelementptr inbounds nuw i8, ptr %110, i64 32
  %wide.load = load <8 x float>, ptr %110, align 4, !invariant.load !3, !alias.scope !16, !noalias !24
  %wide.load29 = load <8 x float>, ptr %111, align 4, !invariant.load !3, !alias.scope !16, !noalias !24
  %112 = getelementptr inbounds nuw float, ptr %14, i64 %index
  %113 = getelementptr inbounds nuw i8, ptr %112, i64 32
  %wide.load30 = load <8 x float>, ptr %112, align 4, !invariant.load !3, !alias.scope !18, !noalias !25
  %wide.load31 = load <8 x float>, ptr %113, align 4, !invariant.load !3, !alias.scope !18, !noalias !25
  %114 = fmul <8 x float> %wide.load, %wide.load30
  %115 = fmul <8 x float> %wide.load29, %wide.load31
  %116 = getelementptr inbounds nuw float, ptr %10, i64 %index
  %117 = getelementptr inbounds nuw i8, ptr %116, i64 32
  %wide.load32 = load <8 x float>, ptr %116, align 4, !invariant.load !3, !alias.scope !14, !noalias !26
  %wide.load33 = load <8 x float>, ptr %117, align 4, !invariant.load !3, !alias.scope !14, !noalias !26
  %118 = fadd <8 x float> %114, %wide.load32
  %119 = fadd <8 x float> %115, %wide.load33
  %120 = fcmp ogt <8 x float> %118, zeroinitializer
  %121 = fcmp ogt <8 x float> %119, zeroinitializer
  %122 = zext <8 x i1> %120 to <8 x i32>
  %123 = zext <8 x i1> %121 to <8 x i32>
  %124 = getelementptr inbounds nuw float, ptr %6, i64 %109
  %125 = getelementptr inbounds nuw i8, ptr %124, i64 32
  %wide.load34 = load <8 x float>, ptr %124, align 4, !invariant.load !3, !alias.scope !10, !noalias !27
  %wide.load35 = load <8 x float>, ptr %125, align 4, !invariant.load !3, !alias.scope !10, !noalias !27
  %126 = getelementptr inbounds nuw float, ptr %8, i64 %index
  %127 = getelementptr inbounds nuw i8, ptr %126, i64 32
  %wide.load36 = load <8 x float>, ptr %126, align 4, !invariant.load !3, !alias.scope !12, !noalias !28
  %wide.load37 = load <8 x float>, ptr %127, align 4, !invariant.load !3, !alias.scope !12, !noalias !28
  %128 = fmul <8 x float> %wide.load34, %wide.load36
  %129 = fmul <8 x float> %wide.load35, %wide.load37
  %130 = getelementptr inbounds nuw float, ptr %4, i64 %index
  %131 = getelementptr inbounds nuw i8, ptr %130, i64 32
  %wide.load38 = load <8 x float>, ptr %130, align 4, !invariant.load !3, !alias.scope !7, !noalias !29
  %wide.load39 = load <8 x float>, ptr %131, align 4, !invariant.load !3, !alias.scope !7, !noalias !29
  %132 = fadd <8 x float> %128, %wide.load38
  %133 = fadd <8 x float> %129, %wide.load39
  %134 = fcmp ogt <8 x float> %132, zeroinitializer
  %135 = fcmp ogt <8 x float> %133, zeroinitializer
  %136 = zext <8 x i1> %134 to <8 x i32>
  %137 = zext <8 x i1> %135 to <8 x i32>
  %138 = add <8 x i32> %vec.phi27, %122
  %139 = add <8 x i32> %vec.phi28, %123
  %140 = add <8 x i32> %vec.phi, %136
  %141 = add <8 x i32> %vec.phi26, %137
  %index.next = or disjoint i64 %index, 16
  %142 = add nuw nsw i64 %108, %index.next
  %143 = getelementptr inbounds nuw float, ptr %12, i64 %142
  %144 = getelementptr inbounds nuw i8, ptr %143, i64 32
  %wide.load.1 = load <8 x float>, ptr %143, align 4, !invariant.load !3, !alias.scope !16, !noalias !24
  %wide.load29.1 = load <8 x float>, ptr %144, align 4, !invariant.load !3, !alias.scope !16, !noalias !24
  %145 = getelementptr inbounds nuw float, ptr %14, i64 %index.next
  %146 = getelementptr inbounds nuw i8, ptr %145, i64 32
  %wide.load30.1 = load <8 x float>, ptr %145, align 4, !invariant.load !3, !alias.scope !18, !noalias !25
  %wide.load31.1 = load <8 x float>, ptr %146, align 4, !invariant.load !3, !alias.scope !18, !noalias !25
  %147 = fmul <8 x float> %wide.load.1, %wide.load30.1
  %148 = fmul <8 x float> %wide.load29.1, %wide.load31.1
  %149 = getelementptr inbounds nuw float, ptr %10, i64 %index.next
  %150 = getelementptr inbounds nuw i8, ptr %149, i64 32
  %wide.load32.1 = load <8 x float>, ptr %149, align 4, !invariant.load !3, !alias.scope !14, !noalias !26
  %wide.load33.1 = load <8 x float>, ptr %150, align 4, !invariant.load !3, !alias.scope !14, !noalias !26
  %151 = fadd <8 x float> %147, %wide.load32.1
  %152 = fadd <8 x float> %148, %wide.load33.1
  %153 = fcmp ogt <8 x float> %151, zeroinitializer
  %154 = fcmp ogt <8 x float> %152, zeroinitializer
  %155 = zext <8 x i1> %153 to <8 x i32>
  %156 = zext <8 x i1> %154 to <8 x i32>
  %157 = getelementptr inbounds nuw float, ptr %6, i64 %142
  %158 = getelementptr inbounds nuw i8, ptr %157, i64 32
  %wide.load34.1 = load <8 x float>, ptr %157, align 4, !invariant.load !3, !alias.scope !10, !noalias !27
  %wide.load35.1 = load <8 x float>, ptr %158, align 4, !invariant.load !3, !alias.scope !10, !noalias !27
  %159 = getelementptr inbounds nuw float, ptr %8, i64 %index.next
  %160 = getelementptr inbounds nuw i8, ptr %159, i64 32
  %wide.load36.1 = load <8 x float>, ptr %159, align 4, !invariant.load !3, !alias.scope !12, !noalias !28
  %wide.load37.1 = load <8 x float>, ptr %160, align 4, !invariant.load !3, !alias.scope !12, !noalias !28
  %161 = fmul <8 x float> %wide.load34.1, %wide.load36.1
  %162 = fmul <8 x float> %wide.load35.1, %wide.load37.1
  %163 = getelementptr inbounds nuw float, ptr %4, i64 %index.next
  %164 = getelementptr inbounds nuw i8, ptr %163, i64 32
  %wide.load38.1 = load <8 x float>, ptr %163, align 4, !invariant.load !3, !alias.scope !7, !noalias !29
  %wide.load39.1 = load <8 x float>, ptr %164, align 4, !invariant.load !3, !alias.scope !7, !noalias !29
  %165 = fadd <8 x float> %161, %wide.load38.1
  %166 = fadd <8 x float> %162, %wide.load39.1
  %167 = fcmp ogt <8 x float> %165, zeroinitializer
  %168 = fcmp ogt <8 x float> %166, zeroinitializer
  %169 = zext <8 x i1> %167 to <8 x i32>
  %170 = zext <8 x i1> %168 to <8 x i32>
  %171 = add <8 x i32> %138, %155
  %172 = add <8 x i32> %139, %156
  %173 = add <8 x i32> %140, %169
  %174 = add <8 x i32> %141, %170
  %index.next.1 = add nuw nsw i64 %index, 32
  %175 = icmp eq i64 %index.next.1, 768
  br i1 %175, label %middle.block, label %vector.body, !llvm.loop !37

middle.block:                                     ; preds = %vector.body
  %bin.rdx40 = add <8 x i32> %172, %171
  %176 = tail call i32 @llvm.vector.reduce.add.v8i32(<8 x i32> %bin.rdx40)
  %bin.rdx = add <8 x i32> %174, %173
  %177 = tail call i32 @llvm.vector.reduce.add.v8i32(<8 x i32> %bin.rdx)
  %178 = add nuw nsw i64 %106, 946
  %179 = getelementptr inbounds nuw i32, ptr %16, i64 %178
  store i32 %176, ptr %179, align 4, !alias.scope !20, !noalias !33
  %180 = getelementptr inbounds nuw i32, ptr %18, i64 %178
  store i32 %177, ptr %180, align 4, !alias.scope !22, !noalias !34
  %181 = add nuw nsw i64 %106, 1
  %exitcond13.not = icmp eq i64 %181, 78
  br i1 %exitcond13.not, label %convert_reduce_fusion_wrapped.exit, label %.preheader, !llvm.loop !35

convert_reduce_fusion_wrapped.exit:               ; preds = %middle.block, %middle.block61, %23, %104
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.vector.reduce.add.v8i32(<8 x i32>) #2

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #2 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 0}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 3072}
!5 = !{i64 3145728}
!6 = !{i64 4096}
!7 = !{!8}
!8 = distinct !{!8, !9, !"convert_reduce_fusion_wrapped: argument 0"}
!9 = distinct !{!9, !"convert_reduce_fusion_wrapped"}
!10 = !{!11}
!11 = distinct !{!11, !9, !"convert_reduce_fusion_wrapped: argument 1"}
!12 = !{!13}
!13 = distinct !{!13, !9, !"convert_reduce_fusion_wrapped: argument 2"}
!14 = !{!15}
!15 = distinct !{!15, !9, !"convert_reduce_fusion_wrapped: argument 3"}
!16 = !{!17}
!17 = distinct !{!17, !9, !"convert_reduce_fusion_wrapped: argument 4"}
!18 = !{!19}
!19 = distinct !{!19, !9, !"convert_reduce_fusion_wrapped: argument 5"}
!20 = !{!21}
!21 = distinct !{!21, !9, !"convert_reduce_fusion_wrapped: argument 6"}
!22 = !{!23}
!23 = distinct !{!23, !9, !"convert_reduce_fusion_wrapped: argument 7"}
!24 = !{!8, !11, !13, !15, !19, !21, !23}
!25 = !{!8, !11, !13, !15, !17, !21, !23}
!26 = !{!8, !11, !13, !17, !19, !21, !23}
!27 = !{!8, !13, !15, !17, !19, !21, !23}
!28 = !{!8, !11, !15, !17, !19, !21, !23}
!29 = !{!11, !13, !15, !17, !19, !21, !23}
!30 = distinct !{!30, !31, !32}
!31 = !{!"llvm.loop.isvectorized", i32 1}
!32 = !{!"llvm.loop.unroll.runtime.disable"}
!33 = !{!8, !11, !13, !15, !17, !19, !23}
!34 = !{!8, !11, !13, !15, !17, !19, !21}
!35 = distinct !{!35, !36}
!36 = !{!"llvm.loop.unroll.disable"}
!37 = distinct !{!37, !31, !32}
