; ModuleID = '__compute_module_convert_reduce_fusion_kernel_module'
source_filename = "__compute_module_convert_reduce_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @convert_reduce_fusion(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !4
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !4
  %9 = getelementptr inbounds nuw i8, ptr %3, i64 48
  %10 = load ptr, ptr %9, align 8, !invariant.load !3, !dereferenceable !5
  %11 = getelementptr inbounds nuw i8, ptr %3, i64 64
  %12 = load ptr, ptr %11, align 8, !invariant.load !3, !dereferenceable !4
  %13 = getelementptr inbounds nuw i8, ptr %3, i64 80
  %14 = load ptr, ptr %13, align 8, !invariant.load !3, !dereferenceable !6
  %15 = getelementptr inbounds nuw i8, ptr %3, i64 96
  %16 = load ptr, ptr %15, align 8, !invariant.load !3, !dereferenceable !6
  %17 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %18 = load ptr, ptr %17, align 8
  %19 = load i64, ptr %18, align 4, !invariant.load !3
  tail call void @llvm.experimental.noalias.scope.decl(metadata !7)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !10)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !12)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !14)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !16)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !18)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !20)
  %20 = icmp slt i64 %19, 11
  br i1 %20, label %21, label %99

21:                                               ; preds = %1
  %22 = icmp sgt i64 %19, -1
  br i1 %22, label %23, label %convert_reduce_fusion_wrapped.exit

23:                                               ; preds = %21
  %24 = mul nuw nsw i64 %19, 27
  %.idx1 = mul nuw nsw i64 %19, 17280
  %25 = getelementptr i8, ptr %10, i64 %.idx1
  br label %vector.ph41

vector.ph41:                                      ; preds = %23, %middle.block59
  %26 = phi i64 [ 0, %23 ], [ %98, %middle.block59 ]
  %.idx2 = mul nuw nsw i64 %26, 640
  %27 = getelementptr i8, ptr %25, i64 %.idx2
  br label %vector.body42

vector.body42:                                    ; preds = %vector.body42, %vector.ph41
  %index43 = phi i64 [ 0, %vector.ph41 ], [ %index.next58.1, %vector.body42 ]
  %vec.phi44 = phi <8 x i32> [ zeroinitializer, %vector.ph41 ], [ %90, %vector.body42 ]
  %vec.phi45 = phi <8 x i32> [ zeroinitializer, %vector.ph41 ], [ %91, %vector.body42 ]
  %vec.phi46 = phi <8 x i32> [ zeroinitializer, %vector.ph41 ], [ %88, %vector.body42 ]
  %vec.phi47 = phi <8 x i32> [ zeroinitializer, %vector.ph41 ], [ %89, %vector.body42 ]
  %28 = getelementptr float, ptr %27, i64 %index43
  %29 = getelementptr i8, ptr %28, i64 32
  %wide.load48 = load <8 x float>, ptr %28, align 4, !invariant.load !3, !alias.scope !14, !noalias !22
  %wide.load49 = load <8 x float>, ptr %29, align 4, !invariant.load !3, !alias.scope !14, !noalias !22
  %30 = getelementptr inbounds nuw float, ptr %12, i64 %index43
  %31 = getelementptr inbounds nuw i8, ptr %30, i64 32
  %wide.load50 = load <8 x float>, ptr %30, align 4, !invariant.load !3, !alias.scope !16, !noalias !23
  %wide.load51 = load <8 x float>, ptr %31, align 4, !invariant.load !3, !alias.scope !16, !noalias !23
  %32 = fmul <8 x float> %wide.load48, %wide.load50
  %33 = fmul <8 x float> %wide.load49, %wide.load51
  %34 = getelementptr inbounds nuw float, ptr %8, i64 %index43
  %35 = getelementptr inbounds nuw i8, ptr %34, i64 32
  %wide.load52 = load <8 x float>, ptr %34, align 4, !invariant.load !3, !alias.scope !12, !noalias !24
  %wide.load53 = load <8 x float>, ptr %35, align 4, !invariant.load !3, !alias.scope !12, !noalias !24
  %36 = fadd <8 x float> %32, %wide.load52
  %37 = fadd <8 x float> %33, %wide.load53
  %38 = fcmp ogt <8 x float> %36, zeroinitializer
  %39 = fcmp ogt <8 x float> %37, zeroinitializer
  %40 = zext <8 x i1> %38 to <8 x i32>
  %41 = zext <8 x i1> %39 to <8 x i32>
  %42 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %36, <8 x float> zeroinitializer)
  %43 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %37, <8 x float> zeroinitializer)
  %44 = getelementptr inbounds nuw float, ptr %6, i64 %index43
  %45 = getelementptr inbounds nuw i8, ptr %44, i64 32
  %wide.load54 = load <8 x float>, ptr %44, align 4, !invariant.load !3, !alias.scope !10, !noalias !25
  %wide.load55 = load <8 x float>, ptr %45, align 4, !invariant.load !3, !alias.scope !10, !noalias !25
  %46 = fmul <8 x float> %wide.load54, %42
  %47 = fmul <8 x float> %wide.load55, %43
  %48 = getelementptr inbounds nuw float, ptr %4, i64 %index43
  %49 = getelementptr inbounds nuw i8, ptr %48, i64 32
  %wide.load56 = load <8 x float>, ptr %48, align 4, !invariant.load !3, !alias.scope !7, !noalias !26
  %wide.load57 = load <8 x float>, ptr %49, align 4, !invariant.load !3, !alias.scope !7, !noalias !26
  %50 = fadd <8 x float> %wide.load56, %46
  %51 = fadd <8 x float> %wide.load57, %47
  %52 = fcmp ogt <8 x float> %50, zeroinitializer
  %53 = fcmp ogt <8 x float> %51, zeroinitializer
  %54 = zext <8 x i1> %52 to <8 x i32>
  %55 = zext <8 x i1> %53 to <8 x i32>
  %56 = add <8 x i32> %vec.phi46, %40
  %57 = add <8 x i32> %vec.phi47, %41
  %58 = add <8 x i32> %vec.phi44, %54
  %59 = add <8 x i32> %vec.phi45, %55
  %index.next58 = or disjoint i64 %index43, 16
  %60 = getelementptr float, ptr %27, i64 %index.next58
  %61 = getelementptr i8, ptr %60, i64 32
  %wide.load48.1 = load <8 x float>, ptr %60, align 4, !invariant.load !3, !alias.scope !14, !noalias !22
  %wide.load49.1 = load <8 x float>, ptr %61, align 4, !invariant.load !3, !alias.scope !14, !noalias !22
  %62 = getelementptr inbounds nuw float, ptr %12, i64 %index.next58
  %63 = getelementptr inbounds nuw i8, ptr %62, i64 32
  %wide.load50.1 = load <8 x float>, ptr %62, align 4, !invariant.load !3, !alias.scope !16, !noalias !23
  %wide.load51.1 = load <8 x float>, ptr %63, align 4, !invariant.load !3, !alias.scope !16, !noalias !23
  %64 = fmul <8 x float> %wide.load48.1, %wide.load50.1
  %65 = fmul <8 x float> %wide.load49.1, %wide.load51.1
  %66 = getelementptr inbounds nuw float, ptr %8, i64 %index.next58
  %67 = getelementptr inbounds nuw i8, ptr %66, i64 32
  %wide.load52.1 = load <8 x float>, ptr %66, align 4, !invariant.load !3, !alias.scope !12, !noalias !24
  %wide.load53.1 = load <8 x float>, ptr %67, align 4, !invariant.load !3, !alias.scope !12, !noalias !24
  %68 = fadd <8 x float> %64, %wide.load52.1
  %69 = fadd <8 x float> %65, %wide.load53.1
  %70 = fcmp ogt <8 x float> %68, zeroinitializer
  %71 = fcmp ogt <8 x float> %69, zeroinitializer
  %72 = zext <8 x i1> %70 to <8 x i32>
  %73 = zext <8 x i1> %71 to <8 x i32>
  %74 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %68, <8 x float> zeroinitializer)
  %75 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %69, <8 x float> zeroinitializer)
  %76 = getelementptr inbounds nuw float, ptr %6, i64 %index.next58
  %77 = getelementptr inbounds nuw i8, ptr %76, i64 32
  %wide.load54.1 = load <8 x float>, ptr %76, align 4, !invariant.load !3, !alias.scope !10, !noalias !25
  %wide.load55.1 = load <8 x float>, ptr %77, align 4, !invariant.load !3, !alias.scope !10, !noalias !25
  %78 = fmul <8 x float> %wide.load54.1, %74
  %79 = fmul <8 x float> %wide.load55.1, %75
  %80 = getelementptr inbounds nuw float, ptr %4, i64 %index.next58
  %81 = getelementptr inbounds nuw i8, ptr %80, i64 32
  %wide.load56.1 = load <8 x float>, ptr %80, align 4, !invariant.load !3, !alias.scope !7, !noalias !26
  %wide.load57.1 = load <8 x float>, ptr %81, align 4, !invariant.load !3, !alias.scope !7, !noalias !26
  %82 = fadd <8 x float> %wide.load56.1, %78
  %83 = fadd <8 x float> %wide.load57.1, %79
  %84 = fcmp ogt <8 x float> %82, zeroinitializer
  %85 = fcmp ogt <8 x float> %83, zeroinitializer
  %86 = zext <8 x i1> %84 to <8 x i32>
  %87 = zext <8 x i1> %85 to <8 x i32>
  %88 = add <8 x i32> %56, %72
  %89 = add <8 x i32> %57, %73
  %90 = add <8 x i32> %58, %86
  %91 = add <8 x i32> %59, %87
  %index.next58.1 = add nuw nsw i64 %index43, 32
  %92 = icmp eq i64 %index.next58.1, 160
  br i1 %92, label %middle.block59, label %vector.body42, !llvm.loop !27

middle.block59:                                   ; preds = %vector.body42
  %bin.rdx61 = add <8 x i32> %89, %88
  %93 = tail call i32 @llvm.vector.reduce.add.v8i32(<8 x i32> %bin.rdx61)
  %bin.rdx60 = add <8 x i32> %91, %90
  %94 = tail call i32 @llvm.vector.reduce.add.v8i32(<8 x i32> %bin.rdx60)
  %95 = add nuw nsw i64 %26, %24
  %96 = getelementptr inbounds nuw i32, ptr %14, i64 %95
  store i32 %93, ptr %96, align 4, !alias.scope !18, !noalias !30
  %97 = getelementptr inbounds nuw i32, ptr %16, i64 %95
  store i32 %94, ptr %97, align 4, !alias.scope !20, !noalias !31
  %98 = add nuw nsw i64 %26, 1
  %exitcond17.not = icmp eq i64 %98, 27
  br i1 %exitcond17.not, label %convert_reduce_fusion_wrapped.exit, label %vector.ph41, !llvm.loop !32

99:                                               ; preds = %1
  %100 = icmp eq i64 %19, 11
  br i1 %100, label %.preheader, label %convert_reduce_fusion_wrapped.exit

.preheader:                                       ; preds = %99, %middle.block
  %101 = phi i64 [ %175, %middle.block ], [ 0, %99 ]
  %.idx = mul nuw nsw i64 %101, 640
  %102 = getelementptr i8, ptr %10, i64 %.idx
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %.preheader
  %index = phi i64 [ 0, %.preheader ], [ %index.next.1, %vector.body ]
  %vec.phi = phi <8 x i32> [ zeroinitializer, %.preheader ], [ %167, %vector.body ]
  %vec.phi28 = phi <8 x i32> [ zeroinitializer, %.preheader ], [ %168, %vector.body ]
  %vec.phi29 = phi <8 x i32> [ zeroinitializer, %.preheader ], [ %165, %vector.body ]
  %vec.phi30 = phi <8 x i32> [ zeroinitializer, %.preheader ], [ %166, %vector.body ]
  %103 = getelementptr float, ptr %102, i64 %index
  %104 = getelementptr i8, ptr %103, i64 190080
  %105 = getelementptr i8, ptr %103, i64 190112
  %wide.load = load <8 x float>, ptr %104, align 4, !invariant.load !3, !alias.scope !14, !noalias !22
  %wide.load31 = load <8 x float>, ptr %105, align 4, !invariant.load !3, !alias.scope !14, !noalias !22
  %106 = getelementptr inbounds nuw float, ptr %12, i64 %index
  %107 = getelementptr inbounds nuw i8, ptr %106, i64 32
  %wide.load32 = load <8 x float>, ptr %106, align 4, !invariant.load !3, !alias.scope !16, !noalias !23
  %wide.load33 = load <8 x float>, ptr %107, align 4, !invariant.load !3, !alias.scope !16, !noalias !23
  %108 = fmul <8 x float> %wide.load, %wide.load32
  %109 = fmul <8 x float> %wide.load31, %wide.load33
  %110 = getelementptr inbounds nuw float, ptr %8, i64 %index
  %111 = getelementptr inbounds nuw i8, ptr %110, i64 32
  %wide.load34 = load <8 x float>, ptr %110, align 4, !invariant.load !3, !alias.scope !12, !noalias !24
  %wide.load35 = load <8 x float>, ptr %111, align 4, !invariant.load !3, !alias.scope !12, !noalias !24
  %112 = fadd <8 x float> %108, %wide.load34
  %113 = fadd <8 x float> %109, %wide.load35
  %114 = fcmp ogt <8 x float> %112, zeroinitializer
  %115 = fcmp ogt <8 x float> %113, zeroinitializer
  %116 = zext <8 x i1> %114 to <8 x i32>
  %117 = zext <8 x i1> %115 to <8 x i32>
  %118 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %112, <8 x float> zeroinitializer)
  %119 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %113, <8 x float> zeroinitializer)
  %120 = getelementptr inbounds nuw float, ptr %6, i64 %index
  %121 = getelementptr inbounds nuw i8, ptr %120, i64 32
  %wide.load36 = load <8 x float>, ptr %120, align 4, !invariant.load !3, !alias.scope !10, !noalias !25
  %wide.load37 = load <8 x float>, ptr %121, align 4, !invariant.load !3, !alias.scope !10, !noalias !25
  %122 = fmul <8 x float> %wide.load36, %118
  %123 = fmul <8 x float> %wide.load37, %119
  %124 = getelementptr inbounds nuw float, ptr %4, i64 %index
  %125 = getelementptr inbounds nuw i8, ptr %124, i64 32
  %wide.load38 = load <8 x float>, ptr %124, align 4, !invariant.load !3, !alias.scope !7, !noalias !26
  %wide.load39 = load <8 x float>, ptr %125, align 4, !invariant.load !3, !alias.scope !7, !noalias !26
  %126 = fadd <8 x float> %wide.load38, %122
  %127 = fadd <8 x float> %wide.load39, %123
  %128 = fcmp ogt <8 x float> %126, zeroinitializer
  %129 = fcmp ogt <8 x float> %127, zeroinitializer
  %130 = zext <8 x i1> %128 to <8 x i32>
  %131 = zext <8 x i1> %129 to <8 x i32>
  %132 = add <8 x i32> %vec.phi29, %116
  %133 = add <8 x i32> %vec.phi30, %117
  %134 = add <8 x i32> %vec.phi, %130
  %135 = add <8 x i32> %vec.phi28, %131
  %index.next = or disjoint i64 %index, 16
  %136 = getelementptr float, ptr %102, i64 %index.next
  %137 = getelementptr i8, ptr %136, i64 190080
  %138 = getelementptr i8, ptr %136, i64 190112
  %wide.load.1 = load <8 x float>, ptr %137, align 4, !invariant.load !3, !alias.scope !14, !noalias !22
  %wide.load31.1 = load <8 x float>, ptr %138, align 4, !invariant.load !3, !alias.scope !14, !noalias !22
  %139 = getelementptr inbounds nuw float, ptr %12, i64 %index.next
  %140 = getelementptr inbounds nuw i8, ptr %139, i64 32
  %wide.load32.1 = load <8 x float>, ptr %139, align 4, !invariant.load !3, !alias.scope !16, !noalias !23
  %wide.load33.1 = load <8 x float>, ptr %140, align 4, !invariant.load !3, !alias.scope !16, !noalias !23
  %141 = fmul <8 x float> %wide.load.1, %wide.load32.1
  %142 = fmul <8 x float> %wide.load31.1, %wide.load33.1
  %143 = getelementptr inbounds nuw float, ptr %8, i64 %index.next
  %144 = getelementptr inbounds nuw i8, ptr %143, i64 32
  %wide.load34.1 = load <8 x float>, ptr %143, align 4, !invariant.load !3, !alias.scope !12, !noalias !24
  %wide.load35.1 = load <8 x float>, ptr %144, align 4, !invariant.load !3, !alias.scope !12, !noalias !24
  %145 = fadd <8 x float> %141, %wide.load34.1
  %146 = fadd <8 x float> %142, %wide.load35.1
  %147 = fcmp ogt <8 x float> %145, zeroinitializer
  %148 = fcmp ogt <8 x float> %146, zeroinitializer
  %149 = zext <8 x i1> %147 to <8 x i32>
  %150 = zext <8 x i1> %148 to <8 x i32>
  %151 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %145, <8 x float> zeroinitializer)
  %152 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %146, <8 x float> zeroinitializer)
  %153 = getelementptr inbounds nuw float, ptr %6, i64 %index.next
  %154 = getelementptr inbounds nuw i8, ptr %153, i64 32
  %wide.load36.1 = load <8 x float>, ptr %153, align 4, !invariant.load !3, !alias.scope !10, !noalias !25
  %wide.load37.1 = load <8 x float>, ptr %154, align 4, !invariant.load !3, !alias.scope !10, !noalias !25
  %155 = fmul <8 x float> %wide.load36.1, %151
  %156 = fmul <8 x float> %wide.load37.1, %152
  %157 = getelementptr inbounds nuw float, ptr %4, i64 %index.next
  %158 = getelementptr inbounds nuw i8, ptr %157, i64 32
  %wide.load38.1 = load <8 x float>, ptr %157, align 4, !invariant.load !3, !alias.scope !7, !noalias !26
  %wide.load39.1 = load <8 x float>, ptr %158, align 4, !invariant.load !3, !alias.scope !7, !noalias !26
  %159 = fadd <8 x float> %wide.load38.1, %155
  %160 = fadd <8 x float> %wide.load39.1, %156
  %161 = fcmp ogt <8 x float> %159, zeroinitializer
  %162 = fcmp ogt <8 x float> %160, zeroinitializer
  %163 = zext <8 x i1> %161 to <8 x i32>
  %164 = zext <8 x i1> %162 to <8 x i32>
  %165 = add <8 x i32> %132, %149
  %166 = add <8 x i32> %133, %150
  %167 = add <8 x i32> %134, %163
  %168 = add <8 x i32> %135, %164
  %index.next.1 = add nuw nsw i64 %index, 32
  %169 = icmp eq i64 %index.next.1, 160
  br i1 %169, label %middle.block, label %vector.body, !llvm.loop !34

middle.block:                                     ; preds = %vector.body
  %bin.rdx40 = add <8 x i32> %166, %165
  %170 = tail call i32 @llvm.vector.reduce.add.v8i32(<8 x i32> %bin.rdx40)
  %bin.rdx = add <8 x i32> %168, %167
  %171 = tail call i32 @llvm.vector.reduce.add.v8i32(<8 x i32> %bin.rdx)
  %172 = add nuw nsw i64 %101, 297
  %173 = getelementptr inbounds nuw i32, ptr %14, i64 %172
  store i32 %170, ptr %173, align 4, !alias.scope !18, !noalias !30
  %174 = getelementptr inbounds nuw i32, ptr %16, i64 %172
  store i32 %171, ptr %174, align 4, !alias.scope !20, !noalias !31
  %175 = add nuw nsw i64 %101, 1
  %exitcond15.not = icmp eq i64 %175, 23
  br i1 %exitcond15.not, label %convert_reduce_fusion_wrapped.exit, label %.preheader, !llvm.loop !32

convert_reduce_fusion_wrapped.exit:               ; preds = %middle.block, %middle.block59, %21, %99
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.maximum.v8f32(<8 x float>, <8 x float>) #2

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.vector.reduce.add.v8i32(<8 x i32>) #3

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #3 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 0}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 640}
!5 = !{i64 204800}
!6 = !{i64 1280}
!7 = !{!8}
!8 = distinct !{!8, !9, !"convert_reduce_fusion_wrapped: argument 0"}
!9 = distinct !{!9, !"convert_reduce_fusion_wrapped"}
!10 = !{!11}
!11 = distinct !{!11, !9, !"convert_reduce_fusion_wrapped: argument 1"}
!12 = !{!13}
!13 = distinct !{!13, !9, !"convert_reduce_fusion_wrapped: argument 2"}
!14 = !{!15}
!15 = distinct !{!15, !9, !"convert_reduce_fusion_wrapped: argument 3"}
!16 = !{!17}
!17 = distinct !{!17, !9, !"convert_reduce_fusion_wrapped: argument 4"}
!18 = !{!19}
!19 = distinct !{!19, !9, !"convert_reduce_fusion_wrapped: argument 5"}
!20 = !{!21}
!21 = distinct !{!21, !9, !"convert_reduce_fusion_wrapped: argument 6"}
!22 = !{!8, !11, !13, !17, !19, !21}
!23 = !{!8, !11, !13, !15, !19, !21}
!24 = !{!8, !11, !15, !17, !19, !21}
!25 = !{!8, !13, !15, !17, !19, !21}
!26 = !{!11, !13, !15, !17, !19, !21}
!27 = distinct !{!27, !28, !29}
!28 = !{!"llvm.loop.isvectorized", i32 1}
!29 = !{!"llvm.loop.unroll.runtime.disable"}
!30 = !{!8, !11, !13, !15, !17, !21}
!31 = !{!8, !11, !13, !15, !17, !19}
!32 = distinct !{!32, !33}
!33 = !{!"llvm.loop.unroll.disable"}
!34 = distinct !{!34, !28, !29}
