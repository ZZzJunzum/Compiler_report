; ModuleID = '__compute_module_convert_reduce_fusion_kernel_module'
source_filename = "__compute_module_convert_reduce_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @convert_reduce_fusion(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !4
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !4
  %9 = getelementptr inbounds nuw i8, ptr %3, i64 64
  %10 = load ptr, ptr %9, align 8, !invariant.load !3, !dereferenceable !4
  %11 = getelementptr inbounds nuw i8, ptr %3, i64 80
  %12 = load ptr, ptr %11, align 8, !invariant.load !3, !dereferenceable !5
  %13 = getelementptr inbounds nuw i8, ptr %3, i64 96
  %14 = load ptr, ptr %13, align 8, !invariant.load !3, !dereferenceable !5
  %15 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %16 = load ptr, ptr %15, align 8
  %17 = load i64, ptr %16, align 4, !invariant.load !3
  tail call void @llvm.experimental.noalias.scope.decl(metadata !6)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !11)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !13)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !15)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !17)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !19)
  %18 = icmp ult i64 %17, 12
  br i1 %18, label %19, label %convert_reduce_fusion_wrapped.exit

19:                                               ; preds = %1
  %20 = getelementptr inbounds nuw i8, ptr %3, i64 48
  %21 = load ptr, ptr %20, align 8, !invariant.load !3, !dereferenceable !21
  %22 = shl nuw nsw i64 %17, 7
  %.idx = shl nuw nsw i64 %17, 19
  %23 = getelementptr i8, ptr %21, i64 %.idx
  br label %vector.ph

vector.ph:                                        ; preds = %19, %middle.block
  %24 = phi i64 [ 0, %19 ], [ %96, %middle.block ]
  %.idx1 = shl nuw nsw i64 %24, 12
  %25 = getelementptr i8, ptr %23, i64 %.idx1
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %vector.ph
  %index = phi i64 [ 0, %vector.ph ], [ %index.next.1, %vector.body ]
  %vec.phi = phi <8 x i32> [ zeroinitializer, %vector.ph ], [ %88, %vector.body ]
  %vec.phi10 = phi <8 x i32> [ zeroinitializer, %vector.ph ], [ %89, %vector.body ]
  %vec.phi11 = phi <8 x i32> [ zeroinitializer, %vector.ph ], [ %86, %vector.body ]
  %vec.phi12 = phi <8 x i32> [ zeroinitializer, %vector.ph ], [ %87, %vector.body ]
  %26 = getelementptr float, ptr %25, i64 %index
  %27 = getelementptr i8, ptr %26, i64 32
  %wide.load = load <8 x float>, ptr %26, align 4, !invariant.load !3, !alias.scope !13, !noalias !22
  %wide.load13 = load <8 x float>, ptr %27, align 4, !invariant.load !3, !alias.scope !13, !noalias !22
  %28 = getelementptr inbounds nuw float, ptr %10, i64 %index
  %29 = getelementptr inbounds nuw i8, ptr %28, i64 32
  %wide.load14 = load <8 x float>, ptr %28, align 4, !invariant.load !3, !alias.scope !15, !noalias !23
  %wide.load15 = load <8 x float>, ptr %29, align 4, !invariant.load !3, !alias.scope !15, !noalias !23
  %30 = fmul <8 x float> %wide.load, %wide.load14
  %31 = fmul <8 x float> %wide.load13, %wide.load15
  %32 = getelementptr inbounds nuw float, ptr %8, i64 %index
  %33 = getelementptr inbounds nuw i8, ptr %32, i64 32
  %wide.load16 = load <8 x float>, ptr %32, align 4, !invariant.load !3, !alias.scope !11, !noalias !24
  %wide.load17 = load <8 x float>, ptr %33, align 4, !invariant.load !3, !alias.scope !11, !noalias !24
  %34 = fadd <8 x float> %30, %wide.load16
  %35 = fadd <8 x float> %31, %wide.load17
  %36 = fcmp ogt <8 x float> %34, zeroinitializer
  %37 = fcmp ogt <8 x float> %35, zeroinitializer
  %38 = zext <8 x i1> %36 to <8 x i32>
  %39 = zext <8 x i1> %37 to <8 x i32>
  %40 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %34, <8 x float> zeroinitializer)
  %41 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %35, <8 x float> zeroinitializer)
  %42 = getelementptr inbounds nuw float, ptr %6, i64 %index
  %43 = getelementptr inbounds nuw i8, ptr %42, i64 32
  %wide.load18 = load <8 x float>, ptr %42, align 4, !invariant.load !3, !alias.scope !9, !noalias !25
  %wide.load19 = load <8 x float>, ptr %43, align 4, !invariant.load !3, !alias.scope !9, !noalias !25
  %44 = fmul <8 x float> %wide.load18, %40
  %45 = fmul <8 x float> %wide.load19, %41
  %46 = getelementptr inbounds nuw float, ptr %4, i64 %index
  %47 = getelementptr inbounds nuw i8, ptr %46, i64 32
  %wide.load20 = load <8 x float>, ptr %46, align 4, !invariant.load !3, !alias.scope !6, !noalias !26
  %wide.load21 = load <8 x float>, ptr %47, align 4, !invariant.load !3, !alias.scope !6, !noalias !26
  %48 = fadd <8 x float> %wide.load20, %44
  %49 = fadd <8 x float> %wide.load21, %45
  %50 = fcmp ogt <8 x float> %48, zeroinitializer
  %51 = fcmp ogt <8 x float> %49, zeroinitializer
  %52 = zext <8 x i1> %50 to <8 x i32>
  %53 = zext <8 x i1> %51 to <8 x i32>
  %54 = add <8 x i32> %vec.phi11, %38
  %55 = add <8 x i32> %vec.phi12, %39
  %56 = add <8 x i32> %vec.phi, %52
  %57 = add <8 x i32> %vec.phi10, %53
  %index.next = or disjoint i64 %index, 16
  %58 = getelementptr float, ptr %25, i64 %index.next
  %59 = getelementptr i8, ptr %58, i64 32
  %wide.load.1 = load <8 x float>, ptr %58, align 4, !invariant.load !3, !alias.scope !13, !noalias !22
  %wide.load13.1 = load <8 x float>, ptr %59, align 4, !invariant.load !3, !alias.scope !13, !noalias !22
  %60 = getelementptr inbounds nuw float, ptr %10, i64 %index.next
  %61 = getelementptr inbounds nuw i8, ptr %60, i64 32
  %wide.load14.1 = load <8 x float>, ptr %60, align 4, !invariant.load !3, !alias.scope !15, !noalias !23
  %wide.load15.1 = load <8 x float>, ptr %61, align 4, !invariant.load !3, !alias.scope !15, !noalias !23
  %62 = fmul <8 x float> %wide.load.1, %wide.load14.1
  %63 = fmul <8 x float> %wide.load13.1, %wide.load15.1
  %64 = getelementptr inbounds nuw float, ptr %8, i64 %index.next
  %65 = getelementptr inbounds nuw i8, ptr %64, i64 32
  %wide.load16.1 = load <8 x float>, ptr %64, align 4, !invariant.load !3, !alias.scope !11, !noalias !24
  %wide.load17.1 = load <8 x float>, ptr %65, align 4, !invariant.load !3, !alias.scope !11, !noalias !24
  %66 = fadd <8 x float> %62, %wide.load16.1
  %67 = fadd <8 x float> %63, %wide.load17.1
  %68 = fcmp ogt <8 x float> %66, zeroinitializer
  %69 = fcmp ogt <8 x float> %67, zeroinitializer
  %70 = zext <8 x i1> %68 to <8 x i32>
  %71 = zext <8 x i1> %69 to <8 x i32>
  %72 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %66, <8 x float> zeroinitializer)
  %73 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %67, <8 x float> zeroinitializer)
  %74 = getelementptr inbounds nuw float, ptr %6, i64 %index.next
  %75 = getelementptr inbounds nuw i8, ptr %74, i64 32
  %wide.load18.1 = load <8 x float>, ptr %74, align 4, !invariant.load !3, !alias.scope !9, !noalias !25
  %wide.load19.1 = load <8 x float>, ptr %75, align 4, !invariant.load !3, !alias.scope !9, !noalias !25
  %76 = fmul <8 x float> %wide.load18.1, %72
  %77 = fmul <8 x float> %wide.load19.1, %73
  %78 = getelementptr inbounds nuw float, ptr %4, i64 %index.next
  %79 = getelementptr inbounds nuw i8, ptr %78, i64 32
  %wide.load20.1 = load <8 x float>, ptr %78, align 4, !invariant.load !3, !alias.scope !6, !noalias !26
  %wide.load21.1 = load <8 x float>, ptr %79, align 4, !invariant.load !3, !alias.scope !6, !noalias !26
  %80 = fadd <8 x float> %wide.load20.1, %76
  %81 = fadd <8 x float> %wide.load21.1, %77
  %82 = fcmp ogt <8 x float> %80, zeroinitializer
  %83 = fcmp ogt <8 x float> %81, zeroinitializer
  %84 = zext <8 x i1> %82 to <8 x i32>
  %85 = zext <8 x i1> %83 to <8 x i32>
  %86 = add <8 x i32> %54, %70
  %87 = add <8 x i32> %55, %71
  %88 = add <8 x i32> %56, %84
  %89 = add <8 x i32> %57, %85
  %index.next.1 = add nuw nsw i64 %index, 32
  %90 = icmp eq i64 %index.next.1, 1024
  br i1 %90, label %middle.block, label %vector.body, !llvm.loop !27

middle.block:                                     ; preds = %vector.body
  %bin.rdx22 = add <8 x i32> %87, %86
  %91 = tail call i32 @llvm.vector.reduce.add.v8i32(<8 x i32> %bin.rdx22)
  %bin.rdx = add <8 x i32> %89, %88
  %92 = tail call i32 @llvm.vector.reduce.add.v8i32(<8 x i32> %bin.rdx)
  %93 = add nuw nsw i64 %24, %22
  %94 = getelementptr inbounds nuw i32, ptr %12, i64 %93
  store i32 %91, ptr %94, align 4, !alias.scope !17, !noalias !30
  %95 = getelementptr inbounds nuw i32, ptr %14, i64 %93
  store i32 %92, ptr %95, align 4, !alias.scope !19, !noalias !31
  %96 = add nuw nsw i64 %24, 1
  %exitcond6.not = icmp eq i64 %96, 128
  br i1 %exitcond6.not, label %convert_reduce_fusion_wrapped.exit, label %vector.ph, !llvm.loop !32

convert_reduce_fusion_wrapped.exit:               ; preds = %middle.block, %1
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.maximum.v8f32(<8 x float>, <8 x float>) #2

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.vector.reduce.add.v8i32(<8 x i32>) #3

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #3 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 0}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 4096}
!5 = !{i64 6144}
!6 = !{!7}
!7 = distinct !{!7, !8, !"convert_reduce_fusion_wrapped: argument 0"}
!8 = distinct !{!8, !"convert_reduce_fusion_wrapped"}
!9 = !{!10}
!10 = distinct !{!10, !8, !"convert_reduce_fusion_wrapped: argument 1"}
!11 = !{!12}
!12 = distinct !{!12, !8, !"convert_reduce_fusion_wrapped: argument 2"}
!13 = !{!14}
!14 = distinct !{!14, !8, !"convert_reduce_fusion_wrapped: argument 3"}
!15 = !{!16}
!16 = distinct !{!16, !8, !"convert_reduce_fusion_wrapped: argument 4"}
!17 = !{!18}
!18 = distinct !{!18, !8, !"convert_reduce_fusion_wrapped: argument 5"}
!19 = !{!20}
!20 = distinct !{!20, !8, !"convert_reduce_fusion_wrapped: argument 6"}
!21 = !{i64 6291456}
!22 = !{!7, !10, !12, !16, !18, !20}
!23 = !{!7, !10, !12, !14, !18, !20}
!24 = !{!7, !10, !14, !16, !18, !20}
!25 = !{!7, !12, !14, !16, !18, !20}
!26 = !{!10, !12, !14, !16, !18, !20}
!27 = distinct !{!27, !28, !29}
!28 = !{!"llvm.loop.isvectorized", i32 1}
!29 = !{!"llvm.loop.unroll.runtime.disable"}
!30 = !{!7, !10, !12, !14, !16, !20}
!31 = !{!7, !10, !12, !14, !16, !18}
!32 = distinct !{!32, !33}
!33 = !{!"llvm.loop.unroll.disable"}
