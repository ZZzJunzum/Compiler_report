; ModuleID = '__compute_module_convert_reduce_fusion_kernel_module'
source_filename = "__compute_module_convert_reduce_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @convert_reduce_fusion(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !4
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !4
  %9 = getelementptr inbounds nuw i8, ptr %3, i64 48
  %10 = load ptr, ptr %9, align 8, !invariant.load !3, !dereferenceable !5
  %11 = getelementptr inbounds nuw i8, ptr %3, i64 64
  %12 = load ptr, ptr %11, align 8, !invariant.load !3, !dereferenceable !4
  %13 = getelementptr inbounds nuw i8, ptr %3, i64 80
  %14 = load ptr, ptr %13, align 8, !invariant.load !3, !dereferenceable !6
  %15 = getelementptr inbounds nuw i8, ptr %3, i64 96
  %16 = load ptr, ptr %15, align 8, !invariant.load !3, !dereferenceable !6
  tail call void @llvm.experimental.noalias.scope.decl(metadata !7)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !10)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !12)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !14)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !16)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !18)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !20)
  %17 = getelementptr inbounds nuw i8, ptr %12, i64 32
  %wide.load10 = load <8 x float>, ptr %12, align 4, !invariant.load !3, !alias.scope !16, !noalias !22
  %wide.load11 = load <8 x float>, ptr %17, align 4, !invariant.load !3, !alias.scope !16, !noalias !22
  %18 = getelementptr inbounds nuw i8, ptr %8, i64 32
  %wide.load12 = load <8 x float>, ptr %8, align 4, !invariant.load !3, !alias.scope !12, !noalias !23
  %wide.load13 = load <8 x float>, ptr %18, align 4, !invariant.load !3, !alias.scope !12, !noalias !23
  %19 = getelementptr inbounds nuw i8, ptr %6, i64 32
  %wide.load14 = load <8 x float>, ptr %6, align 4, !invariant.load !3, !alias.scope !10, !noalias !24
  %wide.load15 = load <8 x float>, ptr %19, align 4, !invariant.load !3, !alias.scope !10, !noalias !24
  %20 = getelementptr inbounds nuw i8, ptr %4, i64 32
  %wide.load16 = load <8 x float>, ptr %4, align 4, !invariant.load !3, !alias.scope !7, !noalias !25
  %wide.load17 = load <8 x float>, ptr %20, align 4, !invariant.load !3, !alias.scope !7, !noalias !25
  %21 = getelementptr inbounds nuw i8, ptr %12, i64 64
  %22 = getelementptr inbounds nuw i8, ptr %12, i64 96
  %wide.load10.1 = load <8 x float>, ptr %21, align 4, !invariant.load !3, !alias.scope !16, !noalias !22
  %wide.load11.1 = load <8 x float>, ptr %22, align 4, !invariant.load !3, !alias.scope !16, !noalias !22
  %23 = getelementptr inbounds nuw i8, ptr %8, i64 64
  %24 = getelementptr inbounds nuw i8, ptr %8, i64 96
  %wide.load12.1 = load <8 x float>, ptr %23, align 4, !invariant.load !3, !alias.scope !12, !noalias !23
  %wide.load13.1 = load <8 x float>, ptr %24, align 4, !invariant.load !3, !alias.scope !12, !noalias !23
  %25 = getelementptr inbounds nuw i8, ptr %6, i64 64
  %26 = getelementptr inbounds nuw i8, ptr %6, i64 96
  %wide.load14.1 = load <8 x float>, ptr %25, align 4, !invariant.load !3, !alias.scope !10, !noalias !24
  %wide.load15.1 = load <8 x float>, ptr %26, align 4, !invariant.load !3, !alias.scope !10, !noalias !24
  %27 = getelementptr inbounds nuw i8, ptr %4, i64 64
  %28 = getelementptr inbounds nuw i8, ptr %4, i64 96
  %wide.load16.1 = load <8 x float>, ptr %27, align 4, !invariant.load !3, !alias.scope !7, !noalias !25
  %wide.load17.1 = load <8 x float>, ptr %28, align 4, !invariant.load !3, !alias.scope !7, !noalias !25
  %29 = getelementptr inbounds nuw i8, ptr %12, i64 128
  %30 = getelementptr inbounds nuw i8, ptr %12, i64 160
  %wide.load10.2 = load <8 x float>, ptr %29, align 4, !invariant.load !3, !alias.scope !16, !noalias !22
  %wide.load11.2 = load <8 x float>, ptr %30, align 4, !invariant.load !3, !alias.scope !16, !noalias !22
  %31 = getelementptr inbounds nuw i8, ptr %8, i64 128
  %32 = getelementptr inbounds nuw i8, ptr %8, i64 160
  %wide.load12.2 = load <8 x float>, ptr %31, align 4, !invariant.load !3, !alias.scope !12, !noalias !23
  %wide.load13.2 = load <8 x float>, ptr %32, align 4, !invariant.load !3, !alias.scope !12, !noalias !23
  %33 = getelementptr inbounds nuw i8, ptr %6, i64 128
  %34 = getelementptr inbounds nuw i8, ptr %6, i64 160
  %wide.load14.2 = load <8 x float>, ptr %33, align 4, !invariant.load !3, !alias.scope !10, !noalias !24
  %wide.load15.2 = load <8 x float>, ptr %34, align 4, !invariant.load !3, !alias.scope !10, !noalias !24
  %35 = getelementptr inbounds nuw i8, ptr %4, i64 128
  %36 = getelementptr inbounds nuw i8, ptr %4, i64 160
  %wide.load16.2 = load <8 x float>, ptr %35, align 4, !invariant.load !3, !alias.scope !7, !noalias !25
  %wide.load17.2 = load <8 x float>, ptr %36, align 4, !invariant.load !3, !alias.scope !7, !noalias !25
  br label %.preheader

.preheader:                                       ; preds = %1, %.preheader
  %37 = phi i64 [ 0, %1 ], [ %110, %.preheader ]
  %.idx = mul nuw nsw i64 %37, 192
  %38 = getelementptr i8, ptr %10, i64 %.idx
  %39 = getelementptr i8, ptr %38, i64 32
  %wide.load = load <8 x float>, ptr %38, align 4, !invariant.load !3, !alias.scope !14, !noalias !26
  %wide.load9 = load <8 x float>, ptr %39, align 4, !invariant.load !3, !alias.scope !14, !noalias !26
  %40 = fmul <8 x float> %wide.load, %wide.load10
  %41 = fmul <8 x float> %wide.load9, %wide.load11
  %42 = fadd <8 x float> %40, %wide.load12
  %43 = fadd <8 x float> %41, %wide.load13
  %44 = fcmp ogt <8 x float> %42, zeroinitializer
  %45 = fcmp ogt <8 x float> %43, zeroinitializer
  %46 = zext <8 x i1> %44 to <8 x i32>
  %47 = zext <8 x i1> %45 to <8 x i32>
  %48 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %42, <8 x float> zeroinitializer)
  %49 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %43, <8 x float> zeroinitializer)
  %50 = fmul <8 x float> %wide.load14, %48
  %51 = fmul <8 x float> %wide.load15, %49
  %52 = fadd <8 x float> %wide.load16, %50
  %53 = fadd <8 x float> %wide.load17, %51
  %54 = fcmp ogt <8 x float> %52, zeroinitializer
  %55 = fcmp ogt <8 x float> %53, zeroinitializer
  %56 = zext <8 x i1> %54 to <8 x i32>
  %57 = zext <8 x i1> %55 to <8 x i32>
  %58 = getelementptr i8, ptr %38, i64 64
  %59 = getelementptr i8, ptr %38, i64 96
  %wide.load.1 = load <8 x float>, ptr %58, align 4, !invariant.load !3, !alias.scope !14, !noalias !26
  %wide.load9.1 = load <8 x float>, ptr %59, align 4, !invariant.load !3, !alias.scope !14, !noalias !26
  %60 = fmul <8 x float> %wide.load.1, %wide.load10.1
  %61 = fmul <8 x float> %wide.load9.1, %wide.load11.1
  %62 = fadd <8 x float> %60, %wide.load12.1
  %63 = fadd <8 x float> %61, %wide.load13.1
  %64 = fcmp ogt <8 x float> %62, zeroinitializer
  %65 = fcmp ogt <8 x float> %63, zeroinitializer
  %66 = zext <8 x i1> %64 to <8 x i32>
  %67 = zext <8 x i1> %65 to <8 x i32>
  %68 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %62, <8 x float> zeroinitializer)
  %69 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %63, <8 x float> zeroinitializer)
  %70 = fmul <8 x float> %wide.load14.1, %68
  %71 = fmul <8 x float> %wide.load15.1, %69
  %72 = fadd <8 x float> %wide.load16.1, %70
  %73 = fadd <8 x float> %wide.load17.1, %71
  %74 = fcmp ogt <8 x float> %72, zeroinitializer
  %75 = fcmp ogt <8 x float> %73, zeroinitializer
  %76 = zext <8 x i1> %74 to <8 x i32>
  %77 = zext <8 x i1> %75 to <8 x i32>
  %78 = add nuw nsw <8 x i32> %46, %66
  %79 = add nuw nsw <8 x i32> %47, %67
  %80 = add nuw nsw <8 x i32> %56, %76
  %81 = add nuw nsw <8 x i32> %57, %77
  %82 = getelementptr i8, ptr %38, i64 128
  %83 = getelementptr i8, ptr %38, i64 160
  %wide.load.2 = load <8 x float>, ptr %82, align 4, !invariant.load !3, !alias.scope !14, !noalias !26
  %wide.load9.2 = load <8 x float>, ptr %83, align 4, !invariant.load !3, !alias.scope !14, !noalias !26
  %84 = fmul <8 x float> %wide.load.2, %wide.load10.2
  %85 = fmul <8 x float> %wide.load9.2, %wide.load11.2
  %86 = fadd <8 x float> %84, %wide.load12.2
  %87 = fadd <8 x float> %85, %wide.load13.2
  %88 = fcmp ogt <8 x float> %86, zeroinitializer
  %89 = fcmp ogt <8 x float> %87, zeroinitializer
  %90 = zext <8 x i1> %88 to <8 x i32>
  %91 = zext <8 x i1> %89 to <8 x i32>
  %92 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %86, <8 x float> zeroinitializer)
  %93 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %87, <8 x float> zeroinitializer)
  %94 = fmul <8 x float> %wide.load14.2, %92
  %95 = fmul <8 x float> %wide.load15.2, %93
  %96 = fadd <8 x float> %wide.load16.2, %94
  %97 = fadd <8 x float> %wide.load17.2, %95
  %98 = fcmp ogt <8 x float> %96, zeroinitializer
  %99 = fcmp ogt <8 x float> %97, zeroinitializer
  %100 = zext <8 x i1> %98 to <8 x i32>
  %101 = zext <8 x i1> %99 to <8 x i32>
  %102 = add nuw nsw <8 x i32> %78, %90
  %103 = add nuw nsw <8 x i32> %79, %91
  %104 = add nuw nsw <8 x i32> %80, %100
  %105 = add nuw nsw <8 x i32> %81, %101
  %bin.rdx18 = add nuw nsw <8 x i32> %103, %102
  %106 = tail call i32 @llvm.vector.reduce.add.v8i32(<8 x i32> %bin.rdx18)
  %bin.rdx = add nuw nsw <8 x i32> %105, %104
  %107 = tail call i32 @llvm.vector.reduce.add.v8i32(<8 x i32> %bin.rdx)
  %108 = getelementptr inbounds nuw i32, ptr %14, i64 %37
  store i32 %106, ptr %108, align 4, !alias.scope !18, !noalias !27
  %109 = getelementptr inbounds nuw i32, ptr %16, i64 %37
  store i32 %107, ptr %109, align 4, !alias.scope !20, !noalias !28
  %110 = add nuw nsw i64 %37, 1
  %exitcond3.not = icmp eq i64 %110, 960
  br i1 %exitcond3.not, label %convert_reduce_fusion_wrapped.exit, label %.preheader, !llvm.loop !29

convert_reduce_fusion_wrapped.exit:               ; preds = %.preheader
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.maximum.v8f32(<8 x float>, <8 x float>) #2

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.vector.reduce.add.v8i32(<8 x i32>) #3

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #3 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 0}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 192}
!5 = !{i64 184320}
!6 = !{i64 3840}
!7 = !{!8}
!8 = distinct !{!8, !9, !"convert_reduce_fusion_wrapped: argument 0"}
!9 = distinct !{!9, !"convert_reduce_fusion_wrapped"}
!10 = !{!11}
!11 = distinct !{!11, !9, !"convert_reduce_fusion_wrapped: argument 1"}
!12 = !{!13}
!13 = distinct !{!13, !9, !"convert_reduce_fusion_wrapped: argument 2"}
!14 = !{!15}
!15 = distinct !{!15, !9, !"convert_reduce_fusion_wrapped: argument 3"}
!16 = !{!17}
!17 = distinct !{!17, !9, !"convert_reduce_fusion_wrapped: argument 4"}
!18 = !{!19}
!19 = distinct !{!19, !9, !"convert_reduce_fusion_wrapped: argument 5"}
!20 = !{!21}
!21 = distinct !{!21, !9, !"convert_reduce_fusion_wrapped: argument 6"}
!22 = !{!8, !11, !13, !15, !19, !21}
!23 = !{!8, !11, !15, !17, !19, !21}
!24 = !{!8, !13, !15, !17, !19, !21}
!25 = !{!11, !13, !15, !17, !19, !21}
!26 = !{!8, !11, !13, !17, !19, !21}
!27 = !{!8, !11, !13, !15, !17, !21}
!28 = !{!8, !11, !13, !15, !17, !19}
!29 = distinct !{!29, !30}
!30 = !{!"llvm.loop.unroll.disable"}
