; ModuleID = '__compute_module_compare_convert_fusion.1_kernel_module'
source_filename = "__compute_module_compare_convert_fusion.1_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @compare_convert_fusion.1(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !5
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !4
  %9 = getelementptr inbounds nuw i8, ptr %3, i64 48
  %10 = load ptr, ptr %9, align 8, !invariant.load !3, !dereferenceable !5
  tail call void @llvm.experimental.noalias.scope.decl(metadata !6)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !11)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !13)
  %11 = getelementptr inbounds nuw i8, ptr %8, i64 32
  %wide.load4 = load <8 x float>, ptr %8, align 4, !invariant.load !3, !alias.scope !11, !noalias !15
  %wide.load5 = load <8 x float>, ptr %11, align 4, !invariant.load !3, !alias.scope !11, !noalias !15
  %12 = getelementptr inbounds nuw i8, ptr %4, i64 32
  %wide.load6 = load <8 x float>, ptr %4, align 4, !invariant.load !3, !alias.scope !6, !noalias !16
  %wide.load7 = load <8 x float>, ptr %12, align 4, !invariant.load !3, !alias.scope !6, !noalias !16
  %13 = getelementptr inbounds nuw i8, ptr %8, i64 64
  %14 = getelementptr inbounds nuw i8, ptr %8, i64 96
  %wide.load4.1 = load <8 x float>, ptr %13, align 4, !invariant.load !3, !alias.scope !11, !noalias !15
  %wide.load5.1 = load <8 x float>, ptr %14, align 4, !invariant.load !3, !alias.scope !11, !noalias !15
  %15 = getelementptr inbounds nuw i8, ptr %4, i64 64
  %16 = getelementptr inbounds nuw i8, ptr %4, i64 96
  %wide.load6.1 = load <8 x float>, ptr %15, align 4, !invariant.load !3, !alias.scope !6, !noalias !16
  %wide.load7.1 = load <8 x float>, ptr %16, align 4, !invariant.load !3, !alias.scope !6, !noalias !16
  %17 = getelementptr inbounds nuw i8, ptr %8, i64 128
  %18 = getelementptr inbounds nuw i8, ptr %8, i64 160
  %wide.load4.2 = load <8 x float>, ptr %17, align 4, !invariant.load !3, !alias.scope !11, !noalias !15
  %wide.load5.2 = load <8 x float>, ptr %18, align 4, !invariant.load !3, !alias.scope !11, !noalias !15
  %19 = getelementptr inbounds nuw i8, ptr %4, i64 128
  %20 = getelementptr inbounds nuw i8, ptr %4, i64 160
  %wide.load6.2 = load <8 x float>, ptr %19, align 4, !invariant.load !3, !alias.scope !6, !noalias !16
  %wide.load7.2 = load <8 x float>, ptr %20, align 4, !invariant.load !3, !alias.scope !6, !noalias !16
  br label %vector.ph

vector.ph:                                        ; preds = %1, %vector.ph
  %21 = phi i64 [ 0, %1 ], [ %61, %vector.ph ]
  %22 = mul nuw nsw i64 %21, 48
  %23 = getelementptr inbounds nuw float, ptr %6, i64 %22
  %24 = getelementptr inbounds nuw i8, ptr %23, i64 32
  %wide.load = load <8 x float>, ptr %23, align 4, !invariant.load !3, !alias.scope !9, !noalias !17
  %wide.load3 = load <8 x float>, ptr %24, align 4, !invariant.load !3, !alias.scope !9, !noalias !17
  %25 = fmul <8 x float> %wide.load, %wide.load4
  %26 = fmul <8 x float> %wide.load3, %wide.load5
  %27 = fadd <8 x float> %25, %wide.load6
  %28 = fadd <8 x float> %26, %wide.load7
  %29 = fcmp ogt <8 x float> %27, zeroinitializer
  %30 = fcmp ogt <8 x float> %28, zeroinitializer
  %31 = zext <8 x i1> %29 to <8 x i32>
  %32 = zext <8 x i1> %30 to <8 x i32>
  %33 = getelementptr inbounds nuw i32, ptr %10, i64 %22
  %34 = getelementptr inbounds nuw i8, ptr %33, i64 32
  store <8 x i32> %31, ptr %33, align 4, !alias.scope !13, !noalias !18
  store <8 x i32> %32, ptr %34, align 4, !alias.scope !13, !noalias !18
  %35 = add nuw nsw i64 %22, 16
  %36 = getelementptr inbounds nuw float, ptr %6, i64 %35
  %37 = getelementptr inbounds nuw i8, ptr %36, i64 32
  %wide.load.1 = load <8 x float>, ptr %36, align 4, !invariant.load !3, !alias.scope !9, !noalias !17
  %wide.load3.1 = load <8 x float>, ptr %37, align 4, !invariant.load !3, !alias.scope !9, !noalias !17
  %38 = fmul <8 x float> %wide.load.1, %wide.load4.1
  %39 = fmul <8 x float> %wide.load3.1, %wide.load5.1
  %40 = fadd <8 x float> %38, %wide.load6.1
  %41 = fadd <8 x float> %39, %wide.load7.1
  %42 = fcmp ogt <8 x float> %40, zeroinitializer
  %43 = fcmp ogt <8 x float> %41, zeroinitializer
  %44 = zext <8 x i1> %42 to <8 x i32>
  %45 = zext <8 x i1> %43 to <8 x i32>
  %46 = getelementptr inbounds nuw i32, ptr %10, i64 %35
  %47 = getelementptr inbounds nuw i8, ptr %46, i64 32
  store <8 x i32> %44, ptr %46, align 4, !alias.scope !13, !noalias !18
  store <8 x i32> %45, ptr %47, align 4, !alias.scope !13, !noalias !18
  %48 = add nuw nsw i64 %22, 32
  %49 = getelementptr inbounds nuw float, ptr %6, i64 %48
  %50 = getelementptr inbounds nuw i8, ptr %49, i64 32
  %wide.load.2 = load <8 x float>, ptr %49, align 4, !invariant.load !3, !alias.scope !9, !noalias !17
  %wide.load3.2 = load <8 x float>, ptr %50, align 4, !invariant.load !3, !alias.scope !9, !noalias !17
  %51 = fmul <8 x float> %wide.load.2, %wide.load4.2
  %52 = fmul <8 x float> %wide.load3.2, %wide.load5.2
  %53 = fadd <8 x float> %51, %wide.load6.2
  %54 = fadd <8 x float> %52, %wide.load7.2
  %55 = fcmp ogt <8 x float> %53, zeroinitializer
  %56 = fcmp ogt <8 x float> %54, zeroinitializer
  %57 = zext <8 x i1> %55 to <8 x i32>
  %58 = zext <8 x i1> %56 to <8 x i32>
  %59 = getelementptr inbounds nuw i32, ptr %10, i64 %48
  %60 = getelementptr inbounds nuw i8, ptr %59, i64 32
  store <8 x i32> %57, ptr %59, align 4, !alias.scope !13, !noalias !18
  store <8 x i32> %58, ptr %60, align 4, !alias.scope !13, !noalias !18
  %61 = add nuw nsw i64 %21, 1
  %exitcond2.not = icmp eq i64 %61, 960
  br i1 %exitcond2.not, label %compare_convert_fusion.1_wrapped.exit, label %vector.ph, !llvm.loop !19

compare_convert_fusion.1_wrapped.exit:            ; preds = %vector.ph
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 1}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 192}
!5 = !{i64 184320}
!6 = !{!7}
!7 = distinct !{!7, !8, !"compare_convert_fusion.1_wrapped: argument 0"}
!8 = distinct !{!8, !"compare_convert_fusion.1_wrapped"}
!9 = !{!10}
!10 = distinct !{!10, !8, !"compare_convert_fusion.1_wrapped: argument 1"}
!11 = !{!12}
!12 = distinct !{!12, !8, !"compare_convert_fusion.1_wrapped: argument 2"}
!13 = !{!14}
!14 = distinct !{!14, !8, !"compare_convert_fusion.1_wrapped: argument 3"}
!15 = !{!7, !10, !14}
!16 = !{!10, !12, !14}
!17 = !{!7, !12, !14}
!18 = !{!7, !10, !12}
!19 = distinct !{!19, !20}
!20 = !{!"llvm.loop.unroll.disable"}
