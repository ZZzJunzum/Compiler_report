; ModuleID = '__compute_module_compare_convert_fusion_kernel_module'
source_filename = "__compute_module_compare_convert_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @compare_convert_fusion(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !4
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !4
  %9 = getelementptr inbounds nuw i8, ptr %3, i64 48
  %10 = load ptr, ptr %9, align 8, !invariant.load !3, !dereferenceable !5
  %11 = getelementptr inbounds nuw i8, ptr %3, i64 64
  %12 = load ptr, ptr %11, align 8, !invariant.load !3, !dereferenceable !4
  %13 = getelementptr inbounds nuw i8, ptr %3, i64 80
  %14 = load ptr, ptr %13, align 8, !invariant.load !3, !dereferenceable !5
  tail call void @llvm.experimental.noalias.scope.decl(metadata !6)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !11)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !13)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !15)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !17)
  %15 = getelementptr inbounds nuw i8, ptr %12, i64 32
  %wide.load4 = load <8 x float>, ptr %12, align 4, !invariant.load !3, !alias.scope !15, !noalias !19
  %wide.load5 = load <8 x float>, ptr %15, align 4, !invariant.load !3, !alias.scope !15, !noalias !19
  %16 = getelementptr inbounds nuw i8, ptr %8, i64 32
  %wide.load6 = load <8 x float>, ptr %8, align 4, !invariant.load !3, !alias.scope !11, !noalias !20
  %wide.load7 = load <8 x float>, ptr %16, align 4, !invariant.load !3, !alias.scope !11, !noalias !20
  %17 = getelementptr inbounds nuw i8, ptr %6, i64 32
  %wide.load8 = load <8 x float>, ptr %6, align 4, !invariant.load !3, !alias.scope !9, !noalias !21
  %wide.load9 = load <8 x float>, ptr %17, align 4, !invariant.load !3, !alias.scope !9, !noalias !21
  %18 = getelementptr inbounds nuw i8, ptr %4, i64 32
  %wide.load10 = load <8 x float>, ptr %4, align 4, !invariant.load !3, !alias.scope !6, !noalias !22
  %wide.load11 = load <8 x float>, ptr %18, align 4, !invariant.load !3, !alias.scope !6, !noalias !22
  %19 = getelementptr inbounds nuw i8, ptr %12, i64 64
  %20 = getelementptr inbounds nuw i8, ptr %12, i64 96
  %wide.load4.1 = load <8 x float>, ptr %19, align 4, !invariant.load !3, !alias.scope !15, !noalias !19
  %wide.load5.1 = load <8 x float>, ptr %20, align 4, !invariant.load !3, !alias.scope !15, !noalias !19
  %21 = getelementptr inbounds nuw i8, ptr %8, i64 64
  %22 = getelementptr inbounds nuw i8, ptr %8, i64 96
  %wide.load6.1 = load <8 x float>, ptr %21, align 4, !invariant.load !3, !alias.scope !11, !noalias !20
  %wide.load7.1 = load <8 x float>, ptr %22, align 4, !invariant.load !3, !alias.scope !11, !noalias !20
  %23 = getelementptr inbounds nuw i8, ptr %6, i64 64
  %24 = getelementptr inbounds nuw i8, ptr %6, i64 96
  %wide.load8.1 = load <8 x float>, ptr %23, align 4, !invariant.load !3, !alias.scope !9, !noalias !21
  %wide.load9.1 = load <8 x float>, ptr %24, align 4, !invariant.load !3, !alias.scope !9, !noalias !21
  %25 = getelementptr inbounds nuw i8, ptr %4, i64 64
  %26 = getelementptr inbounds nuw i8, ptr %4, i64 96
  %wide.load10.1 = load <8 x float>, ptr %25, align 4, !invariant.load !3, !alias.scope !6, !noalias !22
  %wide.load11.1 = load <8 x float>, ptr %26, align 4, !invariant.load !3, !alias.scope !6, !noalias !22
  %27 = getelementptr inbounds nuw i8, ptr %12, i64 128
  %28 = getelementptr inbounds nuw i8, ptr %12, i64 160
  %wide.load4.2 = load <8 x float>, ptr %27, align 4, !invariant.load !3, !alias.scope !15, !noalias !19
  %wide.load5.2 = load <8 x float>, ptr %28, align 4, !invariant.load !3, !alias.scope !15, !noalias !19
  %29 = getelementptr inbounds nuw i8, ptr %8, i64 128
  %30 = getelementptr inbounds nuw i8, ptr %8, i64 160
  %wide.load6.2 = load <8 x float>, ptr %29, align 4, !invariant.load !3, !alias.scope !11, !noalias !20
  %wide.load7.2 = load <8 x float>, ptr %30, align 4, !invariant.load !3, !alias.scope !11, !noalias !20
  %31 = getelementptr inbounds nuw i8, ptr %6, i64 128
  %32 = getelementptr inbounds nuw i8, ptr %6, i64 160
  %wide.load8.2 = load <8 x float>, ptr %31, align 4, !invariant.load !3, !alias.scope !9, !noalias !21
  %wide.load9.2 = load <8 x float>, ptr %32, align 4, !invariant.load !3, !alias.scope !9, !noalias !21
  %33 = getelementptr inbounds nuw i8, ptr %4, i64 128
  %34 = getelementptr inbounds nuw i8, ptr %4, i64 160
  %wide.load10.2 = load <8 x float>, ptr %33, align 4, !invariant.load !3, !alias.scope !6, !noalias !22
  %wide.load11.2 = load <8 x float>, ptr %34, align 4, !invariant.load !3, !alias.scope !6, !noalias !22
  br label %vector.ph

vector.ph:                                        ; preds = %1, %vector.ph
  %35 = phi i64 [ 0, %1 ], [ %93, %vector.ph ]
  %36 = mul nuw nsw i64 %35, 48
  %37 = getelementptr inbounds nuw float, ptr %10, i64 %36
  %38 = getelementptr inbounds nuw i8, ptr %37, i64 32
  %wide.load = load <8 x float>, ptr %37, align 4, !invariant.load !3, !alias.scope !13, !noalias !23
  %wide.load3 = load <8 x float>, ptr %38, align 4, !invariant.load !3, !alias.scope !13, !noalias !23
  %39 = fmul <8 x float> %wide.load, %wide.load4
  %40 = fmul <8 x float> %wide.load3, %wide.load5
  %41 = fadd <8 x float> %39, %wide.load6
  %42 = fadd <8 x float> %40, %wide.load7
  %43 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %41, <8 x float> zeroinitializer)
  %44 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %42, <8 x float> zeroinitializer)
  %45 = fmul <8 x float> %wide.load8, %43
  %46 = fmul <8 x float> %wide.load9, %44
  %47 = fadd <8 x float> %wide.load10, %45
  %48 = fadd <8 x float> %wide.load11, %46
  %49 = fcmp ogt <8 x float> %47, zeroinitializer
  %50 = fcmp ogt <8 x float> %48, zeroinitializer
  %51 = zext <8 x i1> %49 to <8 x i32>
  %52 = zext <8 x i1> %50 to <8 x i32>
  %53 = getelementptr inbounds nuw i32, ptr %14, i64 %36
  %54 = getelementptr inbounds nuw i8, ptr %53, i64 32
  store <8 x i32> %51, ptr %53, align 4, !alias.scope !17, !noalias !24
  store <8 x i32> %52, ptr %54, align 4, !alias.scope !17, !noalias !24
  %55 = add nuw nsw i64 %36, 16
  %56 = getelementptr inbounds nuw float, ptr %10, i64 %55
  %57 = getelementptr inbounds nuw i8, ptr %56, i64 32
  %wide.load.1 = load <8 x float>, ptr %56, align 4, !invariant.load !3, !alias.scope !13, !noalias !23
  %wide.load3.1 = load <8 x float>, ptr %57, align 4, !invariant.load !3, !alias.scope !13, !noalias !23
  %58 = fmul <8 x float> %wide.load.1, %wide.load4.1
  %59 = fmul <8 x float> %wide.load3.1, %wide.load5.1
  %60 = fadd <8 x float> %58, %wide.load6.1
  %61 = fadd <8 x float> %59, %wide.load7.1
  %62 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %60, <8 x float> zeroinitializer)
  %63 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %61, <8 x float> zeroinitializer)
  %64 = fmul <8 x float> %wide.load8.1, %62
  %65 = fmul <8 x float> %wide.load9.1, %63
  %66 = fadd <8 x float> %wide.load10.1, %64
  %67 = fadd <8 x float> %wide.load11.1, %65
  %68 = fcmp ogt <8 x float> %66, zeroinitializer
  %69 = fcmp ogt <8 x float> %67, zeroinitializer
  %70 = zext <8 x i1> %68 to <8 x i32>
  %71 = zext <8 x i1> %69 to <8 x i32>
  %72 = getelementptr inbounds nuw i32, ptr %14, i64 %55
  %73 = getelementptr inbounds nuw i8, ptr %72, i64 32
  store <8 x i32> %70, ptr %72, align 4, !alias.scope !17, !noalias !24
  store <8 x i32> %71, ptr %73, align 4, !alias.scope !17, !noalias !24
  %74 = add nuw nsw i64 %36, 32
  %75 = getelementptr inbounds nuw float, ptr %10, i64 %74
  %76 = getelementptr inbounds nuw i8, ptr %75, i64 32
  %wide.load.2 = load <8 x float>, ptr %75, align 4, !invariant.load !3, !alias.scope !13, !noalias !23
  %wide.load3.2 = load <8 x float>, ptr %76, align 4, !invariant.load !3, !alias.scope !13, !noalias !23
  %77 = fmul <8 x float> %wide.load.2, %wide.load4.2
  %78 = fmul <8 x float> %wide.load3.2, %wide.load5.2
  %79 = fadd <8 x float> %77, %wide.load6.2
  %80 = fadd <8 x float> %78, %wide.load7.2
  %81 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %79, <8 x float> zeroinitializer)
  %82 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %80, <8 x float> zeroinitializer)
  %83 = fmul <8 x float> %wide.load8.2, %81
  %84 = fmul <8 x float> %wide.load9.2, %82
  %85 = fadd <8 x float> %wide.load10.2, %83
  %86 = fadd <8 x float> %wide.load11.2, %84
  %87 = fcmp ogt <8 x float> %85, zeroinitializer
  %88 = fcmp ogt <8 x float> %86, zeroinitializer
  %89 = zext <8 x i1> %87 to <8 x i32>
  %90 = zext <8 x i1> %88 to <8 x i32>
  %91 = getelementptr inbounds nuw i32, ptr %14, i64 %74
  %92 = getelementptr inbounds nuw i8, ptr %91, i64 32
  store <8 x i32> %89, ptr %91, align 4, !alias.scope !17, !noalias !24
  store <8 x i32> %90, ptr %92, align 4, !alias.scope !17, !noalias !24
  %93 = add nuw nsw i64 %35, 1
  %exitcond2.not = icmp eq i64 %93, 960
  br i1 %exitcond2.not, label %compare_convert_fusion_wrapped.exit, label %vector.ph, !llvm.loop !25

compare_convert_fusion_wrapped.exit:              ; preds = %vector.ph
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.maximum.v8f32(<8 x float>, <8 x float>) #2

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 0}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 192}
!5 = !{i64 184320}
!6 = !{!7}
!7 = distinct !{!7, !8, !"compare_convert_fusion_wrapped: argument 0"}
!8 = distinct !{!8, !"compare_convert_fusion_wrapped"}
!9 = !{!10}
!10 = distinct !{!10, !8, !"compare_convert_fusion_wrapped: argument 1"}
!11 = !{!12}
!12 = distinct !{!12, !8, !"compare_convert_fusion_wrapped: argument 2"}
!13 = !{!14}
!14 = distinct !{!14, !8, !"compare_convert_fusion_wrapped: argument 3"}
!15 = !{!16}
!16 = distinct !{!16, !8, !"compare_convert_fusion_wrapped: argument 4"}
!17 = !{!18}
!18 = distinct !{!18, !8, !"compare_convert_fusion_wrapped: argument 5"}
!19 = !{!7, !10, !12, !14, !18}
!20 = !{!7, !10, !14, !16, !18}
!21 = !{!7, !12, !14, !16, !18}
!22 = !{!10, !12, !14, !16, !18}
!23 = !{!7, !10, !12, !16, !18}
!24 = !{!7, !10, !12, !14, !16}
!25 = distinct !{!25, !26}
!26 = !{!"llvm.loop.unroll.disable"}
