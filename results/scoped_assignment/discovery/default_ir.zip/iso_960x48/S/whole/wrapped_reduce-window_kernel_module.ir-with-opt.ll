; ModuleID = '__compute_module_wrapped_reduce-window_kernel_module'
source_filename = "__compute_module_wrapped_reduce-window_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @wrapped_reduce-window(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !5
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !6
  tail call void @llvm.experimental.noalias.scope.decl(metadata !7)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !10)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !12)
  %9 = load i32, ptr %6, align 4, !invariant.load !3, !alias.scope !10, !noalias !14
  br label %.preheader

.preheader:                                       ; preds = %1, %146
  %10 = phi i64 [ 0, %1 ], [ %148, %146 ]
  %.idx1 = mul nuw nsw i64 %10, 192
  %invariant.gep3 = getelementptr i8, ptr %4, i64 %.idx1
  %.idx = shl i64 %10, 3
  %11 = getelementptr i8, ptr %8, i64 %.idx
  br label %12

12:                                               ; preds = %120, %.preheader
  %13 = phi i1 [ true, %.preheader ], [ false, %120 ]
  %14 = phi i64 [ 0, %.preheader ], [ 1, %120 ]
  %15 = shl nuw nsw i64 %14, 5
  %16 = add nsw i64 %15, -8
  %gep4 = getelementptr i32, ptr %invariant.gep3, i64 %15
  %17 = icmp ult i64 %16, 48
  br i1 %17, label %.thread, label %21

.thread:                                          ; preds = %12
  %18 = getelementptr i8, ptr %gep4, i64 -32
  %19 = load i32, ptr %18, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %20 = add i32 %19, %9
  br label %.thread20

21:                                               ; preds = %12
  %22 = add nsw i64 %15, -7
  %23 = icmp ult i64 %22, 48
  br i1 %23, label %.thread20, label %28

.thread20:                                        ; preds = %21, %.thread
  %24 = phi i32 [ %20, %.thread ], [ %9, %21 ]
  %25 = getelementptr i8, ptr %gep4, i64 -28
  %26 = load i32, ptr %25, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %27 = add i32 %26, %24
  br label %.thread21

28:                                               ; preds = %21
  %29 = add nsw i64 %15, -6
  %30 = icmp ult i64 %29, 48
  br i1 %30, label %.thread21, label %35

.thread21:                                        ; preds = %28, %.thread20
  %31 = phi i32 [ %27, %.thread20 ], [ %9, %28 ]
  %32 = getelementptr i8, ptr %gep4, i64 -24
  %33 = load i32, ptr %32, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %34 = add i32 %33, %31
  br label %.thread22

35:                                               ; preds = %28
  %36 = add nsw i64 %15, -5
  %37 = icmp ult i64 %36, 48
  br i1 %37, label %.thread22, label %42

.thread22:                                        ; preds = %35, %.thread21
  %38 = phi i32 [ %34, %.thread21 ], [ %9, %35 ]
  %39 = getelementptr i8, ptr %gep4, i64 -20
  %40 = load i32, ptr %39, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %41 = add i32 %40, %38
  br label %.thread23

42:                                               ; preds = %35
  %43 = add nsw i64 %15, -4
  %44 = icmp ult i64 %43, 48
  br i1 %44, label %.thread23, label %49

.thread23:                                        ; preds = %42, %.thread22
  %45 = phi i32 [ %41, %.thread22 ], [ %9, %42 ]
  %46 = getelementptr i8, ptr %gep4, i64 -16
  %47 = load i32, ptr %46, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %48 = add i32 %47, %45
  br label %.thread24

49:                                               ; preds = %42
  %50 = add nsw i64 %15, -3
  %51 = icmp ult i64 %50, 48
  br i1 %51, label %.thread24, label %56

.thread24:                                        ; preds = %49, %.thread23
  %52 = phi i32 [ %48, %.thread23 ], [ %9, %49 ]
  %53 = getelementptr i8, ptr %gep4, i64 -12
  %54 = load i32, ptr %53, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %55 = add i32 %54, %52
  br label %.thread25

56:                                               ; preds = %49
  %57 = add nsw i64 %15, -2
  %58 = icmp ult i64 %57, 48
  br i1 %58, label %.thread25, label %63

.thread25:                                        ; preds = %56, %.thread24
  %59 = phi i32 [ %55, %.thread24 ], [ %9, %56 ]
  %60 = getelementptr i8, ptr %gep4, i64 -8
  %61 = load i32, ptr %60, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %62 = add i32 %61, %59
  br label %66

63:                                               ; preds = %56
  %64 = add nsw i64 %15, -1
  %65 = icmp ult i64 %64, 48
  br i1 %65, label %66, label %71

66:                                               ; preds = %.thread25, %63
  %67 = phi i32 [ %62, %.thread25 ], [ %9, %63 ]
  %68 = getelementptr i8, ptr %gep4, i64 -4
  %69 = load i32, ptr %68, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %70 = add i32 %69, %67
  br label %71

71:                                               ; preds = %66, %63
  %72 = phi i32 [ %70, %66 ], [ %9, %63 ]
  %73 = load i32, ptr %gep4, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %74 = add i32 %73, %72
  %75 = getelementptr i8, ptr %gep4, i64 4
  %76 = load i32, ptr %75, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %77 = add i32 %76, %74
  %78 = getelementptr i8, ptr %gep4, i64 8
  %79 = load i32, ptr %78, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %80 = add i32 %79, %77
  %81 = getelementptr i8, ptr %gep4, i64 12
  %82 = load i32, ptr %81, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %83 = add i32 %82, %80
  %84 = getelementptr i8, ptr %gep4, i64 16
  %85 = load i32, ptr %84, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %86 = add i32 %85, %83
  %87 = getelementptr i8, ptr %gep4, i64 20
  %88 = load i32, ptr %87, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %89 = add i32 %88, %86
  %90 = getelementptr i8, ptr %gep4, i64 24
  %91 = load i32, ptr %90, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %92 = add i32 %91, %89
  %93 = getelementptr i8, ptr %gep4, i64 28
  %94 = load i32, ptr %93, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %95 = add i32 %94, %92
  %96 = getelementptr i8, ptr %gep4, i64 32
  %97 = load i32, ptr %96, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %98 = add i32 %97, %95
  %99 = getelementptr i8, ptr %gep4, i64 36
  %100 = load i32, ptr %99, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %101 = add i32 %100, %98
  %102 = getelementptr i8, ptr %gep4, i64 40
  %103 = load i32, ptr %102, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %104 = add i32 %103, %101
  %105 = getelementptr i8, ptr %gep4, i64 44
  %106 = load i32, ptr %105, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %107 = add i32 %106, %104
  %108 = getelementptr i8, ptr %gep4, i64 48
  %109 = load i32, ptr %108, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %110 = add i32 %109, %107
  %111 = getelementptr i8, ptr %gep4, i64 52
  %112 = load i32, ptr %111, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %113 = add i32 %112, %110
  %114 = getelementptr i8, ptr %gep4, i64 56
  %115 = load i32, ptr %114, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %116 = add i32 %115, %113
  %117 = getelementptr i8, ptr %gep4, i64 60
  %118 = load i32, ptr %117, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %119 = add i32 %118, %116
  br i1 %13, label %120, label %146

120:                                              ; preds = %71
  %121 = getelementptr i8, ptr %gep4, i64 64
  %122 = load i32, ptr %121, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %123 = add i32 %122, %119
  %124 = getelementptr i8, ptr %gep4, i64 68
  %125 = load i32, ptr %124, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %126 = add i32 %125, %123
  %127 = getelementptr i8, ptr %gep4, i64 72
  %128 = load i32, ptr %127, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %129 = add i32 %128, %126
  %130 = getelementptr i8, ptr %gep4, i64 76
  %131 = load i32, ptr %130, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %132 = add i32 %131, %129
  %133 = getelementptr i8, ptr %gep4, i64 80
  %134 = load i32, ptr %133, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %135 = add i32 %134, %132
  %136 = getelementptr i8, ptr %gep4, i64 84
  %137 = load i32, ptr %136, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %138 = add i32 %137, %135
  %139 = getelementptr i8, ptr %gep4, i64 88
  %140 = load i32, ptr %139, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %141 = add i32 %140, %138
  %142 = getelementptr i8, ptr %gep4, i64 92
  %143 = load i32, ptr %142, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %144 = add i32 %143, %141
  %145 = getelementptr i32, ptr %11, i64 %14
  store i32 %144, ptr %145, align 4, !alias.scope !12, !noalias !16
  br label %12, !llvm.loop !17

146:                                              ; preds = %71
  %147 = getelementptr i32, ptr %11, i64 %14
  store i32 %119, ptr %147, align 4, !alias.scope !12, !noalias !16
  %148 = add nuw nsw i64 %10, 1
  %exitcond.not = icmp eq i64 %148, 960
  br i1 %exitcond.not, label %wrapped_reduce-window_wrapped.exit, label %.preheader, !llvm.loop !17

wrapped_reduce-window_wrapped.exit:               ; preds = %146
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 3}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 184320}
!5 = !{i64 4}
!6 = !{i64 7680}
!7 = !{!8}
!8 = distinct !{!8, !9, !"wrapped_reduce-window_wrapped: argument 0"}
!9 = distinct !{!9, !"wrapped_reduce-window_wrapped"}
!10 = !{!11}
!11 = distinct !{!11, !9, !"wrapped_reduce-window_wrapped: argument 1"}
!12 = !{!13}
!13 = distinct !{!13, !9, !"wrapped_reduce-window_wrapped: argument 2"}
!14 = !{!8, !13}
!15 = !{!11, !13}
!16 = !{!8, !11}
!17 = distinct !{!17, !18}
!18 = !{!"llvm.loop.unroll.disable"}
