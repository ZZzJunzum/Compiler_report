; ModuleID = '__compute_module_convert_reduce_fusion_kernel_module'
source_filename = "__compute_module_convert_reduce_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @convert_reduce_fusion(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !4
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !4
  %9 = getelementptr inbounds nuw i8, ptr %3, i64 64
  %10 = load ptr, ptr %9, align 8, !invariant.load !3, !dereferenceable !4
  %11 = getelementptr inbounds nuw i8, ptr %3, i64 80
  %12 = load ptr, ptr %11, align 8, !invariant.load !3, !dereferenceable !5
  %13 = getelementptr inbounds nuw i8, ptr %3, i64 96
  %14 = load ptr, ptr %13, align 8, !invariant.load !3, !dereferenceable !5
  %15 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %16 = load ptr, ptr %15, align 8
  %17 = load i64, ptr %16, align 4, !invariant.load !3
  tail call void @llvm.experimental.noalias.scope.decl(metadata !6)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !11)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !13)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !15)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !17)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !19)
  %18 = icmp ult i64 %17, 12
  br i1 %18, label %19, label %convert_reduce_fusion_wrapped.exit

19:                                               ; preds = %1
  %20 = getelementptr inbounds nuw i8, ptr %3, i64 48
  %21 = load ptr, ptr %20, align 8, !invariant.load !3, !dereferenceable !21
  %22 = mul nuw nsw i64 %17, 80
  %.idx = mul nuw nsw i64 %17, 15360
  %23 = getelementptr i8, ptr %21, i64 %.idx
  %24 = getelementptr inbounds nuw i8, ptr %10, i64 32
  %wide.load14 = load <8 x float>, ptr %10, align 4, !invariant.load !3, !alias.scope !15, !noalias !22
  %wide.load15 = load <8 x float>, ptr %24, align 4, !invariant.load !3, !alias.scope !15, !noalias !22
  %25 = getelementptr inbounds nuw i8, ptr %8, i64 32
  %wide.load16 = load <8 x float>, ptr %8, align 4, !invariant.load !3, !alias.scope !11, !noalias !23
  %wide.load17 = load <8 x float>, ptr %25, align 4, !invariant.load !3, !alias.scope !11, !noalias !23
  %26 = getelementptr inbounds nuw i8, ptr %6, i64 32
  %wide.load18 = load <8 x float>, ptr %6, align 4, !invariant.load !3, !alias.scope !9, !noalias !24
  %wide.load19 = load <8 x float>, ptr %26, align 4, !invariant.load !3, !alias.scope !9, !noalias !24
  %27 = getelementptr inbounds nuw i8, ptr %4, i64 32
  %wide.load20 = load <8 x float>, ptr %4, align 4, !invariant.load !3, !alias.scope !6, !noalias !25
  %wide.load21 = load <8 x float>, ptr %27, align 4, !invariant.load !3, !alias.scope !6, !noalias !25
  %28 = getelementptr inbounds nuw i8, ptr %10, i64 64
  %29 = getelementptr inbounds nuw i8, ptr %10, i64 96
  %wide.load14.1 = load <8 x float>, ptr %28, align 4, !invariant.load !3, !alias.scope !15, !noalias !22
  %wide.load15.1 = load <8 x float>, ptr %29, align 4, !invariant.load !3, !alias.scope !15, !noalias !22
  %30 = getelementptr inbounds nuw i8, ptr %8, i64 64
  %31 = getelementptr inbounds nuw i8, ptr %8, i64 96
  %wide.load16.1 = load <8 x float>, ptr %30, align 4, !invariant.load !3, !alias.scope !11, !noalias !23
  %wide.load17.1 = load <8 x float>, ptr %31, align 4, !invariant.load !3, !alias.scope !11, !noalias !23
  %32 = getelementptr inbounds nuw i8, ptr %6, i64 64
  %33 = getelementptr inbounds nuw i8, ptr %6, i64 96
  %wide.load18.1 = load <8 x float>, ptr %32, align 4, !invariant.load !3, !alias.scope !9, !noalias !24
  %wide.load19.1 = load <8 x float>, ptr %33, align 4, !invariant.load !3, !alias.scope !9, !noalias !24
  %34 = getelementptr inbounds nuw i8, ptr %4, i64 64
  %35 = getelementptr inbounds nuw i8, ptr %4, i64 96
  %wide.load20.1 = load <8 x float>, ptr %34, align 4, !invariant.load !3, !alias.scope !6, !noalias !25
  %wide.load21.1 = load <8 x float>, ptr %35, align 4, !invariant.load !3, !alias.scope !6, !noalias !25
  %36 = getelementptr inbounds nuw i8, ptr %10, i64 128
  %37 = getelementptr inbounds nuw i8, ptr %10, i64 160
  %wide.load14.2 = load <8 x float>, ptr %36, align 4, !invariant.load !3, !alias.scope !15, !noalias !22
  %wide.load15.2 = load <8 x float>, ptr %37, align 4, !invariant.load !3, !alias.scope !15, !noalias !22
  %38 = getelementptr inbounds nuw i8, ptr %8, i64 128
  %39 = getelementptr inbounds nuw i8, ptr %8, i64 160
  %wide.load16.2 = load <8 x float>, ptr %38, align 4, !invariant.load !3, !alias.scope !11, !noalias !23
  %wide.load17.2 = load <8 x float>, ptr %39, align 4, !invariant.load !3, !alias.scope !11, !noalias !23
  %40 = getelementptr inbounds nuw i8, ptr %6, i64 128
  %41 = getelementptr inbounds nuw i8, ptr %6, i64 160
  %wide.load18.2 = load <8 x float>, ptr %40, align 4, !invariant.load !3, !alias.scope !9, !noalias !24
  %wide.load19.2 = load <8 x float>, ptr %41, align 4, !invariant.load !3, !alias.scope !9, !noalias !24
  %42 = getelementptr inbounds nuw i8, ptr %4, i64 128
  %43 = getelementptr inbounds nuw i8, ptr %4, i64 160
  %wide.load20.2 = load <8 x float>, ptr %42, align 4, !invariant.load !3, !alias.scope !6, !noalias !25
  %wide.load21.2 = load <8 x float>, ptr %43, align 4, !invariant.load !3, !alias.scope !6, !noalias !25
  br label %vector.ph

vector.ph:                                        ; preds = %19, %vector.ph
  %44 = phi i64 [ 0, %19 ], [ %118, %vector.ph ]
  %.idx1 = mul nuw nsw i64 %44, 192
  %45 = getelementptr i8, ptr %23, i64 %.idx1
  %46 = getelementptr i8, ptr %45, i64 32
  %wide.load = load <8 x float>, ptr %45, align 4, !invariant.load !3, !alias.scope !13, !noalias !26
  %wide.load13 = load <8 x float>, ptr %46, align 4, !invariant.load !3, !alias.scope !13, !noalias !26
  %47 = fmul <8 x float> %wide.load, %wide.load14
  %48 = fmul <8 x float> %wide.load13, %wide.load15
  %49 = fadd <8 x float> %47, %wide.load16
  %50 = fadd <8 x float> %48, %wide.load17
  %51 = fcmp ogt <8 x float> %49, zeroinitializer
  %52 = fcmp ogt <8 x float> %50, zeroinitializer
  %53 = zext <8 x i1> %51 to <8 x i32>
  %54 = zext <8 x i1> %52 to <8 x i32>
  %55 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %49, <8 x float> zeroinitializer)
  %56 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %50, <8 x float> zeroinitializer)
  %57 = fmul <8 x float> %wide.load18, %55
  %58 = fmul <8 x float> %wide.load19, %56
  %59 = fadd <8 x float> %wide.load20, %57
  %60 = fadd <8 x float> %wide.load21, %58
  %61 = fcmp ogt <8 x float> %59, zeroinitializer
  %62 = fcmp ogt <8 x float> %60, zeroinitializer
  %63 = zext <8 x i1> %61 to <8 x i32>
  %64 = zext <8 x i1> %62 to <8 x i32>
  %65 = getelementptr i8, ptr %45, i64 64
  %66 = getelementptr i8, ptr %45, i64 96
  %wide.load.1 = load <8 x float>, ptr %65, align 4, !invariant.load !3, !alias.scope !13, !noalias !26
  %wide.load13.1 = load <8 x float>, ptr %66, align 4, !invariant.load !3, !alias.scope !13, !noalias !26
  %67 = fmul <8 x float> %wide.load.1, %wide.load14.1
  %68 = fmul <8 x float> %wide.load13.1, %wide.load15.1
  %69 = fadd <8 x float> %67, %wide.load16.1
  %70 = fadd <8 x float> %68, %wide.load17.1
  %71 = fcmp ogt <8 x float> %69, zeroinitializer
  %72 = fcmp ogt <8 x float> %70, zeroinitializer
  %73 = zext <8 x i1> %71 to <8 x i32>
  %74 = zext <8 x i1> %72 to <8 x i32>
  %75 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %69, <8 x float> zeroinitializer)
  %76 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %70, <8 x float> zeroinitializer)
  %77 = fmul <8 x float> %wide.load18.1, %75
  %78 = fmul <8 x float> %wide.load19.1, %76
  %79 = fadd <8 x float> %wide.load20.1, %77
  %80 = fadd <8 x float> %wide.load21.1, %78
  %81 = fcmp ogt <8 x float> %79, zeroinitializer
  %82 = fcmp ogt <8 x float> %80, zeroinitializer
  %83 = zext <8 x i1> %81 to <8 x i32>
  %84 = zext <8 x i1> %82 to <8 x i32>
  %85 = add nuw nsw <8 x i32> %53, %73
  %86 = add nuw nsw <8 x i32> %54, %74
  %87 = add nuw nsw <8 x i32> %63, %83
  %88 = add nuw nsw <8 x i32> %64, %84
  %89 = getelementptr i8, ptr %45, i64 128
  %90 = getelementptr i8, ptr %45, i64 160
  %wide.load.2 = load <8 x float>, ptr %89, align 4, !invariant.load !3, !alias.scope !13, !noalias !26
  %wide.load13.2 = load <8 x float>, ptr %90, align 4, !invariant.load !3, !alias.scope !13, !noalias !26
  %91 = fmul <8 x float> %wide.load.2, %wide.load14.2
  %92 = fmul <8 x float> %wide.load13.2, %wide.load15.2
  %93 = fadd <8 x float> %91, %wide.load16.2
  %94 = fadd <8 x float> %92, %wide.load17.2
  %95 = fcmp ogt <8 x float> %93, zeroinitializer
  %96 = fcmp ogt <8 x float> %94, zeroinitializer
  %97 = zext <8 x i1> %95 to <8 x i32>
  %98 = zext <8 x i1> %96 to <8 x i32>
  %99 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %93, <8 x float> zeroinitializer)
  %100 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %94, <8 x float> zeroinitializer)
  %101 = fmul <8 x float> %wide.load18.2, %99
  %102 = fmul <8 x float> %wide.load19.2, %100
  %103 = fadd <8 x float> %wide.load20.2, %101
  %104 = fadd <8 x float> %wide.load21.2, %102
  %105 = fcmp ogt <8 x float> %103, zeroinitializer
  %106 = fcmp ogt <8 x float> %104, zeroinitializer
  %107 = zext <8 x i1> %105 to <8 x i32>
  %108 = zext <8 x i1> %106 to <8 x i32>
  %109 = add nuw nsw <8 x i32> %85, %97
  %110 = add nuw nsw <8 x i32> %86, %98
  %111 = add nuw nsw <8 x i32> %87, %107
  %112 = add nuw nsw <8 x i32> %88, %108
  %bin.rdx22 = add nuw nsw <8 x i32> %110, %109
  %113 = tail call i32 @llvm.vector.reduce.add.v8i32(<8 x i32> %bin.rdx22)
  %bin.rdx = add nuw nsw <8 x i32> %112, %111
  %114 = tail call i32 @llvm.vector.reduce.add.v8i32(<8 x i32> %bin.rdx)
  %115 = add nuw nsw i64 %44, %22
  %116 = getelementptr inbounds nuw i32, ptr %12, i64 %115
  store i32 %113, ptr %116, align 4, !alias.scope !17, !noalias !27
  %117 = getelementptr inbounds nuw i32, ptr %14, i64 %115
  store i32 %114, ptr %117, align 4, !alias.scope !19, !noalias !28
  %118 = add nuw nsw i64 %44, 1
  %exitcond6.not = icmp eq i64 %118, 80
  br i1 %exitcond6.not, label %convert_reduce_fusion_wrapped.exit, label %vector.ph, !llvm.loop !29

convert_reduce_fusion_wrapped.exit:               ; preds = %vector.ph, %1
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.maximum.v8f32(<8 x float>, <8 x float>) #2

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.vector.reduce.add.v8i32(<8 x i32>) #3

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #3 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 0}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 192}
!5 = !{i64 3840}
!6 = !{!7}
!7 = distinct !{!7, !8, !"convert_reduce_fusion_wrapped: argument 0"}
!8 = distinct !{!8, !"convert_reduce_fusion_wrapped"}
!9 = !{!10}
!10 = distinct !{!10, !8, !"convert_reduce_fusion_wrapped: argument 1"}
!11 = !{!12}
!12 = distinct !{!12, !8, !"convert_reduce_fusion_wrapped: argument 2"}
!13 = !{!14}
!14 = distinct !{!14, !8, !"convert_reduce_fusion_wrapped: argument 3"}
!15 = !{!16}
!16 = distinct !{!16, !8, !"convert_reduce_fusion_wrapped: argument 4"}
!17 = !{!18}
!18 = distinct !{!18, !8, !"convert_reduce_fusion_wrapped: argument 5"}
!19 = !{!20}
!20 = distinct !{!20, !8, !"convert_reduce_fusion_wrapped: argument 6"}
!21 = !{i64 184320}
!22 = !{!7, !10, !12, !14, !18, !20}
!23 = !{!7, !10, !14, !16, !18, !20}
!24 = !{!7, !12, !14, !16, !18, !20}
!25 = !{!10, !12, !14, !16, !18, !20}
!26 = !{!7, !10, !12, !16, !18, !20}
!27 = !{!7, !10, !12, !14, !16, !20}
!28 = !{!7, !10, !12, !14, !16, !18}
!29 = distinct !{!29, !30}
!30 = !{!"llvm.loop.unroll.disable"}
