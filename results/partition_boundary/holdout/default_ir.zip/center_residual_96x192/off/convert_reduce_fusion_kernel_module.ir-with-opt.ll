; ModuleID = '__compute_module_convert_reduce_fusion_kernel_module'
source_filename = "__compute_module_convert_reduce_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @convert_reduce_fusion(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !5
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !5
  %9 = getelementptr inbounds nuw i8, ptr %3, i64 48
  %10 = load ptr, ptr %9, align 8, !invariant.load !3, !dereferenceable !6
  %11 = getelementptr inbounds nuw i8, ptr %3, i64 64
  %12 = load ptr, ptr %11, align 8, !invariant.load !3, !dereferenceable !5
  %13 = getelementptr inbounds nuw i8, ptr %3, i64 80
  %14 = load ptr, ptr %13, align 8, !invariant.load !3, !dereferenceable !5
  %15 = getelementptr inbounds nuw i8, ptr %3, i64 96
  %16 = load ptr, ptr %15, align 8, !invariant.load !3, !dereferenceable !6
  %17 = getelementptr inbounds nuw i8, ptr %3, i64 112
  %18 = load ptr, ptr %17, align 8, !invariant.load !3, !dereferenceable !6
  tail call void @llvm.experimental.noalias.scope.decl(metadata !7)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !10)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !12)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !14)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !16)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !18)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !20)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !22)
  br label %vector.ph

vector.ph:                                        ; preds = %1, %middle.block
  %19 = phi i64 [ 0, %1 ], [ %65, %middle.block ]
  %.idx = mul nuw nsw i64 %19, 768
  %20 = getelementptr i8, ptr %4, i64 %.idx
  %21 = getelementptr inbounds nuw float, ptr %10, i64 %19
  %22 = load float, ptr %21, align 4, !invariant.load !3, !alias.scope !14, !noalias !24
  %23 = fmul float %22, 0x3F75555560000000
  %broadcast.splatinsert = insertelement <8 x float> poison, float %23, i64 0
  %broadcast.splat = shufflevector <8 x float> %broadcast.splatinsert, <8 x float> poison, <8 x i32> zeroinitializer
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %vector.ph
  %index = phi i64 [ 0, %vector.ph ], [ %index.next, %vector.body ]
  %vec.phi = phi <8 x i32> [ zeroinitializer, %vector.ph ], [ %58, %vector.body ]
  %vec.phi7 = phi <8 x i32> [ zeroinitializer, %vector.ph ], [ %59, %vector.body ]
  %vec.phi8 = phi <8 x i32> [ zeroinitializer, %vector.ph ], [ %56, %vector.body ]
  %vec.phi9 = phi <8 x i32> [ zeroinitializer, %vector.ph ], [ %57, %vector.body ]
  %24 = getelementptr float, ptr %20, i64 %index
  %25 = getelementptr i8, ptr %24, i64 32
  %wide.load = load <8 x float>, ptr %24, align 4, !invariant.load !3, !alias.scope !7, !noalias !25
  %wide.load10 = load <8 x float>, ptr %25, align 4, !invariant.load !3, !alias.scope !7, !noalias !25
  %26 = getelementptr inbounds nuw float, ptr %14, i64 %index
  %27 = getelementptr inbounds nuw i8, ptr %26, i64 32
  %wide.load11 = load <8 x float>, ptr %26, align 4, !invariant.load !3, !alias.scope !18, !noalias !26
  %wide.load12 = load <8 x float>, ptr %27, align 4, !invariant.load !3, !alias.scope !18, !noalias !26
  %28 = fmul <8 x float> %wide.load, %wide.load11
  %29 = fmul <8 x float> %wide.load10, %wide.load12
  %30 = getelementptr inbounds nuw float, ptr %12, i64 %index
  %31 = getelementptr inbounds nuw i8, ptr %30, i64 32
  %wide.load13 = load <8 x float>, ptr %30, align 4, !invariant.load !3, !alias.scope !16, !noalias !27
  %wide.load14 = load <8 x float>, ptr %31, align 4, !invariant.load !3, !alias.scope !16, !noalias !27
  %32 = fadd <8 x float> %28, %wide.load13
  %33 = fadd <8 x float> %29, %wide.load14
  %34 = fsub <8 x float> %32, %broadcast.splat
  %35 = fsub <8 x float> %33, %broadcast.splat
  %36 = fcmp ogt <8 x float> %34, zeroinitializer
  %37 = fcmp ogt <8 x float> %35, zeroinitializer
  %38 = zext <8 x i1> %36 to <8 x i32>
  %39 = zext <8 x i1> %37 to <8 x i32>
  %40 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %34, <8 x float> zeroinitializer)
  %41 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %35, <8 x float> zeroinitializer)
  %42 = getelementptr inbounds nuw float, ptr %8, i64 %index
  %43 = getelementptr inbounds nuw i8, ptr %42, i64 32
  %wide.load15 = load <8 x float>, ptr %42, align 4, !invariant.load !3, !alias.scope !12, !noalias !28
  %wide.load16 = load <8 x float>, ptr %43, align 4, !invariant.load !3, !alias.scope !12, !noalias !28
  %44 = fmul <8 x float> %wide.load15, %40
  %45 = fmul <8 x float> %wide.load16, %41
  %46 = getelementptr inbounds nuw float, ptr %6, i64 %index
  %47 = getelementptr inbounds nuw i8, ptr %46, i64 32
  %wide.load17 = load <8 x float>, ptr %46, align 4, !invariant.load !3, !alias.scope !10, !noalias !29
  %wide.load18 = load <8 x float>, ptr %47, align 4, !invariant.load !3, !alias.scope !10, !noalias !29
  %48 = fadd <8 x float> %wide.load17, %44
  %49 = fadd <8 x float> %wide.load18, %45
  %50 = fadd <8 x float> %wide.load, %48
  %51 = fadd <8 x float> %wide.load10, %49
  %52 = fcmp ogt <8 x float> %50, zeroinitializer
  %53 = fcmp ogt <8 x float> %51, zeroinitializer
  %54 = zext <8 x i1> %52 to <8 x i32>
  %55 = zext <8 x i1> %53 to <8 x i32>
  %56 = add <8 x i32> %vec.phi8, %38
  %57 = add <8 x i32> %vec.phi9, %39
  %58 = add <8 x i32> %vec.phi, %54
  %59 = add <8 x i32> %vec.phi7, %55
  %index.next = add nuw i64 %index, 16
  %60 = icmp eq i64 %index.next, 192
  br i1 %60, label %middle.block, label %vector.body, !llvm.loop !30

middle.block:                                     ; preds = %vector.body
  %bin.rdx19 = add <8 x i32> %57, %56
  %61 = tail call i32 @llvm.vector.reduce.add.v8i32(<8 x i32> %bin.rdx19)
  %bin.rdx = add <8 x i32> %59, %58
  %62 = tail call i32 @llvm.vector.reduce.add.v8i32(<8 x i32> %bin.rdx)
  %63 = getelementptr inbounds nuw i32, ptr %16, i64 %19
  store i32 %61, ptr %63, align 4, !alias.scope !20, !noalias !33
  %64 = getelementptr inbounds nuw i32, ptr %18, i64 %19
  store i32 %62, ptr %64, align 4, !alias.scope !22, !noalias !34
  %65 = add nuw nsw i64 %19, 1
  %exitcond4.not = icmp eq i64 %65, 96
  br i1 %exitcond4.not, label %convert_reduce_fusion_wrapped.exit, label %vector.ph, !llvm.loop !35

convert_reduce_fusion_wrapped.exit:               ; preds = %middle.block
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.maximum.v8f32(<8 x float>, <8 x float>) #2

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.vector.reduce.add.v8i32(<8 x i32>) #3

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #3 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 2}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 73728}
!5 = !{i64 768}
!6 = !{i64 384}
!7 = !{!8}
!8 = distinct !{!8, !9, !"convert_reduce_fusion_wrapped: argument 0"}
!9 = distinct !{!9, !"convert_reduce_fusion_wrapped"}
!10 = !{!11}
!11 = distinct !{!11, !9, !"convert_reduce_fusion_wrapped: argument 1"}
!12 = !{!13}
!13 = distinct !{!13, !9, !"convert_reduce_fusion_wrapped: argument 2"}
!14 = !{!15}
!15 = distinct !{!15, !9, !"convert_reduce_fusion_wrapped: argument 3"}
!16 = !{!17}
!17 = distinct !{!17, !9, !"convert_reduce_fusion_wrapped: argument 4"}
!18 = !{!19}
!19 = distinct !{!19, !9, !"convert_reduce_fusion_wrapped: argument 5"}
!20 = !{!21}
!21 = distinct !{!21, !9, !"convert_reduce_fusion_wrapped: argument 6"}
!22 = !{!23}
!23 = distinct !{!23, !9, !"convert_reduce_fusion_wrapped: argument 7"}
!24 = !{!8, !11, !13, !17, !19, !21, !23}
!25 = !{!11, !13, !15, !17, !19, !21, !23}
!26 = !{!8, !11, !13, !15, !17, !21, !23}
!27 = !{!8, !11, !13, !15, !19, !21, !23}
!28 = !{!8, !11, !15, !17, !19, !21, !23}
!29 = !{!8, !13, !15, !17, !19, !21, !23}
!30 = distinct !{!30, !31, !32}
!31 = !{!"llvm.loop.isvectorized", i32 1}
!32 = !{!"llvm.loop.unroll.runtime.disable"}
!33 = !{!8, !11, !13, !15, !17, !19, !23}
!34 = !{!8, !11, !13, !15, !17, !19, !21}
!35 = distinct !{!35, !36}
!36 = !{!"llvm.loop.unroll.disable"}
