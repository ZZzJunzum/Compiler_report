; ModuleID = '__compute_module_broadcast_add_fusion_kernel_module'
source_filename = "__compute_module_broadcast_add_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @broadcast_add_fusion(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !5
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !4
  %9 = getelementptr inbounds nuw i8, ptr %3, i64 48
  %10 = load ptr, ptr %9, align 8, !invariant.load !3, !dereferenceable !5
  tail call void @llvm.experimental.noalias.scope.decl(metadata !6)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !11)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !13)
  %11 = getelementptr inbounds nuw i8, ptr %8, i64 32
  %wide.load4 = load <8 x float>, ptr %8, align 4, !invariant.load !3, !alias.scope !11, !noalias !15
  %wide.load5 = load <8 x float>, ptr %11, align 4, !invariant.load !3, !alias.scope !11, !noalias !15
  %12 = getelementptr inbounds nuw i8, ptr %4, i64 32
  %wide.load6 = load <8 x float>, ptr %4, align 4, !invariant.load !3, !alias.scope !6, !noalias !16
  %wide.load7 = load <8 x float>, ptr %12, align 4, !invariant.load !3, !alias.scope !6, !noalias !16
  %13 = getelementptr inbounds nuw i8, ptr %8, i64 64
  %14 = getelementptr inbounds nuw i8, ptr %8, i64 96
  %wide.load4.1 = load <8 x float>, ptr %13, align 4, !invariant.load !3, !alias.scope !11, !noalias !15
  %wide.load5.1 = load <8 x float>, ptr %14, align 4, !invariant.load !3, !alias.scope !11, !noalias !15
  %15 = getelementptr inbounds nuw i8, ptr %4, i64 64
  %16 = getelementptr inbounds nuw i8, ptr %4, i64 96
  %wide.load6.1 = load <8 x float>, ptr %15, align 4, !invariant.load !3, !alias.scope !6, !noalias !16
  %wide.load7.1 = load <8 x float>, ptr %16, align 4, !invariant.load !3, !alias.scope !6, !noalias !16
  %17 = getelementptr inbounds nuw i8, ptr %8, i64 128
  %18 = getelementptr inbounds nuw i8, ptr %8, i64 160
  %wide.load4.2 = load <8 x float>, ptr %17, align 4, !invariant.load !3, !alias.scope !11, !noalias !15
  %wide.load5.2 = load <8 x float>, ptr %18, align 4, !invariant.load !3, !alias.scope !11, !noalias !15
  %19 = getelementptr inbounds nuw i8, ptr %4, i64 128
  %20 = getelementptr inbounds nuw i8, ptr %4, i64 160
  %wide.load6.2 = load <8 x float>, ptr %19, align 4, !invariant.load !3, !alias.scope !6, !noalias !16
  %wide.load7.2 = load <8 x float>, ptr %20, align 4, !invariant.load !3, !alias.scope !6, !noalias !16
  %21 = getelementptr inbounds nuw i8, ptr %8, i64 192
  %22 = getelementptr inbounds nuw i8, ptr %8, i64 224
  %wide.load4.3 = load <8 x float>, ptr %21, align 4, !invariant.load !3, !alias.scope !11, !noalias !15
  %wide.load5.3 = load <8 x float>, ptr %22, align 4, !invariant.load !3, !alias.scope !11, !noalias !15
  %23 = getelementptr inbounds nuw i8, ptr %4, i64 192
  %24 = getelementptr inbounds nuw i8, ptr %4, i64 224
  %wide.load6.3 = load <8 x float>, ptr %23, align 4, !invariant.load !3, !alias.scope !6, !noalias !16
  %wide.load7.3 = load <8 x float>, ptr %24, align 4, !invariant.load !3, !alias.scope !6, !noalias !16
  %25 = getelementptr inbounds nuw i8, ptr %8, i64 256
  %26 = getelementptr inbounds nuw i8, ptr %8, i64 288
  %wide.load4.4 = load <8 x float>, ptr %25, align 4, !invariant.load !3, !alias.scope !11, !noalias !15
  %wide.load5.4 = load <8 x float>, ptr %26, align 4, !invariant.load !3, !alias.scope !11, !noalias !15
  %27 = getelementptr inbounds nuw i8, ptr %4, i64 256
  %28 = getelementptr inbounds nuw i8, ptr %4, i64 288
  %wide.load6.4 = load <8 x float>, ptr %27, align 4, !invariant.load !3, !alias.scope !6, !noalias !16
  %wide.load7.4 = load <8 x float>, ptr %28, align 4, !invariant.load !3, !alias.scope !6, !noalias !16
  %29 = getelementptr inbounds nuw i8, ptr %8, i64 320
  %30 = getelementptr inbounds nuw i8, ptr %8, i64 352
  %wide.load4.5 = load <8 x float>, ptr %29, align 4, !invariant.load !3, !alias.scope !11, !noalias !15
  %wide.load5.5 = load <8 x float>, ptr %30, align 4, !invariant.load !3, !alias.scope !11, !noalias !15
  %31 = getelementptr inbounds nuw i8, ptr %4, i64 320
  %32 = getelementptr inbounds nuw i8, ptr %4, i64 352
  %wide.load6.5 = load <8 x float>, ptr %31, align 4, !invariant.load !3, !alias.scope !6, !noalias !16
  %wide.load7.5 = load <8 x float>, ptr %32, align 4, !invariant.load !3, !alias.scope !6, !noalias !16
  %33 = getelementptr inbounds nuw i8, ptr %8, i64 384
  %34 = getelementptr inbounds nuw i8, ptr %8, i64 416
  %wide.load4.6 = load <8 x float>, ptr %33, align 4, !invariant.load !3, !alias.scope !11, !noalias !15
  %wide.load5.6 = load <8 x float>, ptr %34, align 4, !invariant.load !3, !alias.scope !11, !noalias !15
  %35 = getelementptr inbounds nuw i8, ptr %4, i64 384
  %36 = getelementptr inbounds nuw i8, ptr %4, i64 416
  %wide.load6.6 = load <8 x float>, ptr %35, align 4, !invariant.load !3, !alias.scope !6, !noalias !16
  %wide.load7.6 = load <8 x float>, ptr %36, align 4, !invariant.load !3, !alias.scope !6, !noalias !16
  %37 = getelementptr inbounds nuw i8, ptr %8, i64 448
  %38 = getelementptr inbounds nuw i8, ptr %8, i64 480
  %wide.load4.7 = load <8 x float>, ptr %37, align 4, !invariant.load !3, !alias.scope !11, !noalias !15
  %wide.load5.7 = load <8 x float>, ptr %38, align 4, !invariant.load !3, !alias.scope !11, !noalias !15
  %39 = getelementptr inbounds nuw i8, ptr %4, i64 448
  %40 = getelementptr inbounds nuw i8, ptr %4, i64 480
  %wide.load6.7 = load <8 x float>, ptr %39, align 4, !invariant.load !3, !alias.scope !6, !noalias !16
  %wide.load7.7 = load <8 x float>, ptr %40, align 4, !invariant.load !3, !alias.scope !6, !noalias !16
  %41 = getelementptr inbounds nuw i8, ptr %8, i64 512
  %42 = getelementptr inbounds nuw i8, ptr %8, i64 544
  %wide.load4.8 = load <8 x float>, ptr %41, align 4, !invariant.load !3, !alias.scope !11, !noalias !15
  %wide.load5.8 = load <8 x float>, ptr %42, align 4, !invariant.load !3, !alias.scope !11, !noalias !15
  %43 = getelementptr inbounds nuw i8, ptr %4, i64 512
  %44 = getelementptr inbounds nuw i8, ptr %4, i64 544
  %wide.load6.8 = load <8 x float>, ptr %43, align 4, !invariant.load !3, !alias.scope !6, !noalias !16
  %wide.load7.8 = load <8 x float>, ptr %44, align 4, !invariant.load !3, !alias.scope !6, !noalias !16
  %45 = getelementptr inbounds nuw i8, ptr %8, i64 576
  %46 = getelementptr inbounds nuw i8, ptr %8, i64 608
  %wide.load4.9 = load <8 x float>, ptr %45, align 4, !invariant.load !3, !alias.scope !11, !noalias !15
  %wide.load5.9 = load <8 x float>, ptr %46, align 4, !invariant.load !3, !alias.scope !11, !noalias !15
  %47 = getelementptr inbounds nuw i8, ptr %4, i64 576
  %48 = getelementptr inbounds nuw i8, ptr %4, i64 608
  %wide.load6.9 = load <8 x float>, ptr %47, align 4, !invariant.load !3, !alias.scope !6, !noalias !16
  %wide.load7.9 = load <8 x float>, ptr %48, align 4, !invariant.load !3, !alias.scope !6, !noalias !16
  %49 = getelementptr inbounds nuw i8, ptr %8, i64 640
  %50 = getelementptr inbounds nuw i8, ptr %8, i64 672
  %wide.load4.10 = load <8 x float>, ptr %49, align 4, !invariant.load !3, !alias.scope !11, !noalias !15
  %wide.load5.10 = load <8 x float>, ptr %50, align 4, !invariant.load !3, !alias.scope !11, !noalias !15
  %51 = getelementptr inbounds nuw i8, ptr %4, i64 640
  %52 = getelementptr inbounds nuw i8, ptr %4, i64 672
  %wide.load6.10 = load <8 x float>, ptr %51, align 4, !invariant.load !3, !alias.scope !6, !noalias !16
  %wide.load7.10 = load <8 x float>, ptr %52, align 4, !invariant.load !3, !alias.scope !6, !noalias !16
  %53 = getelementptr inbounds nuw i8, ptr %8, i64 704
  %54 = getelementptr inbounds nuw i8, ptr %8, i64 736
  %wide.load4.11 = load <8 x float>, ptr %53, align 4, !invariant.load !3, !alias.scope !11, !noalias !15
  %wide.load5.11 = load <8 x float>, ptr %54, align 4, !invariant.load !3, !alias.scope !11, !noalias !15
  %55 = getelementptr inbounds nuw i8, ptr %4, i64 704
  %56 = getelementptr inbounds nuw i8, ptr %4, i64 736
  %wide.load6.11 = load <8 x float>, ptr %55, align 4, !invariant.load !3, !alias.scope !6, !noalias !16
  %wide.load7.11 = load <8 x float>, ptr %56, align 4, !invariant.load !3, !alias.scope !6, !noalias !16
  br label %vector.ph

vector.ph:                                        ; preds = %1, %vector.ph
  %57 = phi i64 [ 0, %1 ], [ %166, %vector.ph ]
  %58 = mul nuw nsw i64 %57, 192
  %59 = getelementptr inbounds nuw float, ptr %6, i64 %58
  %60 = getelementptr inbounds nuw i8, ptr %59, i64 32
  %wide.load = load <8 x float>, ptr %59, align 4, !invariant.load !3, !alias.scope !9, !noalias !17
  %wide.load3 = load <8 x float>, ptr %60, align 4, !invariant.load !3, !alias.scope !9, !noalias !17
  %61 = fmul <8 x float> %wide.load, %wide.load4
  %62 = fmul <8 x float> %wide.load3, %wide.load5
  %63 = fadd <8 x float> %61, %wide.load6
  %64 = fadd <8 x float> %62, %wide.load7
  %65 = getelementptr inbounds nuw float, ptr %10, i64 %58
  %66 = getelementptr inbounds nuw i8, ptr %65, i64 32
  store <8 x float> %63, ptr %65, align 4, !alias.scope !13, !noalias !18
  store <8 x float> %64, ptr %66, align 4, !alias.scope !13, !noalias !18
  %67 = or disjoint i64 %58, 16
  %68 = getelementptr inbounds nuw float, ptr %6, i64 %67
  %69 = getelementptr inbounds nuw i8, ptr %68, i64 32
  %wide.load.1 = load <8 x float>, ptr %68, align 4, !invariant.load !3, !alias.scope !9, !noalias !17
  %wide.load3.1 = load <8 x float>, ptr %69, align 4, !invariant.load !3, !alias.scope !9, !noalias !17
  %70 = fmul <8 x float> %wide.load.1, %wide.load4.1
  %71 = fmul <8 x float> %wide.load3.1, %wide.load5.1
  %72 = fadd <8 x float> %70, %wide.load6.1
  %73 = fadd <8 x float> %71, %wide.load7.1
  %74 = getelementptr inbounds nuw float, ptr %10, i64 %67
  %75 = getelementptr inbounds nuw i8, ptr %74, i64 32
  store <8 x float> %72, ptr %74, align 4, !alias.scope !13, !noalias !18
  store <8 x float> %73, ptr %75, align 4, !alias.scope !13, !noalias !18
  %76 = or disjoint i64 %58, 32
  %77 = getelementptr inbounds nuw float, ptr %6, i64 %76
  %78 = getelementptr inbounds nuw i8, ptr %77, i64 32
  %wide.load.2 = load <8 x float>, ptr %77, align 4, !invariant.load !3, !alias.scope !9, !noalias !17
  %wide.load3.2 = load <8 x float>, ptr %78, align 4, !invariant.load !3, !alias.scope !9, !noalias !17
  %79 = fmul <8 x float> %wide.load.2, %wide.load4.2
  %80 = fmul <8 x float> %wide.load3.2, %wide.load5.2
  %81 = fadd <8 x float> %79, %wide.load6.2
  %82 = fadd <8 x float> %80, %wide.load7.2
  %83 = getelementptr inbounds nuw float, ptr %10, i64 %76
  %84 = getelementptr inbounds nuw i8, ptr %83, i64 32
  store <8 x float> %81, ptr %83, align 4, !alias.scope !13, !noalias !18
  store <8 x float> %82, ptr %84, align 4, !alias.scope !13, !noalias !18
  %85 = or disjoint i64 %58, 48
  %86 = getelementptr inbounds nuw float, ptr %6, i64 %85
  %87 = getelementptr inbounds nuw i8, ptr %86, i64 32
  %wide.load.3 = load <8 x float>, ptr %86, align 4, !invariant.load !3, !alias.scope !9, !noalias !17
  %wide.load3.3 = load <8 x float>, ptr %87, align 4, !invariant.load !3, !alias.scope !9, !noalias !17
  %88 = fmul <8 x float> %wide.load.3, %wide.load4.3
  %89 = fmul <8 x float> %wide.load3.3, %wide.load5.3
  %90 = fadd <8 x float> %88, %wide.load6.3
  %91 = fadd <8 x float> %89, %wide.load7.3
  %92 = getelementptr inbounds nuw float, ptr %10, i64 %85
  %93 = getelementptr inbounds nuw i8, ptr %92, i64 32
  store <8 x float> %90, ptr %92, align 4, !alias.scope !13, !noalias !18
  store <8 x float> %91, ptr %93, align 4, !alias.scope !13, !noalias !18
  %94 = add nuw nsw i64 %58, 64
  %95 = getelementptr inbounds nuw float, ptr %6, i64 %94
  %96 = getelementptr inbounds nuw i8, ptr %95, i64 32
  %wide.load.4 = load <8 x float>, ptr %95, align 4, !invariant.load !3, !alias.scope !9, !noalias !17
  %wide.load3.4 = load <8 x float>, ptr %96, align 4, !invariant.load !3, !alias.scope !9, !noalias !17
  %97 = fmul <8 x float> %wide.load.4, %wide.load4.4
  %98 = fmul <8 x float> %wide.load3.4, %wide.load5.4
  %99 = fadd <8 x float> %97, %wide.load6.4
  %100 = fadd <8 x float> %98, %wide.load7.4
  %101 = getelementptr inbounds nuw float, ptr %10, i64 %94
  %102 = getelementptr inbounds nuw i8, ptr %101, i64 32
  store <8 x float> %99, ptr %101, align 4, !alias.scope !13, !noalias !18
  store <8 x float> %100, ptr %102, align 4, !alias.scope !13, !noalias !18
  %103 = add nuw nsw i64 %58, 80
  %104 = getelementptr inbounds nuw float, ptr %6, i64 %103
  %105 = getelementptr inbounds nuw i8, ptr %104, i64 32
  %wide.load.5 = load <8 x float>, ptr %104, align 4, !invariant.load !3, !alias.scope !9, !noalias !17
  %wide.load3.5 = load <8 x float>, ptr %105, align 4, !invariant.load !3, !alias.scope !9, !noalias !17
  %106 = fmul <8 x float> %wide.load.5, %wide.load4.5
  %107 = fmul <8 x float> %wide.load3.5, %wide.load5.5
  %108 = fadd <8 x float> %106, %wide.load6.5
  %109 = fadd <8 x float> %107, %wide.load7.5
  %110 = getelementptr inbounds nuw float, ptr %10, i64 %103
  %111 = getelementptr inbounds nuw i8, ptr %110, i64 32
  store <8 x float> %108, ptr %110, align 4, !alias.scope !13, !noalias !18
  store <8 x float> %109, ptr %111, align 4, !alias.scope !13, !noalias !18
  %112 = add nuw nsw i64 %58, 96
  %113 = getelementptr inbounds nuw float, ptr %6, i64 %112
  %114 = getelementptr inbounds nuw i8, ptr %113, i64 32
  %wide.load.6 = load <8 x float>, ptr %113, align 4, !invariant.load !3, !alias.scope !9, !noalias !17
  %wide.load3.6 = load <8 x float>, ptr %114, align 4, !invariant.load !3, !alias.scope !9, !noalias !17
  %115 = fmul <8 x float> %wide.load.6, %wide.load4.6
  %116 = fmul <8 x float> %wide.load3.6, %wide.load5.6
  %117 = fadd <8 x float> %115, %wide.load6.6
  %118 = fadd <8 x float> %116, %wide.load7.6
  %119 = getelementptr inbounds nuw float, ptr %10, i64 %112
  %120 = getelementptr inbounds nuw i8, ptr %119, i64 32
  store <8 x float> %117, ptr %119, align 4, !alias.scope !13, !noalias !18
  store <8 x float> %118, ptr %120, align 4, !alias.scope !13, !noalias !18
  %121 = add nuw nsw i64 %58, 112
  %122 = getelementptr inbounds nuw float, ptr %6, i64 %121
  %123 = getelementptr inbounds nuw i8, ptr %122, i64 32
  %wide.load.7 = load <8 x float>, ptr %122, align 4, !invariant.load !3, !alias.scope !9, !noalias !17
  %wide.load3.7 = load <8 x float>, ptr %123, align 4, !invariant.load !3, !alias.scope !9, !noalias !17
  %124 = fmul <8 x float> %wide.load.7, %wide.load4.7
  %125 = fmul <8 x float> %wide.load3.7, %wide.load5.7
  %126 = fadd <8 x float> %124, %wide.load6.7
  %127 = fadd <8 x float> %125, %wide.load7.7
  %128 = getelementptr inbounds nuw float, ptr %10, i64 %121
  %129 = getelementptr inbounds nuw i8, ptr %128, i64 32
  store <8 x float> %126, ptr %128, align 4, !alias.scope !13, !noalias !18
  store <8 x float> %127, ptr %129, align 4, !alias.scope !13, !noalias !18
  %130 = add nuw nsw i64 %58, 128
  %131 = getelementptr inbounds nuw float, ptr %6, i64 %130
  %132 = getelementptr inbounds nuw i8, ptr %131, i64 32
  %wide.load.8 = load <8 x float>, ptr %131, align 4, !invariant.load !3, !alias.scope !9, !noalias !17
  %wide.load3.8 = load <8 x float>, ptr %132, align 4, !invariant.load !3, !alias.scope !9, !noalias !17
  %133 = fmul <8 x float> %wide.load.8, %wide.load4.8
  %134 = fmul <8 x float> %wide.load3.8, %wide.load5.8
  %135 = fadd <8 x float> %133, %wide.load6.8
  %136 = fadd <8 x float> %134, %wide.load7.8
  %137 = getelementptr inbounds nuw float, ptr %10, i64 %130
  %138 = getelementptr inbounds nuw i8, ptr %137, i64 32
  store <8 x float> %135, ptr %137, align 4, !alias.scope !13, !noalias !18
  store <8 x float> %136, ptr %138, align 4, !alias.scope !13, !noalias !18
  %139 = add nuw nsw i64 %58, 144
  %140 = getelementptr inbounds nuw float, ptr %6, i64 %139
  %141 = getelementptr inbounds nuw i8, ptr %140, i64 32
  %wide.load.9 = load <8 x float>, ptr %140, align 4, !invariant.load !3, !alias.scope !9, !noalias !17
  %wide.load3.9 = load <8 x float>, ptr %141, align 4, !invariant.load !3, !alias.scope !9, !noalias !17
  %142 = fmul <8 x float> %wide.load.9, %wide.load4.9
  %143 = fmul <8 x float> %wide.load3.9, %wide.load5.9
  %144 = fadd <8 x float> %142, %wide.load6.9
  %145 = fadd <8 x float> %143, %wide.load7.9
  %146 = getelementptr inbounds nuw float, ptr %10, i64 %139
  %147 = getelementptr inbounds nuw i8, ptr %146, i64 32
  store <8 x float> %144, ptr %146, align 4, !alias.scope !13, !noalias !18
  store <8 x float> %145, ptr %147, align 4, !alias.scope !13, !noalias !18
  %148 = add nuw nsw i64 %58, 160
  %149 = getelementptr inbounds nuw float, ptr %6, i64 %148
  %150 = getelementptr inbounds nuw i8, ptr %149, i64 32
  %wide.load.10 = load <8 x float>, ptr %149, align 4, !invariant.load !3, !alias.scope !9, !noalias !17
  %wide.load3.10 = load <8 x float>, ptr %150, align 4, !invariant.load !3, !alias.scope !9, !noalias !17
  %151 = fmul <8 x float> %wide.load.10, %wide.load4.10
  %152 = fmul <8 x float> %wide.load3.10, %wide.load5.10
  %153 = fadd <8 x float> %151, %wide.load6.10
  %154 = fadd <8 x float> %152, %wide.load7.10
  %155 = getelementptr inbounds nuw float, ptr %10, i64 %148
  %156 = getelementptr inbounds nuw i8, ptr %155, i64 32
  store <8 x float> %153, ptr %155, align 4, !alias.scope !13, !noalias !18
  store <8 x float> %154, ptr %156, align 4, !alias.scope !13, !noalias !18
  %157 = add nuw nsw i64 %58, 176
  %158 = getelementptr inbounds nuw float, ptr %6, i64 %157
  %159 = getelementptr inbounds nuw i8, ptr %158, i64 32
  %wide.load.11 = load <8 x float>, ptr %158, align 4, !invariant.load !3, !alias.scope !9, !noalias !17
  %wide.load3.11 = load <8 x float>, ptr %159, align 4, !invariant.load !3, !alias.scope !9, !noalias !17
  %160 = fmul <8 x float> %wide.load.11, %wide.load4.11
  %161 = fmul <8 x float> %wide.load3.11, %wide.load5.11
  %162 = fadd <8 x float> %160, %wide.load6.11
  %163 = fadd <8 x float> %161, %wide.load7.11
  %164 = getelementptr inbounds nuw float, ptr %10, i64 %157
  %165 = getelementptr inbounds nuw i8, ptr %164, i64 32
  store <8 x float> %162, ptr %164, align 4, !alias.scope !13, !noalias !18
  store <8 x float> %163, ptr %165, align 4, !alias.scope !13, !noalias !18
  %166 = add nuw nsw i64 %57, 1
  %exitcond2.not = icmp eq i64 %166, 96
  br i1 %exitcond2.not, label %broadcast_add_fusion_wrapped.exit, label %vector.ph, !llvm.loop !19

broadcast_add_fusion_wrapped.exit:                ; preds = %vector.ph
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 1}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 768}
!5 = !{i64 73728}
!6 = !{!7}
!7 = distinct !{!7, !8, !"broadcast_add_fusion_wrapped: argument 0"}
!8 = distinct !{!8, !"broadcast_add_fusion_wrapped"}
!9 = !{!10}
!10 = distinct !{!10, !8, !"broadcast_add_fusion_wrapped: argument 1"}
!11 = !{!12}
!12 = distinct !{!12, !8, !"broadcast_add_fusion_wrapped: argument 2"}
!13 = !{!14}
!14 = distinct !{!14, !8, !"broadcast_add_fusion_wrapped: argument 3"}
!15 = !{!7, !10, !14}
!16 = !{!10, !12, !14}
!17 = !{!7, !12, !14}
!18 = !{!7, !10, !12}
!19 = distinct !{!19, !20}
!20 = !{!"llvm.loop.unroll.disable"}
