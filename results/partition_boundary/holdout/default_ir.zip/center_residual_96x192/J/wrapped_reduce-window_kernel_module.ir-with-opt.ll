; ModuleID = '__compute_module_wrapped_reduce-window_kernel_module'
source_filename = "__compute_module_wrapped_reduce-window_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @wrapped_reduce-window(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !5
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !6
  tail call void @llvm.experimental.noalias.scope.decl(metadata !7)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !10)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !12)
  %9 = load float, ptr %6, align 4, !invariant.load !3, !alias.scope !10, !noalias !14
  br label %.preheader3

.preheader3:                                      ; preds = %1, %112
  %10 = phi i64 [ 0, %1 ], [ %113, %112 ]
  %.idx1 = mul nuw nsw i64 %10, 768
  %11 = getelementptr i8, ptr %4, i64 %.idx1
  %.idx = mul nuw nsw i64 %10, 24
  %12 = getelementptr i8, ptr %8, i64 %.idx
  br label %.preheader

.preheader:                                       ; preds = %.preheader3, %.preheader
  %13 = phi i64 [ 0, %.preheader3 ], [ %111, %.preheader ]
  %.idx2 = shl i64 %13, 7
  %14 = getelementptr i8, ptr %11, i64 %.idx2
  %15 = load float, ptr %14, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %16 = fadd reassoc float %9, %15
  %17 = getelementptr i8, ptr %14, i64 4
  %18 = load float, ptr %17, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %19 = fadd reassoc float %16, %18
  %20 = getelementptr i8, ptr %14, i64 8
  %21 = load float, ptr %20, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %22 = fadd reassoc float %19, %21
  %23 = getelementptr i8, ptr %14, i64 12
  %24 = load float, ptr %23, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %25 = fadd reassoc float %22, %24
  %26 = getelementptr i8, ptr %14, i64 16
  %27 = load float, ptr %26, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %28 = fadd reassoc float %25, %27
  %29 = getelementptr i8, ptr %14, i64 20
  %30 = load float, ptr %29, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %31 = fadd reassoc float %28, %30
  %32 = getelementptr i8, ptr %14, i64 24
  %33 = load float, ptr %32, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %34 = fadd reassoc float %31, %33
  %35 = getelementptr i8, ptr %14, i64 28
  %36 = load float, ptr %35, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %37 = fadd reassoc float %34, %36
  %38 = getelementptr i8, ptr %14, i64 32
  %39 = load float, ptr %38, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %40 = fadd reassoc float %37, %39
  %41 = getelementptr i8, ptr %14, i64 36
  %42 = load float, ptr %41, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %43 = fadd reassoc float %40, %42
  %44 = getelementptr i8, ptr %14, i64 40
  %45 = load float, ptr %44, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %46 = fadd reassoc float %43, %45
  %47 = getelementptr i8, ptr %14, i64 44
  %48 = load float, ptr %47, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %49 = fadd reassoc float %46, %48
  %50 = getelementptr i8, ptr %14, i64 48
  %51 = load float, ptr %50, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %52 = fadd reassoc float %49, %51
  %53 = getelementptr i8, ptr %14, i64 52
  %54 = load float, ptr %53, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %55 = fadd reassoc float %52, %54
  %56 = getelementptr i8, ptr %14, i64 56
  %57 = load float, ptr %56, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %58 = fadd reassoc float %55, %57
  %59 = getelementptr i8, ptr %14, i64 60
  %60 = load float, ptr %59, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %61 = fadd reassoc float %58, %60
  %62 = getelementptr i8, ptr %14, i64 64
  %63 = load float, ptr %62, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %64 = fadd reassoc float %61, %63
  %65 = getelementptr i8, ptr %14, i64 68
  %66 = load float, ptr %65, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %67 = fadd reassoc float %64, %66
  %68 = getelementptr i8, ptr %14, i64 72
  %69 = load float, ptr %68, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %70 = fadd reassoc float %67, %69
  %71 = getelementptr i8, ptr %14, i64 76
  %72 = load float, ptr %71, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %73 = fadd reassoc float %70, %72
  %74 = getelementptr i8, ptr %14, i64 80
  %75 = load float, ptr %74, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %76 = fadd reassoc float %73, %75
  %77 = getelementptr i8, ptr %14, i64 84
  %78 = load float, ptr %77, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %79 = fadd reassoc float %76, %78
  %80 = getelementptr i8, ptr %14, i64 88
  %81 = load float, ptr %80, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %82 = fadd reassoc float %79, %81
  %83 = getelementptr i8, ptr %14, i64 92
  %84 = load float, ptr %83, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %85 = fadd reassoc float %82, %84
  %86 = getelementptr i8, ptr %14, i64 96
  %87 = load float, ptr %86, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %88 = fadd reassoc float %85, %87
  %89 = getelementptr i8, ptr %14, i64 100
  %90 = load float, ptr %89, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %91 = fadd reassoc float %88, %90
  %92 = getelementptr i8, ptr %14, i64 104
  %93 = load float, ptr %92, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %94 = fadd reassoc float %91, %93
  %95 = getelementptr i8, ptr %14, i64 108
  %96 = load float, ptr %95, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %97 = fadd reassoc float %94, %96
  %98 = getelementptr i8, ptr %14, i64 112
  %99 = load float, ptr %98, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %100 = fadd reassoc float %97, %99
  %101 = getelementptr i8, ptr %14, i64 116
  %102 = load float, ptr %101, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %103 = fadd reassoc float %100, %102
  %104 = getelementptr i8, ptr %14, i64 120
  %105 = load float, ptr %104, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %106 = fadd reassoc float %103, %105
  %107 = getelementptr i8, ptr %14, i64 124
  %108 = load float, ptr %107, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %109 = fadd reassoc float %106, %108
  %110 = getelementptr float, ptr %12, i64 %13
  store float %109, ptr %110, align 4, !alias.scope !12, !noalias !16
  %111 = add nuw nsw i64 %13, 1
  %exitcond.not = icmp eq i64 %111, 6
  br i1 %exitcond.not, label %112, label %.preheader, !llvm.loop !17

112:                                              ; preds = %.preheader
  %113 = add nuw nsw i64 %10, 1
  %exitcond4.not = icmp eq i64 %113, 96
  br i1 %exitcond4.not, label %wrapped_reduce-window_wrapped.exit, label %.preheader3, !llvm.loop !17

wrapped_reduce-window_wrapped.exit:               ; preds = %112
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 4}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 73728}
!5 = !{i64 4}
!6 = !{i64 2304}
!7 = !{!8}
!8 = distinct !{!8, !9, !"wrapped_reduce-window_wrapped: argument 0"}
!9 = distinct !{!9, !"wrapped_reduce-window_wrapped"}
!10 = !{!11}
!11 = distinct !{!11, !9, !"wrapped_reduce-window_wrapped: argument 1"}
!12 = !{!13}
!13 = distinct !{!13, !9, !"wrapped_reduce-window_wrapped: argument 2"}
!14 = !{!8, !13}
!15 = !{!11, !13}
!16 = !{!8, !11}
!17 = distinct !{!17, !18}
!18 = !{!"llvm.loop.unroll.disable"}
