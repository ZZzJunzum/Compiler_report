; ModuleID = '__compute_module_shift-left_add_fusion_kernel_module'
source_filename = "__compute_module_shift-left_add_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @shift-left_add_fusion(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !5
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !5
  %9 = getelementptr inbounds nuw i8, ptr %3, i64 64
  %10 = load ptr, ptr %9, align 8, !invariant.load !3, !dereferenceable !5
  %11 = getelementptr inbounds nuw i8, ptr %3, i64 80
  %12 = load ptr, ptr %11, align 8, !invariant.load !3, !dereferenceable !5
  %13 = getelementptr inbounds nuw i8, ptr %3, i64 96
  %14 = load ptr, ptr %13, align 8, !invariant.load !3, !dereferenceable !4
  %15 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %16 = load ptr, ptr %15, align 8
  %17 = load i64, ptr %16, align 4, !invariant.load !3
  tail call void @llvm.experimental.noalias.scope.decl(metadata !6)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !11)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !13)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !15)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !17)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !19)
  %18 = icmp ult i64 %17, 12
  br i1 %18, label %19, label %shift-left_add_fusion_wrapped.exit

19:                                               ; preds = %1
  %20 = getelementptr inbounds nuw i8, ptr %3, i64 48
  %21 = load ptr, ptr %20, align 8, !invariant.load !3, !dereferenceable !21
  %22 = mul nuw nsw i64 %17, 1536
  %.idx = shl nuw nsw i64 %17, 5
  %23 = getelementptr i8, ptr %21, i64 %.idx
  br label %vector.ph

vector.ph:                                        ; preds = %19, %middle.block
  %24 = phi i64 [ 0, %19 ], [ %88, %middle.block ]
  %25 = mul nuw nsw i64 %24, 192
  %26 = add nuw nsw i64 %25, %22
  %27 = getelementptr float, ptr %23, i64 %24
  %28 = load float, ptr %27, align 4, !invariant.load !3, !alias.scope !13, !noalias !22
  %29 = fmul float %28, 0x3F75555560000000
  %broadcast.splatinsert = insertelement <8 x float> poison, float %29, i64 0
  %broadcast.splat = shufflevector <8 x float> %broadcast.splatinsert, <8 x float> poison, <8 x i32> zeroinitializer
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %vector.ph
  %index = phi i64 [ 0, %vector.ph ], [ %index.next.2, %vector.body ]
  %30 = add nuw nsw i64 %26, %index
  %31 = getelementptr inbounds nuw float, ptr %4, i64 %30
  %wide.load = load <8 x float>, ptr %31, align 4, !invariant.load !3, !alias.scope !6, !noalias !23
  %32 = getelementptr inbounds nuw float, ptr %12, i64 %index
  %wide.load5 = load <8 x float>, ptr %32, align 4, !invariant.load !3, !alias.scope !17, !noalias !24
  %33 = fmul <8 x float> %wide.load, %wide.load5
  %34 = getelementptr inbounds nuw float, ptr %10, i64 %index
  %wide.load6 = load <8 x float>, ptr %34, align 4, !invariant.load !3, !alias.scope !15, !noalias !25
  %35 = fadd <8 x float> %33, %wide.load6
  %36 = fsub <8 x float> %35, %broadcast.splat
  %37 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %36, <8 x float> zeroinitializer)
  %38 = getelementptr inbounds nuw float, ptr %8, i64 %index
  %wide.load7 = load <8 x float>, ptr %38, align 4, !invariant.load !3, !alias.scope !11, !noalias !26
  %39 = fmul <8 x float> %wide.load7, %37
  %40 = getelementptr inbounds nuw float, ptr %6, i64 %index
  %wide.load8 = load <8 x float>, ptr %40, align 4, !invariant.load !3, !alias.scope !9, !noalias !27
  %41 = fadd <8 x float> %wide.load8, %39
  %42 = fadd <8 x float> %wide.load, %41
  %43 = fcmp ogt <8 x float> %42, zeroinitializer
  %44 = fcmp ogt <8 x float> %36, zeroinitializer
  %45 = zext <8 x i1> %44 to <8 x i32>
  %46 = select <8 x i1> %43, <8 x i32> splat (i32 256), <8 x i32> zeroinitializer
  %47 = or disjoint <8 x i32> %46, %45
  %48 = getelementptr inbounds nuw i32, ptr %14, i64 %30
  store <8 x i32> %47, ptr %48, align 4, !alias.scope !19, !noalias !28
  %index.next = add nuw nsw i64 %index, 8
  %49 = add nuw nsw i64 %26, %index.next
  %50 = getelementptr inbounds nuw float, ptr %4, i64 %49
  %wide.load.1 = load <8 x float>, ptr %50, align 4, !invariant.load !3, !alias.scope !6, !noalias !23
  %51 = getelementptr inbounds nuw float, ptr %12, i64 %index.next
  %wide.load5.1 = load <8 x float>, ptr %51, align 4, !invariant.load !3, !alias.scope !17, !noalias !24
  %52 = fmul <8 x float> %wide.load.1, %wide.load5.1
  %53 = getelementptr inbounds nuw float, ptr %10, i64 %index.next
  %wide.load6.1 = load <8 x float>, ptr %53, align 4, !invariant.load !3, !alias.scope !15, !noalias !25
  %54 = fadd <8 x float> %52, %wide.load6.1
  %55 = fsub <8 x float> %54, %broadcast.splat
  %56 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %55, <8 x float> zeroinitializer)
  %57 = getelementptr inbounds nuw float, ptr %8, i64 %index.next
  %wide.load7.1 = load <8 x float>, ptr %57, align 4, !invariant.load !3, !alias.scope !11, !noalias !26
  %58 = fmul <8 x float> %wide.load7.1, %56
  %59 = getelementptr inbounds nuw float, ptr %6, i64 %index.next
  %wide.load8.1 = load <8 x float>, ptr %59, align 4, !invariant.load !3, !alias.scope !9, !noalias !27
  %60 = fadd <8 x float> %wide.load8.1, %58
  %61 = fadd <8 x float> %wide.load.1, %60
  %62 = fcmp ogt <8 x float> %61, zeroinitializer
  %63 = fcmp ogt <8 x float> %55, zeroinitializer
  %64 = zext <8 x i1> %63 to <8 x i32>
  %65 = select <8 x i1> %62, <8 x i32> splat (i32 256), <8 x i32> zeroinitializer
  %66 = or disjoint <8 x i32> %65, %64
  %67 = getelementptr inbounds nuw i32, ptr %14, i64 %49
  store <8 x i32> %66, ptr %67, align 4, !alias.scope !19, !noalias !28
  %index.next.1 = add nuw nsw i64 %index, 16
  %68 = add nuw nsw i64 %26, %index.next.1
  %69 = getelementptr inbounds nuw float, ptr %4, i64 %68
  %wide.load.2 = load <8 x float>, ptr %69, align 4, !invariant.load !3, !alias.scope !6, !noalias !23
  %70 = getelementptr inbounds nuw float, ptr %12, i64 %index.next.1
  %wide.load5.2 = load <8 x float>, ptr %70, align 4, !invariant.load !3, !alias.scope !17, !noalias !24
  %71 = fmul <8 x float> %wide.load.2, %wide.load5.2
  %72 = getelementptr inbounds nuw float, ptr %10, i64 %index.next.1
  %wide.load6.2 = load <8 x float>, ptr %72, align 4, !invariant.load !3, !alias.scope !15, !noalias !25
  %73 = fadd <8 x float> %71, %wide.load6.2
  %74 = fsub <8 x float> %73, %broadcast.splat
  %75 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %74, <8 x float> zeroinitializer)
  %76 = getelementptr inbounds nuw float, ptr %8, i64 %index.next.1
  %wide.load7.2 = load <8 x float>, ptr %76, align 4, !invariant.load !3, !alias.scope !11, !noalias !26
  %77 = fmul <8 x float> %wide.load7.2, %75
  %78 = getelementptr inbounds nuw float, ptr %6, i64 %index.next.1
  %wide.load8.2 = load <8 x float>, ptr %78, align 4, !invariant.load !3, !alias.scope !9, !noalias !27
  %79 = fadd <8 x float> %wide.load8.2, %77
  %80 = fadd <8 x float> %wide.load.2, %79
  %81 = fcmp ogt <8 x float> %80, zeroinitializer
  %82 = fcmp ogt <8 x float> %74, zeroinitializer
  %83 = zext <8 x i1> %82 to <8 x i32>
  %84 = select <8 x i1> %81, <8 x i32> splat (i32 256), <8 x i32> zeroinitializer
  %85 = or disjoint <8 x i32> %84, %83
  %86 = getelementptr inbounds nuw i32, ptr %14, i64 %68
  store <8 x i32> %85, ptr %86, align 4, !alias.scope !19, !noalias !28
  %index.next.2 = add nuw nsw i64 %index, 24
  %87 = icmp eq i64 %index.next.2, 192
  br i1 %87, label %middle.block, label %vector.body, !llvm.loop !29

middle.block:                                     ; preds = %vector.body
  %88 = add nuw nsw i64 %24, 1
  %exitcond3.not = icmp eq i64 %88, 8
  br i1 %exitcond3.not, label %shift-left_add_fusion_wrapped.exit, label %vector.ph, !llvm.loop !32

shift-left_add_fusion_wrapped.exit:               ; preds = %middle.block, %1
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.maximum.v8f32(<8 x float>, <8 x float>) #2

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 3}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 73728}
!5 = !{i64 768}
!6 = !{!7}
!7 = distinct !{!7, !8, !"shift-left_add_fusion_wrapped: argument 0"}
!8 = distinct !{!8, !"shift-left_add_fusion_wrapped"}
!9 = !{!10}
!10 = distinct !{!10, !8, !"shift-left_add_fusion_wrapped: argument 1"}
!11 = !{!12}
!12 = distinct !{!12, !8, !"shift-left_add_fusion_wrapped: argument 2"}
!13 = !{!14}
!14 = distinct !{!14, !8, !"shift-left_add_fusion_wrapped: argument 3"}
!15 = !{!16}
!16 = distinct !{!16, !8, !"shift-left_add_fusion_wrapped: argument 4"}
!17 = !{!18}
!18 = distinct !{!18, !8, !"shift-left_add_fusion_wrapped: argument 5"}
!19 = !{!20}
!20 = distinct !{!20, !8, !"shift-left_add_fusion_wrapped: argument 6"}
!21 = !{i64 384}
!22 = !{!7, !10, !12, !16, !18, !20}
!23 = !{!10, !12, !14, !16, !18, !20}
!24 = !{!7, !10, !12, !14, !16, !20}
!25 = !{!7, !10, !12, !14, !18, !20}
!26 = !{!7, !10, !14, !16, !18, !20}
!27 = !{!7, !12, !14, !16, !18, !20}
!28 = !{!7, !10, !12, !14, !16, !18}
!29 = distinct !{!29, !30, !31}
!30 = !{!"llvm.loop.isvectorized", i32 1}
!31 = !{!"llvm.loop.unroll.runtime.disable"}
!32 = distinct !{!32, !33}
!33 = !{!"llvm.loop.unroll.disable"}
