; ModuleID = '__compute_module_wrapped_reduce.2_kernel_module'
source_filename = "__compute_module_wrapped_reduce.2_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @wrapped_reduce.2(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !5
  tail call void @llvm.experimental.noalias.scope.decl(metadata !6)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !11)
  %7 = load i32, ptr %6, align 4, !invariant.load !3, !alias.scope !9, !noalias !13
  br label %.preheader

.preheader:                                       ; preds = %1, %.preheader
  %8 = phi i32 [ %7, %1 ], [ %27, %.preheader ]
  %9 = phi i64 [ 0, %1 ], [ %28, %.preheader ]
  %.idx = mul nuw nsw i64 %9, 24
  %10 = getelementptr i8, ptr %4, i64 %.idx
  %11 = load i32, ptr %10, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %12 = add i32 %11, %8
  %13 = getelementptr i8, ptr %10, i64 4
  %14 = load i32, ptr %13, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %15 = add i32 %14, %12
  %16 = getelementptr i8, ptr %10, i64 8
  %17 = load i32, ptr %16, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %18 = add i32 %17, %15
  %19 = getelementptr i8, ptr %10, i64 12
  %20 = load i32, ptr %19, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %21 = add i32 %20, %18
  %22 = getelementptr i8, ptr %10, i64 16
  %23 = load i32, ptr %22, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %24 = add i32 %23, %21
  %25 = getelementptr i8, ptr %10, i64 20
  %26 = load i32, ptr %25, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %27 = add i32 %26, %24
  %28 = add nuw nsw i64 %9, 1
  %exitcond.not = icmp eq i64 %28, 3
  br i1 %exitcond.not, label %wrapped_reduce.2_wrapped.exit, label %.preheader, !llvm.loop !15

wrapped_reduce.2_wrapped.exit:                    ; preds = %.preheader
  %29 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %30 = load ptr, ptr %29, align 8, !invariant.load !3, !dereferenceable !5
  store i32 %27, ptr %30, align 4, !alias.scope !11, !noalias !17
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 7}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 72}
!5 = !{i64 4}
!6 = !{!7}
!7 = distinct !{!7, !8, !"wrapped_reduce.2_wrapped: argument 0"}
!8 = distinct !{!8, !"wrapped_reduce.2_wrapped"}
!9 = !{!10}
!10 = distinct !{!10, !8, !"wrapped_reduce.2_wrapped: argument 1"}
!11 = !{!12}
!12 = distinct !{!12, !8, !"wrapped_reduce.2_wrapped: argument 2"}
!13 = !{!7, !12}
!14 = !{!10, !12}
!15 = distinct !{!15, !16}
!16 = !{!"llvm.loop.unroll.disable"}
!17 = !{!7, !10}
