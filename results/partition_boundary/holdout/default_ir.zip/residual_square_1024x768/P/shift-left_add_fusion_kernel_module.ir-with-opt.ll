; ModuleID = '__compute_module_shift-left_add_fusion_kernel_module'
source_filename = "__compute_module_shift-left_add_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @shift-left_add_fusion(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !4
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !5
  %9 = getelementptr inbounds nuw i8, ptr %3, i64 48
  %10 = load ptr, ptr %9, align 8, !invariant.load !3, !dereferenceable !4
  %11 = getelementptr inbounds nuw i8, ptr %3, i64 64
  %12 = load ptr, ptr %11, align 8, !invariant.load !3, !dereferenceable !4
  %13 = getelementptr inbounds nuw i8, ptr %3, i64 80
  %14 = load ptr, ptr %13, align 8, !invariant.load !3, !dereferenceable !5
  %15 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %16 = load ptr, ptr %15, align 8
  %17 = load i64, ptr %16, align 4, !invariant.load !3
  tail call void @llvm.experimental.noalias.scope.decl(metadata !6)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !11)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !13)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !15)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !17)
  %18 = icmp slt i64 %17, 11
  br i1 %18, label %19, label %88

19:                                               ; preds = %1
  %20 = icmp sgt i64 %17, -1
  br i1 %20, label %21, label %shift-left_add_fusion_wrapped.exit

21:                                               ; preds = %19
  %22 = mul nuw nsw i64 %17, 66048
  br label %vector.ph18

vector.ph18:                                      ; preds = %21, %middle.block27
  %23 = phi i64 [ 0, %21 ], [ %87, %middle.block27 ]
  %24 = mul nuw nsw i64 %23, 768
  %25 = add nuw nsw i64 %24, %22
  br label %vector.body19

vector.body19:                                    ; preds = %vector.body19, %vector.ph18
  %index20 = phi i64 [ 0, %vector.ph18 ], [ %index.next26.2, %vector.body19 ]
  %26 = add nuw nsw i64 %25, %index20
  %27 = getelementptr inbounds nuw float, ptr %8, i64 %26
  %wide.load21 = load <8 x float>, ptr %27, align 4, !invariant.load !3, !alias.scope !11, !noalias !19
  %28 = getelementptr inbounds nuw float, ptr %12, i64 %index20
  %wide.load22 = load <8 x float>, ptr %28, align 4, !invariant.load !3, !alias.scope !15, !noalias !20
  %29 = fmul <8 x float> %wide.load21, %wide.load22
  %30 = getelementptr inbounds nuw float, ptr %10, i64 %index20
  %wide.load23 = load <8 x float>, ptr %30, align 4, !invariant.load !3, !alias.scope !13, !noalias !21
  %31 = fadd <8 x float> %29, %wide.load23
  %32 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %31, <8 x float> zeroinitializer)
  %33 = fmul <8 x float> %wide.load21, splat (float 2.500000e-01)
  %34 = fadd <8 x float> %33, %32
  %35 = fmul <8 x float> %34, %34
  %36 = getelementptr inbounds nuw float, ptr %6, i64 %index20
  %wide.load24 = load <8 x float>, ptr %36, align 4, !invariant.load !3, !alias.scope !9, !noalias !22
  %37 = fmul <8 x float> %wide.load24, %35
  %38 = getelementptr inbounds nuw float, ptr %4, i64 %index20
  %wide.load25 = load <8 x float>, ptr %38, align 4, !invariant.load !3, !alias.scope !6, !noalias !23
  %39 = fadd <8 x float> %wide.load25, %37
  %40 = fcmp ogt <8 x float> %39, zeroinitializer
  %41 = fcmp ogt <8 x float> %31, zeroinitializer
  %42 = zext <8 x i1> %41 to <8 x i32>
  %43 = select <8 x i1> %40, <8 x i32> splat (i32 1024), <8 x i32> zeroinitializer
  %44 = or disjoint <8 x i32> %43, %42
  %45 = getelementptr inbounds nuw i32, ptr %14, i64 %26
  store <8 x i32> %44, ptr %45, align 4, !alias.scope !17, !noalias !24
  %index.next26 = add nuw nsw i64 %index20, 8
  %46 = add nuw nsw i64 %25, %index.next26
  %47 = getelementptr inbounds nuw float, ptr %8, i64 %46
  %wide.load21.1 = load <8 x float>, ptr %47, align 4, !invariant.load !3, !alias.scope !11, !noalias !19
  %48 = getelementptr inbounds nuw float, ptr %12, i64 %index.next26
  %wide.load22.1 = load <8 x float>, ptr %48, align 4, !invariant.load !3, !alias.scope !15, !noalias !20
  %49 = fmul <8 x float> %wide.load21.1, %wide.load22.1
  %50 = getelementptr inbounds nuw float, ptr %10, i64 %index.next26
  %wide.load23.1 = load <8 x float>, ptr %50, align 4, !invariant.load !3, !alias.scope !13, !noalias !21
  %51 = fadd <8 x float> %49, %wide.load23.1
  %52 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %51, <8 x float> zeroinitializer)
  %53 = fmul <8 x float> %wide.load21.1, splat (float 2.500000e-01)
  %54 = fadd <8 x float> %53, %52
  %55 = fmul <8 x float> %54, %54
  %56 = getelementptr inbounds nuw float, ptr %6, i64 %index.next26
  %wide.load24.1 = load <8 x float>, ptr %56, align 4, !invariant.load !3, !alias.scope !9, !noalias !22
  %57 = fmul <8 x float> %wide.load24.1, %55
  %58 = getelementptr inbounds nuw float, ptr %4, i64 %index.next26
  %wide.load25.1 = load <8 x float>, ptr %58, align 4, !invariant.load !3, !alias.scope !6, !noalias !23
  %59 = fadd <8 x float> %wide.load25.1, %57
  %60 = fcmp ogt <8 x float> %59, zeroinitializer
  %61 = fcmp ogt <8 x float> %51, zeroinitializer
  %62 = zext <8 x i1> %61 to <8 x i32>
  %63 = select <8 x i1> %60, <8 x i32> splat (i32 1024), <8 x i32> zeroinitializer
  %64 = or disjoint <8 x i32> %63, %62
  %65 = getelementptr inbounds nuw i32, ptr %14, i64 %46
  store <8 x i32> %64, ptr %65, align 4, !alias.scope !17, !noalias !24
  %index.next26.1 = add nuw nsw i64 %index20, 16
  %66 = add nuw nsw i64 %25, %index.next26.1
  %67 = getelementptr inbounds nuw float, ptr %8, i64 %66
  %wide.load21.2 = load <8 x float>, ptr %67, align 4, !invariant.load !3, !alias.scope !11, !noalias !19
  %68 = getelementptr inbounds nuw float, ptr %12, i64 %index.next26.1
  %wide.load22.2 = load <8 x float>, ptr %68, align 4, !invariant.load !3, !alias.scope !15, !noalias !20
  %69 = fmul <8 x float> %wide.load21.2, %wide.load22.2
  %70 = getelementptr inbounds nuw float, ptr %10, i64 %index.next26.1
  %wide.load23.2 = load <8 x float>, ptr %70, align 4, !invariant.load !3, !alias.scope !13, !noalias !21
  %71 = fadd <8 x float> %69, %wide.load23.2
  %72 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %71, <8 x float> zeroinitializer)
  %73 = fmul <8 x float> %wide.load21.2, splat (float 2.500000e-01)
  %74 = fadd <8 x float> %73, %72
  %75 = fmul <8 x float> %74, %74
  %76 = getelementptr inbounds nuw float, ptr %6, i64 %index.next26.1
  %wide.load24.2 = load <8 x float>, ptr %76, align 4, !invariant.load !3, !alias.scope !9, !noalias !22
  %77 = fmul <8 x float> %wide.load24.2, %75
  %78 = getelementptr inbounds nuw float, ptr %4, i64 %index.next26.1
  %wide.load25.2 = load <8 x float>, ptr %78, align 4, !invariant.load !3, !alias.scope !6, !noalias !23
  %79 = fadd <8 x float> %wide.load25.2, %77
  %80 = fcmp ogt <8 x float> %79, zeroinitializer
  %81 = fcmp ogt <8 x float> %71, zeroinitializer
  %82 = zext <8 x i1> %81 to <8 x i32>
  %83 = select <8 x i1> %80, <8 x i32> splat (i32 1024), <8 x i32> zeroinitializer
  %84 = or disjoint <8 x i32> %83, %82
  %85 = getelementptr inbounds nuw i32, ptr %14, i64 %66
  store <8 x i32> %84, ptr %85, align 4, !alias.scope !17, !noalias !24
  %index.next26.2 = add nuw nsw i64 %index20, 24
  %86 = icmp eq i64 %index.next26.2, 768
  br i1 %86, label %middle.block27, label %vector.body19, !llvm.loop !25

middle.block27:                                   ; preds = %vector.body19
  %87 = add nuw nsw i64 %23, 1
  %exitcond9.not = icmp eq i64 %87, 86
  br i1 %exitcond9.not, label %shift-left_add_fusion_wrapped.exit, label %vector.ph18, !llvm.loop !28

88:                                               ; preds = %1
  %89 = icmp eq i64 %17, 11
  br i1 %89, label %.preheader, label %shift-left_add_fusion_wrapped.exit

.preheader:                                       ; preds = %88, %middle.block
  %90 = phi i64 [ %154, %middle.block ], [ 0, %88 ]
  %91 = mul nuw nsw i64 %90, 768
  %92 = add nuw nsw i64 %91, 726528
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %.preheader
  %index = phi i64 [ 0, %.preheader ], [ %index.next.2, %vector.body ]
  %93 = add nuw nsw i64 %92, %index
  %94 = getelementptr inbounds nuw float, ptr %8, i64 %93
  %wide.load = load <8 x float>, ptr %94, align 4, !invariant.load !3, !alias.scope !11, !noalias !19
  %95 = getelementptr inbounds nuw float, ptr %12, i64 %index
  %wide.load14 = load <8 x float>, ptr %95, align 4, !invariant.load !3, !alias.scope !15, !noalias !20
  %96 = fmul <8 x float> %wide.load, %wide.load14
  %97 = getelementptr inbounds nuw float, ptr %10, i64 %index
  %wide.load15 = load <8 x float>, ptr %97, align 4, !invariant.load !3, !alias.scope !13, !noalias !21
  %98 = fadd <8 x float> %96, %wide.load15
  %99 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %98, <8 x float> zeroinitializer)
  %100 = fmul <8 x float> %wide.load, splat (float 2.500000e-01)
  %101 = fadd <8 x float> %100, %99
  %102 = fmul <8 x float> %101, %101
  %103 = getelementptr inbounds nuw float, ptr %6, i64 %index
  %wide.load16 = load <8 x float>, ptr %103, align 4, !invariant.load !3, !alias.scope !9, !noalias !22
  %104 = fmul <8 x float> %wide.load16, %102
  %105 = getelementptr inbounds nuw float, ptr %4, i64 %index
  %wide.load17 = load <8 x float>, ptr %105, align 4, !invariant.load !3, !alias.scope !6, !noalias !23
  %106 = fadd <8 x float> %wide.load17, %104
  %107 = fcmp ogt <8 x float> %106, zeroinitializer
  %108 = fcmp ogt <8 x float> %98, zeroinitializer
  %109 = zext <8 x i1> %108 to <8 x i32>
  %110 = select <8 x i1> %107, <8 x i32> splat (i32 1024), <8 x i32> zeroinitializer
  %111 = or disjoint <8 x i32> %110, %109
  %112 = getelementptr inbounds nuw i32, ptr %14, i64 %93
  store <8 x i32> %111, ptr %112, align 4, !alias.scope !17, !noalias !24
  %index.next = add nuw nsw i64 %index, 8
  %113 = add nuw nsw i64 %92, %index.next
  %114 = getelementptr inbounds nuw float, ptr %8, i64 %113
  %wide.load.1 = load <8 x float>, ptr %114, align 4, !invariant.load !3, !alias.scope !11, !noalias !19
  %115 = getelementptr inbounds nuw float, ptr %12, i64 %index.next
  %wide.load14.1 = load <8 x float>, ptr %115, align 4, !invariant.load !3, !alias.scope !15, !noalias !20
  %116 = fmul <8 x float> %wide.load.1, %wide.load14.1
  %117 = getelementptr inbounds nuw float, ptr %10, i64 %index.next
  %wide.load15.1 = load <8 x float>, ptr %117, align 4, !invariant.load !3, !alias.scope !13, !noalias !21
  %118 = fadd <8 x float> %116, %wide.load15.1
  %119 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %118, <8 x float> zeroinitializer)
  %120 = fmul <8 x float> %wide.load.1, splat (float 2.500000e-01)
  %121 = fadd <8 x float> %120, %119
  %122 = fmul <8 x float> %121, %121
  %123 = getelementptr inbounds nuw float, ptr %6, i64 %index.next
  %wide.load16.1 = load <8 x float>, ptr %123, align 4, !invariant.load !3, !alias.scope !9, !noalias !22
  %124 = fmul <8 x float> %wide.load16.1, %122
  %125 = getelementptr inbounds nuw float, ptr %4, i64 %index.next
  %wide.load17.1 = load <8 x float>, ptr %125, align 4, !invariant.load !3, !alias.scope !6, !noalias !23
  %126 = fadd <8 x float> %wide.load17.1, %124
  %127 = fcmp ogt <8 x float> %126, zeroinitializer
  %128 = fcmp ogt <8 x float> %118, zeroinitializer
  %129 = zext <8 x i1> %128 to <8 x i32>
  %130 = select <8 x i1> %127, <8 x i32> splat (i32 1024), <8 x i32> zeroinitializer
  %131 = or disjoint <8 x i32> %130, %129
  %132 = getelementptr inbounds nuw i32, ptr %14, i64 %113
  store <8 x i32> %131, ptr %132, align 4, !alias.scope !17, !noalias !24
  %index.next.1 = add nuw nsw i64 %index, 16
  %133 = add nuw nsw i64 %92, %index.next.1
  %134 = getelementptr inbounds nuw float, ptr %8, i64 %133
  %wide.load.2 = load <8 x float>, ptr %134, align 4, !invariant.load !3, !alias.scope !11, !noalias !19
  %135 = getelementptr inbounds nuw float, ptr %12, i64 %index.next.1
  %wide.load14.2 = load <8 x float>, ptr %135, align 4, !invariant.load !3, !alias.scope !15, !noalias !20
  %136 = fmul <8 x float> %wide.load.2, %wide.load14.2
  %137 = getelementptr inbounds nuw float, ptr %10, i64 %index.next.1
  %wide.load15.2 = load <8 x float>, ptr %137, align 4, !invariant.load !3, !alias.scope !13, !noalias !21
  %138 = fadd <8 x float> %136, %wide.load15.2
  %139 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %138, <8 x float> zeroinitializer)
  %140 = fmul <8 x float> %wide.load.2, splat (float 2.500000e-01)
  %141 = fadd <8 x float> %140, %139
  %142 = fmul <8 x float> %141, %141
  %143 = getelementptr inbounds nuw float, ptr %6, i64 %index.next.1
  %wide.load16.2 = load <8 x float>, ptr %143, align 4, !invariant.load !3, !alias.scope !9, !noalias !22
  %144 = fmul <8 x float> %wide.load16.2, %142
  %145 = getelementptr inbounds nuw float, ptr %4, i64 %index.next.1
  %wide.load17.2 = load <8 x float>, ptr %145, align 4, !invariant.load !3, !alias.scope !6, !noalias !23
  %146 = fadd <8 x float> %wide.load17.2, %144
  %147 = fcmp ogt <8 x float> %146, zeroinitializer
  %148 = fcmp ogt <8 x float> %138, zeroinitializer
  %149 = zext <8 x i1> %148 to <8 x i32>
  %150 = select <8 x i1> %147, <8 x i32> splat (i32 1024), <8 x i32> zeroinitializer
  %151 = or disjoint <8 x i32> %150, %149
  %152 = getelementptr inbounds nuw i32, ptr %14, i64 %133
  store <8 x i32> %151, ptr %152, align 4, !alias.scope !17, !noalias !24
  %index.next.2 = add nuw nsw i64 %index, 24
  %153 = icmp eq i64 %index.next.2, 768
  br i1 %153, label %middle.block, label %vector.body, !llvm.loop !30

middle.block:                                     ; preds = %vector.body
  %154 = add nuw nsw i64 %90, 1
  %exitcond7.not = icmp eq i64 %154, 78
  br i1 %exitcond7.not, label %shift-left_add_fusion_wrapped.exit, label %.preheader, !llvm.loop !28

shift-left_add_fusion_wrapped.exit:               ; preds = %middle.block, %middle.block27, %19, %88
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.maximum.v8f32(<8 x float>, <8 x float>) #2

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 2}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 3072}
!5 = !{i64 3145728}
!6 = !{!7}
!7 = distinct !{!7, !8, !"shift-left_add_fusion_wrapped: argument 0"}
!8 = distinct !{!8, !"shift-left_add_fusion_wrapped"}
!9 = !{!10}
!10 = distinct !{!10, !8, !"shift-left_add_fusion_wrapped: argument 1"}
!11 = !{!12}
!12 = distinct !{!12, !8, !"shift-left_add_fusion_wrapped: argument 2"}
!13 = !{!14}
!14 = distinct !{!14, !8, !"shift-left_add_fusion_wrapped: argument 3"}
!15 = !{!16}
!16 = distinct !{!16, !8, !"shift-left_add_fusion_wrapped: argument 4"}
!17 = !{!18}
!18 = distinct !{!18, !8, !"shift-left_add_fusion_wrapped: argument 5"}
!19 = !{!7, !10, !14, !16, !18}
!20 = !{!7, !10, !12, !14, !18}
!21 = !{!7, !10, !12, !16, !18}
!22 = !{!7, !12, !14, !16, !18}
!23 = !{!10, !12, !14, !16, !18}
!24 = !{!7, !10, !12, !14, !16}
!25 = distinct !{!25, !26, !27}
!26 = !{!"llvm.loop.isvectorized", i32 1}
!27 = !{!"llvm.loop.unroll.runtime.disable"}
!28 = distinct !{!28, !29}
!29 = !{!"llvm.loop.unroll.disable"}
!30 = distinct !{!30, !26, !27}
