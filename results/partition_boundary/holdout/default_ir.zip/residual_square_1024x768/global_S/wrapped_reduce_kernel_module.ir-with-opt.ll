; ModuleID = '__compute_module_wrapped_reduce_kernel_module'
source_filename = "__compute_module_wrapped_reduce_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @wrapped_reduce(ptr readonly captures(none) %0) local_unnamed_addr #0 {
vector.ph:
  %1 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %2 = load ptr, ptr %1, align 8, !invariant.load !3
  %3 = load ptr, ptr %2, align 8, !invariant.load !3, !dereferenceable !4
  tail call void @llvm.experimental.noalias.scope.decl(metadata !5)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !8)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !10)
  %4 = getelementptr inbounds nuw i8, ptr %2, i64 16
  %5 = load ptr, ptr %4, align 8, !invariant.load !3, !dereferenceable !12
  %6 = load i32, ptr %5, align 4, !invariant.load !3, !alias.scope !8, !noalias !13
  %7 = insertelement <8 x i32> <i32 poison, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0>, i32 %6, i64 0
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %vector.ph
  %index = phi i64 [ 0, %vector.ph ], [ %index.next, %vector.body ]
  %vec.phi = phi <8 x i32> [ %7, %vector.ph ], [ %56, %vector.body ]
  %vec.ind = phi <8 x i64> [ <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>, %vector.ph ], [ %vec.ind.next, %vector.body ]
  %8 = mul nuw nsw <8 x i64> %vec.ind, splat (i64 96)
  %9 = getelementptr i8, ptr %3, <8 x i64> %8
  %wide.masked.gather = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %9, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !5, !noalias !14
  %10 = add <8 x i32> %wide.masked.gather, %vec.phi
  %11 = getelementptr i8, <8 x ptr> %9, i64 4
  %wide.masked.gather2 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %11, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !5, !noalias !14
  %12 = add <8 x i32> %wide.masked.gather2, %10
  %13 = getelementptr i8, <8 x ptr> %9, i64 8
  %wide.masked.gather3 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %13, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !5, !noalias !14
  %14 = add <8 x i32> %wide.masked.gather3, %12
  %15 = getelementptr i8, <8 x ptr> %9, i64 12
  %wide.masked.gather4 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %15, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !5, !noalias !14
  %16 = add <8 x i32> %wide.masked.gather4, %14
  %17 = getelementptr i8, <8 x ptr> %9, i64 16
  %wide.masked.gather5 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %17, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !5, !noalias !14
  %18 = add <8 x i32> %wide.masked.gather5, %16
  %19 = getelementptr i8, <8 x ptr> %9, i64 20
  %wide.masked.gather6 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %19, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !5, !noalias !14
  %20 = add <8 x i32> %wide.masked.gather6, %18
  %21 = getelementptr i8, <8 x ptr> %9, i64 24
  %wide.masked.gather7 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %21, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !5, !noalias !14
  %22 = add <8 x i32> %wide.masked.gather7, %20
  %23 = getelementptr i8, <8 x ptr> %9, i64 28
  %wide.masked.gather8 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %23, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !5, !noalias !14
  %24 = add <8 x i32> %wide.masked.gather8, %22
  %25 = getelementptr i8, <8 x ptr> %9, i64 32
  %wide.masked.gather9 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %25, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !5, !noalias !14
  %26 = add <8 x i32> %wide.masked.gather9, %24
  %27 = getelementptr i8, <8 x ptr> %9, i64 36
  %wide.masked.gather10 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %27, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !5, !noalias !14
  %28 = add <8 x i32> %wide.masked.gather10, %26
  %29 = getelementptr i8, <8 x ptr> %9, i64 40
  %wide.masked.gather11 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %29, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !5, !noalias !14
  %30 = add <8 x i32> %wide.masked.gather11, %28
  %31 = getelementptr i8, <8 x ptr> %9, i64 44
  %wide.masked.gather12 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %31, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !5, !noalias !14
  %32 = add <8 x i32> %wide.masked.gather12, %30
  %33 = getelementptr i8, <8 x ptr> %9, i64 48
  %wide.masked.gather13 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %33, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !5, !noalias !14
  %34 = add <8 x i32> %wide.masked.gather13, %32
  %35 = getelementptr i8, <8 x ptr> %9, i64 52
  %wide.masked.gather14 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %35, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !5, !noalias !14
  %36 = add <8 x i32> %wide.masked.gather14, %34
  %37 = getelementptr i8, <8 x ptr> %9, i64 56
  %wide.masked.gather15 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %37, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !5, !noalias !14
  %38 = add <8 x i32> %wide.masked.gather15, %36
  %39 = getelementptr i8, <8 x ptr> %9, i64 60
  %wide.masked.gather16 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %39, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !5, !noalias !14
  %40 = add <8 x i32> %wide.masked.gather16, %38
  %41 = getelementptr i8, <8 x ptr> %9, i64 64
  %wide.masked.gather17 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %41, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !5, !noalias !14
  %42 = add <8 x i32> %wide.masked.gather17, %40
  %43 = getelementptr i8, <8 x ptr> %9, i64 68
  %wide.masked.gather18 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %43, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !5, !noalias !14
  %44 = add <8 x i32> %wide.masked.gather18, %42
  %45 = getelementptr i8, <8 x ptr> %9, i64 72
  %wide.masked.gather19 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %45, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !5, !noalias !14
  %46 = add <8 x i32> %wide.masked.gather19, %44
  %47 = getelementptr i8, <8 x ptr> %9, i64 76
  %wide.masked.gather20 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %47, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !5, !noalias !14
  %48 = add <8 x i32> %wide.masked.gather20, %46
  %49 = getelementptr i8, <8 x ptr> %9, i64 80
  %wide.masked.gather21 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %49, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !5, !noalias !14
  %50 = add <8 x i32> %wide.masked.gather21, %48
  %51 = getelementptr i8, <8 x ptr> %9, i64 84
  %wide.masked.gather22 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %51, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !5, !noalias !14
  %52 = add <8 x i32> %wide.masked.gather22, %50
  %53 = getelementptr i8, <8 x ptr> %9, i64 88
  %wide.masked.gather23 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %53, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !5, !noalias !14
  %54 = add <8 x i32> %wide.masked.gather23, %52
  %55 = getelementptr i8, <8 x ptr> %9, i64 92
  %wide.masked.gather24 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %55, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !5, !noalias !14
  %56 = add <8 x i32> %wide.masked.gather24, %54
  %index.next = add nuw i64 %index, 8
  %vec.ind.next = add nuw nsw <8 x i64> %vec.ind, splat (i64 8)
  %57 = icmp eq i64 %index.next, 32
  br i1 %57, label %wrapped_reduce_wrapped.exit, label %vector.body, !llvm.loop !15

wrapped_reduce_wrapped.exit:                      ; preds = %vector.body
  %58 = tail call i32 @llvm.vector.reduce.add.v8i32(<8 x i32> %56)
  %59 = getelementptr inbounds nuw i8, ptr %2, i64 32
  %60 = load ptr, ptr %59, align 8, !invariant.load !3, !dereferenceable !12
  store i32 %58, ptr %60, align 4, !alias.scope !10, !noalias !19
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr>, <8 x i1>, <8 x i32>) #2

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.vector.reduce.add.v8i32(<8 x i32>) #3

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #3 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 3}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 3072}
!5 = !{!6}
!6 = distinct !{!6, !7, !"wrapped_reduce_wrapped: argument 0"}
!7 = distinct !{!7, !"wrapped_reduce_wrapped"}
!8 = !{!9}
!9 = distinct !{!9, !7, !"wrapped_reduce_wrapped: argument 1"}
!10 = !{!11}
!11 = distinct !{!11, !7, !"wrapped_reduce_wrapped: argument 2"}
!12 = !{i64 4}
!13 = !{!6, !11}
!14 = !{!9, !11}
!15 = distinct !{!15, !16, !17, !18}
!16 = !{!"llvm.loop.unroll.disable"}
!17 = !{!"llvm.loop.isvectorized", i32 1}
!18 = !{!"llvm.loop.unroll.runtime.disable"}
!19 = !{!6, !9}
