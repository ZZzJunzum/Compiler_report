; ModuleID = '__compute_module_multiply_add_fusion_kernel_module'
source_filename = "__compute_module_multiply_add_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @multiply_add_fusion(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !4
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !5
  %9 = getelementptr inbounds nuw i8, ptr %3, i64 48
  %10 = load ptr, ptr %9, align 8, !invariant.load !3, !dereferenceable !4
  %11 = getelementptr inbounds nuw i8, ptr %3, i64 64
  %12 = load ptr, ptr %11, align 8, !invariant.load !3, !dereferenceable !4
  %13 = getelementptr inbounds nuw i8, ptr %3, i64 80
  %14 = load ptr, ptr %13, align 8, !invariant.load !3, !dereferenceable !5
  tail call void @llvm.experimental.noalias.scope.decl(metadata !6)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !11)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !13)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !15)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !17)
  br label %vector.ph

vector.ph:                                        ; preds = %1, %middle.block
  %15 = phi i64 [ 0, %1 ], [ %72, %middle.block ]
  %16 = mul nuw nsw i64 %15, 768
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %vector.ph
  %index = phi i64 [ 0, %vector.ph ], [ %index.next.2, %vector.body ]
  %17 = add nuw nsw i64 %index, %16
  %18 = getelementptr inbounds nuw float, ptr %8, i64 %17
  %wide.load = load <8 x float>, ptr %18, align 4, !invariant.load !3, !alias.scope !11, !noalias !19
  %19 = getelementptr inbounds nuw float, ptr %12, i64 %index
  %wide.load3 = load <8 x float>, ptr %19, align 4, !invariant.load !3, !alias.scope !15, !noalias !20
  %20 = fmul <8 x float> %wide.load, %wide.load3
  %21 = getelementptr inbounds nuw float, ptr %10, i64 %index
  %wide.load4 = load <8 x float>, ptr %21, align 4, !invariant.load !3, !alias.scope !13, !noalias !21
  %22 = fadd <8 x float> %20, %wide.load4
  %23 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %22, <8 x float> zeroinitializer)
  %24 = fmul <8 x float> %wide.load, splat (float 2.500000e-01)
  %25 = fadd <8 x float> %24, %23
  %26 = fmul <8 x float> %25, %25
  %27 = getelementptr inbounds nuw float, ptr %6, i64 %index
  %wide.load5 = load <8 x float>, ptr %27, align 4, !invariant.load !3, !alias.scope !9, !noalias !22
  %28 = fmul <8 x float> %wide.load5, %26
  %29 = getelementptr inbounds nuw float, ptr %4, i64 %index
  %wide.load6 = load <8 x float>, ptr %29, align 4, !invariant.load !3, !alias.scope !6, !noalias !23
  %30 = fadd <8 x float> %wide.load6, %28
  %31 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %30, <8 x float> zeroinitializer)
  %32 = fmul <8 x float> %22, splat (float 1.250000e-01)
  %33 = fadd <8 x float> %32, %31
  %34 = getelementptr inbounds nuw float, ptr %14, i64 %17
  store <8 x float> %33, ptr %34, align 4, !alias.scope !17, !noalias !24
  %index.next = add nuw nsw i64 %index, 8
  %35 = add nuw nsw i64 %index.next, %16
  %36 = getelementptr inbounds nuw float, ptr %8, i64 %35
  %wide.load.1 = load <8 x float>, ptr %36, align 4, !invariant.load !3, !alias.scope !11, !noalias !19
  %37 = getelementptr inbounds nuw float, ptr %12, i64 %index.next
  %wide.load3.1 = load <8 x float>, ptr %37, align 4, !invariant.load !3, !alias.scope !15, !noalias !20
  %38 = fmul <8 x float> %wide.load.1, %wide.load3.1
  %39 = getelementptr inbounds nuw float, ptr %10, i64 %index.next
  %wide.load4.1 = load <8 x float>, ptr %39, align 4, !invariant.load !3, !alias.scope !13, !noalias !21
  %40 = fadd <8 x float> %38, %wide.load4.1
  %41 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %40, <8 x float> zeroinitializer)
  %42 = fmul <8 x float> %wide.load.1, splat (float 2.500000e-01)
  %43 = fadd <8 x float> %42, %41
  %44 = fmul <8 x float> %43, %43
  %45 = getelementptr inbounds nuw float, ptr %6, i64 %index.next
  %wide.load5.1 = load <8 x float>, ptr %45, align 4, !invariant.load !3, !alias.scope !9, !noalias !22
  %46 = fmul <8 x float> %wide.load5.1, %44
  %47 = getelementptr inbounds nuw float, ptr %4, i64 %index.next
  %wide.load6.1 = load <8 x float>, ptr %47, align 4, !invariant.load !3, !alias.scope !6, !noalias !23
  %48 = fadd <8 x float> %wide.load6.1, %46
  %49 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %48, <8 x float> zeroinitializer)
  %50 = fmul <8 x float> %40, splat (float 1.250000e-01)
  %51 = fadd <8 x float> %50, %49
  %52 = getelementptr inbounds nuw float, ptr %14, i64 %35
  store <8 x float> %51, ptr %52, align 4, !alias.scope !17, !noalias !24
  %index.next.1 = add nuw nsw i64 %index, 16
  %53 = add nuw nsw i64 %index.next.1, %16
  %54 = getelementptr inbounds nuw float, ptr %8, i64 %53
  %wide.load.2 = load <8 x float>, ptr %54, align 4, !invariant.load !3, !alias.scope !11, !noalias !19
  %55 = getelementptr inbounds nuw float, ptr %12, i64 %index.next.1
  %wide.load3.2 = load <8 x float>, ptr %55, align 4, !invariant.load !3, !alias.scope !15, !noalias !20
  %56 = fmul <8 x float> %wide.load.2, %wide.load3.2
  %57 = getelementptr inbounds nuw float, ptr %10, i64 %index.next.1
  %wide.load4.2 = load <8 x float>, ptr %57, align 4, !invariant.load !3, !alias.scope !13, !noalias !21
  %58 = fadd <8 x float> %56, %wide.load4.2
  %59 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %58, <8 x float> zeroinitializer)
  %60 = fmul <8 x float> %wide.load.2, splat (float 2.500000e-01)
  %61 = fadd <8 x float> %60, %59
  %62 = fmul <8 x float> %61, %61
  %63 = getelementptr inbounds nuw float, ptr %6, i64 %index.next.1
  %wide.load5.2 = load <8 x float>, ptr %63, align 4, !invariant.load !3, !alias.scope !9, !noalias !22
  %64 = fmul <8 x float> %wide.load5.2, %62
  %65 = getelementptr inbounds nuw float, ptr %4, i64 %index.next.1
  %wide.load6.2 = load <8 x float>, ptr %65, align 4, !invariant.load !3, !alias.scope !6, !noalias !23
  %66 = fadd <8 x float> %wide.load6.2, %64
  %67 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %66, <8 x float> zeroinitializer)
  %68 = fmul <8 x float> %58, splat (float 1.250000e-01)
  %69 = fadd <8 x float> %68, %67
  %70 = getelementptr inbounds nuw float, ptr %14, i64 %53
  store <8 x float> %69, ptr %70, align 4, !alias.scope !17, !noalias !24
  %index.next.2 = add nuw nsw i64 %index, 24
  %71 = icmp eq i64 %index.next.2, 768
  br i1 %71, label %middle.block, label %vector.body, !llvm.loop !25

middle.block:                                     ; preds = %vector.body
  %72 = add nuw nsw i64 %15, 1
  %exitcond2.not = icmp eq i64 %72, 1024
  br i1 %exitcond2.not, label %multiply_add_fusion_wrapped.exit, label %vector.ph, !llvm.loop !28

multiply_add_fusion_wrapped.exit:                 ; preds = %middle.block
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.maximum.v8f32(<8 x float>, <8 x float>) #2

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 1}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 3072}
!5 = !{i64 3145728}
!6 = !{!7}
!7 = distinct !{!7, !8, !"multiply_add_fusion_wrapped: argument 0"}
!8 = distinct !{!8, !"multiply_add_fusion_wrapped"}
!9 = !{!10}
!10 = distinct !{!10, !8, !"multiply_add_fusion_wrapped: argument 1"}
!11 = !{!12}
!12 = distinct !{!12, !8, !"multiply_add_fusion_wrapped: argument 2"}
!13 = !{!14}
!14 = distinct !{!14, !8, !"multiply_add_fusion_wrapped: argument 3"}
!15 = !{!16}
!16 = distinct !{!16, !8, !"multiply_add_fusion_wrapped: argument 4"}
!17 = !{!18}
!18 = distinct !{!18, !8, !"multiply_add_fusion_wrapped: argument 5"}
!19 = !{!7, !10, !14, !16, !18}
!20 = !{!7, !10, !12, !14, !18}
!21 = !{!7, !10, !12, !16, !18}
!22 = !{!7, !12, !14, !16, !18}
!23 = !{!10, !12, !14, !16, !18}
!24 = !{!7, !10, !12, !14, !16}
!25 = distinct !{!25, !26, !27}
!26 = !{!"llvm.loop.isvectorized", i32 1}
!27 = !{!"llvm.loop.unroll.runtime.disable"}
!28 = distinct !{!28, !29}
!29 = !{!"llvm.loop.unroll.disable"}
