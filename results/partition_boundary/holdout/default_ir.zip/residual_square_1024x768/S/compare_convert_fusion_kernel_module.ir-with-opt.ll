; ModuleID = '__compute_module_compare_convert_fusion_kernel_module'
source_filename = "__compute_module_compare_convert_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @compare_convert_fusion(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !4
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !5
  %9 = getelementptr inbounds nuw i8, ptr %3, i64 48
  %10 = load ptr, ptr %9, align 8, !invariant.load !3, !dereferenceable !4
  %11 = getelementptr inbounds nuw i8, ptr %3, i64 64
  %12 = load ptr, ptr %11, align 8, !invariant.load !3, !dereferenceable !4
  %13 = getelementptr inbounds nuw i8, ptr %3, i64 80
  %14 = load ptr, ptr %13, align 8, !invariant.load !3, !dereferenceable !5
  %15 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %16 = load ptr, ptr %15, align 8
  %17 = load i64, ptr %16, align 4, !invariant.load !3
  tail call void @llvm.experimental.noalias.scope.decl(metadata !6)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !11)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !13)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !15)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !17)
  %18 = icmp slt i64 %17, 11
  br i1 %18, label %19, label %79

19:                                               ; preds = %1
  %20 = icmp sgt i64 %17, -1
  br i1 %20, label %21, label %compare_convert_fusion_wrapped.exit

21:                                               ; preds = %19
  %22 = mul nuw nsw i64 %17, 66048
  br label %vector.ph18

vector.ph18:                                      ; preds = %21, %middle.block27
  %23 = phi i64 [ 0, %21 ], [ %78, %middle.block27 ]
  %24 = mul nuw nsw i64 %23, 768
  %25 = add nuw nsw i64 %24, %22
  br label %vector.body19

vector.body19:                                    ; preds = %vector.body19, %vector.ph18
  %index20 = phi i64 [ 0, %vector.ph18 ], [ %index.next26.2, %vector.body19 ]
  %26 = getelementptr inbounds nuw float, ptr %12, i64 %index20
  %wide.load21 = load <8 x float>, ptr %26, align 4, !invariant.load !3, !alias.scope !15, !noalias !19
  %27 = add nuw nsw i64 %25, %index20
  %28 = getelementptr inbounds nuw float, ptr %8, i64 %27
  %wide.load22 = load <8 x float>, ptr %28, align 4, !invariant.load !3, !alias.scope !11, !noalias !20
  %29 = fmul <8 x float> %wide.load21, %wide.load22
  %30 = getelementptr inbounds nuw float, ptr %10, i64 %index20
  %wide.load23 = load <8 x float>, ptr %30, align 4, !invariant.load !3, !alias.scope !13, !noalias !21
  %31 = fadd <8 x float> %29, %wide.load23
  %32 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %31, <8 x float> zeroinitializer)
  %33 = fmul <8 x float> %wide.load22, splat (float 2.500000e-01)
  %34 = fadd <8 x float> %33, %32
  %35 = fmul <8 x float> %34, %34
  %36 = getelementptr inbounds nuw float, ptr %6, i64 %index20
  %wide.load24 = load <8 x float>, ptr %36, align 4, !invariant.load !3, !alias.scope !9, !noalias !22
  %37 = fmul <8 x float> %wide.load24, %35
  %38 = getelementptr inbounds nuw float, ptr %4, i64 %index20
  %wide.load25 = load <8 x float>, ptr %38, align 4, !invariant.load !3, !alias.scope !6, !noalias !23
  %39 = fadd <8 x float> %wide.load25, %37
  %40 = fcmp ogt <8 x float> %39, zeroinitializer
  %41 = zext <8 x i1> %40 to <8 x i32>
  %42 = getelementptr inbounds nuw i32, ptr %14, i64 %27
  store <8 x i32> %41, ptr %42, align 4, !alias.scope !17, !noalias !24
  %index.next26 = add nuw nsw i64 %index20, 8
  %43 = getelementptr inbounds nuw float, ptr %12, i64 %index.next26
  %wide.load21.1 = load <8 x float>, ptr %43, align 4, !invariant.load !3, !alias.scope !15, !noalias !19
  %44 = add nuw nsw i64 %25, %index.next26
  %45 = getelementptr inbounds nuw float, ptr %8, i64 %44
  %wide.load22.1 = load <8 x float>, ptr %45, align 4, !invariant.load !3, !alias.scope !11, !noalias !20
  %46 = fmul <8 x float> %wide.load21.1, %wide.load22.1
  %47 = getelementptr inbounds nuw float, ptr %10, i64 %index.next26
  %wide.load23.1 = load <8 x float>, ptr %47, align 4, !invariant.load !3, !alias.scope !13, !noalias !21
  %48 = fadd <8 x float> %46, %wide.load23.1
  %49 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %48, <8 x float> zeroinitializer)
  %50 = fmul <8 x float> %wide.load22.1, splat (float 2.500000e-01)
  %51 = fadd <8 x float> %50, %49
  %52 = fmul <8 x float> %51, %51
  %53 = getelementptr inbounds nuw float, ptr %6, i64 %index.next26
  %wide.load24.1 = load <8 x float>, ptr %53, align 4, !invariant.load !3, !alias.scope !9, !noalias !22
  %54 = fmul <8 x float> %wide.load24.1, %52
  %55 = getelementptr inbounds nuw float, ptr %4, i64 %index.next26
  %wide.load25.1 = load <8 x float>, ptr %55, align 4, !invariant.load !3, !alias.scope !6, !noalias !23
  %56 = fadd <8 x float> %wide.load25.1, %54
  %57 = fcmp ogt <8 x float> %56, zeroinitializer
  %58 = zext <8 x i1> %57 to <8 x i32>
  %59 = getelementptr inbounds nuw i32, ptr %14, i64 %44
  store <8 x i32> %58, ptr %59, align 4, !alias.scope !17, !noalias !24
  %index.next26.1 = add nuw nsw i64 %index20, 16
  %60 = getelementptr inbounds nuw float, ptr %12, i64 %index.next26.1
  %wide.load21.2 = load <8 x float>, ptr %60, align 4, !invariant.load !3, !alias.scope !15, !noalias !19
  %61 = add nuw nsw i64 %25, %index.next26.1
  %62 = getelementptr inbounds nuw float, ptr %8, i64 %61
  %wide.load22.2 = load <8 x float>, ptr %62, align 4, !invariant.load !3, !alias.scope !11, !noalias !20
  %63 = fmul <8 x float> %wide.load21.2, %wide.load22.2
  %64 = getelementptr inbounds nuw float, ptr %10, i64 %index.next26.1
  %wide.load23.2 = load <8 x float>, ptr %64, align 4, !invariant.load !3, !alias.scope !13, !noalias !21
  %65 = fadd <8 x float> %63, %wide.load23.2
  %66 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %65, <8 x float> zeroinitializer)
  %67 = fmul <8 x float> %wide.load22.2, splat (float 2.500000e-01)
  %68 = fadd <8 x float> %67, %66
  %69 = fmul <8 x float> %68, %68
  %70 = getelementptr inbounds nuw float, ptr %6, i64 %index.next26.1
  %wide.load24.2 = load <8 x float>, ptr %70, align 4, !invariant.load !3, !alias.scope !9, !noalias !22
  %71 = fmul <8 x float> %wide.load24.2, %69
  %72 = getelementptr inbounds nuw float, ptr %4, i64 %index.next26.1
  %wide.load25.2 = load <8 x float>, ptr %72, align 4, !invariant.load !3, !alias.scope !6, !noalias !23
  %73 = fadd <8 x float> %wide.load25.2, %71
  %74 = fcmp ogt <8 x float> %73, zeroinitializer
  %75 = zext <8 x i1> %74 to <8 x i32>
  %76 = getelementptr inbounds nuw i32, ptr %14, i64 %61
  store <8 x i32> %75, ptr %76, align 4, !alias.scope !17, !noalias !24
  %index.next26.2 = add nuw nsw i64 %index20, 24
  %77 = icmp eq i64 %index.next26.2, 768
  br i1 %77, label %middle.block27, label %vector.body19, !llvm.loop !25

middle.block27:                                   ; preds = %vector.body19
  %78 = add nuw nsw i64 %23, 1
  %exitcond9.not = icmp eq i64 %78, 86
  br i1 %exitcond9.not, label %compare_convert_fusion_wrapped.exit, label %vector.ph18, !llvm.loop !28

79:                                               ; preds = %1
  %80 = icmp eq i64 %17, 11
  br i1 %80, label %.preheader, label %compare_convert_fusion_wrapped.exit

.preheader:                                       ; preds = %79, %middle.block
  %81 = phi i64 [ %136, %middle.block ], [ 0, %79 ]
  %82 = mul nuw nsw i64 %81, 768
  %83 = add nuw nsw i64 %82, 726528
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %.preheader
  %index = phi i64 [ 0, %.preheader ], [ %index.next.2, %vector.body ]
  %84 = getelementptr inbounds nuw float, ptr %12, i64 %index
  %wide.load = load <8 x float>, ptr %84, align 4, !invariant.load !3, !alias.scope !15, !noalias !19
  %85 = add nuw nsw i64 %83, %index
  %86 = getelementptr inbounds nuw float, ptr %8, i64 %85
  %wide.load14 = load <8 x float>, ptr %86, align 4, !invariant.load !3, !alias.scope !11, !noalias !20
  %87 = fmul <8 x float> %wide.load, %wide.load14
  %88 = getelementptr inbounds nuw float, ptr %10, i64 %index
  %wide.load15 = load <8 x float>, ptr %88, align 4, !invariant.load !3, !alias.scope !13, !noalias !21
  %89 = fadd <8 x float> %87, %wide.load15
  %90 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %89, <8 x float> zeroinitializer)
  %91 = fmul <8 x float> %wide.load14, splat (float 2.500000e-01)
  %92 = fadd <8 x float> %91, %90
  %93 = fmul <8 x float> %92, %92
  %94 = getelementptr inbounds nuw float, ptr %6, i64 %index
  %wide.load16 = load <8 x float>, ptr %94, align 4, !invariant.load !3, !alias.scope !9, !noalias !22
  %95 = fmul <8 x float> %wide.load16, %93
  %96 = getelementptr inbounds nuw float, ptr %4, i64 %index
  %wide.load17 = load <8 x float>, ptr %96, align 4, !invariant.load !3, !alias.scope !6, !noalias !23
  %97 = fadd <8 x float> %wide.load17, %95
  %98 = fcmp ogt <8 x float> %97, zeroinitializer
  %99 = zext <8 x i1> %98 to <8 x i32>
  %100 = getelementptr inbounds nuw i32, ptr %14, i64 %85
  store <8 x i32> %99, ptr %100, align 4, !alias.scope !17, !noalias !24
  %index.next = add nuw nsw i64 %index, 8
  %101 = getelementptr inbounds nuw float, ptr %12, i64 %index.next
  %wide.load.1 = load <8 x float>, ptr %101, align 4, !invariant.load !3, !alias.scope !15, !noalias !19
  %102 = add nuw nsw i64 %83, %index.next
  %103 = getelementptr inbounds nuw float, ptr %8, i64 %102
  %wide.load14.1 = load <8 x float>, ptr %103, align 4, !invariant.load !3, !alias.scope !11, !noalias !20
  %104 = fmul <8 x float> %wide.load.1, %wide.load14.1
  %105 = getelementptr inbounds nuw float, ptr %10, i64 %index.next
  %wide.load15.1 = load <8 x float>, ptr %105, align 4, !invariant.load !3, !alias.scope !13, !noalias !21
  %106 = fadd <8 x float> %104, %wide.load15.1
  %107 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %106, <8 x float> zeroinitializer)
  %108 = fmul <8 x float> %wide.load14.1, splat (float 2.500000e-01)
  %109 = fadd <8 x float> %108, %107
  %110 = fmul <8 x float> %109, %109
  %111 = getelementptr inbounds nuw float, ptr %6, i64 %index.next
  %wide.load16.1 = load <8 x float>, ptr %111, align 4, !invariant.load !3, !alias.scope !9, !noalias !22
  %112 = fmul <8 x float> %wide.load16.1, %110
  %113 = getelementptr inbounds nuw float, ptr %4, i64 %index.next
  %wide.load17.1 = load <8 x float>, ptr %113, align 4, !invariant.load !3, !alias.scope !6, !noalias !23
  %114 = fadd <8 x float> %wide.load17.1, %112
  %115 = fcmp ogt <8 x float> %114, zeroinitializer
  %116 = zext <8 x i1> %115 to <8 x i32>
  %117 = getelementptr inbounds nuw i32, ptr %14, i64 %102
  store <8 x i32> %116, ptr %117, align 4, !alias.scope !17, !noalias !24
  %index.next.1 = add nuw nsw i64 %index, 16
  %118 = getelementptr inbounds nuw float, ptr %12, i64 %index.next.1
  %wide.load.2 = load <8 x float>, ptr %118, align 4, !invariant.load !3, !alias.scope !15, !noalias !19
  %119 = add nuw nsw i64 %83, %index.next.1
  %120 = getelementptr inbounds nuw float, ptr %8, i64 %119
  %wide.load14.2 = load <8 x float>, ptr %120, align 4, !invariant.load !3, !alias.scope !11, !noalias !20
  %121 = fmul <8 x float> %wide.load.2, %wide.load14.2
  %122 = getelementptr inbounds nuw float, ptr %10, i64 %index.next.1
  %wide.load15.2 = load <8 x float>, ptr %122, align 4, !invariant.load !3, !alias.scope !13, !noalias !21
  %123 = fadd <8 x float> %121, %wide.load15.2
  %124 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %123, <8 x float> zeroinitializer)
  %125 = fmul <8 x float> %wide.load14.2, splat (float 2.500000e-01)
  %126 = fadd <8 x float> %125, %124
  %127 = fmul <8 x float> %126, %126
  %128 = getelementptr inbounds nuw float, ptr %6, i64 %index.next.1
  %wide.load16.2 = load <8 x float>, ptr %128, align 4, !invariant.load !3, !alias.scope !9, !noalias !22
  %129 = fmul <8 x float> %wide.load16.2, %127
  %130 = getelementptr inbounds nuw float, ptr %4, i64 %index.next.1
  %wide.load17.2 = load <8 x float>, ptr %130, align 4, !invariant.load !3, !alias.scope !6, !noalias !23
  %131 = fadd <8 x float> %wide.load17.2, %129
  %132 = fcmp ogt <8 x float> %131, zeroinitializer
  %133 = zext <8 x i1> %132 to <8 x i32>
  %134 = getelementptr inbounds nuw i32, ptr %14, i64 %119
  store <8 x i32> %133, ptr %134, align 4, !alias.scope !17, !noalias !24
  %index.next.2 = add nuw nsw i64 %index, 24
  %135 = icmp eq i64 %index.next.2, 768
  br i1 %135, label %middle.block, label %vector.body, !llvm.loop !30

middle.block:                                     ; preds = %vector.body
  %136 = add nuw nsw i64 %81, 1
  %exitcond7.not = icmp eq i64 %136, 78
  br i1 %exitcond7.not, label %compare_convert_fusion_wrapped.exit, label %.preheader, !llvm.loop !28

compare_convert_fusion_wrapped.exit:              ; preds = %middle.block, %middle.block27, %19, %79
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.maximum.v8f32(<8 x float>, <8 x float>) #2

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 0}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 3072}
!5 = !{i64 3145728}
!6 = !{!7}
!7 = distinct !{!7, !8, !"compare_convert_fusion_wrapped: argument 0"}
!8 = distinct !{!8, !"compare_convert_fusion_wrapped"}
!9 = !{!10}
!10 = distinct !{!10, !8, !"compare_convert_fusion_wrapped: argument 1"}
!11 = !{!12}
!12 = distinct !{!12, !8, !"compare_convert_fusion_wrapped: argument 2"}
!13 = !{!14}
!14 = distinct !{!14, !8, !"compare_convert_fusion_wrapped: argument 3"}
!15 = !{!16}
!16 = distinct !{!16, !8, !"compare_convert_fusion_wrapped: argument 4"}
!17 = !{!18}
!18 = distinct !{!18, !8, !"compare_convert_fusion_wrapped: argument 5"}
!19 = !{!7, !10, !12, !14, !18}
!20 = !{!7, !10, !14, !16, !18}
!21 = !{!7, !10, !12, !16, !18}
!22 = !{!7, !12, !14, !16, !18}
!23 = !{!10, !12, !14, !16, !18}
!24 = !{!7, !10, !12, !14, !16}
!25 = distinct !{!25, !26, !27}
!26 = !{!"llvm.loop.isvectorized", i32 1}
!27 = !{!"llvm.loop.unroll.runtime.disable"}
!28 = distinct !{!28, !29}
!29 = !{!"llvm.loop.unroll.disable"}
!30 = distinct !{!30, !26, !27}
