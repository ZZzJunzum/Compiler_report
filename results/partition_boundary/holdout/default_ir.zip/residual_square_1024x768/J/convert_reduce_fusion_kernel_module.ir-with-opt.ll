; ModuleID = '__compute_module_convert_reduce_fusion_kernel_module'
source_filename = "__compute_module_convert_reduce_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @convert_reduce_fusion(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !4
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !5
  %9 = getelementptr inbounds nuw i8, ptr %3, i64 48
  %10 = load ptr, ptr %9, align 8, !invariant.load !3, !dereferenceable !4
  %11 = getelementptr inbounds nuw i8, ptr %3, i64 64
  %12 = load ptr, ptr %11, align 8, !invariant.load !3, !dereferenceable !4
  %13 = getelementptr inbounds nuw i8, ptr %3, i64 80
  %14 = load ptr, ptr %13, align 8, !invariant.load !3, !dereferenceable !6
  %15 = getelementptr inbounds nuw i8, ptr %3, i64 96
  %16 = load ptr, ptr %15, align 8, !invariant.load !3, !dereferenceable !6
  %17 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %18 = load ptr, ptr %17, align 8
  %19 = load i64, ptr %18, align 4, !invariant.load !3
  tail call void @llvm.experimental.noalias.scope.decl(metadata !7)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !10)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !12)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !14)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !16)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !18)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !20)
  %20 = icmp slt i64 %19, 11
  br i1 %20, label %21, label %73

21:                                               ; preds = %1
  %22 = icmp sgt i64 %19, -1
  br i1 %22, label %23, label %convert_reduce_fusion_wrapped.exit

23:                                               ; preds = %21
  %24 = mul nuw nsw i64 %19, 86
  %.idx1 = mul nuw nsw i64 %19, 264192
  %25 = getelementptr i8, ptr %8, i64 %.idx1
  br label %vector.ph41

vector.ph41:                                      ; preds = %23, %middle.block59
  %26 = phi i64 [ 0, %23 ], [ %72, %middle.block59 ]
  %.idx2 = mul nuw nsw i64 %26, 3072
  %27 = getelementptr i8, ptr %25, i64 %.idx2
  br label %vector.body42

vector.body42:                                    ; preds = %vector.body42, %vector.ph41
  %index43 = phi i64 [ 0, %vector.ph41 ], [ %index.next58, %vector.body42 ]
  %vec.phi44 = phi <8 x i32> [ zeroinitializer, %vector.ph41 ], [ %64, %vector.body42 ]
  %vec.phi45 = phi <8 x i32> [ zeroinitializer, %vector.ph41 ], [ %65, %vector.body42 ]
  %vec.phi46 = phi <8 x i32> [ zeroinitializer, %vector.ph41 ], [ %62, %vector.body42 ]
  %vec.phi47 = phi <8 x i32> [ zeroinitializer, %vector.ph41 ], [ %63, %vector.body42 ]
  %28 = getelementptr float, ptr %27, i64 %index43
  %29 = getelementptr i8, ptr %28, i64 32
  %wide.load48 = load <8 x float>, ptr %28, align 4, !invariant.load !3, !alias.scope !12, !noalias !22
  %wide.load49 = load <8 x float>, ptr %29, align 4, !invariant.load !3, !alias.scope !12, !noalias !22
  %30 = getelementptr inbounds nuw float, ptr %12, i64 %index43
  %31 = getelementptr inbounds nuw i8, ptr %30, i64 32
  %wide.load50 = load <8 x float>, ptr %30, align 4, !invariant.load !3, !alias.scope !16, !noalias !23
  %wide.load51 = load <8 x float>, ptr %31, align 4, !invariant.load !3, !alias.scope !16, !noalias !23
  %32 = fmul <8 x float> %wide.load48, %wide.load50
  %33 = fmul <8 x float> %wide.load49, %wide.load51
  %34 = getelementptr inbounds nuw float, ptr %10, i64 %index43
  %35 = getelementptr inbounds nuw i8, ptr %34, i64 32
  %wide.load52 = load <8 x float>, ptr %34, align 4, !invariant.load !3, !alias.scope !14, !noalias !24
  %wide.load53 = load <8 x float>, ptr %35, align 4, !invariant.load !3, !alias.scope !14, !noalias !24
  %36 = fadd <8 x float> %32, %wide.load52
  %37 = fadd <8 x float> %33, %wide.load53
  %38 = fcmp ogt <8 x float> %36, zeroinitializer
  %39 = fcmp ogt <8 x float> %37, zeroinitializer
  %40 = zext <8 x i1> %38 to <8 x i32>
  %41 = zext <8 x i1> %39 to <8 x i32>
  %42 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %36, <8 x float> zeroinitializer)
  %43 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %37, <8 x float> zeroinitializer)
  %44 = fmul <8 x float> %wide.load48, splat (float 2.500000e-01)
  %45 = fmul <8 x float> %wide.load49, splat (float 2.500000e-01)
  %46 = fadd <8 x float> %44, %42
  %47 = fadd <8 x float> %45, %43
  %48 = fmul <8 x float> %46, %46
  %49 = fmul <8 x float> %47, %47
  %50 = getelementptr inbounds nuw float, ptr %6, i64 %index43
  %51 = getelementptr inbounds nuw i8, ptr %50, i64 32
  %wide.load54 = load <8 x float>, ptr %50, align 4, !invariant.load !3, !alias.scope !10, !noalias !25
  %wide.load55 = load <8 x float>, ptr %51, align 4, !invariant.load !3, !alias.scope !10, !noalias !25
  %52 = fmul <8 x float> %wide.load54, %48
  %53 = fmul <8 x float> %wide.load55, %49
  %54 = getelementptr inbounds nuw float, ptr %4, i64 %index43
  %55 = getelementptr inbounds nuw i8, ptr %54, i64 32
  %wide.load56 = load <8 x float>, ptr %54, align 4, !invariant.load !3, !alias.scope !7, !noalias !26
  %wide.load57 = load <8 x float>, ptr %55, align 4, !invariant.load !3, !alias.scope !7, !noalias !26
  %56 = fadd <8 x float> %wide.load56, %52
  %57 = fadd <8 x float> %wide.load57, %53
  %58 = fcmp ogt <8 x float> %56, zeroinitializer
  %59 = fcmp ogt <8 x float> %57, zeroinitializer
  %60 = zext <8 x i1> %58 to <8 x i32>
  %61 = zext <8 x i1> %59 to <8 x i32>
  %62 = add <8 x i32> %vec.phi46, %40
  %63 = add <8 x i32> %vec.phi47, %41
  %64 = add <8 x i32> %vec.phi44, %60
  %65 = add <8 x i32> %vec.phi45, %61
  %index.next58 = add nuw i64 %index43, 16
  %66 = icmp eq i64 %index.next58, 768
  br i1 %66, label %middle.block59, label %vector.body42, !llvm.loop !27

middle.block59:                                   ; preds = %vector.body42
  %bin.rdx61 = add <8 x i32> %63, %62
  %67 = tail call i32 @llvm.vector.reduce.add.v8i32(<8 x i32> %bin.rdx61)
  %bin.rdx60 = add <8 x i32> %65, %64
  %68 = tail call i32 @llvm.vector.reduce.add.v8i32(<8 x i32> %bin.rdx60)
  %69 = add nuw nsw i64 %26, %24
  %70 = getelementptr inbounds nuw i32, ptr %14, i64 %69
  store i32 %67, ptr %70, align 4, !alias.scope !18, !noalias !30
  %71 = getelementptr inbounds nuw i32, ptr %16, i64 %69
  store i32 %68, ptr %71, align 4, !alias.scope !20, !noalias !31
  %72 = add nuw nsw i64 %26, 1
  %exitcond17.not = icmp eq i64 %72, 86
  br i1 %exitcond17.not, label %convert_reduce_fusion_wrapped.exit, label %vector.ph41, !llvm.loop !32

73:                                               ; preds = %1
  %74 = icmp eq i64 %19, 11
  br i1 %74, label %.preheader, label %convert_reduce_fusion_wrapped.exit

.preheader:                                       ; preds = %73, %middle.block
  %75 = phi i64 [ %122, %middle.block ], [ 0, %73 ]
  %.idx = mul nuw nsw i64 %75, 3072
  %76 = getelementptr i8, ptr %8, i64 %.idx
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %.preheader
  %index = phi i64 [ 0, %.preheader ], [ %index.next, %vector.body ]
  %vec.phi = phi <8 x i32> [ zeroinitializer, %.preheader ], [ %114, %vector.body ]
  %vec.phi28 = phi <8 x i32> [ zeroinitializer, %.preheader ], [ %115, %vector.body ]
  %vec.phi29 = phi <8 x i32> [ zeroinitializer, %.preheader ], [ %112, %vector.body ]
  %vec.phi30 = phi <8 x i32> [ zeroinitializer, %.preheader ], [ %113, %vector.body ]
  %77 = getelementptr float, ptr %76, i64 %index
  %78 = getelementptr i8, ptr %77, i64 2906112
  %79 = getelementptr i8, ptr %77, i64 2906144
  %wide.load = load <8 x float>, ptr %78, align 4, !invariant.load !3, !alias.scope !12, !noalias !22
  %wide.load31 = load <8 x float>, ptr %79, align 4, !invariant.load !3, !alias.scope !12, !noalias !22
  %80 = getelementptr inbounds nuw float, ptr %12, i64 %index
  %81 = getelementptr inbounds nuw i8, ptr %80, i64 32
  %wide.load32 = load <8 x float>, ptr %80, align 4, !invariant.load !3, !alias.scope !16, !noalias !23
  %wide.load33 = load <8 x float>, ptr %81, align 4, !invariant.load !3, !alias.scope !16, !noalias !23
  %82 = fmul <8 x float> %wide.load, %wide.load32
  %83 = fmul <8 x float> %wide.load31, %wide.load33
  %84 = getelementptr inbounds nuw float, ptr %10, i64 %index
  %85 = getelementptr inbounds nuw i8, ptr %84, i64 32
  %wide.load34 = load <8 x float>, ptr %84, align 4, !invariant.load !3, !alias.scope !14, !noalias !24
  %wide.load35 = load <8 x float>, ptr %85, align 4, !invariant.load !3, !alias.scope !14, !noalias !24
  %86 = fadd <8 x float> %82, %wide.load34
  %87 = fadd <8 x float> %83, %wide.load35
  %88 = fcmp ogt <8 x float> %86, zeroinitializer
  %89 = fcmp ogt <8 x float> %87, zeroinitializer
  %90 = zext <8 x i1> %88 to <8 x i32>
  %91 = zext <8 x i1> %89 to <8 x i32>
  %92 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %86, <8 x float> zeroinitializer)
  %93 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %87, <8 x float> zeroinitializer)
  %94 = fmul <8 x float> %wide.load, splat (float 2.500000e-01)
  %95 = fmul <8 x float> %wide.load31, splat (float 2.500000e-01)
  %96 = fadd <8 x float> %94, %92
  %97 = fadd <8 x float> %95, %93
  %98 = fmul <8 x float> %96, %96
  %99 = fmul <8 x float> %97, %97
  %100 = getelementptr inbounds nuw float, ptr %6, i64 %index
  %101 = getelementptr inbounds nuw i8, ptr %100, i64 32
  %wide.load36 = load <8 x float>, ptr %100, align 4, !invariant.load !3, !alias.scope !10, !noalias !25
  %wide.load37 = load <8 x float>, ptr %101, align 4, !invariant.load !3, !alias.scope !10, !noalias !25
  %102 = fmul <8 x float> %wide.load36, %98
  %103 = fmul <8 x float> %wide.load37, %99
  %104 = getelementptr inbounds nuw float, ptr %4, i64 %index
  %105 = getelementptr inbounds nuw i8, ptr %104, i64 32
  %wide.load38 = load <8 x float>, ptr %104, align 4, !invariant.load !3, !alias.scope !7, !noalias !26
  %wide.load39 = load <8 x float>, ptr %105, align 4, !invariant.load !3, !alias.scope !7, !noalias !26
  %106 = fadd <8 x float> %wide.load38, %102
  %107 = fadd <8 x float> %wide.load39, %103
  %108 = fcmp ogt <8 x float> %106, zeroinitializer
  %109 = fcmp ogt <8 x float> %107, zeroinitializer
  %110 = zext <8 x i1> %108 to <8 x i32>
  %111 = zext <8 x i1> %109 to <8 x i32>
  %112 = add <8 x i32> %vec.phi29, %90
  %113 = add <8 x i32> %vec.phi30, %91
  %114 = add <8 x i32> %vec.phi, %110
  %115 = add <8 x i32> %vec.phi28, %111
  %index.next = add nuw i64 %index, 16
  %116 = icmp eq i64 %index.next, 768
  br i1 %116, label %middle.block, label %vector.body, !llvm.loop !34

middle.block:                                     ; preds = %vector.body
  %bin.rdx40 = add <8 x i32> %113, %112
  %117 = tail call i32 @llvm.vector.reduce.add.v8i32(<8 x i32> %bin.rdx40)
  %bin.rdx = add <8 x i32> %115, %114
  %118 = tail call i32 @llvm.vector.reduce.add.v8i32(<8 x i32> %bin.rdx)
  %119 = add nuw nsw i64 %75, 946
  %120 = getelementptr inbounds nuw i32, ptr %14, i64 %119
  store i32 %117, ptr %120, align 4, !alias.scope !18, !noalias !30
  %121 = getelementptr inbounds nuw i32, ptr %16, i64 %119
  store i32 %118, ptr %121, align 4, !alias.scope !20, !noalias !31
  %122 = add nuw nsw i64 %75, 1
  %exitcond15.not = icmp eq i64 %122, 78
  br i1 %exitcond15.not, label %convert_reduce_fusion_wrapped.exit, label %.preheader, !llvm.loop !32

convert_reduce_fusion_wrapped.exit:               ; preds = %middle.block, %middle.block59, %21, %73
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.maximum.v8f32(<8 x float>, <8 x float>) #2

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.vector.reduce.add.v8i32(<8 x i32>) #3

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #3 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 0}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 3072}
!5 = !{i64 3145728}
!6 = !{i64 4096}
!7 = !{!8}
!8 = distinct !{!8, !9, !"convert_reduce_fusion_wrapped: argument 0"}
!9 = distinct !{!9, !"convert_reduce_fusion_wrapped"}
!10 = !{!11}
!11 = distinct !{!11, !9, !"convert_reduce_fusion_wrapped: argument 1"}
!12 = !{!13}
!13 = distinct !{!13, !9, !"convert_reduce_fusion_wrapped: argument 2"}
!14 = !{!15}
!15 = distinct !{!15, !9, !"convert_reduce_fusion_wrapped: argument 3"}
!16 = !{!17}
!17 = distinct !{!17, !9, !"convert_reduce_fusion_wrapped: argument 4"}
!18 = !{!19}
!19 = distinct !{!19, !9, !"convert_reduce_fusion_wrapped: argument 5"}
!20 = !{!21}
!21 = distinct !{!21, !9, !"convert_reduce_fusion_wrapped: argument 6"}
!22 = !{!8, !11, !15, !17, !19, !21}
!23 = !{!8, !11, !13, !15, !19, !21}
!24 = !{!8, !11, !13, !17, !19, !21}
!25 = !{!8, !13, !15, !17, !19, !21}
!26 = !{!11, !13, !15, !17, !19, !21}
!27 = distinct !{!27, !28, !29}
!28 = !{!"llvm.loop.isvectorized", i32 1}
!29 = !{!"llvm.loop.unroll.runtime.disable"}
!30 = !{!8, !11, !13, !15, !17, !21}
!31 = !{!8, !11, !13, !15, !17, !19}
!32 = distinct !{!32, !33}
!33 = !{!"llvm.loop.unroll.disable"}
!34 = distinct !{!34, !28, !29}
