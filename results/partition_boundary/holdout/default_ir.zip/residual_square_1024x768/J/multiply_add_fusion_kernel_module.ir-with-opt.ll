; ModuleID = '__compute_module_multiply_add_fusion_kernel_module'
source_filename = "__compute_module_multiply_add_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @multiply_add_fusion(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !4
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !5
  %9 = getelementptr inbounds nuw i8, ptr %3, i64 48
  %10 = load ptr, ptr %9, align 8, !invariant.load !3, !dereferenceable !4
  %11 = getelementptr inbounds nuw i8, ptr %3, i64 64
  %12 = load ptr, ptr %11, align 8, !invariant.load !3, !dereferenceable !4
  %13 = getelementptr inbounds nuw i8, ptr %3, i64 80
  %14 = load ptr, ptr %13, align 8, !invariant.load !3, !dereferenceable !5
  %15 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %16 = load ptr, ptr %15, align 8
  %17 = load i64, ptr %16, align 4, !invariant.load !3
  tail call void @llvm.experimental.noalias.scope.decl(metadata !6)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !11)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !13)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !15)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !17)
  %18 = icmp slt i64 %17, 11
  br i1 %18, label %19, label %82

19:                                               ; preds = %1
  %20 = icmp sgt i64 %17, -1
  br i1 %20, label %21, label %multiply_add_fusion_wrapped.exit

21:                                               ; preds = %19
  %22 = mul nuw nsw i64 %17, 66048
  br label %vector.ph18

vector.ph18:                                      ; preds = %21, %middle.block27
  %23 = phi i64 [ 0, %21 ], [ %81, %middle.block27 ]
  %24 = mul nuw nsw i64 %23, 768
  %25 = add nuw nsw i64 %24, %22
  br label %vector.body19

vector.body19:                                    ; preds = %vector.body19, %vector.ph18
  %index20 = phi i64 [ 0, %vector.ph18 ], [ %index.next26.2, %vector.body19 ]
  %26 = add nuw nsw i64 %25, %index20
  %27 = getelementptr inbounds nuw float, ptr %8, i64 %26
  %wide.load21 = load <8 x float>, ptr %27, align 4, !invariant.load !3, !alias.scope !11, !noalias !19
  %28 = getelementptr inbounds nuw float, ptr %12, i64 %index20
  %wide.load22 = load <8 x float>, ptr %28, align 4, !invariant.load !3, !alias.scope !15, !noalias !20
  %29 = fmul <8 x float> %wide.load21, %wide.load22
  %30 = getelementptr inbounds nuw float, ptr %10, i64 %index20
  %wide.load23 = load <8 x float>, ptr %30, align 4, !invariant.load !3, !alias.scope !13, !noalias !21
  %31 = fadd <8 x float> %29, %wide.load23
  %32 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %31, <8 x float> zeroinitializer)
  %33 = fmul <8 x float> %wide.load21, splat (float 2.500000e-01)
  %34 = fadd <8 x float> %33, %32
  %35 = fmul <8 x float> %34, %34
  %36 = getelementptr inbounds nuw float, ptr %6, i64 %index20
  %wide.load24 = load <8 x float>, ptr %36, align 4, !invariant.load !3, !alias.scope !9, !noalias !22
  %37 = fmul <8 x float> %wide.load24, %35
  %38 = getelementptr inbounds nuw float, ptr %4, i64 %index20
  %wide.load25 = load <8 x float>, ptr %38, align 4, !invariant.load !3, !alias.scope !6, !noalias !23
  %39 = fadd <8 x float> %wide.load25, %37
  %40 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %39, <8 x float> zeroinitializer)
  %41 = fmul <8 x float> %31, splat (float 1.250000e-01)
  %42 = fadd <8 x float> %41, %40
  %43 = getelementptr inbounds nuw float, ptr %14, i64 %26
  store <8 x float> %42, ptr %43, align 4, !alias.scope !17, !noalias !24
  %index.next26 = add nuw nsw i64 %index20, 8
  %44 = add nuw nsw i64 %25, %index.next26
  %45 = getelementptr inbounds nuw float, ptr %8, i64 %44
  %wide.load21.1 = load <8 x float>, ptr %45, align 4, !invariant.load !3, !alias.scope !11, !noalias !19
  %46 = getelementptr inbounds nuw float, ptr %12, i64 %index.next26
  %wide.load22.1 = load <8 x float>, ptr %46, align 4, !invariant.load !3, !alias.scope !15, !noalias !20
  %47 = fmul <8 x float> %wide.load21.1, %wide.load22.1
  %48 = getelementptr inbounds nuw float, ptr %10, i64 %index.next26
  %wide.load23.1 = load <8 x float>, ptr %48, align 4, !invariant.load !3, !alias.scope !13, !noalias !21
  %49 = fadd <8 x float> %47, %wide.load23.1
  %50 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %49, <8 x float> zeroinitializer)
  %51 = fmul <8 x float> %wide.load21.1, splat (float 2.500000e-01)
  %52 = fadd <8 x float> %51, %50
  %53 = fmul <8 x float> %52, %52
  %54 = getelementptr inbounds nuw float, ptr %6, i64 %index.next26
  %wide.load24.1 = load <8 x float>, ptr %54, align 4, !invariant.load !3, !alias.scope !9, !noalias !22
  %55 = fmul <8 x float> %wide.load24.1, %53
  %56 = getelementptr inbounds nuw float, ptr %4, i64 %index.next26
  %wide.load25.1 = load <8 x float>, ptr %56, align 4, !invariant.load !3, !alias.scope !6, !noalias !23
  %57 = fadd <8 x float> %wide.load25.1, %55
  %58 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %57, <8 x float> zeroinitializer)
  %59 = fmul <8 x float> %49, splat (float 1.250000e-01)
  %60 = fadd <8 x float> %59, %58
  %61 = getelementptr inbounds nuw float, ptr %14, i64 %44
  store <8 x float> %60, ptr %61, align 4, !alias.scope !17, !noalias !24
  %index.next26.1 = add nuw nsw i64 %index20, 16
  %62 = add nuw nsw i64 %25, %index.next26.1
  %63 = getelementptr inbounds nuw float, ptr %8, i64 %62
  %wide.load21.2 = load <8 x float>, ptr %63, align 4, !invariant.load !3, !alias.scope !11, !noalias !19
  %64 = getelementptr inbounds nuw float, ptr %12, i64 %index.next26.1
  %wide.load22.2 = load <8 x float>, ptr %64, align 4, !invariant.load !3, !alias.scope !15, !noalias !20
  %65 = fmul <8 x float> %wide.load21.2, %wide.load22.2
  %66 = getelementptr inbounds nuw float, ptr %10, i64 %index.next26.1
  %wide.load23.2 = load <8 x float>, ptr %66, align 4, !invariant.load !3, !alias.scope !13, !noalias !21
  %67 = fadd <8 x float> %65, %wide.load23.2
  %68 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %67, <8 x float> zeroinitializer)
  %69 = fmul <8 x float> %wide.load21.2, splat (float 2.500000e-01)
  %70 = fadd <8 x float> %69, %68
  %71 = fmul <8 x float> %70, %70
  %72 = getelementptr inbounds nuw float, ptr %6, i64 %index.next26.1
  %wide.load24.2 = load <8 x float>, ptr %72, align 4, !invariant.load !3, !alias.scope !9, !noalias !22
  %73 = fmul <8 x float> %wide.load24.2, %71
  %74 = getelementptr inbounds nuw float, ptr %4, i64 %index.next26.1
  %wide.load25.2 = load <8 x float>, ptr %74, align 4, !invariant.load !3, !alias.scope !6, !noalias !23
  %75 = fadd <8 x float> %wide.load25.2, %73
  %76 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %75, <8 x float> zeroinitializer)
  %77 = fmul <8 x float> %67, splat (float 1.250000e-01)
  %78 = fadd <8 x float> %77, %76
  %79 = getelementptr inbounds nuw float, ptr %14, i64 %62
  store <8 x float> %78, ptr %79, align 4, !alias.scope !17, !noalias !24
  %index.next26.2 = add nuw nsw i64 %index20, 24
  %80 = icmp eq i64 %index.next26.2, 768
  br i1 %80, label %middle.block27, label %vector.body19, !llvm.loop !25

middle.block27:                                   ; preds = %vector.body19
  %81 = add nuw nsw i64 %23, 1
  %exitcond9.not = icmp eq i64 %81, 86
  br i1 %exitcond9.not, label %multiply_add_fusion_wrapped.exit, label %vector.ph18, !llvm.loop !28

82:                                               ; preds = %1
  %83 = icmp eq i64 %17, 11
  br i1 %83, label %.preheader, label %multiply_add_fusion_wrapped.exit

.preheader:                                       ; preds = %82, %middle.block
  %84 = phi i64 [ %142, %middle.block ], [ 0, %82 ]
  %85 = mul nuw nsw i64 %84, 768
  %86 = add nuw nsw i64 %85, 726528
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %.preheader
  %index = phi i64 [ 0, %.preheader ], [ %index.next.2, %vector.body ]
  %87 = add nuw nsw i64 %86, %index
  %88 = getelementptr inbounds nuw float, ptr %8, i64 %87
  %wide.load = load <8 x float>, ptr %88, align 4, !invariant.load !3, !alias.scope !11, !noalias !19
  %89 = getelementptr inbounds nuw float, ptr %12, i64 %index
  %wide.load14 = load <8 x float>, ptr %89, align 4, !invariant.load !3, !alias.scope !15, !noalias !20
  %90 = fmul <8 x float> %wide.load, %wide.load14
  %91 = getelementptr inbounds nuw float, ptr %10, i64 %index
  %wide.load15 = load <8 x float>, ptr %91, align 4, !invariant.load !3, !alias.scope !13, !noalias !21
  %92 = fadd <8 x float> %90, %wide.load15
  %93 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %92, <8 x float> zeroinitializer)
  %94 = fmul <8 x float> %wide.load, splat (float 2.500000e-01)
  %95 = fadd <8 x float> %94, %93
  %96 = fmul <8 x float> %95, %95
  %97 = getelementptr inbounds nuw float, ptr %6, i64 %index
  %wide.load16 = load <8 x float>, ptr %97, align 4, !invariant.load !3, !alias.scope !9, !noalias !22
  %98 = fmul <8 x float> %wide.load16, %96
  %99 = getelementptr inbounds nuw float, ptr %4, i64 %index
  %wide.load17 = load <8 x float>, ptr %99, align 4, !invariant.load !3, !alias.scope !6, !noalias !23
  %100 = fadd <8 x float> %wide.load17, %98
  %101 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %100, <8 x float> zeroinitializer)
  %102 = fmul <8 x float> %92, splat (float 1.250000e-01)
  %103 = fadd <8 x float> %102, %101
  %104 = getelementptr inbounds nuw float, ptr %14, i64 %87
  store <8 x float> %103, ptr %104, align 4, !alias.scope !17, !noalias !24
  %index.next = add nuw nsw i64 %index, 8
  %105 = add nuw nsw i64 %86, %index.next
  %106 = getelementptr inbounds nuw float, ptr %8, i64 %105
  %wide.load.1 = load <8 x float>, ptr %106, align 4, !invariant.load !3, !alias.scope !11, !noalias !19
  %107 = getelementptr inbounds nuw float, ptr %12, i64 %index.next
  %wide.load14.1 = load <8 x float>, ptr %107, align 4, !invariant.load !3, !alias.scope !15, !noalias !20
  %108 = fmul <8 x float> %wide.load.1, %wide.load14.1
  %109 = getelementptr inbounds nuw float, ptr %10, i64 %index.next
  %wide.load15.1 = load <8 x float>, ptr %109, align 4, !invariant.load !3, !alias.scope !13, !noalias !21
  %110 = fadd <8 x float> %108, %wide.load15.1
  %111 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %110, <8 x float> zeroinitializer)
  %112 = fmul <8 x float> %wide.load.1, splat (float 2.500000e-01)
  %113 = fadd <8 x float> %112, %111
  %114 = fmul <8 x float> %113, %113
  %115 = getelementptr inbounds nuw float, ptr %6, i64 %index.next
  %wide.load16.1 = load <8 x float>, ptr %115, align 4, !invariant.load !3, !alias.scope !9, !noalias !22
  %116 = fmul <8 x float> %wide.load16.1, %114
  %117 = getelementptr inbounds nuw float, ptr %4, i64 %index.next
  %wide.load17.1 = load <8 x float>, ptr %117, align 4, !invariant.load !3, !alias.scope !6, !noalias !23
  %118 = fadd <8 x float> %wide.load17.1, %116
  %119 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %118, <8 x float> zeroinitializer)
  %120 = fmul <8 x float> %110, splat (float 1.250000e-01)
  %121 = fadd <8 x float> %120, %119
  %122 = getelementptr inbounds nuw float, ptr %14, i64 %105
  store <8 x float> %121, ptr %122, align 4, !alias.scope !17, !noalias !24
  %index.next.1 = add nuw nsw i64 %index, 16
  %123 = add nuw nsw i64 %86, %index.next.1
  %124 = getelementptr inbounds nuw float, ptr %8, i64 %123
  %wide.load.2 = load <8 x float>, ptr %124, align 4, !invariant.load !3, !alias.scope !11, !noalias !19
  %125 = getelementptr inbounds nuw float, ptr %12, i64 %index.next.1
  %wide.load14.2 = load <8 x float>, ptr %125, align 4, !invariant.load !3, !alias.scope !15, !noalias !20
  %126 = fmul <8 x float> %wide.load.2, %wide.load14.2
  %127 = getelementptr inbounds nuw float, ptr %10, i64 %index.next.1
  %wide.load15.2 = load <8 x float>, ptr %127, align 4, !invariant.load !3, !alias.scope !13, !noalias !21
  %128 = fadd <8 x float> %126, %wide.load15.2
  %129 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %128, <8 x float> zeroinitializer)
  %130 = fmul <8 x float> %wide.load.2, splat (float 2.500000e-01)
  %131 = fadd <8 x float> %130, %129
  %132 = fmul <8 x float> %131, %131
  %133 = getelementptr inbounds nuw float, ptr %6, i64 %index.next.1
  %wide.load16.2 = load <8 x float>, ptr %133, align 4, !invariant.load !3, !alias.scope !9, !noalias !22
  %134 = fmul <8 x float> %wide.load16.2, %132
  %135 = getelementptr inbounds nuw float, ptr %4, i64 %index.next.1
  %wide.load17.2 = load <8 x float>, ptr %135, align 4, !invariant.load !3, !alias.scope !6, !noalias !23
  %136 = fadd <8 x float> %wide.load17.2, %134
  %137 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %136, <8 x float> zeroinitializer)
  %138 = fmul <8 x float> %128, splat (float 1.250000e-01)
  %139 = fadd <8 x float> %138, %137
  %140 = getelementptr inbounds nuw float, ptr %14, i64 %123
  store <8 x float> %139, ptr %140, align 4, !alias.scope !17, !noalias !24
  %index.next.2 = add nuw nsw i64 %index, 24
  %141 = icmp eq i64 %index.next.2, 768
  br i1 %141, label %middle.block, label %vector.body, !llvm.loop !30

middle.block:                                     ; preds = %vector.body
  %142 = add nuw nsw i64 %84, 1
  %exitcond7.not = icmp eq i64 %142, 78
  br i1 %exitcond7.not, label %multiply_add_fusion_wrapped.exit, label %.preheader, !llvm.loop !28

multiply_add_fusion_wrapped.exit:                 ; preds = %middle.block, %middle.block27, %19, %82
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.maximum.v8f32(<8 x float>, <8 x float>) #2

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 1}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 3072}
!5 = !{i64 3145728}
!6 = !{!7}
!7 = distinct !{!7, !8, !"multiply_add_fusion_wrapped: argument 0"}
!8 = distinct !{!8, !"multiply_add_fusion_wrapped"}
!9 = !{!10}
!10 = distinct !{!10, !8, !"multiply_add_fusion_wrapped: argument 1"}
!11 = !{!12}
!12 = distinct !{!12, !8, !"multiply_add_fusion_wrapped: argument 2"}
!13 = !{!14}
!14 = distinct !{!14, !8, !"multiply_add_fusion_wrapped: argument 3"}
!15 = !{!16}
!16 = distinct !{!16, !8, !"multiply_add_fusion_wrapped: argument 4"}
!17 = !{!18}
!18 = distinct !{!18, !8, !"multiply_add_fusion_wrapped: argument 5"}
!19 = !{!7, !10, !14, !16, !18}
!20 = !{!7, !10, !12, !14, !18}
!21 = !{!7, !10, !12, !16, !18}
!22 = !{!7, !12, !14, !16, !18}
!23 = !{!10, !12, !14, !16, !18}
!24 = !{!7, !10, !12, !14, !16}
!25 = distinct !{!25, !26, !27}
!26 = !{!"llvm.loop.isvectorized", i32 1}
!27 = !{!"llvm.loop.unroll.runtime.disable"}
!28 = distinct !{!28, !29}
!29 = !{!"llvm.loop.unroll.disable"}
!30 = distinct !{!30, !26, !27}
