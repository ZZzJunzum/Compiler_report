; ModuleID = '__compute_module_multiply_add_fusion_kernel_module'
source_filename = "__compute_module_multiply_add_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @multiply_add_fusion(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !4
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !5
  %9 = getelementptr inbounds nuw i8, ptr %3, i64 48
  %10 = load ptr, ptr %9, align 8, !invariant.load !3, !dereferenceable !4
  %11 = getelementptr inbounds nuw i8, ptr %3, i64 64
  %12 = load ptr, ptr %11, align 8, !invariant.load !3, !dereferenceable !4
  %13 = getelementptr inbounds nuw i8, ptr %3, i64 80
  %14 = load ptr, ptr %13, align 8, !invariant.load !3, !dereferenceable !5
  %15 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %16 = load ptr, ptr %15, align 8
  %17 = load i64, ptr %16, align 4, !invariant.load !3
  tail call void @llvm.experimental.noalias.scope.decl(metadata !6)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !11)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !13)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !15)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !17)
  %18 = icmp ult i64 %17, 12
  br i1 %18, label %19, label %multiply_add_fusion_wrapped.exit

19:                                               ; preds = %1
  %20 = mul nuw nsw i64 %17, 1536
  br label %vector.ph

vector.ph:                                        ; preds = %19, %middle.block
  %21 = phi i64 [ 0, %19 ], [ %79, %middle.block ]
  %22 = mul nuw nsw i64 %21, 192
  %23 = add nuw nsw i64 %22, %20
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %vector.ph
  %index = phi i64 [ 0, %vector.ph ], [ %index.next.2, %vector.body ]
  %24 = add nuw nsw i64 %23, %index
  %25 = getelementptr inbounds nuw float, ptr %8, i64 %24
  %wide.load = load <8 x float>, ptr %25, align 4, !invariant.load !3, !alias.scope !11, !noalias !19
  %26 = getelementptr inbounds nuw float, ptr %12, i64 %index
  %wide.load5 = load <8 x float>, ptr %26, align 4, !invariant.load !3, !alias.scope !15, !noalias !20
  %27 = fmul <8 x float> %wide.load, %wide.load5
  %28 = getelementptr inbounds nuw float, ptr %10, i64 %index
  %wide.load6 = load <8 x float>, ptr %28, align 4, !invariant.load !3, !alias.scope !13, !noalias !21
  %29 = fadd <8 x float> %27, %wide.load6
  %30 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %29, <8 x float> zeroinitializer)
  %31 = fmul <8 x float> %wide.load, splat (float 2.500000e-01)
  %32 = fadd <8 x float> %31, %30
  %33 = fmul <8 x float> %32, %32
  %34 = getelementptr inbounds nuw float, ptr %6, i64 %index
  %wide.load7 = load <8 x float>, ptr %34, align 4, !invariant.load !3, !alias.scope !9, !noalias !22
  %35 = fmul <8 x float> %wide.load7, %33
  %36 = getelementptr inbounds nuw float, ptr %4, i64 %index
  %wide.load8 = load <8 x float>, ptr %36, align 4, !invariant.load !3, !alias.scope !6, !noalias !23
  %37 = fadd <8 x float> %wide.load8, %35
  %38 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %37, <8 x float> zeroinitializer)
  %39 = fmul <8 x float> %29, splat (float 1.250000e-01)
  %40 = fadd <8 x float> %39, %38
  %41 = getelementptr inbounds nuw float, ptr %14, i64 %24
  store <8 x float> %40, ptr %41, align 4, !alias.scope !17, !noalias !24
  %index.next = add nuw nsw i64 %index, 8
  %42 = add nuw nsw i64 %23, %index.next
  %43 = getelementptr inbounds nuw float, ptr %8, i64 %42
  %wide.load.1 = load <8 x float>, ptr %43, align 4, !invariant.load !3, !alias.scope !11, !noalias !19
  %44 = getelementptr inbounds nuw float, ptr %12, i64 %index.next
  %wide.load5.1 = load <8 x float>, ptr %44, align 4, !invariant.load !3, !alias.scope !15, !noalias !20
  %45 = fmul <8 x float> %wide.load.1, %wide.load5.1
  %46 = getelementptr inbounds nuw float, ptr %10, i64 %index.next
  %wide.load6.1 = load <8 x float>, ptr %46, align 4, !invariant.load !3, !alias.scope !13, !noalias !21
  %47 = fadd <8 x float> %45, %wide.load6.1
  %48 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %47, <8 x float> zeroinitializer)
  %49 = fmul <8 x float> %wide.load.1, splat (float 2.500000e-01)
  %50 = fadd <8 x float> %49, %48
  %51 = fmul <8 x float> %50, %50
  %52 = getelementptr inbounds nuw float, ptr %6, i64 %index.next
  %wide.load7.1 = load <8 x float>, ptr %52, align 4, !invariant.load !3, !alias.scope !9, !noalias !22
  %53 = fmul <8 x float> %wide.load7.1, %51
  %54 = getelementptr inbounds nuw float, ptr %4, i64 %index.next
  %wide.load8.1 = load <8 x float>, ptr %54, align 4, !invariant.load !3, !alias.scope !6, !noalias !23
  %55 = fadd <8 x float> %wide.load8.1, %53
  %56 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %55, <8 x float> zeroinitializer)
  %57 = fmul <8 x float> %47, splat (float 1.250000e-01)
  %58 = fadd <8 x float> %57, %56
  %59 = getelementptr inbounds nuw float, ptr %14, i64 %42
  store <8 x float> %58, ptr %59, align 4, !alias.scope !17, !noalias !24
  %index.next.1 = add nuw nsw i64 %index, 16
  %60 = add nuw nsw i64 %23, %index.next.1
  %61 = getelementptr inbounds nuw float, ptr %8, i64 %60
  %wide.load.2 = load <8 x float>, ptr %61, align 4, !invariant.load !3, !alias.scope !11, !noalias !19
  %62 = getelementptr inbounds nuw float, ptr %12, i64 %index.next.1
  %wide.load5.2 = load <8 x float>, ptr %62, align 4, !invariant.load !3, !alias.scope !15, !noalias !20
  %63 = fmul <8 x float> %wide.load.2, %wide.load5.2
  %64 = getelementptr inbounds nuw float, ptr %10, i64 %index.next.1
  %wide.load6.2 = load <8 x float>, ptr %64, align 4, !invariant.load !3, !alias.scope !13, !noalias !21
  %65 = fadd <8 x float> %63, %wide.load6.2
  %66 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %65, <8 x float> zeroinitializer)
  %67 = fmul <8 x float> %wide.load.2, splat (float 2.500000e-01)
  %68 = fadd <8 x float> %67, %66
  %69 = fmul <8 x float> %68, %68
  %70 = getelementptr inbounds nuw float, ptr %6, i64 %index.next.1
  %wide.load7.2 = load <8 x float>, ptr %70, align 4, !invariant.load !3, !alias.scope !9, !noalias !22
  %71 = fmul <8 x float> %wide.load7.2, %69
  %72 = getelementptr inbounds nuw float, ptr %4, i64 %index.next.1
  %wide.load8.2 = load <8 x float>, ptr %72, align 4, !invariant.load !3, !alias.scope !6, !noalias !23
  %73 = fadd <8 x float> %wide.load8.2, %71
  %74 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %73, <8 x float> zeroinitializer)
  %75 = fmul <8 x float> %65, splat (float 1.250000e-01)
  %76 = fadd <8 x float> %75, %74
  %77 = getelementptr inbounds nuw float, ptr %14, i64 %60
  store <8 x float> %76, ptr %77, align 4, !alias.scope !17, !noalias !24
  %index.next.2 = add nuw nsw i64 %index, 24
  %78 = icmp eq i64 %index.next.2, 192
  br i1 %78, label %middle.block, label %vector.body, !llvm.loop !25

middle.block:                                     ; preds = %vector.body
  %79 = add nuw nsw i64 %21, 1
  %exitcond3.not = icmp eq i64 %79, 8
  br i1 %exitcond3.not, label %multiply_add_fusion_wrapped.exit, label %vector.ph, !llvm.loop !28

multiply_add_fusion_wrapped.exit:                 ; preds = %middle.block, %1
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.maximum.v8f32(<8 x float>, <8 x float>) #2

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 2}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 768}
!5 = !{i64 73728}
!6 = !{!7}
!7 = distinct !{!7, !8, !"multiply_add_fusion_wrapped: argument 0"}
!8 = distinct !{!8, !"multiply_add_fusion_wrapped"}
!9 = !{!10}
!10 = distinct !{!10, !8, !"multiply_add_fusion_wrapped: argument 1"}
!11 = !{!12}
!12 = distinct !{!12, !8, !"multiply_add_fusion_wrapped: argument 2"}
!13 = !{!14}
!14 = distinct !{!14, !8, !"multiply_add_fusion_wrapped: argument 3"}
!15 = !{!16}
!16 = distinct !{!16, !8, !"multiply_add_fusion_wrapped: argument 4"}
!17 = !{!18}
!18 = distinct !{!18, !8, !"multiply_add_fusion_wrapped: argument 5"}
!19 = !{!7, !10, !14, !16, !18}
!20 = !{!7, !10, !12, !14, !18}
!21 = !{!7, !10, !12, !16, !18}
!22 = !{!7, !12, !14, !16, !18}
!23 = !{!10, !12, !14, !16, !18}
!24 = !{!7, !10, !12, !14, !16}
!25 = distinct !{!25, !26, !27}
!26 = !{!"llvm.loop.isvectorized", i32 1}
!27 = !{!"llvm.loop.unroll.runtime.disable"}
!28 = distinct !{!28, !29}
!29 = !{!"llvm.loop.unroll.disable"}
