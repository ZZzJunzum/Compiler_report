; ModuleID = '__compute_module_convert_reduce_fusion_kernel_module'
source_filename = "__compute_module_convert_reduce_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @convert_reduce_fusion(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !4
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !5
  %9 = getelementptr inbounds nuw i8, ptr %3, i64 48
  %10 = load ptr, ptr %9, align 8, !invariant.load !3, !dereferenceable !4
  %11 = getelementptr inbounds nuw i8, ptr %3, i64 64
  %12 = load ptr, ptr %11, align 8, !invariant.load !3, !dereferenceable !4
  %13 = getelementptr inbounds nuw i8, ptr %3, i64 80
  %14 = load ptr, ptr %13, align 8, !invariant.load !3, !dereferenceable !6
  %15 = getelementptr inbounds nuw i8, ptr %3, i64 96
  %16 = load ptr, ptr %15, align 8, !invariant.load !3, !dereferenceable !6
  tail call void @llvm.experimental.noalias.scope.decl(metadata !7)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !10)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !12)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !14)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !16)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !18)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !20)
  br label %.preheader

.preheader:                                       ; preds = %1, %middle.block
  %17 = phi i64 [ 0, %1 ], [ %62, %middle.block ]
  %.idx = mul nuw nsw i64 %17, 768
  %18 = getelementptr i8, ptr %8, i64 %.idx
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %.preheader
  %index = phi i64 [ 0, %.preheader ], [ %index.next, %vector.body ]
  %vec.phi = phi <8 x i32> [ zeroinitializer, %.preheader ], [ %55, %vector.body ]
  %vec.phi6 = phi <8 x i32> [ zeroinitializer, %.preheader ], [ %56, %vector.body ]
  %vec.phi7 = phi <8 x i32> [ zeroinitializer, %.preheader ], [ %53, %vector.body ]
  %vec.phi8 = phi <8 x i32> [ zeroinitializer, %.preheader ], [ %54, %vector.body ]
  %19 = getelementptr float, ptr %18, i64 %index
  %20 = getelementptr i8, ptr %19, i64 32
  %wide.load = load <8 x float>, ptr %19, align 4, !invariant.load !3, !alias.scope !12, !noalias !22
  %wide.load9 = load <8 x float>, ptr %20, align 4, !invariant.load !3, !alias.scope !12, !noalias !22
  %21 = getelementptr inbounds nuw float, ptr %12, i64 %index
  %22 = getelementptr inbounds nuw i8, ptr %21, i64 32
  %wide.load10 = load <8 x float>, ptr %21, align 4, !invariant.load !3, !alias.scope !16, !noalias !23
  %wide.load11 = load <8 x float>, ptr %22, align 4, !invariant.load !3, !alias.scope !16, !noalias !23
  %23 = fmul <8 x float> %wide.load, %wide.load10
  %24 = fmul <8 x float> %wide.load9, %wide.load11
  %25 = getelementptr inbounds nuw float, ptr %10, i64 %index
  %26 = getelementptr inbounds nuw i8, ptr %25, i64 32
  %wide.load12 = load <8 x float>, ptr %25, align 4, !invariant.load !3, !alias.scope !14, !noalias !24
  %wide.load13 = load <8 x float>, ptr %26, align 4, !invariant.load !3, !alias.scope !14, !noalias !24
  %27 = fadd <8 x float> %23, %wide.load12
  %28 = fadd <8 x float> %24, %wide.load13
  %29 = fcmp ogt <8 x float> %27, zeroinitializer
  %30 = fcmp ogt <8 x float> %28, zeroinitializer
  %31 = zext <8 x i1> %29 to <8 x i32>
  %32 = zext <8 x i1> %30 to <8 x i32>
  %33 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %27, <8 x float> zeroinitializer)
  %34 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %28, <8 x float> zeroinitializer)
  %35 = fmul <8 x float> %wide.load, splat (float 2.500000e-01)
  %36 = fmul <8 x float> %wide.load9, splat (float 2.500000e-01)
  %37 = fadd <8 x float> %35, %33
  %38 = fadd <8 x float> %36, %34
  %39 = fmul <8 x float> %37, %37
  %40 = fmul <8 x float> %38, %38
  %41 = getelementptr inbounds nuw float, ptr %6, i64 %index
  %42 = getelementptr inbounds nuw i8, ptr %41, i64 32
  %wide.load14 = load <8 x float>, ptr %41, align 4, !invariant.load !3, !alias.scope !10, !noalias !25
  %wide.load15 = load <8 x float>, ptr %42, align 4, !invariant.load !3, !alias.scope !10, !noalias !25
  %43 = fmul <8 x float> %wide.load14, %39
  %44 = fmul <8 x float> %wide.load15, %40
  %45 = getelementptr inbounds nuw float, ptr %4, i64 %index
  %46 = getelementptr inbounds nuw i8, ptr %45, i64 32
  %wide.load16 = load <8 x float>, ptr %45, align 4, !invariant.load !3, !alias.scope !7, !noalias !26
  %wide.load17 = load <8 x float>, ptr %46, align 4, !invariant.load !3, !alias.scope !7, !noalias !26
  %47 = fadd <8 x float> %wide.load16, %43
  %48 = fadd <8 x float> %wide.load17, %44
  %49 = fcmp ogt <8 x float> %47, zeroinitializer
  %50 = fcmp ogt <8 x float> %48, zeroinitializer
  %51 = zext <8 x i1> %49 to <8 x i32>
  %52 = zext <8 x i1> %50 to <8 x i32>
  %53 = add <8 x i32> %vec.phi7, %31
  %54 = add <8 x i32> %vec.phi8, %32
  %55 = add <8 x i32> %vec.phi, %51
  %56 = add <8 x i32> %vec.phi6, %52
  %index.next = add nuw i64 %index, 16
  %57 = icmp eq i64 %index.next, 192
  br i1 %57, label %middle.block, label %vector.body, !llvm.loop !27

middle.block:                                     ; preds = %vector.body
  %bin.rdx18 = add <8 x i32> %54, %53
  %58 = tail call i32 @llvm.vector.reduce.add.v8i32(<8 x i32> %bin.rdx18)
  %bin.rdx = add <8 x i32> %56, %55
  %59 = tail call i32 @llvm.vector.reduce.add.v8i32(<8 x i32> %bin.rdx)
  %60 = getelementptr inbounds nuw i32, ptr %14, i64 %17
  store i32 %58, ptr %60, align 4, !alias.scope !18, !noalias !30
  %61 = getelementptr inbounds nuw i32, ptr %16, i64 %17
  store i32 %59, ptr %61, align 4, !alias.scope !20, !noalias !31
  %62 = add nuw nsw i64 %17, 1
  %exitcond3.not = icmp eq i64 %62, 96
  br i1 %exitcond3.not, label %convert_reduce_fusion_wrapped.exit, label %.preheader, !llvm.loop !32

convert_reduce_fusion_wrapped.exit:               ; preds = %middle.block
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.maximum.v8f32(<8 x float>, <8 x float>) #2

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.vector.reduce.add.v8i32(<8 x i32>) #3

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #3 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 0}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 768}
!5 = !{i64 73728}
!6 = !{i64 384}
!7 = !{!8}
!8 = distinct !{!8, !9, !"convert_reduce_fusion_wrapped: argument 0"}
!9 = distinct !{!9, !"convert_reduce_fusion_wrapped"}
!10 = !{!11}
!11 = distinct !{!11, !9, !"convert_reduce_fusion_wrapped: argument 1"}
!12 = !{!13}
!13 = distinct !{!13, !9, !"convert_reduce_fusion_wrapped: argument 2"}
!14 = !{!15}
!15 = distinct !{!15, !9, !"convert_reduce_fusion_wrapped: argument 3"}
!16 = !{!17}
!17 = distinct !{!17, !9, !"convert_reduce_fusion_wrapped: argument 4"}
!18 = !{!19}
!19 = distinct !{!19, !9, !"convert_reduce_fusion_wrapped: argument 5"}
!20 = !{!21}
!21 = distinct !{!21, !9, !"convert_reduce_fusion_wrapped: argument 6"}
!22 = !{!8, !11, !15, !17, !19, !21}
!23 = !{!8, !11, !13, !15, !19, !21}
!24 = !{!8, !11, !13, !17, !19, !21}
!25 = !{!8, !13, !15, !17, !19, !21}
!26 = !{!11, !13, !15, !17, !19, !21}
!27 = distinct !{!27, !28, !29}
!28 = !{!"llvm.loop.isvectorized", i32 1}
!29 = !{!"llvm.loop.unroll.runtime.disable"}
!30 = !{!8, !11, !13, !15, !17, !21}
!31 = !{!8, !11, !13, !15, !17, !19}
!32 = distinct !{!32, !33}
!33 = !{!"llvm.loop.unroll.disable"}
