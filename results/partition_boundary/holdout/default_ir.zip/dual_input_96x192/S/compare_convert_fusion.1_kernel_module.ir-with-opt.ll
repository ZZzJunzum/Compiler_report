; ModuleID = '__compute_module_compare_convert_fusion.1_kernel_module'
source_filename = "__compute_module_compare_convert_fusion.1_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @compare_convert_fusion.1(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !5
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !4
  %9 = getelementptr inbounds nuw i8, ptr %3, i64 48
  %10 = load ptr, ptr %9, align 8, !invariant.load !3, !dereferenceable !5
  tail call void @llvm.experimental.noalias.scope.decl(metadata !6)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !11)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !13)
  %11 = getelementptr inbounds nuw i8, ptr %8, i64 32
  %wide.load4 = load <8 x float>, ptr %8, align 4, !invariant.load !3, !alias.scope !11, !noalias !15
  %wide.load5 = load <8 x float>, ptr %11, align 4, !invariant.load !3, !alias.scope !11, !noalias !15
  %12 = getelementptr inbounds nuw i8, ptr %4, i64 32
  %wide.load6 = load <8 x float>, ptr %4, align 4, !invariant.load !3, !alias.scope !6, !noalias !16
  %wide.load7 = load <8 x float>, ptr %12, align 4, !invariant.load !3, !alias.scope !6, !noalias !16
  %13 = getelementptr inbounds nuw i8, ptr %8, i64 64
  %14 = getelementptr inbounds nuw i8, ptr %8, i64 96
  %wide.load4.1 = load <8 x float>, ptr %13, align 4, !invariant.load !3, !alias.scope !11, !noalias !15
  %wide.load5.1 = load <8 x float>, ptr %14, align 4, !invariant.load !3, !alias.scope !11, !noalias !15
  %15 = getelementptr inbounds nuw i8, ptr %4, i64 64
  %16 = getelementptr inbounds nuw i8, ptr %4, i64 96
  %wide.load6.1 = load <8 x float>, ptr %15, align 4, !invariant.load !3, !alias.scope !6, !noalias !16
  %wide.load7.1 = load <8 x float>, ptr %16, align 4, !invariant.load !3, !alias.scope !6, !noalias !16
  %17 = getelementptr inbounds nuw i8, ptr %8, i64 128
  %18 = getelementptr inbounds nuw i8, ptr %8, i64 160
  %wide.load4.2 = load <8 x float>, ptr %17, align 4, !invariant.load !3, !alias.scope !11, !noalias !15
  %wide.load5.2 = load <8 x float>, ptr %18, align 4, !invariant.load !3, !alias.scope !11, !noalias !15
  %19 = getelementptr inbounds nuw i8, ptr %4, i64 128
  %20 = getelementptr inbounds nuw i8, ptr %4, i64 160
  %wide.load6.2 = load <8 x float>, ptr %19, align 4, !invariant.load !3, !alias.scope !6, !noalias !16
  %wide.load7.2 = load <8 x float>, ptr %20, align 4, !invariant.load !3, !alias.scope !6, !noalias !16
  %21 = getelementptr inbounds nuw i8, ptr %8, i64 192
  %22 = getelementptr inbounds nuw i8, ptr %8, i64 224
  %wide.load4.3 = load <8 x float>, ptr %21, align 4, !invariant.load !3, !alias.scope !11, !noalias !15
  %wide.load5.3 = load <8 x float>, ptr %22, align 4, !invariant.load !3, !alias.scope !11, !noalias !15
  %23 = getelementptr inbounds nuw i8, ptr %4, i64 192
  %24 = getelementptr inbounds nuw i8, ptr %4, i64 224
  %wide.load6.3 = load <8 x float>, ptr %23, align 4, !invariant.load !3, !alias.scope !6, !noalias !16
  %wide.load7.3 = load <8 x float>, ptr %24, align 4, !invariant.load !3, !alias.scope !6, !noalias !16
  %25 = getelementptr inbounds nuw i8, ptr %8, i64 256
  %26 = getelementptr inbounds nuw i8, ptr %8, i64 288
  %wide.load4.4 = load <8 x float>, ptr %25, align 4, !invariant.load !3, !alias.scope !11, !noalias !15
  %wide.load5.4 = load <8 x float>, ptr %26, align 4, !invariant.load !3, !alias.scope !11, !noalias !15
  %27 = getelementptr inbounds nuw i8, ptr %4, i64 256
  %28 = getelementptr inbounds nuw i8, ptr %4, i64 288
  %wide.load6.4 = load <8 x float>, ptr %27, align 4, !invariant.load !3, !alias.scope !6, !noalias !16
  %wide.load7.4 = load <8 x float>, ptr %28, align 4, !invariant.load !3, !alias.scope !6, !noalias !16
  %29 = getelementptr inbounds nuw i8, ptr %8, i64 320
  %30 = getelementptr inbounds nuw i8, ptr %8, i64 352
  %wide.load4.5 = load <8 x float>, ptr %29, align 4, !invariant.load !3, !alias.scope !11, !noalias !15
  %wide.load5.5 = load <8 x float>, ptr %30, align 4, !invariant.load !3, !alias.scope !11, !noalias !15
  %31 = getelementptr inbounds nuw i8, ptr %4, i64 320
  %32 = getelementptr inbounds nuw i8, ptr %4, i64 352
  %wide.load6.5 = load <8 x float>, ptr %31, align 4, !invariant.load !3, !alias.scope !6, !noalias !16
  %wide.load7.5 = load <8 x float>, ptr %32, align 4, !invariant.load !3, !alias.scope !6, !noalias !16
  %33 = getelementptr inbounds nuw i8, ptr %8, i64 384
  %34 = getelementptr inbounds nuw i8, ptr %8, i64 416
  %wide.load4.6 = load <8 x float>, ptr %33, align 4, !invariant.load !3, !alias.scope !11, !noalias !15
  %wide.load5.6 = load <8 x float>, ptr %34, align 4, !invariant.load !3, !alias.scope !11, !noalias !15
  %35 = getelementptr inbounds nuw i8, ptr %4, i64 384
  %36 = getelementptr inbounds nuw i8, ptr %4, i64 416
  %wide.load6.6 = load <8 x float>, ptr %35, align 4, !invariant.load !3, !alias.scope !6, !noalias !16
  %wide.load7.6 = load <8 x float>, ptr %36, align 4, !invariant.load !3, !alias.scope !6, !noalias !16
  %37 = getelementptr inbounds nuw i8, ptr %8, i64 448
  %38 = getelementptr inbounds nuw i8, ptr %8, i64 480
  %wide.load4.7 = load <8 x float>, ptr %37, align 4, !invariant.load !3, !alias.scope !11, !noalias !15
  %wide.load5.7 = load <8 x float>, ptr %38, align 4, !invariant.load !3, !alias.scope !11, !noalias !15
  %39 = getelementptr inbounds nuw i8, ptr %4, i64 448
  %40 = getelementptr inbounds nuw i8, ptr %4, i64 480
  %wide.load6.7 = load <8 x float>, ptr %39, align 4, !invariant.load !3, !alias.scope !6, !noalias !16
  %wide.load7.7 = load <8 x float>, ptr %40, align 4, !invariant.load !3, !alias.scope !6, !noalias !16
  %41 = getelementptr inbounds nuw i8, ptr %8, i64 512
  %42 = getelementptr inbounds nuw i8, ptr %8, i64 544
  %wide.load4.8 = load <8 x float>, ptr %41, align 4, !invariant.load !3, !alias.scope !11, !noalias !15
  %wide.load5.8 = load <8 x float>, ptr %42, align 4, !invariant.load !3, !alias.scope !11, !noalias !15
  %43 = getelementptr inbounds nuw i8, ptr %4, i64 512
  %44 = getelementptr inbounds nuw i8, ptr %4, i64 544
  %wide.load6.8 = load <8 x float>, ptr %43, align 4, !invariant.load !3, !alias.scope !6, !noalias !16
  %wide.load7.8 = load <8 x float>, ptr %44, align 4, !invariant.load !3, !alias.scope !6, !noalias !16
  %45 = getelementptr inbounds nuw i8, ptr %8, i64 576
  %46 = getelementptr inbounds nuw i8, ptr %8, i64 608
  %wide.load4.9 = load <8 x float>, ptr %45, align 4, !invariant.load !3, !alias.scope !11, !noalias !15
  %wide.load5.9 = load <8 x float>, ptr %46, align 4, !invariant.load !3, !alias.scope !11, !noalias !15
  %47 = getelementptr inbounds nuw i8, ptr %4, i64 576
  %48 = getelementptr inbounds nuw i8, ptr %4, i64 608
  %wide.load6.9 = load <8 x float>, ptr %47, align 4, !invariant.load !3, !alias.scope !6, !noalias !16
  %wide.load7.9 = load <8 x float>, ptr %48, align 4, !invariant.load !3, !alias.scope !6, !noalias !16
  %49 = getelementptr inbounds nuw i8, ptr %8, i64 640
  %50 = getelementptr inbounds nuw i8, ptr %8, i64 672
  %wide.load4.10 = load <8 x float>, ptr %49, align 4, !invariant.load !3, !alias.scope !11, !noalias !15
  %wide.load5.10 = load <8 x float>, ptr %50, align 4, !invariant.load !3, !alias.scope !11, !noalias !15
  %51 = getelementptr inbounds nuw i8, ptr %4, i64 640
  %52 = getelementptr inbounds nuw i8, ptr %4, i64 672
  %wide.load6.10 = load <8 x float>, ptr %51, align 4, !invariant.load !3, !alias.scope !6, !noalias !16
  %wide.load7.10 = load <8 x float>, ptr %52, align 4, !invariant.load !3, !alias.scope !6, !noalias !16
  %53 = getelementptr inbounds nuw i8, ptr %8, i64 704
  %54 = getelementptr inbounds nuw i8, ptr %8, i64 736
  %wide.load4.11 = load <8 x float>, ptr %53, align 4, !invariant.load !3, !alias.scope !11, !noalias !15
  %wide.load5.11 = load <8 x float>, ptr %54, align 4, !invariant.load !3, !alias.scope !11, !noalias !15
  %55 = getelementptr inbounds nuw i8, ptr %4, i64 704
  %56 = getelementptr inbounds nuw i8, ptr %4, i64 736
  %wide.load6.11 = load <8 x float>, ptr %55, align 4, !invariant.load !3, !alias.scope !6, !noalias !16
  %wide.load7.11 = load <8 x float>, ptr %56, align 4, !invariant.load !3, !alias.scope !6, !noalias !16
  br label %vector.ph

vector.ph:                                        ; preds = %1, %vector.ph
  %57 = phi i64 [ 0, %1 ], [ %214, %vector.ph ]
  %58 = mul nuw nsw i64 %57, 192
  %59 = getelementptr inbounds nuw float, ptr %6, i64 %58
  %60 = getelementptr inbounds nuw i8, ptr %59, i64 32
  %wide.load = load <8 x float>, ptr %59, align 4, !invariant.load !3, !alias.scope !9, !noalias !17
  %wide.load3 = load <8 x float>, ptr %60, align 4, !invariant.load !3, !alias.scope !9, !noalias !17
  %61 = fmul <8 x float> %wide.load, %wide.load4
  %62 = fmul <8 x float> %wide.load3, %wide.load5
  %63 = fadd <8 x float> %61, %wide.load6
  %64 = fadd <8 x float> %62, %wide.load7
  %65 = fcmp ogt <8 x float> %63, zeroinitializer
  %66 = fcmp ogt <8 x float> %64, zeroinitializer
  %67 = zext <8 x i1> %65 to <8 x i32>
  %68 = zext <8 x i1> %66 to <8 x i32>
  %69 = getelementptr inbounds nuw i32, ptr %10, i64 %58
  %70 = getelementptr inbounds nuw i8, ptr %69, i64 32
  store <8 x i32> %67, ptr %69, align 4, !alias.scope !13, !noalias !18
  store <8 x i32> %68, ptr %70, align 4, !alias.scope !13, !noalias !18
  %71 = or disjoint i64 %58, 16
  %72 = getelementptr inbounds nuw float, ptr %6, i64 %71
  %73 = getelementptr inbounds nuw i8, ptr %72, i64 32
  %wide.load.1 = load <8 x float>, ptr %72, align 4, !invariant.load !3, !alias.scope !9, !noalias !17
  %wide.load3.1 = load <8 x float>, ptr %73, align 4, !invariant.load !3, !alias.scope !9, !noalias !17
  %74 = fmul <8 x float> %wide.load.1, %wide.load4.1
  %75 = fmul <8 x float> %wide.load3.1, %wide.load5.1
  %76 = fadd <8 x float> %74, %wide.load6.1
  %77 = fadd <8 x float> %75, %wide.load7.1
  %78 = fcmp ogt <8 x float> %76, zeroinitializer
  %79 = fcmp ogt <8 x float> %77, zeroinitializer
  %80 = zext <8 x i1> %78 to <8 x i32>
  %81 = zext <8 x i1> %79 to <8 x i32>
  %82 = getelementptr inbounds nuw i32, ptr %10, i64 %71
  %83 = getelementptr inbounds nuw i8, ptr %82, i64 32
  store <8 x i32> %80, ptr %82, align 4, !alias.scope !13, !noalias !18
  store <8 x i32> %81, ptr %83, align 4, !alias.scope !13, !noalias !18
  %84 = or disjoint i64 %58, 32
  %85 = getelementptr inbounds nuw float, ptr %6, i64 %84
  %86 = getelementptr inbounds nuw i8, ptr %85, i64 32
  %wide.load.2 = load <8 x float>, ptr %85, align 4, !invariant.load !3, !alias.scope !9, !noalias !17
  %wide.load3.2 = load <8 x float>, ptr %86, align 4, !invariant.load !3, !alias.scope !9, !noalias !17
  %87 = fmul <8 x float> %wide.load.2, %wide.load4.2
  %88 = fmul <8 x float> %wide.load3.2, %wide.load5.2
  %89 = fadd <8 x float> %87, %wide.load6.2
  %90 = fadd <8 x float> %88, %wide.load7.2
  %91 = fcmp ogt <8 x float> %89, zeroinitializer
  %92 = fcmp ogt <8 x float> %90, zeroinitializer
  %93 = zext <8 x i1> %91 to <8 x i32>
  %94 = zext <8 x i1> %92 to <8 x i32>
  %95 = getelementptr inbounds nuw i32, ptr %10, i64 %84
  %96 = getelementptr inbounds nuw i8, ptr %95, i64 32
  store <8 x i32> %93, ptr %95, align 4, !alias.scope !13, !noalias !18
  store <8 x i32> %94, ptr %96, align 4, !alias.scope !13, !noalias !18
  %97 = or disjoint i64 %58, 48
  %98 = getelementptr inbounds nuw float, ptr %6, i64 %97
  %99 = getelementptr inbounds nuw i8, ptr %98, i64 32
  %wide.load.3 = load <8 x float>, ptr %98, align 4, !invariant.load !3, !alias.scope !9, !noalias !17
  %wide.load3.3 = load <8 x float>, ptr %99, align 4, !invariant.load !3, !alias.scope !9, !noalias !17
  %100 = fmul <8 x float> %wide.load.3, %wide.load4.3
  %101 = fmul <8 x float> %wide.load3.3, %wide.load5.3
  %102 = fadd <8 x float> %100, %wide.load6.3
  %103 = fadd <8 x float> %101, %wide.load7.3
  %104 = fcmp ogt <8 x float> %102, zeroinitializer
  %105 = fcmp ogt <8 x float> %103, zeroinitializer
  %106 = zext <8 x i1> %104 to <8 x i32>
  %107 = zext <8 x i1> %105 to <8 x i32>
  %108 = getelementptr inbounds nuw i32, ptr %10, i64 %97
  %109 = getelementptr inbounds nuw i8, ptr %108, i64 32
  store <8 x i32> %106, ptr %108, align 4, !alias.scope !13, !noalias !18
  store <8 x i32> %107, ptr %109, align 4, !alias.scope !13, !noalias !18
  %110 = add nuw nsw i64 %58, 64
  %111 = getelementptr inbounds nuw float, ptr %6, i64 %110
  %112 = getelementptr inbounds nuw i8, ptr %111, i64 32
  %wide.load.4 = load <8 x float>, ptr %111, align 4, !invariant.load !3, !alias.scope !9, !noalias !17
  %wide.load3.4 = load <8 x float>, ptr %112, align 4, !invariant.load !3, !alias.scope !9, !noalias !17
  %113 = fmul <8 x float> %wide.load.4, %wide.load4.4
  %114 = fmul <8 x float> %wide.load3.4, %wide.load5.4
  %115 = fadd <8 x float> %113, %wide.load6.4
  %116 = fadd <8 x float> %114, %wide.load7.4
  %117 = fcmp ogt <8 x float> %115, zeroinitializer
  %118 = fcmp ogt <8 x float> %116, zeroinitializer
  %119 = zext <8 x i1> %117 to <8 x i32>
  %120 = zext <8 x i1> %118 to <8 x i32>
  %121 = getelementptr inbounds nuw i32, ptr %10, i64 %110
  %122 = getelementptr inbounds nuw i8, ptr %121, i64 32
  store <8 x i32> %119, ptr %121, align 4, !alias.scope !13, !noalias !18
  store <8 x i32> %120, ptr %122, align 4, !alias.scope !13, !noalias !18
  %123 = add nuw nsw i64 %58, 80
  %124 = getelementptr inbounds nuw float, ptr %6, i64 %123
  %125 = getelementptr inbounds nuw i8, ptr %124, i64 32
  %wide.load.5 = load <8 x float>, ptr %124, align 4, !invariant.load !3, !alias.scope !9, !noalias !17
  %wide.load3.5 = load <8 x float>, ptr %125, align 4, !invariant.load !3, !alias.scope !9, !noalias !17
  %126 = fmul <8 x float> %wide.load.5, %wide.load4.5
  %127 = fmul <8 x float> %wide.load3.5, %wide.load5.5
  %128 = fadd <8 x float> %126, %wide.load6.5
  %129 = fadd <8 x float> %127, %wide.load7.5
  %130 = fcmp ogt <8 x float> %128, zeroinitializer
  %131 = fcmp ogt <8 x float> %129, zeroinitializer
  %132 = zext <8 x i1> %130 to <8 x i32>
  %133 = zext <8 x i1> %131 to <8 x i32>
  %134 = getelementptr inbounds nuw i32, ptr %10, i64 %123
  %135 = getelementptr inbounds nuw i8, ptr %134, i64 32
  store <8 x i32> %132, ptr %134, align 4, !alias.scope !13, !noalias !18
  store <8 x i32> %133, ptr %135, align 4, !alias.scope !13, !noalias !18
  %136 = add nuw nsw i64 %58, 96
  %137 = getelementptr inbounds nuw float, ptr %6, i64 %136
  %138 = getelementptr inbounds nuw i8, ptr %137, i64 32
  %wide.load.6 = load <8 x float>, ptr %137, align 4, !invariant.load !3, !alias.scope !9, !noalias !17
  %wide.load3.6 = load <8 x float>, ptr %138, align 4, !invariant.load !3, !alias.scope !9, !noalias !17
  %139 = fmul <8 x float> %wide.load.6, %wide.load4.6
  %140 = fmul <8 x float> %wide.load3.6, %wide.load5.6
  %141 = fadd <8 x float> %139, %wide.load6.6
  %142 = fadd <8 x float> %140, %wide.load7.6
  %143 = fcmp ogt <8 x float> %141, zeroinitializer
  %144 = fcmp ogt <8 x float> %142, zeroinitializer
  %145 = zext <8 x i1> %143 to <8 x i32>
  %146 = zext <8 x i1> %144 to <8 x i32>
  %147 = getelementptr inbounds nuw i32, ptr %10, i64 %136
  %148 = getelementptr inbounds nuw i8, ptr %147, i64 32
  store <8 x i32> %145, ptr %147, align 4, !alias.scope !13, !noalias !18
  store <8 x i32> %146, ptr %148, align 4, !alias.scope !13, !noalias !18
  %149 = add nuw nsw i64 %58, 112
  %150 = getelementptr inbounds nuw float, ptr %6, i64 %149
  %151 = getelementptr inbounds nuw i8, ptr %150, i64 32
  %wide.load.7 = load <8 x float>, ptr %150, align 4, !invariant.load !3, !alias.scope !9, !noalias !17
  %wide.load3.7 = load <8 x float>, ptr %151, align 4, !invariant.load !3, !alias.scope !9, !noalias !17
  %152 = fmul <8 x float> %wide.load.7, %wide.load4.7
  %153 = fmul <8 x float> %wide.load3.7, %wide.load5.7
  %154 = fadd <8 x float> %152, %wide.load6.7
  %155 = fadd <8 x float> %153, %wide.load7.7
  %156 = fcmp ogt <8 x float> %154, zeroinitializer
  %157 = fcmp ogt <8 x float> %155, zeroinitializer
  %158 = zext <8 x i1> %156 to <8 x i32>
  %159 = zext <8 x i1> %157 to <8 x i32>
  %160 = getelementptr inbounds nuw i32, ptr %10, i64 %149
  %161 = getelementptr inbounds nuw i8, ptr %160, i64 32
  store <8 x i32> %158, ptr %160, align 4, !alias.scope !13, !noalias !18
  store <8 x i32> %159, ptr %161, align 4, !alias.scope !13, !noalias !18
  %162 = add nuw nsw i64 %58, 128
  %163 = getelementptr inbounds nuw float, ptr %6, i64 %162
  %164 = getelementptr inbounds nuw i8, ptr %163, i64 32
  %wide.load.8 = load <8 x float>, ptr %163, align 4, !invariant.load !3, !alias.scope !9, !noalias !17
  %wide.load3.8 = load <8 x float>, ptr %164, align 4, !invariant.load !3, !alias.scope !9, !noalias !17
  %165 = fmul <8 x float> %wide.load.8, %wide.load4.8
  %166 = fmul <8 x float> %wide.load3.8, %wide.load5.8
  %167 = fadd <8 x float> %165, %wide.load6.8
  %168 = fadd <8 x float> %166, %wide.load7.8
  %169 = fcmp ogt <8 x float> %167, zeroinitializer
  %170 = fcmp ogt <8 x float> %168, zeroinitializer
  %171 = zext <8 x i1> %169 to <8 x i32>
  %172 = zext <8 x i1> %170 to <8 x i32>
  %173 = getelementptr inbounds nuw i32, ptr %10, i64 %162
  %174 = getelementptr inbounds nuw i8, ptr %173, i64 32
  store <8 x i32> %171, ptr %173, align 4, !alias.scope !13, !noalias !18
  store <8 x i32> %172, ptr %174, align 4, !alias.scope !13, !noalias !18
  %175 = add nuw nsw i64 %58, 144
  %176 = getelementptr inbounds nuw float, ptr %6, i64 %175
  %177 = getelementptr inbounds nuw i8, ptr %176, i64 32
  %wide.load.9 = load <8 x float>, ptr %176, align 4, !invariant.load !3, !alias.scope !9, !noalias !17
  %wide.load3.9 = load <8 x float>, ptr %177, align 4, !invariant.load !3, !alias.scope !9, !noalias !17
  %178 = fmul <8 x float> %wide.load.9, %wide.load4.9
  %179 = fmul <8 x float> %wide.load3.9, %wide.load5.9
  %180 = fadd <8 x float> %178, %wide.load6.9
  %181 = fadd <8 x float> %179, %wide.load7.9
  %182 = fcmp ogt <8 x float> %180, zeroinitializer
  %183 = fcmp ogt <8 x float> %181, zeroinitializer
  %184 = zext <8 x i1> %182 to <8 x i32>
  %185 = zext <8 x i1> %183 to <8 x i32>
  %186 = getelementptr inbounds nuw i32, ptr %10, i64 %175
  %187 = getelementptr inbounds nuw i8, ptr %186, i64 32
  store <8 x i32> %184, ptr %186, align 4, !alias.scope !13, !noalias !18
  store <8 x i32> %185, ptr %187, align 4, !alias.scope !13, !noalias !18
  %188 = add nuw nsw i64 %58, 160
  %189 = getelementptr inbounds nuw float, ptr %6, i64 %188
  %190 = getelementptr inbounds nuw i8, ptr %189, i64 32
  %wide.load.10 = load <8 x float>, ptr %189, align 4, !invariant.load !3, !alias.scope !9, !noalias !17
  %wide.load3.10 = load <8 x float>, ptr %190, align 4, !invariant.load !3, !alias.scope !9, !noalias !17
  %191 = fmul <8 x float> %wide.load.10, %wide.load4.10
  %192 = fmul <8 x float> %wide.load3.10, %wide.load5.10
  %193 = fadd <8 x float> %191, %wide.load6.10
  %194 = fadd <8 x float> %192, %wide.load7.10
  %195 = fcmp ogt <8 x float> %193, zeroinitializer
  %196 = fcmp ogt <8 x float> %194, zeroinitializer
  %197 = zext <8 x i1> %195 to <8 x i32>
  %198 = zext <8 x i1> %196 to <8 x i32>
  %199 = getelementptr inbounds nuw i32, ptr %10, i64 %188
  %200 = getelementptr inbounds nuw i8, ptr %199, i64 32
  store <8 x i32> %197, ptr %199, align 4, !alias.scope !13, !noalias !18
  store <8 x i32> %198, ptr %200, align 4, !alias.scope !13, !noalias !18
  %201 = add nuw nsw i64 %58, 176
  %202 = getelementptr inbounds nuw float, ptr %6, i64 %201
  %203 = getelementptr inbounds nuw i8, ptr %202, i64 32
  %wide.load.11 = load <8 x float>, ptr %202, align 4, !invariant.load !3, !alias.scope !9, !noalias !17
  %wide.load3.11 = load <8 x float>, ptr %203, align 4, !invariant.load !3, !alias.scope !9, !noalias !17
  %204 = fmul <8 x float> %wide.load.11, %wide.load4.11
  %205 = fmul <8 x float> %wide.load3.11, %wide.load5.11
  %206 = fadd <8 x float> %204, %wide.load6.11
  %207 = fadd <8 x float> %205, %wide.load7.11
  %208 = fcmp ogt <8 x float> %206, zeroinitializer
  %209 = fcmp ogt <8 x float> %207, zeroinitializer
  %210 = zext <8 x i1> %208 to <8 x i32>
  %211 = zext <8 x i1> %209 to <8 x i32>
  %212 = getelementptr inbounds nuw i32, ptr %10, i64 %201
  %213 = getelementptr inbounds nuw i8, ptr %212, i64 32
  store <8 x i32> %210, ptr %212, align 4, !alias.scope !13, !noalias !18
  store <8 x i32> %211, ptr %213, align 4, !alias.scope !13, !noalias !18
  %214 = add nuw nsw i64 %57, 1
  %exitcond2.not = icmp eq i64 %214, 96
  br i1 %exitcond2.not, label %compare_convert_fusion.1_wrapped.exit, label %vector.ph, !llvm.loop !19

compare_convert_fusion.1_wrapped.exit:            ; preds = %vector.ph
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 1}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 768}
!5 = !{i64 73728}
!6 = !{!7}
!7 = distinct !{!7, !8, !"compare_convert_fusion.1_wrapped: argument 0"}
!8 = distinct !{!8, !"compare_convert_fusion.1_wrapped"}
!9 = !{!10}
!10 = distinct !{!10, !8, !"compare_convert_fusion.1_wrapped: argument 1"}
!11 = !{!12}
!12 = distinct !{!12, !8, !"compare_convert_fusion.1_wrapped: argument 2"}
!13 = !{!14}
!14 = distinct !{!14, !8, !"compare_convert_fusion.1_wrapped: argument 3"}
!15 = !{!7, !10, !14}
!16 = !{!10, !12, !14}
!17 = !{!7, !12, !14}
!18 = !{!7, !10, !12}
!19 = distinct !{!19, !20}
!20 = !{!"llvm.loop.unroll.disable"}
