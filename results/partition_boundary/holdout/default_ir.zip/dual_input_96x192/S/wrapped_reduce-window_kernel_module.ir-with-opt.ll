; ModuleID = '__compute_module_wrapped_reduce-window_kernel_module'
source_filename = "__compute_module_wrapped_reduce-window_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @wrapped_reduce-window(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !5
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !6
  tail call void @llvm.experimental.noalias.scope.decl(metadata !7)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !10)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !12)
  %9 = load i32, ptr %6, align 4, !invariant.load !3, !alias.scope !10, !noalias !14
  br label %.preheader3

.preheader3:                                      ; preds = %1, %112
  %10 = phi i64 [ 0, %1 ], [ %113, %112 ]
  %.idx1 = mul nuw nsw i64 %10, 768
  %11 = getelementptr i8, ptr %4, i64 %.idx1
  %.idx = mul nuw nsw i64 %10, 24
  %12 = getelementptr i8, ptr %8, i64 %.idx
  br label %.preheader

.preheader:                                       ; preds = %.preheader3, %.preheader
  %13 = phi i64 [ 0, %.preheader3 ], [ %111, %.preheader ]
  %.idx2 = shl i64 %13, 7
  %14 = getelementptr i8, ptr %11, i64 %.idx2
  %15 = load i32, ptr %14, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %16 = add i32 %15, %9
  %17 = getelementptr i8, ptr %14, i64 4
  %18 = load i32, ptr %17, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %19 = add i32 %18, %16
  %20 = getelementptr i8, ptr %14, i64 8
  %21 = load i32, ptr %20, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %22 = add i32 %21, %19
  %23 = getelementptr i8, ptr %14, i64 12
  %24 = load i32, ptr %23, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %25 = add i32 %24, %22
  %26 = getelementptr i8, ptr %14, i64 16
  %27 = load i32, ptr %26, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %28 = add i32 %27, %25
  %29 = getelementptr i8, ptr %14, i64 20
  %30 = load i32, ptr %29, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %31 = add i32 %30, %28
  %32 = getelementptr i8, ptr %14, i64 24
  %33 = load i32, ptr %32, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %34 = add i32 %33, %31
  %35 = getelementptr i8, ptr %14, i64 28
  %36 = load i32, ptr %35, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %37 = add i32 %36, %34
  %38 = getelementptr i8, ptr %14, i64 32
  %39 = load i32, ptr %38, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %40 = add i32 %39, %37
  %41 = getelementptr i8, ptr %14, i64 36
  %42 = load i32, ptr %41, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %43 = add i32 %42, %40
  %44 = getelementptr i8, ptr %14, i64 40
  %45 = load i32, ptr %44, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %46 = add i32 %45, %43
  %47 = getelementptr i8, ptr %14, i64 44
  %48 = load i32, ptr %47, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %49 = add i32 %48, %46
  %50 = getelementptr i8, ptr %14, i64 48
  %51 = load i32, ptr %50, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %52 = add i32 %51, %49
  %53 = getelementptr i8, ptr %14, i64 52
  %54 = load i32, ptr %53, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %55 = add i32 %54, %52
  %56 = getelementptr i8, ptr %14, i64 56
  %57 = load i32, ptr %56, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %58 = add i32 %57, %55
  %59 = getelementptr i8, ptr %14, i64 60
  %60 = load i32, ptr %59, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %61 = add i32 %60, %58
  %62 = getelementptr i8, ptr %14, i64 64
  %63 = load i32, ptr %62, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %64 = add i32 %63, %61
  %65 = getelementptr i8, ptr %14, i64 68
  %66 = load i32, ptr %65, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %67 = add i32 %66, %64
  %68 = getelementptr i8, ptr %14, i64 72
  %69 = load i32, ptr %68, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %70 = add i32 %69, %67
  %71 = getelementptr i8, ptr %14, i64 76
  %72 = load i32, ptr %71, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %73 = add i32 %72, %70
  %74 = getelementptr i8, ptr %14, i64 80
  %75 = load i32, ptr %74, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %76 = add i32 %75, %73
  %77 = getelementptr i8, ptr %14, i64 84
  %78 = load i32, ptr %77, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %79 = add i32 %78, %76
  %80 = getelementptr i8, ptr %14, i64 88
  %81 = load i32, ptr %80, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %82 = add i32 %81, %79
  %83 = getelementptr i8, ptr %14, i64 92
  %84 = load i32, ptr %83, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %85 = add i32 %84, %82
  %86 = getelementptr i8, ptr %14, i64 96
  %87 = load i32, ptr %86, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %88 = add i32 %87, %85
  %89 = getelementptr i8, ptr %14, i64 100
  %90 = load i32, ptr %89, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %91 = add i32 %90, %88
  %92 = getelementptr i8, ptr %14, i64 104
  %93 = load i32, ptr %92, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %94 = add i32 %93, %91
  %95 = getelementptr i8, ptr %14, i64 108
  %96 = load i32, ptr %95, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %97 = add i32 %96, %94
  %98 = getelementptr i8, ptr %14, i64 112
  %99 = load i32, ptr %98, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %100 = add i32 %99, %97
  %101 = getelementptr i8, ptr %14, i64 116
  %102 = load i32, ptr %101, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %103 = add i32 %102, %100
  %104 = getelementptr i8, ptr %14, i64 120
  %105 = load i32, ptr %104, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %106 = add i32 %105, %103
  %107 = getelementptr i8, ptr %14, i64 124
  %108 = load i32, ptr %107, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %109 = add i32 %108, %106
  %110 = getelementptr i32, ptr %12, i64 %13
  store i32 %109, ptr %110, align 4, !alias.scope !12, !noalias !16
  %111 = add nuw nsw i64 %13, 1
  %exitcond.not = icmp eq i64 %111, 6
  br i1 %exitcond.not, label %112, label %.preheader, !llvm.loop !17

112:                                              ; preds = %.preheader
  %113 = add nuw nsw i64 %10, 1
  %exitcond4.not = icmp eq i64 %113, 96
  br i1 %exitcond4.not, label %wrapped_reduce-window_wrapped.exit, label %.preheader3, !llvm.loop !17

wrapped_reduce-window_wrapped.exit:               ; preds = %112
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 3}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 73728}
!5 = !{i64 4}
!6 = !{i64 2304}
!7 = !{!8}
!8 = distinct !{!8, !9, !"wrapped_reduce-window_wrapped: argument 0"}
!9 = distinct !{!9, !"wrapped_reduce-window_wrapped"}
!10 = !{!11}
!11 = distinct !{!11, !9, !"wrapped_reduce-window_wrapped: argument 1"}
!12 = !{!13}
!13 = distinct !{!13, !9, !"wrapped_reduce-window_wrapped: argument 2"}
!14 = !{!8, !13}
!15 = !{!11, !13}
!16 = !{!8, !11}
!17 = distinct !{!17, !18}
!18 = !{!"llvm.loop.unroll.disable"}
