; ModuleID = '__compute_module_convert_reduce_fusion_kernel_module'
source_filename = "__compute_module_convert_reduce_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @convert_reduce_fusion(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !5
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !4
  %9 = getelementptr inbounds nuw i8, ptr %3, i64 48
  %10 = load ptr, ptr %9, align 8, !invariant.load !3, !dereferenceable !4
  %11 = getelementptr inbounds nuw i8, ptr %3, i64 64
  %12 = load ptr, ptr %11, align 8, !invariant.load !3, !dereferenceable !5
  %13 = getelementptr inbounds nuw i8, ptr %3, i64 80
  %14 = load ptr, ptr %13, align 8, !invariant.load !3, !dereferenceable !4
  tail call void @llvm.experimental.noalias.scope.decl(metadata !6)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !11)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !13)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !15)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !17)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !19)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !21)
  br label %vector.ph

vector.ph:                                        ; preds = %1, %middle.block
  %15 = phi i32 [ 0, %1 ], [ %89, %middle.block ]
  %16 = phi i32 [ 0, %1 ], [ %88, %middle.block ]
  %17 = phi i64 [ 0, %1 ], [ %90, %middle.block ]
  %18 = mul nuw nsw i64 %17, 192
  %19 = insertelement <8 x i32> <i32 poison, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0>, i32 %15, i64 0
  %20 = insertelement <8 x i32> <i32 poison, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0>, i32 %16, i64 0
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %vector.ph
  %index = phi i64 [ 0, %vector.ph ], [ %index.next.1, %vector.body ]
  %vec.phi = phi <8 x i32> [ %19, %vector.ph ], [ %85, %vector.body ]
  %vec.phi9 = phi <8 x i32> [ zeroinitializer, %vector.ph ], [ %86, %vector.body ]
  %vec.phi10 = phi <8 x i32> [ %20, %vector.ph ], [ %83, %vector.body ]
  %vec.phi11 = phi <8 x i32> [ zeroinitializer, %vector.ph ], [ %84, %vector.body ]
  %21 = add nuw nsw i64 %index, %18
  %22 = getelementptr inbounds nuw float, ptr %12, i64 %21
  %23 = getelementptr inbounds nuw i8, ptr %22, i64 32
  %wide.load = load <8 x float>, ptr %22, align 4, !invariant.load !3, !alias.scope !15, !noalias !23
  %wide.load12 = load <8 x float>, ptr %23, align 4, !invariant.load !3, !alias.scope !15, !noalias !23
  %24 = getelementptr inbounds nuw float, ptr %14, i64 %index
  %25 = getelementptr inbounds nuw i8, ptr %24, i64 32
  %wide.load13 = load <8 x float>, ptr %24, align 4, !invariant.load !3, !alias.scope !17, !noalias !24
  %wide.load14 = load <8 x float>, ptr %25, align 4, !invariant.load !3, !alias.scope !17, !noalias !24
  %26 = fmul <8 x float> %wide.load, %wide.load13
  %27 = fmul <8 x float> %wide.load12, %wide.load14
  %28 = getelementptr inbounds nuw float, ptr %10, i64 %index
  %29 = getelementptr inbounds nuw i8, ptr %28, i64 32
  %wide.load15 = load <8 x float>, ptr %28, align 4, !invariant.load !3, !alias.scope !13, !noalias !25
  %wide.load16 = load <8 x float>, ptr %29, align 4, !invariant.load !3, !alias.scope !13, !noalias !25
  %30 = fadd <8 x float> %26, %wide.load15
  %31 = fadd <8 x float> %27, %wide.load16
  %32 = fcmp ogt <8 x float> %30, zeroinitializer
  %33 = fcmp ogt <8 x float> %31, zeroinitializer
  %34 = zext <8 x i1> %32 to <8 x i32>
  %35 = zext <8 x i1> %33 to <8 x i32>
  %36 = getelementptr inbounds nuw float, ptr %6, i64 %21
  %37 = getelementptr inbounds nuw i8, ptr %36, i64 32
  %wide.load17 = load <8 x float>, ptr %36, align 4, !invariant.load !3, !alias.scope !9, !noalias !26
  %wide.load18 = load <8 x float>, ptr %37, align 4, !invariant.load !3, !alias.scope !9, !noalias !26
  %38 = getelementptr inbounds nuw float, ptr %8, i64 %index
  %39 = getelementptr inbounds nuw i8, ptr %38, i64 32
  %wide.load19 = load <8 x float>, ptr %38, align 4, !invariant.load !3, !alias.scope !11, !noalias !27
  %wide.load20 = load <8 x float>, ptr %39, align 4, !invariant.load !3, !alias.scope !11, !noalias !27
  %40 = fmul <8 x float> %wide.load17, %wide.load19
  %41 = fmul <8 x float> %wide.load18, %wide.load20
  %42 = getelementptr inbounds nuw float, ptr %4, i64 %index
  %43 = getelementptr inbounds nuw i8, ptr %42, i64 32
  %wide.load21 = load <8 x float>, ptr %42, align 4, !invariant.load !3, !alias.scope !6, !noalias !28
  %wide.load22 = load <8 x float>, ptr %43, align 4, !invariant.load !3, !alias.scope !6, !noalias !28
  %44 = fadd <8 x float> %40, %wide.load21
  %45 = fadd <8 x float> %41, %wide.load22
  %46 = fcmp ogt <8 x float> %44, zeroinitializer
  %47 = fcmp ogt <8 x float> %45, zeroinitializer
  %48 = zext <8 x i1> %46 to <8 x i32>
  %49 = zext <8 x i1> %47 to <8 x i32>
  %50 = add <8 x i32> %vec.phi10, %34
  %51 = add <8 x i32> %vec.phi11, %35
  %52 = add <8 x i32> %vec.phi, %48
  %53 = add <8 x i32> %vec.phi9, %49
  %index.next = or disjoint i64 %index, 16
  %54 = add nuw nsw i64 %index.next, %18
  %55 = getelementptr inbounds nuw float, ptr %12, i64 %54
  %56 = getelementptr inbounds nuw i8, ptr %55, i64 32
  %wide.load.1 = load <8 x float>, ptr %55, align 4, !invariant.load !3, !alias.scope !15, !noalias !23
  %wide.load12.1 = load <8 x float>, ptr %56, align 4, !invariant.load !3, !alias.scope !15, !noalias !23
  %57 = getelementptr inbounds nuw float, ptr %14, i64 %index.next
  %58 = getelementptr inbounds nuw i8, ptr %57, i64 32
  %wide.load13.1 = load <8 x float>, ptr %57, align 4, !invariant.load !3, !alias.scope !17, !noalias !24
  %wide.load14.1 = load <8 x float>, ptr %58, align 4, !invariant.load !3, !alias.scope !17, !noalias !24
  %59 = fmul <8 x float> %wide.load.1, %wide.load13.1
  %60 = fmul <8 x float> %wide.load12.1, %wide.load14.1
  %61 = getelementptr inbounds nuw float, ptr %10, i64 %index.next
  %62 = getelementptr inbounds nuw i8, ptr %61, i64 32
  %wide.load15.1 = load <8 x float>, ptr %61, align 4, !invariant.load !3, !alias.scope !13, !noalias !25
  %wide.load16.1 = load <8 x float>, ptr %62, align 4, !invariant.load !3, !alias.scope !13, !noalias !25
  %63 = fadd <8 x float> %59, %wide.load15.1
  %64 = fadd <8 x float> %60, %wide.load16.1
  %65 = fcmp ogt <8 x float> %63, zeroinitializer
  %66 = fcmp ogt <8 x float> %64, zeroinitializer
  %67 = zext <8 x i1> %65 to <8 x i32>
  %68 = zext <8 x i1> %66 to <8 x i32>
  %69 = getelementptr inbounds nuw float, ptr %6, i64 %54
  %70 = getelementptr inbounds nuw i8, ptr %69, i64 32
  %wide.load17.1 = load <8 x float>, ptr %69, align 4, !invariant.load !3, !alias.scope !9, !noalias !26
  %wide.load18.1 = load <8 x float>, ptr %70, align 4, !invariant.load !3, !alias.scope !9, !noalias !26
  %71 = getelementptr inbounds nuw float, ptr %8, i64 %index.next
  %72 = getelementptr inbounds nuw i8, ptr %71, i64 32
  %wide.load19.1 = load <8 x float>, ptr %71, align 4, !invariant.load !3, !alias.scope !11, !noalias !27
  %wide.load20.1 = load <8 x float>, ptr %72, align 4, !invariant.load !3, !alias.scope !11, !noalias !27
  %73 = fmul <8 x float> %wide.load17.1, %wide.load19.1
  %74 = fmul <8 x float> %wide.load18.1, %wide.load20.1
  %75 = getelementptr inbounds nuw float, ptr %4, i64 %index.next
  %76 = getelementptr inbounds nuw i8, ptr %75, i64 32
  %wide.load21.1 = load <8 x float>, ptr %75, align 4, !invariant.load !3, !alias.scope !6, !noalias !28
  %wide.load22.1 = load <8 x float>, ptr %76, align 4, !invariant.load !3, !alias.scope !6, !noalias !28
  %77 = fadd <8 x float> %73, %wide.load21.1
  %78 = fadd <8 x float> %74, %wide.load22.1
  %79 = fcmp ogt <8 x float> %77, zeroinitializer
  %80 = fcmp ogt <8 x float> %78, zeroinitializer
  %81 = zext <8 x i1> %79 to <8 x i32>
  %82 = zext <8 x i1> %80 to <8 x i32>
  %83 = add <8 x i32> %50, %67
  %84 = add <8 x i32> %51, %68
  %85 = add <8 x i32> %52, %81
  %86 = add <8 x i32> %53, %82
  %index.next.1 = add nuw nsw i64 %index, 32
  %87 = icmp eq i64 %index.next.1, 192
  br i1 %87, label %middle.block, label %vector.body, !llvm.loop !29

middle.block:                                     ; preds = %vector.body
  %bin.rdx23 = add <8 x i32> %84, %83
  %88 = tail call i32 @llvm.vector.reduce.add.v8i32(<8 x i32> %bin.rdx23)
  %bin.rdx = add <8 x i32> %86, %85
  %89 = tail call i32 @llvm.vector.reduce.add.v8i32(<8 x i32> %bin.rdx)
  %90 = add nuw nsw i64 %17, 1
  %exitcond6.not = icmp eq i64 %90, 96
  br i1 %exitcond6.not, label %convert_reduce_fusion_wrapped.exit, label %vector.ph, !llvm.loop !32

convert_reduce_fusion_wrapped.exit:               ; preds = %middle.block
  %91 = getelementptr inbounds nuw i8, ptr %3, i64 112
  %92 = load ptr, ptr %91, align 8, !invariant.load !3, !dereferenceable !34
  %93 = getelementptr inbounds nuw i8, ptr %3, i64 96
  %94 = load ptr, ptr %93, align 8, !invariant.load !3, !dereferenceable !34
  store i32 %88, ptr %94, align 4, !alias.scope !19, !noalias !35
  store i32 %89, ptr %92, align 4, !alias.scope !21, !noalias !36
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.vector.reduce.add.v8i32(<8 x i32>) #2

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #2 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 1}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 768}
!5 = !{i64 73728}
!6 = !{!7}
!7 = distinct !{!7, !8, !"convert_reduce_fusion_wrapped: argument 0"}
!8 = distinct !{!8, !"convert_reduce_fusion_wrapped"}
!9 = !{!10}
!10 = distinct !{!10, !8, !"convert_reduce_fusion_wrapped: argument 1"}
!11 = !{!12}
!12 = distinct !{!12, !8, !"convert_reduce_fusion_wrapped: argument 2"}
!13 = !{!14}
!14 = distinct !{!14, !8, !"convert_reduce_fusion_wrapped: argument 3"}
!15 = !{!16}
!16 = distinct !{!16, !8, !"convert_reduce_fusion_wrapped: argument 4"}
!17 = !{!18}
!18 = distinct !{!18, !8, !"convert_reduce_fusion_wrapped: argument 5"}
!19 = !{!20}
!20 = distinct !{!20, !8, !"convert_reduce_fusion_wrapped: argument 6"}
!21 = !{!22}
!22 = distinct !{!22, !8, !"convert_reduce_fusion_wrapped: argument 7"}
!23 = !{!7, !10, !12, !14, !18, !20, !22}
!24 = !{!7, !10, !12, !14, !16, !20, !22}
!25 = !{!7, !10, !12, !16, !18, !20, !22}
!26 = !{!7, !12, !14, !16, !18, !20, !22}
!27 = !{!7, !10, !14, !16, !18, !20, !22}
!28 = !{!10, !12, !14, !16, !18, !20, !22}
!29 = distinct !{!29, !30, !31}
!30 = !{!"llvm.loop.isvectorized", i32 1}
!31 = !{!"llvm.loop.unroll.runtime.disable"}
!32 = distinct !{!32, !33}
!33 = !{!"llvm.loop.unroll.disable"}
!34 = !{i64 4}
!35 = !{!7, !10, !12, !14, !16, !18, !22}
!36 = !{!7, !10, !12, !14, !16, !18, !20}
