; ModuleID = '__compute_module_shift-left_add_fusion_kernel_module'
source_filename = "__compute_module_shift-left_add_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @shift-left_add_fusion(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !5
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !4
  %9 = getelementptr inbounds nuw i8, ptr %3, i64 48
  %10 = load ptr, ptr %9, align 8, !invariant.load !3, !dereferenceable !4
  %11 = getelementptr inbounds nuw i8, ptr %3, i64 64
  %12 = load ptr, ptr %11, align 8, !invariant.load !3, !dereferenceable !5
  %13 = getelementptr inbounds nuw i8, ptr %3, i64 80
  %14 = load ptr, ptr %13, align 8, !invariant.load !3, !dereferenceable !4
  %15 = getelementptr inbounds nuw i8, ptr %3, i64 96
  %16 = load ptr, ptr %15, align 8, !invariant.load !3, !dereferenceable !5
  tail call void @llvm.experimental.noalias.scope.decl(metadata !6)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !11)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !13)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !15)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !17)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !19)
  br label %vector.ph

vector.ph:                                        ; preds = %1, %middle.block
  %17 = phi i64 [ 0, %1 ], [ %71, %middle.block ]
  %18 = mul nuw nsw i64 %17, 192
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %vector.ph
  %index = phi i64 [ 0, %vector.ph ], [ %index.next.2, %vector.body ]
  %19 = add nuw nsw i64 %index, %18
  %20 = getelementptr inbounds nuw float, ptr %6, i64 %19
  %wide.load = load <8 x float>, ptr %20, align 4, !invariant.load !3, !alias.scope !9, !noalias !21
  %21 = getelementptr inbounds nuw float, ptr %8, i64 %index
  %wide.load3 = load <8 x float>, ptr %21, align 4, !invariant.load !3, !alias.scope !11, !noalias !22
  %22 = getelementptr inbounds nuw float, ptr %12, i64 %19
  %wide.load4 = load <8 x float>, ptr %22, align 4, !invariant.load !3, !alias.scope !15, !noalias !23
  %23 = getelementptr inbounds nuw float, ptr %14, i64 %index
  %wide.load5 = load <8 x float>, ptr %23, align 4, !invariant.load !3, !alias.scope !17, !noalias !24
  %24 = fmul <8 x float> %wide.load, %wide.load3
  %25 = getelementptr inbounds nuw float, ptr %4, i64 %index
  %wide.load6 = load <8 x float>, ptr %25, align 4, !invariant.load !3, !alias.scope !6, !noalias !25
  %26 = fmul <8 x float> %wide.load4, %wide.load5
  %27 = getelementptr inbounds nuw float, ptr %10, i64 %index
  %wide.load7 = load <8 x float>, ptr %27, align 4, !invariant.load !3, !alias.scope !13, !noalias !26
  %28 = fadd <8 x float> %24, %wide.load6
  %29 = fadd <8 x float> %26, %wide.load7
  %30 = fcmp ogt <8 x float> %28, zeroinitializer
  %31 = fcmp ogt <8 x float> %29, zeroinitializer
  %32 = zext <8 x i1> %31 to <8 x i32>
  %33 = select <8 x i1> %30, <8 x i32> splat (i32 256), <8 x i32> zeroinitializer
  %34 = or disjoint <8 x i32> %33, %32
  %35 = getelementptr inbounds nuw i32, ptr %16, i64 %19
  store <8 x i32> %34, ptr %35, align 4, !alias.scope !19, !noalias !27
  %index.next = add nuw nsw i64 %index, 8
  %36 = add nuw nsw i64 %index.next, %18
  %37 = getelementptr inbounds nuw float, ptr %6, i64 %36
  %wide.load.1 = load <8 x float>, ptr %37, align 4, !invariant.load !3, !alias.scope !9, !noalias !21
  %38 = getelementptr inbounds nuw float, ptr %8, i64 %index.next
  %wide.load3.1 = load <8 x float>, ptr %38, align 4, !invariant.load !3, !alias.scope !11, !noalias !22
  %39 = getelementptr inbounds nuw float, ptr %12, i64 %36
  %wide.load4.1 = load <8 x float>, ptr %39, align 4, !invariant.load !3, !alias.scope !15, !noalias !23
  %40 = getelementptr inbounds nuw float, ptr %14, i64 %index.next
  %wide.load5.1 = load <8 x float>, ptr %40, align 4, !invariant.load !3, !alias.scope !17, !noalias !24
  %41 = fmul <8 x float> %wide.load.1, %wide.load3.1
  %42 = getelementptr inbounds nuw float, ptr %4, i64 %index.next
  %wide.load6.1 = load <8 x float>, ptr %42, align 4, !invariant.load !3, !alias.scope !6, !noalias !25
  %43 = fmul <8 x float> %wide.load4.1, %wide.load5.1
  %44 = getelementptr inbounds nuw float, ptr %10, i64 %index.next
  %wide.load7.1 = load <8 x float>, ptr %44, align 4, !invariant.load !3, !alias.scope !13, !noalias !26
  %45 = fadd <8 x float> %41, %wide.load6.1
  %46 = fadd <8 x float> %43, %wide.load7.1
  %47 = fcmp ogt <8 x float> %45, zeroinitializer
  %48 = fcmp ogt <8 x float> %46, zeroinitializer
  %49 = zext <8 x i1> %48 to <8 x i32>
  %50 = select <8 x i1> %47, <8 x i32> splat (i32 256), <8 x i32> zeroinitializer
  %51 = or disjoint <8 x i32> %50, %49
  %52 = getelementptr inbounds nuw i32, ptr %16, i64 %36
  store <8 x i32> %51, ptr %52, align 4, !alias.scope !19, !noalias !27
  %index.next.1 = add nuw nsw i64 %index, 16
  %53 = add nuw nsw i64 %index.next.1, %18
  %54 = getelementptr inbounds nuw float, ptr %6, i64 %53
  %wide.load.2 = load <8 x float>, ptr %54, align 4, !invariant.load !3, !alias.scope !9, !noalias !21
  %55 = getelementptr inbounds nuw float, ptr %8, i64 %index.next.1
  %wide.load3.2 = load <8 x float>, ptr %55, align 4, !invariant.load !3, !alias.scope !11, !noalias !22
  %56 = getelementptr inbounds nuw float, ptr %12, i64 %53
  %wide.load4.2 = load <8 x float>, ptr %56, align 4, !invariant.load !3, !alias.scope !15, !noalias !23
  %57 = getelementptr inbounds nuw float, ptr %14, i64 %index.next.1
  %wide.load5.2 = load <8 x float>, ptr %57, align 4, !invariant.load !3, !alias.scope !17, !noalias !24
  %58 = fmul <8 x float> %wide.load.2, %wide.load3.2
  %59 = getelementptr inbounds nuw float, ptr %4, i64 %index.next.1
  %wide.load6.2 = load <8 x float>, ptr %59, align 4, !invariant.load !3, !alias.scope !6, !noalias !25
  %60 = fmul <8 x float> %wide.load4.2, %wide.load5.2
  %61 = getelementptr inbounds nuw float, ptr %10, i64 %index.next.1
  %wide.load7.2 = load <8 x float>, ptr %61, align 4, !invariant.load !3, !alias.scope !13, !noalias !26
  %62 = fadd <8 x float> %58, %wide.load6.2
  %63 = fadd <8 x float> %60, %wide.load7.2
  %64 = fcmp ogt <8 x float> %62, zeroinitializer
  %65 = fcmp ogt <8 x float> %63, zeroinitializer
  %66 = zext <8 x i1> %65 to <8 x i32>
  %67 = select <8 x i1> %64, <8 x i32> splat (i32 256), <8 x i32> zeroinitializer
  %68 = or disjoint <8 x i32> %67, %66
  %69 = getelementptr inbounds nuw i32, ptr %16, i64 %53
  store <8 x i32> %68, ptr %69, align 4, !alias.scope !19, !noalias !27
  %index.next.2 = add nuw nsw i64 %index, 24
  %70 = icmp eq i64 %index.next.2, 192
  br i1 %70, label %middle.block, label %vector.body, !llvm.loop !28

middle.block:                                     ; preds = %vector.body
  %71 = add nuw nsw i64 %17, 1
  %exitcond2.not = icmp eq i64 %71, 96
  br i1 %exitcond2.not, label %shift-left_add_fusion_wrapped.exit, label %vector.ph, !llvm.loop !31

shift-left_add_fusion_wrapped.exit:               ; preds = %middle.block
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 2}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 768}
!5 = !{i64 73728}
!6 = !{!7}
!7 = distinct !{!7, !8, !"shift-left_add_fusion_wrapped: argument 0"}
!8 = distinct !{!8, !"shift-left_add_fusion_wrapped"}
!9 = !{!10}
!10 = distinct !{!10, !8, !"shift-left_add_fusion_wrapped: argument 1"}
!11 = !{!12}
!12 = distinct !{!12, !8, !"shift-left_add_fusion_wrapped: argument 2"}
!13 = !{!14}
!14 = distinct !{!14, !8, !"shift-left_add_fusion_wrapped: argument 3"}
!15 = !{!16}
!16 = distinct !{!16, !8, !"shift-left_add_fusion_wrapped: argument 4"}
!17 = !{!18}
!18 = distinct !{!18, !8, !"shift-left_add_fusion_wrapped: argument 5"}
!19 = !{!20}
!20 = distinct !{!20, !8, !"shift-left_add_fusion_wrapped: argument 6"}
!21 = !{!7, !12, !14, !16, !18, !20}
!22 = !{!7, !10, !14, !16, !18, !20}
!23 = !{!7, !10, !12, !14, !18, !20}
!24 = !{!7, !10, !12, !14, !16, !20}
!25 = !{!10, !12, !14, !16, !18, !20}
!26 = !{!7, !10, !12, !16, !18, !20}
!27 = !{!7, !10, !12, !14, !16, !18}
!28 = distinct !{!28, !29, !30}
!29 = !{!"llvm.loop.isvectorized", i32 1}
!30 = !{!"llvm.loop.unroll.runtime.disable"}
!31 = distinct !{!31, !32}
!32 = !{!"llvm.loop.unroll.disable"}
