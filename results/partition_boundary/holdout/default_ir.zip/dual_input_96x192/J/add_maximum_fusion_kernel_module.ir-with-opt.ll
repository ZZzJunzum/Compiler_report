; ModuleID = '__compute_module_add_maximum_fusion_kernel_module'
source_filename = "__compute_module_add_maximum_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @add_maximum_fusion(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !5
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !4
  %9 = getelementptr inbounds nuw i8, ptr %3, i64 48
  %10 = load ptr, ptr %9, align 8, !invariant.load !3, !dereferenceable !4
  %11 = getelementptr inbounds nuw i8, ptr %3, i64 64
  %12 = load ptr, ptr %11, align 8, !invariant.load !3, !dereferenceable !5
  %13 = getelementptr inbounds nuw i8, ptr %3, i64 80
  %14 = load ptr, ptr %13, align 8, !invariant.load !3, !dereferenceable !4
  %15 = getelementptr inbounds nuw i8, ptr %3, i64 96
  %16 = load ptr, ptr %15, align 8, !invariant.load !3, !dereferenceable !5
  tail call void @llvm.experimental.noalias.scope.decl(metadata !6)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !11)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !13)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !15)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !17)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !19)
  br label %vector.ph

vector.ph:                                        ; preds = %1, %middle.block
  %17 = phi i64 [ 0, %1 ], [ %70, %middle.block ]
  %18 = mul nuw nsw i64 %17, 192
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %vector.ph
  %index = phi i64 [ 0, %vector.ph ], [ %index.next.1, %vector.body ]
  %19 = add nuw nsw i64 %index, %18
  %20 = getelementptr inbounds nuw float, ptr %12, i64 %19
  %21 = getelementptr inbounds nuw i8, ptr %20, i64 32
  %wide.load = load <8 x float>, ptr %20, align 4, !invariant.load !3, !alias.scope !15, !noalias !21
  %wide.load3 = load <8 x float>, ptr %21, align 4, !invariant.load !3, !alias.scope !15, !noalias !21
  %22 = getelementptr inbounds nuw float, ptr %14, i64 %index
  %23 = getelementptr inbounds nuw i8, ptr %22, i64 32
  %wide.load4 = load <8 x float>, ptr %22, align 4, !invariant.load !3, !alias.scope !17, !noalias !22
  %wide.load5 = load <8 x float>, ptr %23, align 4, !invariant.load !3, !alias.scope !17, !noalias !22
  %24 = getelementptr inbounds nuw float, ptr %6, i64 %19
  %25 = getelementptr inbounds nuw i8, ptr %24, i64 32
  %wide.load6 = load <8 x float>, ptr %24, align 4, !invariant.load !3, !alias.scope !9, !noalias !23
  %wide.load7 = load <8 x float>, ptr %25, align 4, !invariant.load !3, !alias.scope !9, !noalias !23
  %26 = getelementptr inbounds nuw float, ptr %8, i64 %index
  %27 = getelementptr inbounds nuw i8, ptr %26, i64 32
  %wide.load8 = load <8 x float>, ptr %26, align 4, !invariant.load !3, !alias.scope !11, !noalias !24
  %wide.load9 = load <8 x float>, ptr %27, align 4, !invariant.load !3, !alias.scope !11, !noalias !24
  %28 = fmul <8 x float> %wide.load, %wide.load4
  %29 = fmul <8 x float> %wide.load3, %wide.load5
  %30 = getelementptr inbounds nuw float, ptr %10, i64 %index
  %31 = getelementptr inbounds nuw i8, ptr %30, i64 32
  %wide.load10 = load <8 x float>, ptr %30, align 4, !invariant.load !3, !alias.scope !13, !noalias !25
  %wide.load11 = load <8 x float>, ptr %31, align 4, !invariant.load !3, !alias.scope !13, !noalias !25
  %32 = fmul <8 x float> %wide.load6, %wide.load8
  %33 = fmul <8 x float> %wide.load7, %wide.load9
  %34 = getelementptr inbounds nuw float, ptr %4, i64 %index
  %35 = getelementptr inbounds nuw i8, ptr %34, i64 32
  %wide.load12 = load <8 x float>, ptr %34, align 4, !invariant.load !3, !alias.scope !6, !noalias !26
  %wide.load13 = load <8 x float>, ptr %35, align 4, !invariant.load !3, !alias.scope !6, !noalias !26
  %36 = fadd <8 x float> %28, %wide.load10
  %37 = fadd <8 x float> %29, %wide.load11
  %38 = fadd <8 x float> %32, %wide.load12
  %39 = fadd <8 x float> %33, %wide.load13
  %40 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %36, <8 x float> %38)
  %41 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %37, <8 x float> %39)
  %42 = getelementptr inbounds nuw float, ptr %16, i64 %19
  %43 = getelementptr inbounds nuw i8, ptr %42, i64 32
  store <8 x float> %40, ptr %42, align 4, !alias.scope !19, !noalias !27
  store <8 x float> %41, ptr %43, align 4, !alias.scope !19, !noalias !27
  %index.next = or disjoint i64 %index, 16
  %44 = add nuw nsw i64 %index.next, %18
  %45 = getelementptr inbounds nuw float, ptr %12, i64 %44
  %46 = getelementptr inbounds nuw i8, ptr %45, i64 32
  %wide.load.1 = load <8 x float>, ptr %45, align 4, !invariant.load !3, !alias.scope !15, !noalias !21
  %wide.load3.1 = load <8 x float>, ptr %46, align 4, !invariant.load !3, !alias.scope !15, !noalias !21
  %47 = getelementptr inbounds nuw float, ptr %14, i64 %index.next
  %48 = getelementptr inbounds nuw i8, ptr %47, i64 32
  %wide.load4.1 = load <8 x float>, ptr %47, align 4, !invariant.load !3, !alias.scope !17, !noalias !22
  %wide.load5.1 = load <8 x float>, ptr %48, align 4, !invariant.load !3, !alias.scope !17, !noalias !22
  %49 = getelementptr inbounds nuw float, ptr %6, i64 %44
  %50 = getelementptr inbounds nuw i8, ptr %49, i64 32
  %wide.load6.1 = load <8 x float>, ptr %49, align 4, !invariant.load !3, !alias.scope !9, !noalias !23
  %wide.load7.1 = load <8 x float>, ptr %50, align 4, !invariant.load !3, !alias.scope !9, !noalias !23
  %51 = getelementptr inbounds nuw float, ptr %8, i64 %index.next
  %52 = getelementptr inbounds nuw i8, ptr %51, i64 32
  %wide.load8.1 = load <8 x float>, ptr %51, align 4, !invariant.load !3, !alias.scope !11, !noalias !24
  %wide.load9.1 = load <8 x float>, ptr %52, align 4, !invariant.load !3, !alias.scope !11, !noalias !24
  %53 = fmul <8 x float> %wide.load.1, %wide.load4.1
  %54 = fmul <8 x float> %wide.load3.1, %wide.load5.1
  %55 = getelementptr inbounds nuw float, ptr %10, i64 %index.next
  %56 = getelementptr inbounds nuw i8, ptr %55, i64 32
  %wide.load10.1 = load <8 x float>, ptr %55, align 4, !invariant.load !3, !alias.scope !13, !noalias !25
  %wide.load11.1 = load <8 x float>, ptr %56, align 4, !invariant.load !3, !alias.scope !13, !noalias !25
  %57 = fmul <8 x float> %wide.load6.1, %wide.load8.1
  %58 = fmul <8 x float> %wide.load7.1, %wide.load9.1
  %59 = getelementptr inbounds nuw float, ptr %4, i64 %index.next
  %60 = getelementptr inbounds nuw i8, ptr %59, i64 32
  %wide.load12.1 = load <8 x float>, ptr %59, align 4, !invariant.load !3, !alias.scope !6, !noalias !26
  %wide.load13.1 = load <8 x float>, ptr %60, align 4, !invariant.load !3, !alias.scope !6, !noalias !26
  %61 = fadd <8 x float> %53, %wide.load10.1
  %62 = fadd <8 x float> %54, %wide.load11.1
  %63 = fadd <8 x float> %57, %wide.load12.1
  %64 = fadd <8 x float> %58, %wide.load13.1
  %65 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %61, <8 x float> %63)
  %66 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %62, <8 x float> %64)
  %67 = getelementptr inbounds nuw float, ptr %16, i64 %44
  %68 = getelementptr inbounds nuw i8, ptr %67, i64 32
  store <8 x float> %65, ptr %67, align 4, !alias.scope !19, !noalias !27
  store <8 x float> %66, ptr %68, align 4, !alias.scope !19, !noalias !27
  %index.next.1 = add nuw nsw i64 %index, 32
  %69 = icmp eq i64 %index.next.1, 192
  br i1 %69, label %middle.block, label %vector.body, !llvm.loop !28

middle.block:                                     ; preds = %vector.body
  %70 = add nuw nsw i64 %17, 1
  %exitcond2.not = icmp eq i64 %70, 96
  br i1 %exitcond2.not, label %add_maximum_fusion_wrapped.exit, label %vector.ph, !llvm.loop !31

add_maximum_fusion_wrapped.exit:                  ; preds = %middle.block
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.maximum.v8f32(<8 x float>, <8 x float>) #2

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 0}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 768}
!5 = !{i64 73728}
!6 = !{!7}
!7 = distinct !{!7, !8, !"add_maximum_fusion_wrapped: argument 0"}
!8 = distinct !{!8, !"add_maximum_fusion_wrapped"}
!9 = !{!10}
!10 = distinct !{!10, !8, !"add_maximum_fusion_wrapped: argument 1"}
!11 = !{!12}
!12 = distinct !{!12, !8, !"add_maximum_fusion_wrapped: argument 2"}
!13 = !{!14}
!14 = distinct !{!14, !8, !"add_maximum_fusion_wrapped: argument 3"}
!15 = !{!16}
!16 = distinct !{!16, !8, !"add_maximum_fusion_wrapped: argument 4"}
!17 = !{!18}
!18 = distinct !{!18, !8, !"add_maximum_fusion_wrapped: argument 5"}
!19 = !{!20}
!20 = distinct !{!20, !8, !"add_maximum_fusion_wrapped: argument 6"}
!21 = !{!7, !10, !12, !14, !18, !20}
!22 = !{!7, !10, !12, !14, !16, !20}
!23 = !{!7, !12, !14, !16, !18, !20}
!24 = !{!7, !10, !14, !16, !18, !20}
!25 = !{!7, !10, !12, !16, !18, !20}
!26 = !{!10, !12, !14, !16, !18, !20}
!27 = !{!7, !10, !12, !14, !16, !18}
!28 = distinct !{!28, !29, !30}
!29 = !{!"llvm.loop.isvectorized", i32 1}
!30 = !{!"llvm.loop.unroll.runtime.disable"}
!31 = distinct !{!31, !32}
!32 = !{!"llvm.loop.unroll.disable"}
