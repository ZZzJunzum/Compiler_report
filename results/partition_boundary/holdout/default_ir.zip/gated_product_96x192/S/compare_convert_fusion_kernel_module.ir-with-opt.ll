; ModuleID = '__compute_module_compare_convert_fusion_kernel_module'
source_filename = "__compute_module_compare_convert_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @compare_convert_fusion(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !5
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !4
  %9 = getelementptr inbounds nuw i8, ptr %3, i64 48
  %10 = load ptr, ptr %9, align 8, !invariant.load !3, !dereferenceable !5
  %11 = getelementptr inbounds nuw i8, ptr %3, i64 64
  %12 = load ptr, ptr %11, align 8, !invariant.load !3, !dereferenceable !4
  tail call void @llvm.experimental.noalias.scope.decl(metadata !6)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !11)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !13)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !15)
  %13 = getelementptr inbounds nuw i8, ptr %10, i64 32
  %wide.load4 = load <8 x float>, ptr %10, align 4, !invariant.load !3, !alias.scope !13, !noalias !17
  %wide.load5 = load <8 x float>, ptr %13, align 4, !invariant.load !3, !alias.scope !13, !noalias !17
  %14 = getelementptr inbounds nuw i8, ptr %6, i64 32
  %wide.load6 = load <8 x float>, ptr %6, align 4, !invariant.load !3, !alias.scope !9, !noalias !18
  %wide.load7 = load <8 x float>, ptr %14, align 4, !invariant.load !3, !alias.scope !9, !noalias !18
  %15 = getelementptr inbounds nuw i8, ptr %10, i64 64
  %16 = getelementptr inbounds nuw i8, ptr %10, i64 96
  %wide.load4.1 = load <8 x float>, ptr %15, align 4, !invariant.load !3, !alias.scope !13, !noalias !17
  %wide.load5.1 = load <8 x float>, ptr %16, align 4, !invariant.load !3, !alias.scope !13, !noalias !17
  %17 = getelementptr inbounds nuw i8, ptr %6, i64 64
  %18 = getelementptr inbounds nuw i8, ptr %6, i64 96
  %wide.load6.1 = load <8 x float>, ptr %17, align 4, !invariant.load !3, !alias.scope !9, !noalias !18
  %wide.load7.1 = load <8 x float>, ptr %18, align 4, !invariant.load !3, !alias.scope !9, !noalias !18
  %19 = getelementptr inbounds nuw i8, ptr %10, i64 128
  %20 = getelementptr inbounds nuw i8, ptr %10, i64 160
  %wide.load4.2 = load <8 x float>, ptr %19, align 4, !invariant.load !3, !alias.scope !13, !noalias !17
  %wide.load5.2 = load <8 x float>, ptr %20, align 4, !invariant.load !3, !alias.scope !13, !noalias !17
  %21 = getelementptr inbounds nuw i8, ptr %6, i64 128
  %22 = getelementptr inbounds nuw i8, ptr %6, i64 160
  %wide.load6.2 = load <8 x float>, ptr %21, align 4, !invariant.load !3, !alias.scope !9, !noalias !18
  %wide.load7.2 = load <8 x float>, ptr %22, align 4, !invariant.load !3, !alias.scope !9, !noalias !18
  %23 = getelementptr inbounds nuw i8, ptr %10, i64 192
  %24 = getelementptr inbounds nuw i8, ptr %10, i64 224
  %wide.load4.3 = load <8 x float>, ptr %23, align 4, !invariant.load !3, !alias.scope !13, !noalias !17
  %wide.load5.3 = load <8 x float>, ptr %24, align 4, !invariant.load !3, !alias.scope !13, !noalias !17
  %25 = getelementptr inbounds nuw i8, ptr %6, i64 192
  %26 = getelementptr inbounds nuw i8, ptr %6, i64 224
  %wide.load6.3 = load <8 x float>, ptr %25, align 4, !invariant.load !3, !alias.scope !9, !noalias !18
  %wide.load7.3 = load <8 x float>, ptr %26, align 4, !invariant.load !3, !alias.scope !9, !noalias !18
  %27 = getelementptr inbounds nuw i8, ptr %10, i64 256
  %28 = getelementptr inbounds nuw i8, ptr %10, i64 288
  %wide.load4.4 = load <8 x float>, ptr %27, align 4, !invariant.load !3, !alias.scope !13, !noalias !17
  %wide.load5.4 = load <8 x float>, ptr %28, align 4, !invariant.load !3, !alias.scope !13, !noalias !17
  %29 = getelementptr inbounds nuw i8, ptr %6, i64 256
  %30 = getelementptr inbounds nuw i8, ptr %6, i64 288
  %wide.load6.4 = load <8 x float>, ptr %29, align 4, !invariant.load !3, !alias.scope !9, !noalias !18
  %wide.load7.4 = load <8 x float>, ptr %30, align 4, !invariant.load !3, !alias.scope !9, !noalias !18
  %31 = getelementptr inbounds nuw i8, ptr %10, i64 320
  %32 = getelementptr inbounds nuw i8, ptr %10, i64 352
  %wide.load4.5 = load <8 x float>, ptr %31, align 4, !invariant.load !3, !alias.scope !13, !noalias !17
  %wide.load5.5 = load <8 x float>, ptr %32, align 4, !invariant.load !3, !alias.scope !13, !noalias !17
  %33 = getelementptr inbounds nuw i8, ptr %6, i64 320
  %34 = getelementptr inbounds nuw i8, ptr %6, i64 352
  %wide.load6.5 = load <8 x float>, ptr %33, align 4, !invariant.load !3, !alias.scope !9, !noalias !18
  %wide.load7.5 = load <8 x float>, ptr %34, align 4, !invariant.load !3, !alias.scope !9, !noalias !18
  %35 = getelementptr inbounds nuw i8, ptr %10, i64 384
  %36 = getelementptr inbounds nuw i8, ptr %10, i64 416
  %wide.load4.6 = load <8 x float>, ptr %35, align 4, !invariant.load !3, !alias.scope !13, !noalias !17
  %wide.load5.6 = load <8 x float>, ptr %36, align 4, !invariant.load !3, !alias.scope !13, !noalias !17
  %37 = getelementptr inbounds nuw i8, ptr %6, i64 384
  %38 = getelementptr inbounds nuw i8, ptr %6, i64 416
  %wide.load6.6 = load <8 x float>, ptr %37, align 4, !invariant.load !3, !alias.scope !9, !noalias !18
  %wide.load7.6 = load <8 x float>, ptr %38, align 4, !invariant.load !3, !alias.scope !9, !noalias !18
  %39 = getelementptr inbounds nuw i8, ptr %10, i64 448
  %40 = getelementptr inbounds nuw i8, ptr %10, i64 480
  %wide.load4.7 = load <8 x float>, ptr %39, align 4, !invariant.load !3, !alias.scope !13, !noalias !17
  %wide.load5.7 = load <8 x float>, ptr %40, align 4, !invariant.load !3, !alias.scope !13, !noalias !17
  %41 = getelementptr inbounds nuw i8, ptr %6, i64 448
  %42 = getelementptr inbounds nuw i8, ptr %6, i64 480
  %wide.load6.7 = load <8 x float>, ptr %41, align 4, !invariant.load !3, !alias.scope !9, !noalias !18
  %wide.load7.7 = load <8 x float>, ptr %42, align 4, !invariant.load !3, !alias.scope !9, !noalias !18
  %43 = getelementptr inbounds nuw i8, ptr %10, i64 512
  %44 = getelementptr inbounds nuw i8, ptr %10, i64 544
  %wide.load4.8 = load <8 x float>, ptr %43, align 4, !invariant.load !3, !alias.scope !13, !noalias !17
  %wide.load5.8 = load <8 x float>, ptr %44, align 4, !invariant.load !3, !alias.scope !13, !noalias !17
  %45 = getelementptr inbounds nuw i8, ptr %6, i64 512
  %46 = getelementptr inbounds nuw i8, ptr %6, i64 544
  %wide.load6.8 = load <8 x float>, ptr %45, align 4, !invariant.load !3, !alias.scope !9, !noalias !18
  %wide.load7.8 = load <8 x float>, ptr %46, align 4, !invariant.load !3, !alias.scope !9, !noalias !18
  %47 = getelementptr inbounds nuw i8, ptr %10, i64 576
  %48 = getelementptr inbounds nuw i8, ptr %10, i64 608
  %wide.load4.9 = load <8 x float>, ptr %47, align 4, !invariant.load !3, !alias.scope !13, !noalias !17
  %wide.load5.9 = load <8 x float>, ptr %48, align 4, !invariant.load !3, !alias.scope !13, !noalias !17
  %49 = getelementptr inbounds nuw i8, ptr %6, i64 576
  %50 = getelementptr inbounds nuw i8, ptr %6, i64 608
  %wide.load6.9 = load <8 x float>, ptr %49, align 4, !invariant.load !3, !alias.scope !9, !noalias !18
  %wide.load7.9 = load <8 x float>, ptr %50, align 4, !invariant.load !3, !alias.scope !9, !noalias !18
  %51 = getelementptr inbounds nuw i8, ptr %10, i64 640
  %52 = getelementptr inbounds nuw i8, ptr %10, i64 672
  %wide.load4.10 = load <8 x float>, ptr %51, align 4, !invariant.load !3, !alias.scope !13, !noalias !17
  %wide.load5.10 = load <8 x float>, ptr %52, align 4, !invariant.load !3, !alias.scope !13, !noalias !17
  %53 = getelementptr inbounds nuw i8, ptr %6, i64 640
  %54 = getelementptr inbounds nuw i8, ptr %6, i64 672
  %wide.load6.10 = load <8 x float>, ptr %53, align 4, !invariant.load !3, !alias.scope !9, !noalias !18
  %wide.load7.10 = load <8 x float>, ptr %54, align 4, !invariant.load !3, !alias.scope !9, !noalias !18
  %55 = getelementptr inbounds nuw i8, ptr %10, i64 704
  %56 = getelementptr inbounds nuw i8, ptr %10, i64 736
  %wide.load4.11 = load <8 x float>, ptr %55, align 4, !invariant.load !3, !alias.scope !13, !noalias !17
  %wide.load5.11 = load <8 x float>, ptr %56, align 4, !invariant.load !3, !alias.scope !13, !noalias !17
  %57 = getelementptr inbounds nuw i8, ptr %6, i64 704
  %58 = getelementptr inbounds nuw i8, ptr %6, i64 736
  %wide.load6.11 = load <8 x float>, ptr %57, align 4, !invariant.load !3, !alias.scope !9, !noalias !18
  %wide.load7.11 = load <8 x float>, ptr %58, align 4, !invariant.load !3, !alias.scope !9, !noalias !18
  br label %vector.ph

vector.ph:                                        ; preds = %1, %vector.ph
  %59 = phi i64 [ 0, %1 ], [ %264, %vector.ph ]
  %60 = mul nuw nsw i64 %59, 192
  %61 = getelementptr inbounds nuw float, ptr %8, i64 %60
  %62 = getelementptr inbounds nuw i8, ptr %61, i64 32
  %wide.load = load <8 x float>, ptr %61, align 4, !invariant.load !3, !alias.scope !11, !noalias !19
  %wide.load3 = load <8 x float>, ptr %62, align 4, !invariant.load !3, !alias.scope !11, !noalias !19
  %63 = fmul <8 x float> %wide.load, %wide.load4
  %64 = fmul <8 x float> %wide.load3, %wide.load5
  %65 = getelementptr inbounds nuw float, ptr %4, i64 %60
  %66 = getelementptr inbounds nuw i8, ptr %65, i64 32
  %wide.load8 = load <8 x float>, ptr %65, align 4, !invariant.load !3, !alias.scope !6, !noalias !20
  %wide.load9 = load <8 x float>, ptr %66, align 4, !invariant.load !3, !alias.scope !6, !noalias !20
  %67 = fadd <8 x float> %63, %wide.load6
  %68 = fadd <8 x float> %64, %wide.load7
  %69 = fmul <8 x float> %wide.load8, %67
  %70 = fmul <8 x float> %wide.load9, %68
  %71 = fcmp ogt <8 x float> %69, zeroinitializer
  %72 = fcmp ogt <8 x float> %70, zeroinitializer
  %73 = zext <8 x i1> %71 to <8 x i32>
  %74 = zext <8 x i1> %72 to <8 x i32>
  %75 = getelementptr inbounds nuw i32, ptr %12, i64 %60
  %76 = getelementptr inbounds nuw i8, ptr %75, i64 32
  store <8 x i32> %73, ptr %75, align 4, !alias.scope !15, !noalias !21
  store <8 x i32> %74, ptr %76, align 4, !alias.scope !15, !noalias !21
  %77 = or disjoint i64 %60, 16
  %78 = getelementptr inbounds nuw float, ptr %8, i64 %77
  %79 = getelementptr inbounds nuw i8, ptr %78, i64 32
  %wide.load.1 = load <8 x float>, ptr %78, align 4, !invariant.load !3, !alias.scope !11, !noalias !19
  %wide.load3.1 = load <8 x float>, ptr %79, align 4, !invariant.load !3, !alias.scope !11, !noalias !19
  %80 = fmul <8 x float> %wide.load.1, %wide.load4.1
  %81 = fmul <8 x float> %wide.load3.1, %wide.load5.1
  %82 = getelementptr inbounds nuw float, ptr %4, i64 %77
  %83 = getelementptr inbounds nuw i8, ptr %82, i64 32
  %wide.load8.1 = load <8 x float>, ptr %82, align 4, !invariant.load !3, !alias.scope !6, !noalias !20
  %wide.load9.1 = load <8 x float>, ptr %83, align 4, !invariant.load !3, !alias.scope !6, !noalias !20
  %84 = fadd <8 x float> %80, %wide.load6.1
  %85 = fadd <8 x float> %81, %wide.load7.1
  %86 = fmul <8 x float> %wide.load8.1, %84
  %87 = fmul <8 x float> %wide.load9.1, %85
  %88 = fcmp ogt <8 x float> %86, zeroinitializer
  %89 = fcmp ogt <8 x float> %87, zeroinitializer
  %90 = zext <8 x i1> %88 to <8 x i32>
  %91 = zext <8 x i1> %89 to <8 x i32>
  %92 = getelementptr inbounds nuw i32, ptr %12, i64 %77
  %93 = getelementptr inbounds nuw i8, ptr %92, i64 32
  store <8 x i32> %90, ptr %92, align 4, !alias.scope !15, !noalias !21
  store <8 x i32> %91, ptr %93, align 4, !alias.scope !15, !noalias !21
  %94 = or disjoint i64 %60, 32
  %95 = getelementptr inbounds nuw float, ptr %8, i64 %94
  %96 = getelementptr inbounds nuw i8, ptr %95, i64 32
  %wide.load.2 = load <8 x float>, ptr %95, align 4, !invariant.load !3, !alias.scope !11, !noalias !19
  %wide.load3.2 = load <8 x float>, ptr %96, align 4, !invariant.load !3, !alias.scope !11, !noalias !19
  %97 = fmul <8 x float> %wide.load.2, %wide.load4.2
  %98 = fmul <8 x float> %wide.load3.2, %wide.load5.2
  %99 = getelementptr inbounds nuw float, ptr %4, i64 %94
  %100 = getelementptr inbounds nuw i8, ptr %99, i64 32
  %wide.load8.2 = load <8 x float>, ptr %99, align 4, !invariant.load !3, !alias.scope !6, !noalias !20
  %wide.load9.2 = load <8 x float>, ptr %100, align 4, !invariant.load !3, !alias.scope !6, !noalias !20
  %101 = fadd <8 x float> %97, %wide.load6.2
  %102 = fadd <8 x float> %98, %wide.load7.2
  %103 = fmul <8 x float> %wide.load8.2, %101
  %104 = fmul <8 x float> %wide.load9.2, %102
  %105 = fcmp ogt <8 x float> %103, zeroinitializer
  %106 = fcmp ogt <8 x float> %104, zeroinitializer
  %107 = zext <8 x i1> %105 to <8 x i32>
  %108 = zext <8 x i1> %106 to <8 x i32>
  %109 = getelementptr inbounds nuw i32, ptr %12, i64 %94
  %110 = getelementptr inbounds nuw i8, ptr %109, i64 32
  store <8 x i32> %107, ptr %109, align 4, !alias.scope !15, !noalias !21
  store <8 x i32> %108, ptr %110, align 4, !alias.scope !15, !noalias !21
  %111 = or disjoint i64 %60, 48
  %112 = getelementptr inbounds nuw float, ptr %8, i64 %111
  %113 = getelementptr inbounds nuw i8, ptr %112, i64 32
  %wide.load.3 = load <8 x float>, ptr %112, align 4, !invariant.load !3, !alias.scope !11, !noalias !19
  %wide.load3.3 = load <8 x float>, ptr %113, align 4, !invariant.load !3, !alias.scope !11, !noalias !19
  %114 = fmul <8 x float> %wide.load.3, %wide.load4.3
  %115 = fmul <8 x float> %wide.load3.3, %wide.load5.3
  %116 = getelementptr inbounds nuw float, ptr %4, i64 %111
  %117 = getelementptr inbounds nuw i8, ptr %116, i64 32
  %wide.load8.3 = load <8 x float>, ptr %116, align 4, !invariant.load !3, !alias.scope !6, !noalias !20
  %wide.load9.3 = load <8 x float>, ptr %117, align 4, !invariant.load !3, !alias.scope !6, !noalias !20
  %118 = fadd <8 x float> %114, %wide.load6.3
  %119 = fadd <8 x float> %115, %wide.load7.3
  %120 = fmul <8 x float> %wide.load8.3, %118
  %121 = fmul <8 x float> %wide.load9.3, %119
  %122 = fcmp ogt <8 x float> %120, zeroinitializer
  %123 = fcmp ogt <8 x float> %121, zeroinitializer
  %124 = zext <8 x i1> %122 to <8 x i32>
  %125 = zext <8 x i1> %123 to <8 x i32>
  %126 = getelementptr inbounds nuw i32, ptr %12, i64 %111
  %127 = getelementptr inbounds nuw i8, ptr %126, i64 32
  store <8 x i32> %124, ptr %126, align 4, !alias.scope !15, !noalias !21
  store <8 x i32> %125, ptr %127, align 4, !alias.scope !15, !noalias !21
  %128 = add nuw nsw i64 %60, 64
  %129 = getelementptr inbounds nuw float, ptr %8, i64 %128
  %130 = getelementptr inbounds nuw i8, ptr %129, i64 32
  %wide.load.4 = load <8 x float>, ptr %129, align 4, !invariant.load !3, !alias.scope !11, !noalias !19
  %wide.load3.4 = load <8 x float>, ptr %130, align 4, !invariant.load !3, !alias.scope !11, !noalias !19
  %131 = fmul <8 x float> %wide.load.4, %wide.load4.4
  %132 = fmul <8 x float> %wide.load3.4, %wide.load5.4
  %133 = getelementptr inbounds nuw float, ptr %4, i64 %128
  %134 = getelementptr inbounds nuw i8, ptr %133, i64 32
  %wide.load8.4 = load <8 x float>, ptr %133, align 4, !invariant.load !3, !alias.scope !6, !noalias !20
  %wide.load9.4 = load <8 x float>, ptr %134, align 4, !invariant.load !3, !alias.scope !6, !noalias !20
  %135 = fadd <8 x float> %131, %wide.load6.4
  %136 = fadd <8 x float> %132, %wide.load7.4
  %137 = fmul <8 x float> %wide.load8.4, %135
  %138 = fmul <8 x float> %wide.load9.4, %136
  %139 = fcmp ogt <8 x float> %137, zeroinitializer
  %140 = fcmp ogt <8 x float> %138, zeroinitializer
  %141 = zext <8 x i1> %139 to <8 x i32>
  %142 = zext <8 x i1> %140 to <8 x i32>
  %143 = getelementptr inbounds nuw i32, ptr %12, i64 %128
  %144 = getelementptr inbounds nuw i8, ptr %143, i64 32
  store <8 x i32> %141, ptr %143, align 4, !alias.scope !15, !noalias !21
  store <8 x i32> %142, ptr %144, align 4, !alias.scope !15, !noalias !21
  %145 = add nuw nsw i64 %60, 80
  %146 = getelementptr inbounds nuw float, ptr %8, i64 %145
  %147 = getelementptr inbounds nuw i8, ptr %146, i64 32
  %wide.load.5 = load <8 x float>, ptr %146, align 4, !invariant.load !3, !alias.scope !11, !noalias !19
  %wide.load3.5 = load <8 x float>, ptr %147, align 4, !invariant.load !3, !alias.scope !11, !noalias !19
  %148 = fmul <8 x float> %wide.load.5, %wide.load4.5
  %149 = fmul <8 x float> %wide.load3.5, %wide.load5.5
  %150 = getelementptr inbounds nuw float, ptr %4, i64 %145
  %151 = getelementptr inbounds nuw i8, ptr %150, i64 32
  %wide.load8.5 = load <8 x float>, ptr %150, align 4, !invariant.load !3, !alias.scope !6, !noalias !20
  %wide.load9.5 = load <8 x float>, ptr %151, align 4, !invariant.load !3, !alias.scope !6, !noalias !20
  %152 = fadd <8 x float> %148, %wide.load6.5
  %153 = fadd <8 x float> %149, %wide.load7.5
  %154 = fmul <8 x float> %wide.load8.5, %152
  %155 = fmul <8 x float> %wide.load9.5, %153
  %156 = fcmp ogt <8 x float> %154, zeroinitializer
  %157 = fcmp ogt <8 x float> %155, zeroinitializer
  %158 = zext <8 x i1> %156 to <8 x i32>
  %159 = zext <8 x i1> %157 to <8 x i32>
  %160 = getelementptr inbounds nuw i32, ptr %12, i64 %145
  %161 = getelementptr inbounds nuw i8, ptr %160, i64 32
  store <8 x i32> %158, ptr %160, align 4, !alias.scope !15, !noalias !21
  store <8 x i32> %159, ptr %161, align 4, !alias.scope !15, !noalias !21
  %162 = add nuw nsw i64 %60, 96
  %163 = getelementptr inbounds nuw float, ptr %8, i64 %162
  %164 = getelementptr inbounds nuw i8, ptr %163, i64 32
  %wide.load.6 = load <8 x float>, ptr %163, align 4, !invariant.load !3, !alias.scope !11, !noalias !19
  %wide.load3.6 = load <8 x float>, ptr %164, align 4, !invariant.load !3, !alias.scope !11, !noalias !19
  %165 = fmul <8 x float> %wide.load.6, %wide.load4.6
  %166 = fmul <8 x float> %wide.load3.6, %wide.load5.6
  %167 = getelementptr inbounds nuw float, ptr %4, i64 %162
  %168 = getelementptr inbounds nuw i8, ptr %167, i64 32
  %wide.load8.6 = load <8 x float>, ptr %167, align 4, !invariant.load !3, !alias.scope !6, !noalias !20
  %wide.load9.6 = load <8 x float>, ptr %168, align 4, !invariant.load !3, !alias.scope !6, !noalias !20
  %169 = fadd <8 x float> %165, %wide.load6.6
  %170 = fadd <8 x float> %166, %wide.load7.6
  %171 = fmul <8 x float> %wide.load8.6, %169
  %172 = fmul <8 x float> %wide.load9.6, %170
  %173 = fcmp ogt <8 x float> %171, zeroinitializer
  %174 = fcmp ogt <8 x float> %172, zeroinitializer
  %175 = zext <8 x i1> %173 to <8 x i32>
  %176 = zext <8 x i1> %174 to <8 x i32>
  %177 = getelementptr inbounds nuw i32, ptr %12, i64 %162
  %178 = getelementptr inbounds nuw i8, ptr %177, i64 32
  store <8 x i32> %175, ptr %177, align 4, !alias.scope !15, !noalias !21
  store <8 x i32> %176, ptr %178, align 4, !alias.scope !15, !noalias !21
  %179 = add nuw nsw i64 %60, 112
  %180 = getelementptr inbounds nuw float, ptr %8, i64 %179
  %181 = getelementptr inbounds nuw i8, ptr %180, i64 32
  %wide.load.7 = load <8 x float>, ptr %180, align 4, !invariant.load !3, !alias.scope !11, !noalias !19
  %wide.load3.7 = load <8 x float>, ptr %181, align 4, !invariant.load !3, !alias.scope !11, !noalias !19
  %182 = fmul <8 x float> %wide.load.7, %wide.load4.7
  %183 = fmul <8 x float> %wide.load3.7, %wide.load5.7
  %184 = getelementptr inbounds nuw float, ptr %4, i64 %179
  %185 = getelementptr inbounds nuw i8, ptr %184, i64 32
  %wide.load8.7 = load <8 x float>, ptr %184, align 4, !invariant.load !3, !alias.scope !6, !noalias !20
  %wide.load9.7 = load <8 x float>, ptr %185, align 4, !invariant.load !3, !alias.scope !6, !noalias !20
  %186 = fadd <8 x float> %182, %wide.load6.7
  %187 = fadd <8 x float> %183, %wide.load7.7
  %188 = fmul <8 x float> %wide.load8.7, %186
  %189 = fmul <8 x float> %wide.load9.7, %187
  %190 = fcmp ogt <8 x float> %188, zeroinitializer
  %191 = fcmp ogt <8 x float> %189, zeroinitializer
  %192 = zext <8 x i1> %190 to <8 x i32>
  %193 = zext <8 x i1> %191 to <8 x i32>
  %194 = getelementptr inbounds nuw i32, ptr %12, i64 %179
  %195 = getelementptr inbounds nuw i8, ptr %194, i64 32
  store <8 x i32> %192, ptr %194, align 4, !alias.scope !15, !noalias !21
  store <8 x i32> %193, ptr %195, align 4, !alias.scope !15, !noalias !21
  %196 = add nuw nsw i64 %60, 128
  %197 = getelementptr inbounds nuw float, ptr %8, i64 %196
  %198 = getelementptr inbounds nuw i8, ptr %197, i64 32
  %wide.load.8 = load <8 x float>, ptr %197, align 4, !invariant.load !3, !alias.scope !11, !noalias !19
  %wide.load3.8 = load <8 x float>, ptr %198, align 4, !invariant.load !3, !alias.scope !11, !noalias !19
  %199 = fmul <8 x float> %wide.load.8, %wide.load4.8
  %200 = fmul <8 x float> %wide.load3.8, %wide.load5.8
  %201 = getelementptr inbounds nuw float, ptr %4, i64 %196
  %202 = getelementptr inbounds nuw i8, ptr %201, i64 32
  %wide.load8.8 = load <8 x float>, ptr %201, align 4, !invariant.load !3, !alias.scope !6, !noalias !20
  %wide.load9.8 = load <8 x float>, ptr %202, align 4, !invariant.load !3, !alias.scope !6, !noalias !20
  %203 = fadd <8 x float> %199, %wide.load6.8
  %204 = fadd <8 x float> %200, %wide.load7.8
  %205 = fmul <8 x float> %wide.load8.8, %203
  %206 = fmul <8 x float> %wide.load9.8, %204
  %207 = fcmp ogt <8 x float> %205, zeroinitializer
  %208 = fcmp ogt <8 x float> %206, zeroinitializer
  %209 = zext <8 x i1> %207 to <8 x i32>
  %210 = zext <8 x i1> %208 to <8 x i32>
  %211 = getelementptr inbounds nuw i32, ptr %12, i64 %196
  %212 = getelementptr inbounds nuw i8, ptr %211, i64 32
  store <8 x i32> %209, ptr %211, align 4, !alias.scope !15, !noalias !21
  store <8 x i32> %210, ptr %212, align 4, !alias.scope !15, !noalias !21
  %213 = add nuw nsw i64 %60, 144
  %214 = getelementptr inbounds nuw float, ptr %8, i64 %213
  %215 = getelementptr inbounds nuw i8, ptr %214, i64 32
  %wide.load.9 = load <8 x float>, ptr %214, align 4, !invariant.load !3, !alias.scope !11, !noalias !19
  %wide.load3.9 = load <8 x float>, ptr %215, align 4, !invariant.load !3, !alias.scope !11, !noalias !19
  %216 = fmul <8 x float> %wide.load.9, %wide.load4.9
  %217 = fmul <8 x float> %wide.load3.9, %wide.load5.9
  %218 = getelementptr inbounds nuw float, ptr %4, i64 %213
  %219 = getelementptr inbounds nuw i8, ptr %218, i64 32
  %wide.load8.9 = load <8 x float>, ptr %218, align 4, !invariant.load !3, !alias.scope !6, !noalias !20
  %wide.load9.9 = load <8 x float>, ptr %219, align 4, !invariant.load !3, !alias.scope !6, !noalias !20
  %220 = fadd <8 x float> %216, %wide.load6.9
  %221 = fadd <8 x float> %217, %wide.load7.9
  %222 = fmul <8 x float> %wide.load8.9, %220
  %223 = fmul <8 x float> %wide.load9.9, %221
  %224 = fcmp ogt <8 x float> %222, zeroinitializer
  %225 = fcmp ogt <8 x float> %223, zeroinitializer
  %226 = zext <8 x i1> %224 to <8 x i32>
  %227 = zext <8 x i1> %225 to <8 x i32>
  %228 = getelementptr inbounds nuw i32, ptr %12, i64 %213
  %229 = getelementptr inbounds nuw i8, ptr %228, i64 32
  store <8 x i32> %226, ptr %228, align 4, !alias.scope !15, !noalias !21
  store <8 x i32> %227, ptr %229, align 4, !alias.scope !15, !noalias !21
  %230 = add nuw nsw i64 %60, 160
  %231 = getelementptr inbounds nuw float, ptr %8, i64 %230
  %232 = getelementptr inbounds nuw i8, ptr %231, i64 32
  %wide.load.10 = load <8 x float>, ptr %231, align 4, !invariant.load !3, !alias.scope !11, !noalias !19
  %wide.load3.10 = load <8 x float>, ptr %232, align 4, !invariant.load !3, !alias.scope !11, !noalias !19
  %233 = fmul <8 x float> %wide.load.10, %wide.load4.10
  %234 = fmul <8 x float> %wide.load3.10, %wide.load5.10
  %235 = getelementptr inbounds nuw float, ptr %4, i64 %230
  %236 = getelementptr inbounds nuw i8, ptr %235, i64 32
  %wide.load8.10 = load <8 x float>, ptr %235, align 4, !invariant.load !3, !alias.scope !6, !noalias !20
  %wide.load9.10 = load <8 x float>, ptr %236, align 4, !invariant.load !3, !alias.scope !6, !noalias !20
  %237 = fadd <8 x float> %233, %wide.load6.10
  %238 = fadd <8 x float> %234, %wide.load7.10
  %239 = fmul <8 x float> %wide.load8.10, %237
  %240 = fmul <8 x float> %wide.load9.10, %238
  %241 = fcmp ogt <8 x float> %239, zeroinitializer
  %242 = fcmp ogt <8 x float> %240, zeroinitializer
  %243 = zext <8 x i1> %241 to <8 x i32>
  %244 = zext <8 x i1> %242 to <8 x i32>
  %245 = getelementptr inbounds nuw i32, ptr %12, i64 %230
  %246 = getelementptr inbounds nuw i8, ptr %245, i64 32
  store <8 x i32> %243, ptr %245, align 4, !alias.scope !15, !noalias !21
  store <8 x i32> %244, ptr %246, align 4, !alias.scope !15, !noalias !21
  %247 = add nuw nsw i64 %60, 176
  %248 = getelementptr inbounds nuw float, ptr %8, i64 %247
  %249 = getelementptr inbounds nuw i8, ptr %248, i64 32
  %wide.load.11 = load <8 x float>, ptr %248, align 4, !invariant.load !3, !alias.scope !11, !noalias !19
  %wide.load3.11 = load <8 x float>, ptr %249, align 4, !invariant.load !3, !alias.scope !11, !noalias !19
  %250 = fmul <8 x float> %wide.load.11, %wide.load4.11
  %251 = fmul <8 x float> %wide.load3.11, %wide.load5.11
  %252 = getelementptr inbounds nuw float, ptr %4, i64 %247
  %253 = getelementptr inbounds nuw i8, ptr %252, i64 32
  %wide.load8.11 = load <8 x float>, ptr %252, align 4, !invariant.load !3, !alias.scope !6, !noalias !20
  %wide.load9.11 = load <8 x float>, ptr %253, align 4, !invariant.load !3, !alias.scope !6, !noalias !20
  %254 = fadd <8 x float> %250, %wide.load6.11
  %255 = fadd <8 x float> %251, %wide.load7.11
  %256 = fmul <8 x float> %wide.load8.11, %254
  %257 = fmul <8 x float> %wide.load9.11, %255
  %258 = fcmp ogt <8 x float> %256, zeroinitializer
  %259 = fcmp ogt <8 x float> %257, zeroinitializer
  %260 = zext <8 x i1> %258 to <8 x i32>
  %261 = zext <8 x i1> %259 to <8 x i32>
  %262 = getelementptr inbounds nuw i32, ptr %12, i64 %247
  %263 = getelementptr inbounds nuw i8, ptr %262, i64 32
  store <8 x i32> %260, ptr %262, align 4, !alias.scope !15, !noalias !21
  store <8 x i32> %261, ptr %263, align 4, !alias.scope !15, !noalias !21
  %264 = add nuw nsw i64 %59, 1
  %exitcond2.not = icmp eq i64 %264, 96
  br i1 %exitcond2.not, label %compare_convert_fusion_wrapped.exit, label %vector.ph, !llvm.loop !22

compare_convert_fusion_wrapped.exit:              ; preds = %vector.ph
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 1}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 73728}
!5 = !{i64 768}
!6 = !{!7}
!7 = distinct !{!7, !8, !"compare_convert_fusion_wrapped: argument 0"}
!8 = distinct !{!8, !"compare_convert_fusion_wrapped"}
!9 = !{!10}
!10 = distinct !{!10, !8, !"compare_convert_fusion_wrapped: argument 1"}
!11 = !{!12}
!12 = distinct !{!12, !8, !"compare_convert_fusion_wrapped: argument 2"}
!13 = !{!14}
!14 = distinct !{!14, !8, !"compare_convert_fusion_wrapped: argument 3"}
!15 = !{!16}
!16 = distinct !{!16, !8, !"compare_convert_fusion_wrapped: argument 4"}
!17 = !{!7, !10, !12, !16}
!18 = !{!7, !12, !14, !16}
!19 = !{!7, !10, !14, !16}
!20 = !{!10, !12, !14, !16}
!21 = !{!7, !10, !12, !14}
!22 = distinct !{!22, !23}
!23 = !{!"llvm.loop.unroll.disable"}
