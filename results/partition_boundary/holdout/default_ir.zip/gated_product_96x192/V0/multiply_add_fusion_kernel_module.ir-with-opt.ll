; ModuleID = '__compute_module_multiply_add_fusion_kernel_module'
source_filename = "__compute_module_multiply_add_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @multiply_add_fusion(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !5
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !5
  %9 = getelementptr inbounds nuw i8, ptr %3, i64 48
  %10 = load ptr, ptr %9, align 8, !invariant.load !3, !dereferenceable !5
  %11 = getelementptr inbounds nuw i8, ptr %3, i64 64
  %12 = load ptr, ptr %11, align 8, !invariant.load !3, !dereferenceable !5
  %13 = getelementptr inbounds nuw i8, ptr %3, i64 80
  %14 = load ptr, ptr %13, align 8, !invariant.load !3, !dereferenceable !4
  %15 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %16 = load ptr, ptr %15, align 8
  %17 = load i64, ptr %16, align 4, !invariant.load !3
  tail call void @llvm.experimental.noalias.scope.decl(metadata !6)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !11)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !13)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !15)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !17)
  %18 = icmp ult i64 %17, 12
  br i1 %18, label %19, label %multiply_add_fusion_wrapped.exit

19:                                               ; preds = %1
  %20 = mul nuw nsw i64 %17, 1536
  br label %vector.ph

vector.ph:                                        ; preds = %19, %middle.block
  %21 = phi i64 [ 0, %19 ], [ %56, %middle.block ]
  %22 = mul nuw nsw i64 %21, 192
  %23 = add nuw nsw i64 %22, %20
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %vector.ph
  %index = phi i64 [ 0, %vector.ph ], [ %index.next, %vector.body ]
  %24 = getelementptr inbounds nuw float, ptr %12, i64 %index
  %wide.load = load <8 x float>, ptr %24, align 4, !invariant.load !3, !alias.scope !15, !noalias !19
  %25 = add nuw nsw i64 %23, %index
  %26 = getelementptr inbounds nuw float, ptr %4, i64 %25
  %wide.load5 = load <8 x float>, ptr %26, align 4, !invariant.load !3, !alias.scope !6, !noalias !20
  %27 = fmul <8 x float> %wide.load, %wide.load5
  %28 = getelementptr inbounds nuw float, ptr %10, i64 %index
  %wide.load6 = load <8 x float>, ptr %28, align 4, !invariant.load !3, !alias.scope !13, !noalias !21
  %29 = fadd <8 x float> %27, %wide.load6
  %30 = fneg <8 x float> %29
  %31 = fcmp uge <8 x float> %30, splat (float 0xC055F33340000000)
  %32 = select <8 x i1> %31, <8 x float> %30, <8 x float> splat (float 0xC055F33340000000)
  %33 = fcmp ule <8 x float> %32, splat (float 0x4056333340000000)
  %34 = select <8 x i1> %33, <8 x float> %32, <8 x float> splat (float 0x4056333340000000)
  %exp_f32.i = fmul <8 x float> %34, splat (float 0x3FF7154760000000)
  %exp_f321.i = fadd <8 x float> splat (float 5.000000e-01), %exp_f32.i
  %35 = call <8 x float> @llvm.floor.v8f32(<8 x float> %exp_f321.i)
  %36 = fcmp uge <8 x float> %35, splat (float -1.270000e+02)
  %37 = select <8 x i1> %36, <8 x float> %35, <8 x float> splat (float -1.270000e+02)
  %38 = fcmp ule <8 x float> %37, splat (float 1.270000e+02)
  %39 = select <8 x i1> %38, <8 x float> %37, <8 x float> splat (float 1.270000e+02)
  %exp_f322.i = fmul <8 x float> splat (float 0x3FE6300000000000), %39
  %40 = fsub <8 x float> %34, %exp_f322.i
  %exp_f323.i = fmul <8 x float> splat (float 0xBF2BD01060000000), %39
  %41 = fsub <8 x float> %40, %exp_f323.i
  %exp_f324.i = fmul <8 x float> %41, splat (float 0x3F2A0D2CE0000000)
  %exp_f325.i = fadd <8 x float> splat (float 0x3F56E879C0000000), %exp_f324.i
  %exp_f326.i = fmul <8 x float> %exp_f325.i, %41
  %exp_f327.i = fadd <8 x float> splat (float 0x3F81112100000000), %exp_f326.i
  %exp_f328.i = fmul <8 x float> %exp_f327.i, %41
  %exp_f329.i = fadd <8 x float> splat (float 0x3FA5553820000000), %exp_f328.i
  %exp_f3210.i = fmul <8 x float> %exp_f329.i, %41
  %exp_f3211.i = fadd <8 x float> splat (float 0x3FC5555540000000), %exp_f3210.i
  %exp_f3212.i = fmul <8 x float> %exp_f3211.i, %41
  %exp_f3213.i = fadd <8 x float> splat (float 5.000000e-01), %exp_f3212.i
  %exp_f3214.i = fmul <8 x float> %41, %41
  %exp_f3215.i = fmul <8 x float> %exp_f3213.i, %exp_f3214.i
  %exp_f3216.i = fadd <8 x float> %41, %exp_f3215.i
  %exp_f3217.i = fadd <8 x float> splat (float 1.000000e+00), %exp_f3216.i
  %42 = fptosi <8 x float> %39 to <8 x i32>
  %43 = add <8 x i32> %42, splat (i32 127)
  %44 = shl <8 x i32> %43, splat (i32 23)
  %45 = bitcast <8 x i32> %44 to <8 x float>
  %exp_f3218.i = fmul <8 x float> %exp_f3217.i, %45
  %46 = getelementptr inbounds nuw float, ptr %8, i64 %index
  %wide.load7 = load <8 x float>, ptr %46, align 4, !invariant.load !3, !alias.scope !11, !noalias !22
  %47 = fadd <8 x float> %exp_f3218.i, splat (float 1.000000e+00)
  %48 = fmul <8 x float> %wide.load5, %wide.load7
  %49 = getelementptr inbounds nuw float, ptr %6, i64 %index
  %wide.load8 = load <8 x float>, ptr %49, align 4, !invariant.load !3, !alias.scope !9, !noalias !23
  %50 = fdiv <8 x float> splat (float 1.000000e+00), %47
  %51 = fadd <8 x float> %48, %wide.load8
  %52 = fmul <8 x float> %51, %50
  %53 = fadd <8 x float> %wide.load5, %52
  %54 = getelementptr inbounds nuw float, ptr %14, i64 %25
  store <8 x float> %53, ptr %54, align 4, !alias.scope !17, !noalias !24
  %index.next = add nuw i64 %index, 8
  %55 = icmp eq i64 %index.next, 192
  br i1 %55, label %middle.block, label %vector.body, !llvm.loop !25

middle.block:                                     ; preds = %vector.body
  %56 = add nuw nsw i64 %21, 1
  %exitcond3.not = icmp eq i64 %56, 8
  br i1 %exitcond3.not, label %multiply_add_fusion_wrapped.exit, label %vector.ph, !llvm.loop !28

multiply_add_fusion_wrapped.exit:                 ; preds = %middle.block, %1
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <4 x float> @llvm.floor.v4f32(<4 x float>) #2

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.floor.v8f32(<8 x float>) #2

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <16 x float> @llvm.floor.v16f32(<16 x float>) #2

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 0}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 73728}
!5 = !{i64 768}
!6 = !{!7}
!7 = distinct !{!7, !8, !"multiply_add_fusion_wrapped: argument 0"}
!8 = distinct !{!8, !"multiply_add_fusion_wrapped"}
!9 = !{!10}
!10 = distinct !{!10, !8, !"multiply_add_fusion_wrapped: argument 1"}
!11 = !{!12}
!12 = distinct !{!12, !8, !"multiply_add_fusion_wrapped: argument 2"}
!13 = !{!14}
!14 = distinct !{!14, !8, !"multiply_add_fusion_wrapped: argument 3"}
!15 = !{!16}
!16 = distinct !{!16, !8, !"multiply_add_fusion_wrapped: argument 4"}
!17 = !{!18}
!18 = distinct !{!18, !8, !"multiply_add_fusion_wrapped: argument 5"}
!19 = !{!7, !10, !12, !14, !18}
!20 = !{!10, !12, !14, !16, !18}
!21 = !{!7, !10, !12, !16, !18}
!22 = !{!7, !10, !14, !16, !18}
!23 = !{!7, !12, !14, !16, !18}
!24 = !{!7, !10, !12, !14, !16}
!25 = distinct !{!25, !26, !27}
!26 = !{!"llvm.loop.isvectorized", i32 1}
!27 = !{!"llvm.loop.unroll.runtime.disable"}
!28 = distinct !{!28, !29}
!29 = !{!"llvm.loop.unroll.disable"}
