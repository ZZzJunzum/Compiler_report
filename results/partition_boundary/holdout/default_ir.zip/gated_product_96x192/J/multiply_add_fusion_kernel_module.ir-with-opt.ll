; ModuleID = '__compute_module_multiply_add_fusion_kernel_module'
source_filename = "__compute_module_multiply_add_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @multiply_add_fusion(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !4
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !5
  %9 = getelementptr inbounds nuw i8, ptr %3, i64 48
  %10 = load ptr, ptr %9, align 8, !invariant.load !3, !dereferenceable !5
  %11 = getelementptr inbounds nuw i8, ptr %3, i64 64
  %12 = load ptr, ptr %11, align 8, !invariant.load !3, !dereferenceable !4
  tail call void @llvm.experimental.noalias.scope.decl(metadata !6)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !11)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !13)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !15)
  %13 = getelementptr inbounds nuw i8, ptr %10, i64 32
  %wide.load = load <8 x float>, ptr %10, align 4, !invariant.load !3, !alias.scope !13, !noalias !17
  %wide.load3 = load <8 x float>, ptr %13, align 4, !invariant.load !3, !alias.scope !13, !noalias !17
  %14 = getelementptr inbounds nuw i8, ptr %8, i64 32
  %wide.load6 = load <8 x float>, ptr %8, align 4, !invariant.load !3, !alias.scope !11, !noalias !18
  %wide.load7 = load <8 x float>, ptr %14, align 4, !invariant.load !3, !alias.scope !11, !noalias !18
  %15 = getelementptr inbounds nuw i8, ptr %10, i64 64
  %16 = getelementptr inbounds nuw i8, ptr %10, i64 96
  %wide.load.1 = load <8 x float>, ptr %15, align 4, !invariant.load !3, !alias.scope !13, !noalias !17
  %wide.load3.1 = load <8 x float>, ptr %16, align 4, !invariant.load !3, !alias.scope !13, !noalias !17
  %17 = getelementptr inbounds nuw i8, ptr %8, i64 64
  %18 = getelementptr inbounds nuw i8, ptr %8, i64 96
  %wide.load6.1 = load <8 x float>, ptr %17, align 4, !invariant.load !3, !alias.scope !11, !noalias !18
  %wide.load7.1 = load <8 x float>, ptr %18, align 4, !invariant.load !3, !alias.scope !11, !noalias !18
  %19 = getelementptr inbounds nuw i8, ptr %10, i64 128
  %20 = getelementptr inbounds nuw i8, ptr %10, i64 160
  %wide.load.2 = load <8 x float>, ptr %19, align 4, !invariant.load !3, !alias.scope !13, !noalias !17
  %wide.load3.2 = load <8 x float>, ptr %20, align 4, !invariant.load !3, !alias.scope !13, !noalias !17
  %21 = getelementptr inbounds nuw i8, ptr %8, i64 128
  %22 = getelementptr inbounds nuw i8, ptr %8, i64 160
  %wide.load6.2 = load <8 x float>, ptr %21, align 4, !invariant.load !3, !alias.scope !11, !noalias !18
  %wide.load7.2 = load <8 x float>, ptr %22, align 4, !invariant.load !3, !alias.scope !11, !noalias !18
  %23 = getelementptr inbounds nuw i8, ptr %10, i64 192
  %24 = getelementptr inbounds nuw i8, ptr %10, i64 224
  %wide.load.3 = load <8 x float>, ptr %23, align 4, !invariant.load !3, !alias.scope !13, !noalias !17
  %wide.load3.3 = load <8 x float>, ptr %24, align 4, !invariant.load !3, !alias.scope !13, !noalias !17
  %25 = getelementptr inbounds nuw i8, ptr %8, i64 192
  %26 = getelementptr inbounds nuw i8, ptr %8, i64 224
  %wide.load6.3 = load <8 x float>, ptr %25, align 4, !invariant.load !3, !alias.scope !11, !noalias !18
  %wide.load7.3 = load <8 x float>, ptr %26, align 4, !invariant.load !3, !alias.scope !11, !noalias !18
  %27 = getelementptr inbounds nuw i8, ptr %10, i64 256
  %28 = getelementptr inbounds nuw i8, ptr %10, i64 288
  %wide.load.4 = load <8 x float>, ptr %27, align 4, !invariant.load !3, !alias.scope !13, !noalias !17
  %wide.load3.4 = load <8 x float>, ptr %28, align 4, !invariant.load !3, !alias.scope !13, !noalias !17
  %29 = getelementptr inbounds nuw i8, ptr %8, i64 256
  %30 = getelementptr inbounds nuw i8, ptr %8, i64 288
  %wide.load6.4 = load <8 x float>, ptr %29, align 4, !invariant.load !3, !alias.scope !11, !noalias !18
  %wide.load7.4 = load <8 x float>, ptr %30, align 4, !invariant.load !3, !alias.scope !11, !noalias !18
  %31 = getelementptr inbounds nuw i8, ptr %10, i64 320
  %32 = getelementptr inbounds nuw i8, ptr %10, i64 352
  %wide.load.5 = load <8 x float>, ptr %31, align 4, !invariant.load !3, !alias.scope !13, !noalias !17
  %wide.load3.5 = load <8 x float>, ptr %32, align 4, !invariant.load !3, !alias.scope !13, !noalias !17
  %33 = getelementptr inbounds nuw i8, ptr %8, i64 320
  %34 = getelementptr inbounds nuw i8, ptr %8, i64 352
  %wide.load6.5 = load <8 x float>, ptr %33, align 4, !invariant.load !3, !alias.scope !11, !noalias !18
  %wide.load7.5 = load <8 x float>, ptr %34, align 4, !invariant.load !3, !alias.scope !11, !noalias !18
  %35 = getelementptr inbounds nuw i8, ptr %10, i64 384
  %36 = getelementptr inbounds nuw i8, ptr %10, i64 416
  %wide.load.6 = load <8 x float>, ptr %35, align 4, !invariant.load !3, !alias.scope !13, !noalias !17
  %wide.load3.6 = load <8 x float>, ptr %36, align 4, !invariant.load !3, !alias.scope !13, !noalias !17
  %37 = getelementptr inbounds nuw i8, ptr %8, i64 384
  %38 = getelementptr inbounds nuw i8, ptr %8, i64 416
  %wide.load6.6 = load <8 x float>, ptr %37, align 4, !invariant.load !3, !alias.scope !11, !noalias !18
  %wide.load7.6 = load <8 x float>, ptr %38, align 4, !invariant.load !3, !alias.scope !11, !noalias !18
  %39 = getelementptr inbounds nuw i8, ptr %10, i64 448
  %40 = getelementptr inbounds nuw i8, ptr %10, i64 480
  %wide.load.7 = load <8 x float>, ptr %39, align 4, !invariant.load !3, !alias.scope !13, !noalias !17
  %wide.load3.7 = load <8 x float>, ptr %40, align 4, !invariant.load !3, !alias.scope !13, !noalias !17
  %41 = getelementptr inbounds nuw i8, ptr %8, i64 448
  %42 = getelementptr inbounds nuw i8, ptr %8, i64 480
  %wide.load6.7 = load <8 x float>, ptr %41, align 4, !invariant.load !3, !alias.scope !11, !noalias !18
  %wide.load7.7 = load <8 x float>, ptr %42, align 4, !invariant.load !3, !alias.scope !11, !noalias !18
  %43 = getelementptr inbounds nuw i8, ptr %10, i64 512
  %44 = getelementptr inbounds nuw i8, ptr %10, i64 544
  %wide.load.8 = load <8 x float>, ptr %43, align 4, !invariant.load !3, !alias.scope !13, !noalias !17
  %wide.load3.8 = load <8 x float>, ptr %44, align 4, !invariant.load !3, !alias.scope !13, !noalias !17
  %45 = getelementptr inbounds nuw i8, ptr %8, i64 512
  %46 = getelementptr inbounds nuw i8, ptr %8, i64 544
  %wide.load6.8 = load <8 x float>, ptr %45, align 4, !invariant.load !3, !alias.scope !11, !noalias !18
  %wide.load7.8 = load <8 x float>, ptr %46, align 4, !invariant.load !3, !alias.scope !11, !noalias !18
  %47 = getelementptr inbounds nuw i8, ptr %10, i64 576
  %48 = getelementptr inbounds nuw i8, ptr %10, i64 608
  %wide.load.9 = load <8 x float>, ptr %47, align 4, !invariant.load !3, !alias.scope !13, !noalias !17
  %wide.load3.9 = load <8 x float>, ptr %48, align 4, !invariant.load !3, !alias.scope !13, !noalias !17
  %49 = getelementptr inbounds nuw i8, ptr %8, i64 576
  %50 = getelementptr inbounds nuw i8, ptr %8, i64 608
  %wide.load6.9 = load <8 x float>, ptr %49, align 4, !invariant.load !3, !alias.scope !11, !noalias !18
  %wide.load7.9 = load <8 x float>, ptr %50, align 4, !invariant.load !3, !alias.scope !11, !noalias !18
  %51 = getelementptr inbounds nuw i8, ptr %10, i64 640
  %52 = getelementptr inbounds nuw i8, ptr %10, i64 672
  %wide.load.10 = load <8 x float>, ptr %51, align 4, !invariant.load !3, !alias.scope !13, !noalias !17
  %wide.load3.10 = load <8 x float>, ptr %52, align 4, !invariant.load !3, !alias.scope !13, !noalias !17
  %53 = getelementptr inbounds nuw i8, ptr %8, i64 640
  %54 = getelementptr inbounds nuw i8, ptr %8, i64 672
  %wide.load6.10 = load <8 x float>, ptr %53, align 4, !invariant.load !3, !alias.scope !11, !noalias !18
  %wide.load7.10 = load <8 x float>, ptr %54, align 4, !invariant.load !3, !alias.scope !11, !noalias !18
  %55 = getelementptr inbounds nuw i8, ptr %10, i64 704
  %56 = getelementptr inbounds nuw i8, ptr %10, i64 736
  %wide.load.11 = load <8 x float>, ptr %55, align 4, !invariant.load !3, !alias.scope !13, !noalias !17
  %wide.load3.11 = load <8 x float>, ptr %56, align 4, !invariant.load !3, !alias.scope !13, !noalias !17
  %57 = getelementptr inbounds nuw i8, ptr %8, i64 704
  %58 = getelementptr inbounds nuw i8, ptr %8, i64 736
  %wide.load6.11 = load <8 x float>, ptr %57, align 4, !invariant.load !3, !alias.scope !11, !noalias !18
  %wide.load7.11 = load <8 x float>, ptr %58, align 4, !invariant.load !3, !alias.scope !11, !noalias !18
  br label %vector.ph

vector.ph:                                        ; preds = %1, %vector.ph
  %59 = phi i64 [ 0, %1 ], [ %240, %vector.ph ]
  %60 = mul nuw nsw i64 %59, 192
  %61 = getelementptr inbounds nuw float, ptr %4, i64 %60
  %62 = getelementptr inbounds nuw i8, ptr %61, i64 32
  %wide.load4 = load <8 x float>, ptr %61, align 4, !invariant.load !3, !alias.scope !6, !noalias !19
  %wide.load5 = load <8 x float>, ptr %62, align 4, !invariant.load !3, !alias.scope !6, !noalias !19
  %63 = fmul <8 x float> %wide.load, %wide.load4
  %64 = fmul <8 x float> %wide.load3, %wide.load5
  %65 = getelementptr inbounds nuw float, ptr %6, i64 %60
  %66 = getelementptr inbounds nuw i8, ptr %65, i64 32
  %wide.load8 = load <8 x float>, ptr %65, align 4, !invariant.load !3, !alias.scope !9, !noalias !20
  %wide.load9 = load <8 x float>, ptr %66, align 4, !invariant.load !3, !alias.scope !9, !noalias !20
  %67 = fadd <8 x float> %63, %wide.load6
  %68 = fadd <8 x float> %64, %wide.load7
  %69 = fmul <8 x float> %wide.load8, %67
  %70 = fmul <8 x float> %wide.load9, %68
  %71 = fadd <8 x float> %wide.load4, %69
  %72 = fadd <8 x float> %wide.load5, %70
  %73 = getelementptr inbounds nuw float, ptr %12, i64 %60
  %74 = getelementptr inbounds nuw i8, ptr %73, i64 32
  store <8 x float> %71, ptr %73, align 4, !alias.scope !15, !noalias !21
  store <8 x float> %72, ptr %74, align 4, !alias.scope !15, !noalias !21
  %75 = or disjoint i64 %60, 16
  %76 = getelementptr inbounds nuw float, ptr %4, i64 %75
  %77 = getelementptr inbounds nuw i8, ptr %76, i64 32
  %wide.load4.1 = load <8 x float>, ptr %76, align 4, !invariant.load !3, !alias.scope !6, !noalias !19
  %wide.load5.1 = load <8 x float>, ptr %77, align 4, !invariant.load !3, !alias.scope !6, !noalias !19
  %78 = fmul <8 x float> %wide.load.1, %wide.load4.1
  %79 = fmul <8 x float> %wide.load3.1, %wide.load5.1
  %80 = getelementptr inbounds nuw float, ptr %6, i64 %75
  %81 = getelementptr inbounds nuw i8, ptr %80, i64 32
  %wide.load8.1 = load <8 x float>, ptr %80, align 4, !invariant.load !3, !alias.scope !9, !noalias !20
  %wide.load9.1 = load <8 x float>, ptr %81, align 4, !invariant.load !3, !alias.scope !9, !noalias !20
  %82 = fadd <8 x float> %78, %wide.load6.1
  %83 = fadd <8 x float> %79, %wide.load7.1
  %84 = fmul <8 x float> %wide.load8.1, %82
  %85 = fmul <8 x float> %wide.load9.1, %83
  %86 = fadd <8 x float> %wide.load4.1, %84
  %87 = fadd <8 x float> %wide.load5.1, %85
  %88 = getelementptr inbounds nuw float, ptr %12, i64 %75
  %89 = getelementptr inbounds nuw i8, ptr %88, i64 32
  store <8 x float> %86, ptr %88, align 4, !alias.scope !15, !noalias !21
  store <8 x float> %87, ptr %89, align 4, !alias.scope !15, !noalias !21
  %90 = or disjoint i64 %60, 32
  %91 = getelementptr inbounds nuw float, ptr %4, i64 %90
  %92 = getelementptr inbounds nuw i8, ptr %91, i64 32
  %wide.load4.2 = load <8 x float>, ptr %91, align 4, !invariant.load !3, !alias.scope !6, !noalias !19
  %wide.load5.2 = load <8 x float>, ptr %92, align 4, !invariant.load !3, !alias.scope !6, !noalias !19
  %93 = fmul <8 x float> %wide.load.2, %wide.load4.2
  %94 = fmul <8 x float> %wide.load3.2, %wide.load5.2
  %95 = getelementptr inbounds nuw float, ptr %6, i64 %90
  %96 = getelementptr inbounds nuw i8, ptr %95, i64 32
  %wide.load8.2 = load <8 x float>, ptr %95, align 4, !invariant.load !3, !alias.scope !9, !noalias !20
  %wide.load9.2 = load <8 x float>, ptr %96, align 4, !invariant.load !3, !alias.scope !9, !noalias !20
  %97 = fadd <8 x float> %93, %wide.load6.2
  %98 = fadd <8 x float> %94, %wide.load7.2
  %99 = fmul <8 x float> %wide.load8.2, %97
  %100 = fmul <8 x float> %wide.load9.2, %98
  %101 = fadd <8 x float> %wide.load4.2, %99
  %102 = fadd <8 x float> %wide.load5.2, %100
  %103 = getelementptr inbounds nuw float, ptr %12, i64 %90
  %104 = getelementptr inbounds nuw i8, ptr %103, i64 32
  store <8 x float> %101, ptr %103, align 4, !alias.scope !15, !noalias !21
  store <8 x float> %102, ptr %104, align 4, !alias.scope !15, !noalias !21
  %105 = or disjoint i64 %60, 48
  %106 = getelementptr inbounds nuw float, ptr %4, i64 %105
  %107 = getelementptr inbounds nuw i8, ptr %106, i64 32
  %wide.load4.3 = load <8 x float>, ptr %106, align 4, !invariant.load !3, !alias.scope !6, !noalias !19
  %wide.load5.3 = load <8 x float>, ptr %107, align 4, !invariant.load !3, !alias.scope !6, !noalias !19
  %108 = fmul <8 x float> %wide.load.3, %wide.load4.3
  %109 = fmul <8 x float> %wide.load3.3, %wide.load5.3
  %110 = getelementptr inbounds nuw float, ptr %6, i64 %105
  %111 = getelementptr inbounds nuw i8, ptr %110, i64 32
  %wide.load8.3 = load <8 x float>, ptr %110, align 4, !invariant.load !3, !alias.scope !9, !noalias !20
  %wide.load9.3 = load <8 x float>, ptr %111, align 4, !invariant.load !3, !alias.scope !9, !noalias !20
  %112 = fadd <8 x float> %108, %wide.load6.3
  %113 = fadd <8 x float> %109, %wide.load7.3
  %114 = fmul <8 x float> %wide.load8.3, %112
  %115 = fmul <8 x float> %wide.load9.3, %113
  %116 = fadd <8 x float> %wide.load4.3, %114
  %117 = fadd <8 x float> %wide.load5.3, %115
  %118 = getelementptr inbounds nuw float, ptr %12, i64 %105
  %119 = getelementptr inbounds nuw i8, ptr %118, i64 32
  store <8 x float> %116, ptr %118, align 4, !alias.scope !15, !noalias !21
  store <8 x float> %117, ptr %119, align 4, !alias.scope !15, !noalias !21
  %120 = add nuw nsw i64 %60, 64
  %121 = getelementptr inbounds nuw float, ptr %4, i64 %120
  %122 = getelementptr inbounds nuw i8, ptr %121, i64 32
  %wide.load4.4 = load <8 x float>, ptr %121, align 4, !invariant.load !3, !alias.scope !6, !noalias !19
  %wide.load5.4 = load <8 x float>, ptr %122, align 4, !invariant.load !3, !alias.scope !6, !noalias !19
  %123 = fmul <8 x float> %wide.load.4, %wide.load4.4
  %124 = fmul <8 x float> %wide.load3.4, %wide.load5.4
  %125 = getelementptr inbounds nuw float, ptr %6, i64 %120
  %126 = getelementptr inbounds nuw i8, ptr %125, i64 32
  %wide.load8.4 = load <8 x float>, ptr %125, align 4, !invariant.load !3, !alias.scope !9, !noalias !20
  %wide.load9.4 = load <8 x float>, ptr %126, align 4, !invariant.load !3, !alias.scope !9, !noalias !20
  %127 = fadd <8 x float> %123, %wide.load6.4
  %128 = fadd <8 x float> %124, %wide.load7.4
  %129 = fmul <8 x float> %wide.load8.4, %127
  %130 = fmul <8 x float> %wide.load9.4, %128
  %131 = fadd <8 x float> %wide.load4.4, %129
  %132 = fadd <8 x float> %wide.load5.4, %130
  %133 = getelementptr inbounds nuw float, ptr %12, i64 %120
  %134 = getelementptr inbounds nuw i8, ptr %133, i64 32
  store <8 x float> %131, ptr %133, align 4, !alias.scope !15, !noalias !21
  store <8 x float> %132, ptr %134, align 4, !alias.scope !15, !noalias !21
  %135 = add nuw nsw i64 %60, 80
  %136 = getelementptr inbounds nuw float, ptr %4, i64 %135
  %137 = getelementptr inbounds nuw i8, ptr %136, i64 32
  %wide.load4.5 = load <8 x float>, ptr %136, align 4, !invariant.load !3, !alias.scope !6, !noalias !19
  %wide.load5.5 = load <8 x float>, ptr %137, align 4, !invariant.load !3, !alias.scope !6, !noalias !19
  %138 = fmul <8 x float> %wide.load.5, %wide.load4.5
  %139 = fmul <8 x float> %wide.load3.5, %wide.load5.5
  %140 = getelementptr inbounds nuw float, ptr %6, i64 %135
  %141 = getelementptr inbounds nuw i8, ptr %140, i64 32
  %wide.load8.5 = load <8 x float>, ptr %140, align 4, !invariant.load !3, !alias.scope !9, !noalias !20
  %wide.load9.5 = load <8 x float>, ptr %141, align 4, !invariant.load !3, !alias.scope !9, !noalias !20
  %142 = fadd <8 x float> %138, %wide.load6.5
  %143 = fadd <8 x float> %139, %wide.load7.5
  %144 = fmul <8 x float> %wide.load8.5, %142
  %145 = fmul <8 x float> %wide.load9.5, %143
  %146 = fadd <8 x float> %wide.load4.5, %144
  %147 = fadd <8 x float> %wide.load5.5, %145
  %148 = getelementptr inbounds nuw float, ptr %12, i64 %135
  %149 = getelementptr inbounds nuw i8, ptr %148, i64 32
  store <8 x float> %146, ptr %148, align 4, !alias.scope !15, !noalias !21
  store <8 x float> %147, ptr %149, align 4, !alias.scope !15, !noalias !21
  %150 = add nuw nsw i64 %60, 96
  %151 = getelementptr inbounds nuw float, ptr %4, i64 %150
  %152 = getelementptr inbounds nuw i8, ptr %151, i64 32
  %wide.load4.6 = load <8 x float>, ptr %151, align 4, !invariant.load !3, !alias.scope !6, !noalias !19
  %wide.load5.6 = load <8 x float>, ptr %152, align 4, !invariant.load !3, !alias.scope !6, !noalias !19
  %153 = fmul <8 x float> %wide.load.6, %wide.load4.6
  %154 = fmul <8 x float> %wide.load3.6, %wide.load5.6
  %155 = getelementptr inbounds nuw float, ptr %6, i64 %150
  %156 = getelementptr inbounds nuw i8, ptr %155, i64 32
  %wide.load8.6 = load <8 x float>, ptr %155, align 4, !invariant.load !3, !alias.scope !9, !noalias !20
  %wide.load9.6 = load <8 x float>, ptr %156, align 4, !invariant.load !3, !alias.scope !9, !noalias !20
  %157 = fadd <8 x float> %153, %wide.load6.6
  %158 = fadd <8 x float> %154, %wide.load7.6
  %159 = fmul <8 x float> %wide.load8.6, %157
  %160 = fmul <8 x float> %wide.load9.6, %158
  %161 = fadd <8 x float> %wide.load4.6, %159
  %162 = fadd <8 x float> %wide.load5.6, %160
  %163 = getelementptr inbounds nuw float, ptr %12, i64 %150
  %164 = getelementptr inbounds nuw i8, ptr %163, i64 32
  store <8 x float> %161, ptr %163, align 4, !alias.scope !15, !noalias !21
  store <8 x float> %162, ptr %164, align 4, !alias.scope !15, !noalias !21
  %165 = add nuw nsw i64 %60, 112
  %166 = getelementptr inbounds nuw float, ptr %4, i64 %165
  %167 = getelementptr inbounds nuw i8, ptr %166, i64 32
  %wide.load4.7 = load <8 x float>, ptr %166, align 4, !invariant.load !3, !alias.scope !6, !noalias !19
  %wide.load5.7 = load <8 x float>, ptr %167, align 4, !invariant.load !3, !alias.scope !6, !noalias !19
  %168 = fmul <8 x float> %wide.load.7, %wide.load4.7
  %169 = fmul <8 x float> %wide.load3.7, %wide.load5.7
  %170 = getelementptr inbounds nuw float, ptr %6, i64 %165
  %171 = getelementptr inbounds nuw i8, ptr %170, i64 32
  %wide.load8.7 = load <8 x float>, ptr %170, align 4, !invariant.load !3, !alias.scope !9, !noalias !20
  %wide.load9.7 = load <8 x float>, ptr %171, align 4, !invariant.load !3, !alias.scope !9, !noalias !20
  %172 = fadd <8 x float> %168, %wide.load6.7
  %173 = fadd <8 x float> %169, %wide.load7.7
  %174 = fmul <8 x float> %wide.load8.7, %172
  %175 = fmul <8 x float> %wide.load9.7, %173
  %176 = fadd <8 x float> %wide.load4.7, %174
  %177 = fadd <8 x float> %wide.load5.7, %175
  %178 = getelementptr inbounds nuw float, ptr %12, i64 %165
  %179 = getelementptr inbounds nuw i8, ptr %178, i64 32
  store <8 x float> %176, ptr %178, align 4, !alias.scope !15, !noalias !21
  store <8 x float> %177, ptr %179, align 4, !alias.scope !15, !noalias !21
  %180 = add nuw nsw i64 %60, 128
  %181 = getelementptr inbounds nuw float, ptr %4, i64 %180
  %182 = getelementptr inbounds nuw i8, ptr %181, i64 32
  %wide.load4.8 = load <8 x float>, ptr %181, align 4, !invariant.load !3, !alias.scope !6, !noalias !19
  %wide.load5.8 = load <8 x float>, ptr %182, align 4, !invariant.load !3, !alias.scope !6, !noalias !19
  %183 = fmul <8 x float> %wide.load.8, %wide.load4.8
  %184 = fmul <8 x float> %wide.load3.8, %wide.load5.8
  %185 = getelementptr inbounds nuw float, ptr %6, i64 %180
  %186 = getelementptr inbounds nuw i8, ptr %185, i64 32
  %wide.load8.8 = load <8 x float>, ptr %185, align 4, !invariant.load !3, !alias.scope !9, !noalias !20
  %wide.load9.8 = load <8 x float>, ptr %186, align 4, !invariant.load !3, !alias.scope !9, !noalias !20
  %187 = fadd <8 x float> %183, %wide.load6.8
  %188 = fadd <8 x float> %184, %wide.load7.8
  %189 = fmul <8 x float> %wide.load8.8, %187
  %190 = fmul <8 x float> %wide.load9.8, %188
  %191 = fadd <8 x float> %wide.load4.8, %189
  %192 = fadd <8 x float> %wide.load5.8, %190
  %193 = getelementptr inbounds nuw float, ptr %12, i64 %180
  %194 = getelementptr inbounds nuw i8, ptr %193, i64 32
  store <8 x float> %191, ptr %193, align 4, !alias.scope !15, !noalias !21
  store <8 x float> %192, ptr %194, align 4, !alias.scope !15, !noalias !21
  %195 = add nuw nsw i64 %60, 144
  %196 = getelementptr inbounds nuw float, ptr %4, i64 %195
  %197 = getelementptr inbounds nuw i8, ptr %196, i64 32
  %wide.load4.9 = load <8 x float>, ptr %196, align 4, !invariant.load !3, !alias.scope !6, !noalias !19
  %wide.load5.9 = load <8 x float>, ptr %197, align 4, !invariant.load !3, !alias.scope !6, !noalias !19
  %198 = fmul <8 x float> %wide.load.9, %wide.load4.9
  %199 = fmul <8 x float> %wide.load3.9, %wide.load5.9
  %200 = getelementptr inbounds nuw float, ptr %6, i64 %195
  %201 = getelementptr inbounds nuw i8, ptr %200, i64 32
  %wide.load8.9 = load <8 x float>, ptr %200, align 4, !invariant.load !3, !alias.scope !9, !noalias !20
  %wide.load9.9 = load <8 x float>, ptr %201, align 4, !invariant.load !3, !alias.scope !9, !noalias !20
  %202 = fadd <8 x float> %198, %wide.load6.9
  %203 = fadd <8 x float> %199, %wide.load7.9
  %204 = fmul <8 x float> %wide.load8.9, %202
  %205 = fmul <8 x float> %wide.load9.9, %203
  %206 = fadd <8 x float> %wide.load4.9, %204
  %207 = fadd <8 x float> %wide.load5.9, %205
  %208 = getelementptr inbounds nuw float, ptr %12, i64 %195
  %209 = getelementptr inbounds nuw i8, ptr %208, i64 32
  store <8 x float> %206, ptr %208, align 4, !alias.scope !15, !noalias !21
  store <8 x float> %207, ptr %209, align 4, !alias.scope !15, !noalias !21
  %210 = add nuw nsw i64 %60, 160
  %211 = getelementptr inbounds nuw float, ptr %4, i64 %210
  %212 = getelementptr inbounds nuw i8, ptr %211, i64 32
  %wide.load4.10 = load <8 x float>, ptr %211, align 4, !invariant.load !3, !alias.scope !6, !noalias !19
  %wide.load5.10 = load <8 x float>, ptr %212, align 4, !invariant.load !3, !alias.scope !6, !noalias !19
  %213 = fmul <8 x float> %wide.load.10, %wide.load4.10
  %214 = fmul <8 x float> %wide.load3.10, %wide.load5.10
  %215 = getelementptr inbounds nuw float, ptr %6, i64 %210
  %216 = getelementptr inbounds nuw i8, ptr %215, i64 32
  %wide.load8.10 = load <8 x float>, ptr %215, align 4, !invariant.load !3, !alias.scope !9, !noalias !20
  %wide.load9.10 = load <8 x float>, ptr %216, align 4, !invariant.load !3, !alias.scope !9, !noalias !20
  %217 = fadd <8 x float> %213, %wide.load6.10
  %218 = fadd <8 x float> %214, %wide.load7.10
  %219 = fmul <8 x float> %wide.load8.10, %217
  %220 = fmul <8 x float> %wide.load9.10, %218
  %221 = fadd <8 x float> %wide.load4.10, %219
  %222 = fadd <8 x float> %wide.load5.10, %220
  %223 = getelementptr inbounds nuw float, ptr %12, i64 %210
  %224 = getelementptr inbounds nuw i8, ptr %223, i64 32
  store <8 x float> %221, ptr %223, align 4, !alias.scope !15, !noalias !21
  store <8 x float> %222, ptr %224, align 4, !alias.scope !15, !noalias !21
  %225 = add nuw nsw i64 %60, 176
  %226 = getelementptr inbounds nuw float, ptr %4, i64 %225
  %227 = getelementptr inbounds nuw i8, ptr %226, i64 32
  %wide.load4.11 = load <8 x float>, ptr %226, align 4, !invariant.load !3, !alias.scope !6, !noalias !19
  %wide.load5.11 = load <8 x float>, ptr %227, align 4, !invariant.load !3, !alias.scope !6, !noalias !19
  %228 = fmul <8 x float> %wide.load.11, %wide.load4.11
  %229 = fmul <8 x float> %wide.load3.11, %wide.load5.11
  %230 = getelementptr inbounds nuw float, ptr %6, i64 %225
  %231 = getelementptr inbounds nuw i8, ptr %230, i64 32
  %wide.load8.11 = load <8 x float>, ptr %230, align 4, !invariant.load !3, !alias.scope !9, !noalias !20
  %wide.load9.11 = load <8 x float>, ptr %231, align 4, !invariant.load !3, !alias.scope !9, !noalias !20
  %232 = fadd <8 x float> %228, %wide.load6.11
  %233 = fadd <8 x float> %229, %wide.load7.11
  %234 = fmul <8 x float> %wide.load8.11, %232
  %235 = fmul <8 x float> %wide.load9.11, %233
  %236 = fadd <8 x float> %wide.load4.11, %234
  %237 = fadd <8 x float> %wide.load5.11, %235
  %238 = getelementptr inbounds nuw float, ptr %12, i64 %225
  %239 = getelementptr inbounds nuw i8, ptr %238, i64 32
  store <8 x float> %236, ptr %238, align 4, !alias.scope !15, !noalias !21
  store <8 x float> %237, ptr %239, align 4, !alias.scope !15, !noalias !21
  %240 = add nuw nsw i64 %59, 1
  %exitcond2.not = icmp eq i64 %240, 96
  br i1 %exitcond2.not, label %multiply_add_fusion_wrapped.exit, label %vector.ph, !llvm.loop !22

multiply_add_fusion_wrapped.exit:                 ; preds = %vector.ph
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 2}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 73728}
!5 = !{i64 768}
!6 = !{!7}
!7 = distinct !{!7, !8, !"multiply_add_fusion_wrapped: argument 0"}
!8 = distinct !{!8, !"multiply_add_fusion_wrapped"}
!9 = !{!10}
!10 = distinct !{!10, !8, !"multiply_add_fusion_wrapped: argument 1"}
!11 = !{!12}
!12 = distinct !{!12, !8, !"multiply_add_fusion_wrapped: argument 2"}
!13 = !{!14}
!14 = distinct !{!14, !8, !"multiply_add_fusion_wrapped: argument 3"}
!15 = !{!16}
!16 = distinct !{!16, !8, !"multiply_add_fusion_wrapped: argument 4"}
!17 = !{!7, !10, !12, !16}
!18 = !{!7, !10, !14, !16}
!19 = !{!10, !12, !14, !16}
!20 = !{!7, !12, !14, !16}
!21 = !{!7, !10, !12, !14}
!22 = distinct !{!22, !23}
!23 = !{!"llvm.loop.unroll.disable"}
