; ModuleID = '__compute_module_convert_reduce_fusion_kernel_module'
source_filename = "__compute_module_convert_reduce_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @convert_reduce_fusion(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !5
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !4
  %9 = getelementptr inbounds nuw i8, ptr %3, i64 48
  %10 = load ptr, ptr %9, align 8, !invariant.load !3, !dereferenceable !5
  %11 = getelementptr inbounds nuw i8, ptr %3, i64 64
  %12 = load ptr, ptr %11, align 8, !invariant.load !3, !dereferenceable !5
  %13 = getelementptr inbounds nuw i8, ptr %3, i64 80
  %14 = load ptr, ptr %13, align 8, !invariant.load !3, !dereferenceable !5
  tail call void @llvm.experimental.noalias.scope.decl(metadata !6)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !11)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !13)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !15)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !17)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !19)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !21)
  br label %vector.ph

vector.ph:                                        ; preds = %1, %middle.block
  %15 = phi i32 [ 0, %1 ], [ %58, %middle.block ]
  %16 = phi i32 [ 0, %1 ], [ %57, %middle.block ]
  %17 = phi i64 [ 0, %1 ], [ %59, %middle.block ]
  %18 = mul nuw nsw i64 %17, 192
  %19 = insertelement <8 x i32> <i32 poison, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0>, i32 %15, i64 0
  %20 = insertelement <8 x i32> <i32 poison, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0>, i32 %16, i64 0
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %vector.ph
  %index = phi i64 [ 0, %vector.ph ], [ %index.next, %vector.body ]
  %vec.phi = phi <8 x i32> [ %19, %vector.ph ], [ %54, %vector.body ]
  %vec.phi9 = phi <8 x i32> [ zeroinitializer, %vector.ph ], [ %55, %vector.body ]
  %vec.phi10 = phi <8 x i32> [ %20, %vector.ph ], [ %52, %vector.body ]
  %vec.phi11 = phi <8 x i32> [ zeroinitializer, %vector.ph ], [ %53, %vector.body ]
  %21 = add nuw nsw i64 %index, %18
  %22 = getelementptr inbounds nuw float, ptr %8, i64 %21
  %23 = getelementptr inbounds nuw i8, ptr %22, i64 32
  %wide.load = load <8 x float>, ptr %22, align 4, !invariant.load !3, !alias.scope !11, !noalias !23
  %wide.load12 = load <8 x float>, ptr %23, align 4, !invariant.load !3, !alias.scope !11, !noalias !23
  %24 = getelementptr inbounds nuw float, ptr %14, i64 %index
  %25 = getelementptr inbounds nuw i8, ptr %24, i64 32
  %wide.load13 = load <8 x float>, ptr %24, align 4, !invariant.load !3, !alias.scope !17, !noalias !24
  %wide.load14 = load <8 x float>, ptr %25, align 4, !invariant.load !3, !alias.scope !17, !noalias !24
  %26 = fmul <8 x float> %wide.load, %wide.load13
  %27 = fmul <8 x float> %wide.load12, %wide.load14
  %28 = getelementptr inbounds nuw float, ptr %12, i64 %index
  %29 = getelementptr inbounds nuw i8, ptr %28, i64 32
  %wide.load15 = load <8 x float>, ptr %28, align 4, !invariant.load !3, !alias.scope !15, !noalias !25
  %wide.load16 = load <8 x float>, ptr %29, align 4, !invariant.load !3, !alias.scope !15, !noalias !25
  %30 = fadd <8 x float> %26, %wide.load15
  %31 = fadd <8 x float> %27, %wide.load16
  %32 = fcmp ogt <8 x float> %30, zeroinitializer
  %33 = fcmp ogt <8 x float> %31, zeroinitializer
  %34 = zext <8 x i1> %32 to <8 x i32>
  %35 = zext <8 x i1> %33 to <8 x i32>
  %36 = getelementptr inbounds nuw float, ptr %10, i64 %index
  %37 = getelementptr inbounds nuw i8, ptr %36, i64 32
  %wide.load17 = load <8 x float>, ptr %36, align 4, !invariant.load !3, !alias.scope !13, !noalias !26
  %wide.load18 = load <8 x float>, ptr %37, align 4, !invariant.load !3, !alias.scope !13, !noalias !26
  %38 = fmul <8 x float> %wide.load, %wide.load17
  %39 = fmul <8 x float> %wide.load12, %wide.load18
  %40 = getelementptr inbounds nuw float, ptr %6, i64 %index
  %41 = getelementptr inbounds nuw i8, ptr %40, i64 32
  %wide.load19 = load <8 x float>, ptr %40, align 4, !invariant.load !3, !alias.scope !9, !noalias !27
  %wide.load20 = load <8 x float>, ptr %41, align 4, !invariant.load !3, !alias.scope !9, !noalias !27
  %42 = getelementptr inbounds nuw float, ptr %4, i64 %21
  %43 = getelementptr inbounds nuw i8, ptr %42, i64 32
  %wide.load21 = load <8 x float>, ptr %42, align 4, !invariant.load !3, !alias.scope !6, !noalias !28
  %wide.load22 = load <8 x float>, ptr %43, align 4, !invariant.load !3, !alias.scope !6, !noalias !28
  %44 = fadd <8 x float> %38, %wide.load19
  %45 = fadd <8 x float> %39, %wide.load20
  %46 = fmul <8 x float> %wide.load21, %44
  %47 = fmul <8 x float> %wide.load22, %45
  %48 = fcmp ogt <8 x float> %46, zeroinitializer
  %49 = fcmp ogt <8 x float> %47, zeroinitializer
  %50 = zext <8 x i1> %48 to <8 x i32>
  %51 = zext <8 x i1> %49 to <8 x i32>
  %52 = add <8 x i32> %vec.phi10, %34
  %53 = add <8 x i32> %vec.phi11, %35
  %54 = add <8 x i32> %vec.phi, %50
  %55 = add <8 x i32> %vec.phi9, %51
  %index.next = add nuw i64 %index, 16
  %56 = icmp eq i64 %index.next, 192
  br i1 %56, label %middle.block, label %vector.body, !llvm.loop !29

middle.block:                                     ; preds = %vector.body
  %bin.rdx23 = add <8 x i32> %53, %52
  %57 = tail call i32 @llvm.vector.reduce.add.v8i32(<8 x i32> %bin.rdx23)
  %bin.rdx = add <8 x i32> %55, %54
  %58 = tail call i32 @llvm.vector.reduce.add.v8i32(<8 x i32> %bin.rdx)
  %59 = add nuw nsw i64 %17, 1
  %exitcond6.not = icmp eq i64 %59, 96
  br i1 %exitcond6.not, label %convert_reduce_fusion_wrapped.exit, label %vector.ph, !llvm.loop !32

convert_reduce_fusion_wrapped.exit:               ; preds = %middle.block
  %60 = getelementptr inbounds nuw i8, ptr %3, i64 112
  %61 = load ptr, ptr %60, align 8, !invariant.load !3, !dereferenceable !34
  %62 = getelementptr inbounds nuw i8, ptr %3, i64 96
  %63 = load ptr, ptr %62, align 8, !invariant.load !3, !dereferenceable !34
  store i32 %57, ptr %63, align 4, !alias.scope !19, !noalias !35
  store i32 %58, ptr %61, align 4, !alias.scope !21, !noalias !36
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.vector.reduce.add.v8i32(<8 x i32>) #2

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #2 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 1}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 73728}
!5 = !{i64 768}
!6 = !{!7}
!7 = distinct !{!7, !8, !"convert_reduce_fusion_wrapped: argument 0"}
!8 = distinct !{!8, !"convert_reduce_fusion_wrapped"}
!9 = !{!10}
!10 = distinct !{!10, !8, !"convert_reduce_fusion_wrapped: argument 1"}
!11 = !{!12}
!12 = distinct !{!12, !8, !"convert_reduce_fusion_wrapped: argument 2"}
!13 = !{!14}
!14 = distinct !{!14, !8, !"convert_reduce_fusion_wrapped: argument 3"}
!15 = !{!16}
!16 = distinct !{!16, !8, !"convert_reduce_fusion_wrapped: argument 4"}
!17 = !{!18}
!18 = distinct !{!18, !8, !"convert_reduce_fusion_wrapped: argument 5"}
!19 = !{!20}
!20 = distinct !{!20, !8, !"convert_reduce_fusion_wrapped: argument 6"}
!21 = !{!22}
!22 = distinct !{!22, !8, !"convert_reduce_fusion_wrapped: argument 7"}
!23 = !{!7, !10, !14, !16, !18, !20, !22}
!24 = !{!7, !10, !12, !14, !16, !20, !22}
!25 = !{!7, !10, !12, !14, !18, !20, !22}
!26 = !{!7, !10, !12, !16, !18, !20, !22}
!27 = !{!7, !12, !14, !16, !18, !20, !22}
!28 = !{!10, !12, !14, !16, !18, !20, !22}
!29 = distinct !{!29, !30, !31}
!30 = !{!"llvm.loop.isvectorized", i32 1}
!31 = !{!"llvm.loop.unroll.runtime.disable"}
!32 = distinct !{!32, !33}
!33 = !{!"llvm.loop.unroll.disable"}
!34 = !{i64 4}
!35 = !{!7, !10, !12, !14, !16, !18, !22}
!36 = !{!7, !10, !12, !14, !16, !18, !20}
