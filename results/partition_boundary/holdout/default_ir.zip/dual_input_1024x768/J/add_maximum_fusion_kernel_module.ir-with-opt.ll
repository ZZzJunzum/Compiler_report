; ModuleID = '__compute_module_add_maximum_fusion_kernel_module'
source_filename = "__compute_module_add_maximum_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @add_maximum_fusion(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !5
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !4
  %9 = getelementptr inbounds nuw i8, ptr %3, i64 48
  %10 = load ptr, ptr %9, align 8, !invariant.load !3, !dereferenceable !4
  %11 = getelementptr inbounds nuw i8, ptr %3, i64 64
  %12 = load ptr, ptr %11, align 8, !invariant.load !3, !dereferenceable !5
  %13 = getelementptr inbounds nuw i8, ptr %3, i64 80
  %14 = load ptr, ptr %13, align 8, !invariant.load !3, !dereferenceable !4
  %15 = getelementptr inbounds nuw i8, ptr %3, i64 96
  %16 = load ptr, ptr %15, align 8, !invariant.load !3, !dereferenceable !5
  %17 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %18 = load ptr, ptr %17, align 8
  %19 = load i64, ptr %18, align 4, !invariant.load !3
  tail call void @llvm.experimental.noalias.scope.decl(metadata !6)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !11)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !13)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !15)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !17)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !19)
  %20 = icmp ult i64 %19, 4
  br i1 %20, label %21, label %add_maximum_fusion_wrapped.exit

21:                                               ; preds = %1
  %22 = mul nuw nsw i64 %19, 196608
  br label %vector.ph

vector.ph:                                        ; preds = %21, %middle.block
  %23 = phi i64 [ 0, %21 ], [ %77, %middle.block ]
  %24 = mul nuw nsw i64 %23, 768
  %25 = add nuw nsw i64 %24, %22
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %vector.ph
  %index = phi i64 [ 0, %vector.ph ], [ %index.next.1, %vector.body ]
  %26 = add nuw nsw i64 %25, %index
  %27 = getelementptr inbounds nuw float, ptr %12, i64 %26
  %28 = getelementptr inbounds nuw i8, ptr %27, i64 32
  %wide.load = load <8 x float>, ptr %27, align 4, !invariant.load !3, !alias.scope !15, !noalias !21
  %wide.load5 = load <8 x float>, ptr %28, align 4, !invariant.load !3, !alias.scope !15, !noalias !21
  %29 = getelementptr inbounds nuw float, ptr %14, i64 %index
  %30 = getelementptr inbounds nuw i8, ptr %29, i64 32
  %wide.load6 = load <8 x float>, ptr %29, align 4, !invariant.load !3, !alias.scope !17, !noalias !22
  %wide.load7 = load <8 x float>, ptr %30, align 4, !invariant.load !3, !alias.scope !17, !noalias !22
  %31 = getelementptr inbounds nuw float, ptr %6, i64 %26
  %32 = getelementptr inbounds nuw i8, ptr %31, i64 32
  %wide.load8 = load <8 x float>, ptr %31, align 4, !invariant.load !3, !alias.scope !9, !noalias !23
  %wide.load9 = load <8 x float>, ptr %32, align 4, !invariant.load !3, !alias.scope !9, !noalias !23
  %33 = getelementptr inbounds nuw float, ptr %8, i64 %index
  %34 = getelementptr inbounds nuw i8, ptr %33, i64 32
  %wide.load10 = load <8 x float>, ptr %33, align 4, !invariant.load !3, !alias.scope !11, !noalias !24
  %wide.load11 = load <8 x float>, ptr %34, align 4, !invariant.load !3, !alias.scope !11, !noalias !24
  %35 = fmul <8 x float> %wide.load, %wide.load6
  %36 = fmul <8 x float> %wide.load5, %wide.load7
  %37 = getelementptr inbounds nuw float, ptr %10, i64 %index
  %38 = getelementptr inbounds nuw i8, ptr %37, i64 32
  %wide.load12 = load <8 x float>, ptr %37, align 4, !invariant.load !3, !alias.scope !13, !noalias !25
  %wide.load13 = load <8 x float>, ptr %38, align 4, !invariant.load !3, !alias.scope !13, !noalias !25
  %39 = fmul <8 x float> %wide.load8, %wide.load10
  %40 = fmul <8 x float> %wide.load9, %wide.load11
  %41 = getelementptr inbounds nuw float, ptr %4, i64 %index
  %42 = getelementptr inbounds nuw i8, ptr %41, i64 32
  %wide.load14 = load <8 x float>, ptr %41, align 4, !invariant.load !3, !alias.scope !6, !noalias !26
  %wide.load15 = load <8 x float>, ptr %42, align 4, !invariant.load !3, !alias.scope !6, !noalias !26
  %43 = fadd <8 x float> %35, %wide.load12
  %44 = fadd <8 x float> %36, %wide.load13
  %45 = fadd <8 x float> %39, %wide.load14
  %46 = fadd <8 x float> %40, %wide.load15
  %47 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %43, <8 x float> %45)
  %48 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %44, <8 x float> %46)
  %49 = getelementptr inbounds nuw float, ptr %16, i64 %26
  %50 = getelementptr inbounds nuw i8, ptr %49, i64 32
  store <8 x float> %47, ptr %49, align 4, !alias.scope !19, !noalias !27
  store <8 x float> %48, ptr %50, align 4, !alias.scope !19, !noalias !27
  %index.next = or disjoint i64 %index, 16
  %51 = add nuw nsw i64 %25, %index.next
  %52 = getelementptr inbounds nuw float, ptr %12, i64 %51
  %53 = getelementptr inbounds nuw i8, ptr %52, i64 32
  %wide.load.1 = load <8 x float>, ptr %52, align 4, !invariant.load !3, !alias.scope !15, !noalias !21
  %wide.load5.1 = load <8 x float>, ptr %53, align 4, !invariant.load !3, !alias.scope !15, !noalias !21
  %54 = getelementptr inbounds nuw float, ptr %14, i64 %index.next
  %55 = getelementptr inbounds nuw i8, ptr %54, i64 32
  %wide.load6.1 = load <8 x float>, ptr %54, align 4, !invariant.load !3, !alias.scope !17, !noalias !22
  %wide.load7.1 = load <8 x float>, ptr %55, align 4, !invariant.load !3, !alias.scope !17, !noalias !22
  %56 = getelementptr inbounds nuw float, ptr %6, i64 %51
  %57 = getelementptr inbounds nuw i8, ptr %56, i64 32
  %wide.load8.1 = load <8 x float>, ptr %56, align 4, !invariant.load !3, !alias.scope !9, !noalias !23
  %wide.load9.1 = load <8 x float>, ptr %57, align 4, !invariant.load !3, !alias.scope !9, !noalias !23
  %58 = getelementptr inbounds nuw float, ptr %8, i64 %index.next
  %59 = getelementptr inbounds nuw i8, ptr %58, i64 32
  %wide.load10.1 = load <8 x float>, ptr %58, align 4, !invariant.load !3, !alias.scope !11, !noalias !24
  %wide.load11.1 = load <8 x float>, ptr %59, align 4, !invariant.load !3, !alias.scope !11, !noalias !24
  %60 = fmul <8 x float> %wide.load.1, %wide.load6.1
  %61 = fmul <8 x float> %wide.load5.1, %wide.load7.1
  %62 = getelementptr inbounds nuw float, ptr %10, i64 %index.next
  %63 = getelementptr inbounds nuw i8, ptr %62, i64 32
  %wide.load12.1 = load <8 x float>, ptr %62, align 4, !invariant.load !3, !alias.scope !13, !noalias !25
  %wide.load13.1 = load <8 x float>, ptr %63, align 4, !invariant.load !3, !alias.scope !13, !noalias !25
  %64 = fmul <8 x float> %wide.load8.1, %wide.load10.1
  %65 = fmul <8 x float> %wide.load9.1, %wide.load11.1
  %66 = getelementptr inbounds nuw float, ptr %4, i64 %index.next
  %67 = getelementptr inbounds nuw i8, ptr %66, i64 32
  %wide.load14.1 = load <8 x float>, ptr %66, align 4, !invariant.load !3, !alias.scope !6, !noalias !26
  %wide.load15.1 = load <8 x float>, ptr %67, align 4, !invariant.load !3, !alias.scope !6, !noalias !26
  %68 = fadd <8 x float> %60, %wide.load12.1
  %69 = fadd <8 x float> %61, %wide.load13.1
  %70 = fadd <8 x float> %64, %wide.load14.1
  %71 = fadd <8 x float> %65, %wide.load15.1
  %72 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %68, <8 x float> %70)
  %73 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %69, <8 x float> %71)
  %74 = getelementptr inbounds nuw float, ptr %16, i64 %51
  %75 = getelementptr inbounds nuw i8, ptr %74, i64 32
  store <8 x float> %72, ptr %74, align 4, !alias.scope !19, !noalias !27
  store <8 x float> %73, ptr %75, align 4, !alias.scope !19, !noalias !27
  %index.next.1 = add nuw nsw i64 %index, 32
  %76 = icmp eq i64 %index.next.1, 768
  br i1 %76, label %middle.block, label %vector.body, !llvm.loop !28

middle.block:                                     ; preds = %vector.body
  %77 = add nuw nsw i64 %23, 1
  %exitcond3.not = icmp eq i64 %77, 256
  br i1 %exitcond3.not, label %add_maximum_fusion_wrapped.exit, label %vector.ph, !llvm.loop !31

add_maximum_fusion_wrapped.exit:                  ; preds = %middle.block, %1
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.maximum.v8f32(<8 x float>, <8 x float>) #2

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 0}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 3072}
!5 = !{i64 3145728}
!6 = !{!7}
!7 = distinct !{!7, !8, !"add_maximum_fusion_wrapped: argument 0"}
!8 = distinct !{!8, !"add_maximum_fusion_wrapped"}
!9 = !{!10}
!10 = distinct !{!10, !8, !"add_maximum_fusion_wrapped: argument 1"}
!11 = !{!12}
!12 = distinct !{!12, !8, !"add_maximum_fusion_wrapped: argument 2"}
!13 = !{!14}
!14 = distinct !{!14, !8, !"add_maximum_fusion_wrapped: argument 3"}
!15 = !{!16}
!16 = distinct !{!16, !8, !"add_maximum_fusion_wrapped: argument 4"}
!17 = !{!18}
!18 = distinct !{!18, !8, !"add_maximum_fusion_wrapped: argument 5"}
!19 = !{!20}
!20 = distinct !{!20, !8, !"add_maximum_fusion_wrapped: argument 6"}
!21 = !{!7, !10, !12, !14, !18, !20}
!22 = !{!7, !10, !12, !14, !16, !20}
!23 = !{!7, !12, !14, !16, !18, !20}
!24 = !{!7, !10, !14, !16, !18, !20}
!25 = !{!7, !10, !12, !16, !18, !20}
!26 = !{!10, !12, !14, !16, !18, !20}
!27 = !{!7, !10, !12, !14, !16, !18}
!28 = distinct !{!28, !29, !30}
!29 = !{!"llvm.loop.isvectorized", i32 1}
!30 = !{!"llvm.loop.unroll.runtime.disable"}
!31 = distinct !{!31, !32}
!32 = !{!"llvm.loop.unroll.disable"}
