; ModuleID = '__compute_module_shift-left_add_fusion_kernel_module'
source_filename = "__compute_module_shift-left_add_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @shift-left_add_fusion(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !5
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !4
  %9 = getelementptr inbounds nuw i8, ptr %3, i64 48
  %10 = load ptr, ptr %9, align 8, !invariant.load !3, !dereferenceable !4
  %11 = getelementptr inbounds nuw i8, ptr %3, i64 64
  %12 = load ptr, ptr %11, align 8, !invariant.load !3, !dereferenceable !5
  %13 = getelementptr inbounds nuw i8, ptr %3, i64 80
  %14 = load ptr, ptr %13, align 8, !invariant.load !3, !dereferenceable !4
  %15 = getelementptr inbounds nuw i8, ptr %3, i64 96
  %16 = load ptr, ptr %15, align 8, !invariant.load !3, !dereferenceable !5
  %17 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %18 = load ptr, ptr %17, align 8
  %19 = load i64, ptr %18, align 4, !invariant.load !3
  tail call void @llvm.experimental.noalias.scope.decl(metadata !6)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !11)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !13)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !15)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !17)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !19)
  %20 = icmp ult i64 %19, 4
  br i1 %20, label %21, label %shift-left_add_fusion_wrapped.exit

21:                                               ; preds = %1
  %22 = mul nuw nsw i64 %19, 196608
  br label %vector.ph

vector.ph:                                        ; preds = %21, %middle.block
  %23 = phi i64 [ 0, %21 ], [ %78, %middle.block ]
  %24 = mul nuw nsw i64 %23, 768
  %25 = add nuw nsw i64 %24, %22
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %vector.ph
  %index = phi i64 [ 0, %vector.ph ], [ %index.next.2, %vector.body ]
  %26 = add nuw nsw i64 %25, %index
  %27 = getelementptr inbounds nuw float, ptr %6, i64 %26
  %wide.load = load <8 x float>, ptr %27, align 4, !invariant.load !3, !alias.scope !9, !noalias !21
  %28 = getelementptr inbounds nuw float, ptr %8, i64 %index
  %wide.load5 = load <8 x float>, ptr %28, align 4, !invariant.load !3, !alias.scope !11, !noalias !22
  %29 = getelementptr inbounds nuw float, ptr %12, i64 %26
  %wide.load6 = load <8 x float>, ptr %29, align 4, !invariant.load !3, !alias.scope !15, !noalias !23
  %30 = getelementptr inbounds nuw float, ptr %14, i64 %index
  %wide.load7 = load <8 x float>, ptr %30, align 4, !invariant.load !3, !alias.scope !17, !noalias !24
  %31 = fmul <8 x float> %wide.load, %wide.load5
  %32 = getelementptr inbounds nuw float, ptr %4, i64 %index
  %wide.load8 = load <8 x float>, ptr %32, align 4, !invariant.load !3, !alias.scope !6, !noalias !25
  %33 = fmul <8 x float> %wide.load6, %wide.load7
  %34 = getelementptr inbounds nuw float, ptr %10, i64 %index
  %wide.load9 = load <8 x float>, ptr %34, align 4, !invariant.load !3, !alias.scope !13, !noalias !26
  %35 = fadd <8 x float> %31, %wide.load8
  %36 = fadd <8 x float> %33, %wide.load9
  %37 = fcmp ogt <8 x float> %35, zeroinitializer
  %38 = fcmp ogt <8 x float> %36, zeroinitializer
  %39 = zext <8 x i1> %38 to <8 x i32>
  %40 = select <8 x i1> %37, <8 x i32> splat (i32 1024), <8 x i32> zeroinitializer
  %41 = or disjoint <8 x i32> %40, %39
  %42 = getelementptr inbounds nuw i32, ptr %16, i64 %26
  store <8 x i32> %41, ptr %42, align 4, !alias.scope !19, !noalias !27
  %index.next = add nuw nsw i64 %index, 8
  %43 = add nuw nsw i64 %25, %index.next
  %44 = getelementptr inbounds nuw float, ptr %6, i64 %43
  %wide.load.1 = load <8 x float>, ptr %44, align 4, !invariant.load !3, !alias.scope !9, !noalias !21
  %45 = getelementptr inbounds nuw float, ptr %8, i64 %index.next
  %wide.load5.1 = load <8 x float>, ptr %45, align 4, !invariant.load !3, !alias.scope !11, !noalias !22
  %46 = getelementptr inbounds nuw float, ptr %12, i64 %43
  %wide.load6.1 = load <8 x float>, ptr %46, align 4, !invariant.load !3, !alias.scope !15, !noalias !23
  %47 = getelementptr inbounds nuw float, ptr %14, i64 %index.next
  %wide.load7.1 = load <8 x float>, ptr %47, align 4, !invariant.load !3, !alias.scope !17, !noalias !24
  %48 = fmul <8 x float> %wide.load.1, %wide.load5.1
  %49 = getelementptr inbounds nuw float, ptr %4, i64 %index.next
  %wide.load8.1 = load <8 x float>, ptr %49, align 4, !invariant.load !3, !alias.scope !6, !noalias !25
  %50 = fmul <8 x float> %wide.load6.1, %wide.load7.1
  %51 = getelementptr inbounds nuw float, ptr %10, i64 %index.next
  %wide.load9.1 = load <8 x float>, ptr %51, align 4, !invariant.load !3, !alias.scope !13, !noalias !26
  %52 = fadd <8 x float> %48, %wide.load8.1
  %53 = fadd <8 x float> %50, %wide.load9.1
  %54 = fcmp ogt <8 x float> %52, zeroinitializer
  %55 = fcmp ogt <8 x float> %53, zeroinitializer
  %56 = zext <8 x i1> %55 to <8 x i32>
  %57 = select <8 x i1> %54, <8 x i32> splat (i32 1024), <8 x i32> zeroinitializer
  %58 = or disjoint <8 x i32> %57, %56
  %59 = getelementptr inbounds nuw i32, ptr %16, i64 %43
  store <8 x i32> %58, ptr %59, align 4, !alias.scope !19, !noalias !27
  %index.next.1 = add nuw nsw i64 %index, 16
  %60 = add nuw nsw i64 %25, %index.next.1
  %61 = getelementptr inbounds nuw float, ptr %6, i64 %60
  %wide.load.2 = load <8 x float>, ptr %61, align 4, !invariant.load !3, !alias.scope !9, !noalias !21
  %62 = getelementptr inbounds nuw float, ptr %8, i64 %index.next.1
  %wide.load5.2 = load <8 x float>, ptr %62, align 4, !invariant.load !3, !alias.scope !11, !noalias !22
  %63 = getelementptr inbounds nuw float, ptr %12, i64 %60
  %wide.load6.2 = load <8 x float>, ptr %63, align 4, !invariant.load !3, !alias.scope !15, !noalias !23
  %64 = getelementptr inbounds nuw float, ptr %14, i64 %index.next.1
  %wide.load7.2 = load <8 x float>, ptr %64, align 4, !invariant.load !3, !alias.scope !17, !noalias !24
  %65 = fmul <8 x float> %wide.load.2, %wide.load5.2
  %66 = getelementptr inbounds nuw float, ptr %4, i64 %index.next.1
  %wide.load8.2 = load <8 x float>, ptr %66, align 4, !invariant.load !3, !alias.scope !6, !noalias !25
  %67 = fmul <8 x float> %wide.load6.2, %wide.load7.2
  %68 = getelementptr inbounds nuw float, ptr %10, i64 %index.next.1
  %wide.load9.2 = load <8 x float>, ptr %68, align 4, !invariant.load !3, !alias.scope !13, !noalias !26
  %69 = fadd <8 x float> %65, %wide.load8.2
  %70 = fadd <8 x float> %67, %wide.load9.2
  %71 = fcmp ogt <8 x float> %69, zeroinitializer
  %72 = fcmp ogt <8 x float> %70, zeroinitializer
  %73 = zext <8 x i1> %72 to <8 x i32>
  %74 = select <8 x i1> %71, <8 x i32> splat (i32 1024), <8 x i32> zeroinitializer
  %75 = or disjoint <8 x i32> %74, %73
  %76 = getelementptr inbounds nuw i32, ptr %16, i64 %60
  store <8 x i32> %75, ptr %76, align 4, !alias.scope !19, !noalias !27
  %index.next.2 = add nuw nsw i64 %index, 24
  %77 = icmp eq i64 %index.next.2, 768
  br i1 %77, label %middle.block, label %vector.body, !llvm.loop !28

middle.block:                                     ; preds = %vector.body
  %78 = add nuw nsw i64 %23, 1
  %exitcond3.not = icmp eq i64 %78, 256
  br i1 %exitcond3.not, label %shift-left_add_fusion_wrapped.exit, label %vector.ph, !llvm.loop !31

shift-left_add_fusion_wrapped.exit:               ; preds = %middle.block, %1
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 2}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 3072}
!5 = !{i64 3145728}
!6 = !{!7}
!7 = distinct !{!7, !8, !"shift-left_add_fusion_wrapped: argument 0"}
!8 = distinct !{!8, !"shift-left_add_fusion_wrapped"}
!9 = !{!10}
!10 = distinct !{!10, !8, !"shift-left_add_fusion_wrapped: argument 1"}
!11 = !{!12}
!12 = distinct !{!12, !8, !"shift-left_add_fusion_wrapped: argument 2"}
!13 = !{!14}
!14 = distinct !{!14, !8, !"shift-left_add_fusion_wrapped: argument 3"}
!15 = !{!16}
!16 = distinct !{!16, !8, !"shift-left_add_fusion_wrapped: argument 4"}
!17 = !{!18}
!18 = distinct !{!18, !8, !"shift-left_add_fusion_wrapped: argument 5"}
!19 = !{!20}
!20 = distinct !{!20, !8, !"shift-left_add_fusion_wrapped: argument 6"}
!21 = !{!7, !12, !14, !16, !18, !20}
!22 = !{!7, !10, !14, !16, !18, !20}
!23 = !{!7, !10, !12, !14, !18, !20}
!24 = !{!7, !10, !12, !14, !16, !20}
!25 = !{!10, !12, !14, !16, !18, !20}
!26 = !{!7, !10, !12, !16, !18, !20}
!27 = !{!7, !10, !12, !14, !16, !18}
!28 = distinct !{!28, !29, !30}
!29 = !{!"llvm.loop.isvectorized", i32 1}
!30 = !{!"llvm.loop.unroll.runtime.disable"}
!31 = distinct !{!31, !32}
!32 = !{!"llvm.loop.unroll.disable"}
