; ModuleID = '__compute_module_multiply_add_fusion_kernel_module'
source_filename = "__compute_module_multiply_add_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @multiply_add_fusion(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !4
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !5
  %9 = getelementptr inbounds nuw i8, ptr %3, i64 48
  %10 = load ptr, ptr %9, align 8, !invariant.load !3, !dereferenceable !5
  %11 = getelementptr inbounds nuw i8, ptr %3, i64 64
  %12 = load ptr, ptr %11, align 8, !invariant.load !3, !dereferenceable !4
  tail call void @llvm.experimental.noalias.scope.decl(metadata !6)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !11)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !13)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !15)
  br label %vector.ph

vector.ph:                                        ; preds = %1, %middle.block
  %13 = phi i64 [ 0, %1 ], [ %73, %middle.block ]
  %14 = mul nuw nsw i64 %13, 768
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %vector.ph
  %index = phi i64 [ 0, %vector.ph ], [ %index.next.2, %vector.body ]
  %15 = getelementptr inbounds nuw float, ptr %10, i64 %index
  %16 = getelementptr inbounds nuw i8, ptr %15, i64 32
  %wide.load = load <8 x float>, ptr %15, align 4, !invariant.load !3, !alias.scope !13, !noalias !17
  %wide.load3 = load <8 x float>, ptr %16, align 4, !invariant.load !3, !alias.scope !13, !noalias !17
  %17 = add nuw nsw i64 %index, %14
  %18 = getelementptr inbounds nuw float, ptr %4, i64 %17
  %19 = getelementptr inbounds nuw i8, ptr %18, i64 32
  %wide.load4 = load <8 x float>, ptr %18, align 4, !invariant.load !3, !alias.scope !6, !noalias !18
  %wide.load5 = load <8 x float>, ptr %19, align 4, !invariant.load !3, !alias.scope !6, !noalias !18
  %20 = fmul <8 x float> %wide.load, %wide.load4
  %21 = fmul <8 x float> %wide.load3, %wide.load5
  %22 = getelementptr inbounds nuw float, ptr %8, i64 %index
  %23 = getelementptr inbounds nuw i8, ptr %22, i64 32
  %wide.load6 = load <8 x float>, ptr %22, align 4, !invariant.load !3, !alias.scope !11, !noalias !19
  %wide.load7 = load <8 x float>, ptr %23, align 4, !invariant.load !3, !alias.scope !11, !noalias !19
  %24 = getelementptr inbounds nuw float, ptr %6, i64 %17
  %25 = getelementptr inbounds nuw i8, ptr %24, i64 32
  %wide.load8 = load <8 x float>, ptr %24, align 4, !invariant.load !3, !alias.scope !9, !noalias !20
  %wide.load9 = load <8 x float>, ptr %25, align 4, !invariant.load !3, !alias.scope !9, !noalias !20
  %26 = fadd <8 x float> %20, %wide.load6
  %27 = fadd <8 x float> %21, %wide.load7
  %28 = fmul <8 x float> %wide.load8, %26
  %29 = fmul <8 x float> %wide.load9, %27
  %30 = fadd <8 x float> %wide.load4, %28
  %31 = fadd <8 x float> %wide.load5, %29
  %32 = getelementptr inbounds nuw float, ptr %12, i64 %17
  %33 = getelementptr inbounds nuw i8, ptr %32, i64 32
  store <8 x float> %30, ptr %32, align 4, !alias.scope !15, !noalias !21
  store <8 x float> %31, ptr %33, align 4, !alias.scope !15, !noalias !21
  %index.next = add nuw nsw i64 %index, 16
  %34 = getelementptr inbounds nuw float, ptr %10, i64 %index.next
  %35 = getelementptr inbounds nuw i8, ptr %34, i64 32
  %wide.load.1 = load <8 x float>, ptr %34, align 4, !invariant.load !3, !alias.scope !13, !noalias !17
  %wide.load3.1 = load <8 x float>, ptr %35, align 4, !invariant.load !3, !alias.scope !13, !noalias !17
  %36 = add nuw nsw i64 %index.next, %14
  %37 = getelementptr inbounds nuw float, ptr %4, i64 %36
  %38 = getelementptr inbounds nuw i8, ptr %37, i64 32
  %wide.load4.1 = load <8 x float>, ptr %37, align 4, !invariant.load !3, !alias.scope !6, !noalias !18
  %wide.load5.1 = load <8 x float>, ptr %38, align 4, !invariant.load !3, !alias.scope !6, !noalias !18
  %39 = fmul <8 x float> %wide.load.1, %wide.load4.1
  %40 = fmul <8 x float> %wide.load3.1, %wide.load5.1
  %41 = getelementptr inbounds nuw float, ptr %8, i64 %index.next
  %42 = getelementptr inbounds nuw i8, ptr %41, i64 32
  %wide.load6.1 = load <8 x float>, ptr %41, align 4, !invariant.load !3, !alias.scope !11, !noalias !19
  %wide.load7.1 = load <8 x float>, ptr %42, align 4, !invariant.load !3, !alias.scope !11, !noalias !19
  %43 = getelementptr inbounds nuw float, ptr %6, i64 %36
  %44 = getelementptr inbounds nuw i8, ptr %43, i64 32
  %wide.load8.1 = load <8 x float>, ptr %43, align 4, !invariant.load !3, !alias.scope !9, !noalias !20
  %wide.load9.1 = load <8 x float>, ptr %44, align 4, !invariant.load !3, !alias.scope !9, !noalias !20
  %45 = fadd <8 x float> %39, %wide.load6.1
  %46 = fadd <8 x float> %40, %wide.load7.1
  %47 = fmul <8 x float> %wide.load8.1, %45
  %48 = fmul <8 x float> %wide.load9.1, %46
  %49 = fadd <8 x float> %wide.load4.1, %47
  %50 = fadd <8 x float> %wide.load5.1, %48
  %51 = getelementptr inbounds nuw float, ptr %12, i64 %36
  %52 = getelementptr inbounds nuw i8, ptr %51, i64 32
  store <8 x float> %49, ptr %51, align 4, !alias.scope !15, !noalias !21
  store <8 x float> %50, ptr %52, align 4, !alias.scope !15, !noalias !21
  %index.next.1 = add nuw nsw i64 %index, 32
  %53 = getelementptr inbounds nuw float, ptr %10, i64 %index.next.1
  %54 = getelementptr inbounds nuw i8, ptr %53, i64 32
  %wide.load.2 = load <8 x float>, ptr %53, align 4, !invariant.load !3, !alias.scope !13, !noalias !17
  %wide.load3.2 = load <8 x float>, ptr %54, align 4, !invariant.load !3, !alias.scope !13, !noalias !17
  %55 = add nuw nsw i64 %index.next.1, %14
  %56 = getelementptr inbounds nuw float, ptr %4, i64 %55
  %57 = getelementptr inbounds nuw i8, ptr %56, i64 32
  %wide.load4.2 = load <8 x float>, ptr %56, align 4, !invariant.load !3, !alias.scope !6, !noalias !18
  %wide.load5.2 = load <8 x float>, ptr %57, align 4, !invariant.load !3, !alias.scope !6, !noalias !18
  %58 = fmul <8 x float> %wide.load.2, %wide.load4.2
  %59 = fmul <8 x float> %wide.load3.2, %wide.load5.2
  %60 = getelementptr inbounds nuw float, ptr %8, i64 %index.next.1
  %61 = getelementptr inbounds nuw i8, ptr %60, i64 32
  %wide.load6.2 = load <8 x float>, ptr %60, align 4, !invariant.load !3, !alias.scope !11, !noalias !19
  %wide.load7.2 = load <8 x float>, ptr %61, align 4, !invariant.load !3, !alias.scope !11, !noalias !19
  %62 = getelementptr inbounds nuw float, ptr %6, i64 %55
  %63 = getelementptr inbounds nuw i8, ptr %62, i64 32
  %wide.load8.2 = load <8 x float>, ptr %62, align 4, !invariant.load !3, !alias.scope !9, !noalias !20
  %wide.load9.2 = load <8 x float>, ptr %63, align 4, !invariant.load !3, !alias.scope !9, !noalias !20
  %64 = fadd <8 x float> %58, %wide.load6.2
  %65 = fadd <8 x float> %59, %wide.load7.2
  %66 = fmul <8 x float> %wide.load8.2, %64
  %67 = fmul <8 x float> %wide.load9.2, %65
  %68 = fadd <8 x float> %wide.load4.2, %66
  %69 = fadd <8 x float> %wide.load5.2, %67
  %70 = getelementptr inbounds nuw float, ptr %12, i64 %55
  %71 = getelementptr inbounds nuw i8, ptr %70, i64 32
  store <8 x float> %68, ptr %70, align 4, !alias.scope !15, !noalias !21
  store <8 x float> %69, ptr %71, align 4, !alias.scope !15, !noalias !21
  %index.next.2 = add nuw nsw i64 %index, 48
  %72 = icmp eq i64 %index.next.2, 768
  br i1 %72, label %middle.block, label %vector.body, !llvm.loop !22

middle.block:                                     ; preds = %vector.body
  %73 = add nuw nsw i64 %13, 1
  %exitcond2.not = icmp eq i64 %73, 1024
  br i1 %exitcond2.not, label %multiply_add_fusion_wrapped.exit, label %vector.ph, !llvm.loop !25

multiply_add_fusion_wrapped.exit:                 ; preds = %middle.block
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 2}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 3145728}
!5 = !{i64 3072}
!6 = !{!7}
!7 = distinct !{!7, !8, !"multiply_add_fusion_wrapped: argument 0"}
!8 = distinct !{!8, !"multiply_add_fusion_wrapped"}
!9 = !{!10}
!10 = distinct !{!10, !8, !"multiply_add_fusion_wrapped: argument 1"}
!11 = !{!12}
!12 = distinct !{!12, !8, !"multiply_add_fusion_wrapped: argument 2"}
!13 = !{!14}
!14 = distinct !{!14, !8, !"multiply_add_fusion_wrapped: argument 3"}
!15 = !{!16}
!16 = distinct !{!16, !8, !"multiply_add_fusion_wrapped: argument 4"}
!17 = !{!7, !10, !12, !16}
!18 = !{!10, !12, !14, !16}
!19 = !{!7, !10, !14, !16}
!20 = !{!7, !12, !14, !16}
!21 = !{!7, !10, !12, !14}
!22 = distinct !{!22, !23, !24}
!23 = !{!"llvm.loop.isvectorized", i32 1}
!24 = !{!"llvm.loop.unroll.runtime.disable"}
!25 = distinct !{!25, !26}
!26 = !{!"llvm.loop.unroll.disable"}
