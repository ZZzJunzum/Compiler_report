; ModuleID = '__compute_module_convert_reduce_fusion_kernel_module'
source_filename = "__compute_module_convert_reduce_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @convert_reduce_fusion(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !5
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !4
  %9 = getelementptr inbounds nuw i8, ptr %3, i64 48
  %10 = load ptr, ptr %9, align 8, !invariant.load !3, !dereferenceable !5
  %11 = getelementptr inbounds nuw i8, ptr %3, i64 64
  %12 = load ptr, ptr %11, align 8, !invariant.load !3, !dereferenceable !5
  %13 = getelementptr inbounds nuw i8, ptr %3, i64 80
  %14 = load ptr, ptr %13, align 8, !invariant.load !3, !dereferenceable !5
  %15 = getelementptr inbounds nuw i8, ptr %3, i64 96
  %16 = load ptr, ptr %15, align 8, !invariant.load !3, !dereferenceable !6
  %17 = getelementptr inbounds nuw i8, ptr %3, i64 112
  %18 = load ptr, ptr %17, align 8, !invariant.load !3, !dereferenceable !6
  tail call void @llvm.experimental.noalias.scope.decl(metadata !7)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !10)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !12)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !14)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !16)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !18)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !20)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !22)
  br label %vector.ph

vector.ph:                                        ; preds = %1, %middle.block
  %19 = phi i64 [ 0, %1 ], [ %61, %middle.block ]
  %20 = mul nuw nsw i64 %19, 768
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %vector.ph
  %index = phi i64 [ 0, %vector.ph ], [ %index.next, %vector.body ]
  %vec.phi = phi <8 x i32> [ zeroinitializer, %vector.ph ], [ %54, %vector.body ]
  %vec.phi7 = phi <8 x i32> [ zeroinitializer, %vector.ph ], [ %55, %vector.body ]
  %vec.phi8 = phi <8 x i32> [ zeroinitializer, %vector.ph ], [ %52, %vector.body ]
  %vec.phi9 = phi <8 x i32> [ zeroinitializer, %vector.ph ], [ %53, %vector.body ]
  %21 = add nuw nsw i64 %index, %20
  %22 = getelementptr inbounds nuw float, ptr %8, i64 %21
  %23 = getelementptr inbounds nuw i8, ptr %22, i64 32
  %wide.load = load <8 x float>, ptr %22, align 4, !invariant.load !3, !alias.scope !12, !noalias !24
  %wide.load10 = load <8 x float>, ptr %23, align 4, !invariant.load !3, !alias.scope !12, !noalias !24
  %24 = getelementptr inbounds nuw float, ptr %14, i64 %index
  %25 = getelementptr inbounds nuw i8, ptr %24, i64 32
  %wide.load11 = load <8 x float>, ptr %24, align 4, !invariant.load !3, !alias.scope !18, !noalias !25
  %wide.load12 = load <8 x float>, ptr %25, align 4, !invariant.load !3, !alias.scope !18, !noalias !25
  %26 = fmul <8 x float> %wide.load, %wide.load11
  %27 = fmul <8 x float> %wide.load10, %wide.load12
  %28 = getelementptr inbounds nuw float, ptr %12, i64 %index
  %29 = getelementptr inbounds nuw i8, ptr %28, i64 32
  %wide.load13 = load <8 x float>, ptr %28, align 4, !invariant.load !3, !alias.scope !16, !noalias !26
  %wide.load14 = load <8 x float>, ptr %29, align 4, !invariant.load !3, !alias.scope !16, !noalias !26
  %30 = fadd <8 x float> %26, %wide.load13
  %31 = fadd <8 x float> %27, %wide.load14
  %32 = fcmp ogt <8 x float> %30, zeroinitializer
  %33 = fcmp ogt <8 x float> %31, zeroinitializer
  %34 = zext <8 x i1> %32 to <8 x i32>
  %35 = zext <8 x i1> %33 to <8 x i32>
  %36 = getelementptr inbounds nuw float, ptr %10, i64 %index
  %37 = getelementptr inbounds nuw i8, ptr %36, i64 32
  %wide.load15 = load <8 x float>, ptr %36, align 4, !invariant.load !3, !alias.scope !14, !noalias !27
  %wide.load16 = load <8 x float>, ptr %37, align 4, !invariant.load !3, !alias.scope !14, !noalias !27
  %38 = fmul <8 x float> %wide.load, %wide.load15
  %39 = fmul <8 x float> %wide.load10, %wide.load16
  %40 = getelementptr inbounds nuw float, ptr %6, i64 %index
  %41 = getelementptr inbounds nuw i8, ptr %40, i64 32
  %wide.load17 = load <8 x float>, ptr %40, align 4, !invariant.load !3, !alias.scope !10, !noalias !28
  %wide.load18 = load <8 x float>, ptr %41, align 4, !invariant.load !3, !alias.scope !10, !noalias !28
  %42 = getelementptr inbounds nuw float, ptr %4, i64 %21
  %43 = getelementptr inbounds nuw i8, ptr %42, i64 32
  %wide.load19 = load <8 x float>, ptr %42, align 4, !invariant.load !3, !alias.scope !7, !noalias !29
  %wide.load20 = load <8 x float>, ptr %43, align 4, !invariant.load !3, !alias.scope !7, !noalias !29
  %44 = fadd <8 x float> %38, %wide.load17
  %45 = fadd <8 x float> %39, %wide.load18
  %46 = fmul <8 x float> %wide.load19, %44
  %47 = fmul <8 x float> %wide.load20, %45
  %48 = fcmp ogt <8 x float> %46, zeroinitializer
  %49 = fcmp ogt <8 x float> %47, zeroinitializer
  %50 = zext <8 x i1> %48 to <8 x i32>
  %51 = zext <8 x i1> %49 to <8 x i32>
  %52 = add <8 x i32> %vec.phi8, %34
  %53 = add <8 x i32> %vec.phi9, %35
  %54 = add <8 x i32> %vec.phi, %50
  %55 = add <8 x i32> %vec.phi7, %51
  %index.next = add nuw i64 %index, 16
  %56 = icmp eq i64 %index.next, 768
  br i1 %56, label %middle.block, label %vector.body, !llvm.loop !30

middle.block:                                     ; preds = %vector.body
  %bin.rdx21 = add <8 x i32> %53, %52
  %57 = tail call i32 @llvm.vector.reduce.add.v8i32(<8 x i32> %bin.rdx21)
  %bin.rdx = add <8 x i32> %55, %54
  %58 = tail call i32 @llvm.vector.reduce.add.v8i32(<8 x i32> %bin.rdx)
  %59 = getelementptr inbounds nuw i32, ptr %16, i64 %19
  store i32 %57, ptr %59, align 4, !alias.scope !20, !noalias !33
  %60 = getelementptr inbounds nuw i32, ptr %18, i64 %19
  store i32 %58, ptr %60, align 4, !alias.scope !22, !noalias !34
  %61 = add nuw nsw i64 %19, 1
  %exitcond4.not = icmp eq i64 %61, 1024
  br i1 %exitcond4.not, label %convert_reduce_fusion_wrapped.exit, label %vector.ph, !llvm.loop !35

convert_reduce_fusion_wrapped.exit:               ; preds = %middle.block
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.vector.reduce.add.v8i32(<8 x i32>) #2

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #2 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 1}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 3145728}
!5 = !{i64 3072}
!6 = !{i64 4096}
!7 = !{!8}
!8 = distinct !{!8, !9, !"convert_reduce_fusion_wrapped: argument 0"}
!9 = distinct !{!9, !"convert_reduce_fusion_wrapped"}
!10 = !{!11}
!11 = distinct !{!11, !9, !"convert_reduce_fusion_wrapped: argument 1"}
!12 = !{!13}
!13 = distinct !{!13, !9, !"convert_reduce_fusion_wrapped: argument 2"}
!14 = !{!15}
!15 = distinct !{!15, !9, !"convert_reduce_fusion_wrapped: argument 3"}
!16 = !{!17}
!17 = distinct !{!17, !9, !"convert_reduce_fusion_wrapped: argument 4"}
!18 = !{!19}
!19 = distinct !{!19, !9, !"convert_reduce_fusion_wrapped: argument 5"}
!20 = !{!21}
!21 = distinct !{!21, !9, !"convert_reduce_fusion_wrapped: argument 6"}
!22 = !{!23}
!23 = distinct !{!23, !9, !"convert_reduce_fusion_wrapped: argument 7"}
!24 = !{!8, !11, !15, !17, !19, !21, !23}
!25 = !{!8, !11, !13, !15, !17, !21, !23}
!26 = !{!8, !11, !13, !15, !19, !21, !23}
!27 = !{!8, !11, !13, !17, !19, !21, !23}
!28 = !{!8, !13, !15, !17, !19, !21, !23}
!29 = !{!11, !13, !15, !17, !19, !21, !23}
!30 = distinct !{!30, !31, !32}
!31 = !{!"llvm.loop.isvectorized", i32 1}
!32 = !{!"llvm.loop.unroll.runtime.disable"}
!33 = !{!8, !11, !13, !15, !17, !19, !23}
!34 = !{!8, !11, !13, !15, !17, !19, !21}
!35 = distinct !{!35, !36}
!36 = !{!"llvm.loop.unroll.disable"}
