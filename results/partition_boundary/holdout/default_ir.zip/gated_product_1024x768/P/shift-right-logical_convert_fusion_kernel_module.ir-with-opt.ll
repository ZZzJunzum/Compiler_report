; ModuleID = '__compute_module_shift-right-logical_convert_fusion_kernel_module'
source_filename = "__compute_module_shift-right-logical_convert_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @shift-right-logical_convert_fusion(ptr readonly captures(none) %0) local_unnamed_addr #0 {
vector.ph:
  %1 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %2 = load ptr, ptr %1, align 8, !invariant.load !3
  %3 = load ptr, ptr %2, align 8, !invariant.load !3, !dereferenceable !4
  %4 = getelementptr inbounds nuw i8, ptr %2, i64 16
  %5 = load ptr, ptr %4, align 8, !invariant.load !3, !dereferenceable !4
  tail call void @llvm.experimental.noalias.scope.decl(metadata !5)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !8)
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %vector.ph
  %index = phi i64 [ 0, %vector.ph ], [ %index.next.3, %vector.body ]
  %6 = getelementptr inbounds nuw i32, ptr %3, i64 %index
  %7 = getelementptr inbounds nuw i8, ptr %6, i64 32
  %8 = getelementptr inbounds nuw i8, ptr %6, i64 64
  %9 = getelementptr inbounds nuw i8, ptr %6, i64 96
  %wide.load = load <8 x i32>, ptr %6, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %wide.load1 = load <8 x i32>, ptr %7, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %wide.load2 = load <8 x i32>, ptr %8, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %wide.load3 = load <8 x i32>, ptr %9, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %10 = lshr <8 x i32> %wide.load, splat (i32 10)
  %11 = lshr <8 x i32> %wide.load1, splat (i32 10)
  %12 = lshr <8 x i32> %wide.load2, splat (i32 10)
  %13 = lshr <8 x i32> %wide.load3, splat (i32 10)
  %14 = getelementptr inbounds nuw i32, ptr %5, i64 %index
  %15 = getelementptr inbounds nuw i8, ptr %14, i64 32
  %16 = getelementptr inbounds nuw i8, ptr %14, i64 64
  %17 = getelementptr inbounds nuw i8, ptr %14, i64 96
  store <8 x i32> %10, ptr %14, align 4, !alias.scope !8, !noalias !5
  store <8 x i32> %11, ptr %15, align 4, !alias.scope !8, !noalias !5
  store <8 x i32> %12, ptr %16, align 4, !alias.scope !8, !noalias !5
  store <8 x i32> %13, ptr %17, align 4, !alias.scope !8, !noalias !5
  %index.next = or disjoint i64 %index, 32
  %18 = getelementptr inbounds nuw i32, ptr %3, i64 %index.next
  %19 = getelementptr inbounds nuw i8, ptr %18, i64 32
  %20 = getelementptr inbounds nuw i8, ptr %18, i64 64
  %21 = getelementptr inbounds nuw i8, ptr %18, i64 96
  %wide.load.1 = load <8 x i32>, ptr %18, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %wide.load1.1 = load <8 x i32>, ptr %19, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %wide.load2.1 = load <8 x i32>, ptr %20, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %wide.load3.1 = load <8 x i32>, ptr %21, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %22 = lshr <8 x i32> %wide.load.1, splat (i32 10)
  %23 = lshr <8 x i32> %wide.load1.1, splat (i32 10)
  %24 = lshr <8 x i32> %wide.load2.1, splat (i32 10)
  %25 = lshr <8 x i32> %wide.load3.1, splat (i32 10)
  %26 = getelementptr inbounds nuw i32, ptr %5, i64 %index.next
  %27 = getelementptr inbounds nuw i8, ptr %26, i64 32
  %28 = getelementptr inbounds nuw i8, ptr %26, i64 64
  %29 = getelementptr inbounds nuw i8, ptr %26, i64 96
  store <8 x i32> %22, ptr %26, align 4, !alias.scope !8, !noalias !5
  store <8 x i32> %23, ptr %27, align 4, !alias.scope !8, !noalias !5
  store <8 x i32> %24, ptr %28, align 4, !alias.scope !8, !noalias !5
  store <8 x i32> %25, ptr %29, align 4, !alias.scope !8, !noalias !5
  %index.next.1 = or disjoint i64 %index, 64
  %30 = getelementptr inbounds nuw i32, ptr %3, i64 %index.next.1
  %31 = getelementptr inbounds nuw i8, ptr %30, i64 32
  %32 = getelementptr inbounds nuw i8, ptr %30, i64 64
  %33 = getelementptr inbounds nuw i8, ptr %30, i64 96
  %wide.load.2 = load <8 x i32>, ptr %30, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %wide.load1.2 = load <8 x i32>, ptr %31, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %wide.load2.2 = load <8 x i32>, ptr %32, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %wide.load3.2 = load <8 x i32>, ptr %33, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %34 = lshr <8 x i32> %wide.load.2, splat (i32 10)
  %35 = lshr <8 x i32> %wide.load1.2, splat (i32 10)
  %36 = lshr <8 x i32> %wide.load2.2, splat (i32 10)
  %37 = lshr <8 x i32> %wide.load3.2, splat (i32 10)
  %38 = getelementptr inbounds nuw i32, ptr %5, i64 %index.next.1
  %39 = getelementptr inbounds nuw i8, ptr %38, i64 32
  %40 = getelementptr inbounds nuw i8, ptr %38, i64 64
  %41 = getelementptr inbounds nuw i8, ptr %38, i64 96
  store <8 x i32> %34, ptr %38, align 4, !alias.scope !8, !noalias !5
  store <8 x i32> %35, ptr %39, align 4, !alias.scope !8, !noalias !5
  store <8 x i32> %36, ptr %40, align 4, !alias.scope !8, !noalias !5
  store <8 x i32> %37, ptr %41, align 4, !alias.scope !8, !noalias !5
  %index.next.2 = or disjoint i64 %index, 96
  %42 = getelementptr inbounds nuw i32, ptr %3, i64 %index.next.2
  %43 = getelementptr inbounds nuw i8, ptr %42, i64 32
  %44 = getelementptr inbounds nuw i8, ptr %42, i64 64
  %45 = getelementptr inbounds nuw i8, ptr %42, i64 96
  %wide.load.3 = load <8 x i32>, ptr %42, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %wide.load1.3 = load <8 x i32>, ptr %43, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %wide.load2.3 = load <8 x i32>, ptr %44, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %wide.load3.3 = load <8 x i32>, ptr %45, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %46 = lshr <8 x i32> %wide.load.3, splat (i32 10)
  %47 = lshr <8 x i32> %wide.load1.3, splat (i32 10)
  %48 = lshr <8 x i32> %wide.load2.3, splat (i32 10)
  %49 = lshr <8 x i32> %wide.load3.3, splat (i32 10)
  %50 = getelementptr inbounds nuw i32, ptr %5, i64 %index.next.2
  %51 = getelementptr inbounds nuw i8, ptr %50, i64 32
  %52 = getelementptr inbounds nuw i8, ptr %50, i64 64
  %53 = getelementptr inbounds nuw i8, ptr %50, i64 96
  store <8 x i32> %46, ptr %50, align 4, !alias.scope !8, !noalias !5
  store <8 x i32> %47, ptr %51, align 4, !alias.scope !8, !noalias !5
  store <8 x i32> %48, ptr %52, align 4, !alias.scope !8, !noalias !5
  store <8 x i32> %49, ptr %53, align 4, !alias.scope !8, !noalias !5
  %index.next.3 = add nuw nsw i64 %index, 128
  %54 = icmp eq i64 %index.next.3, 1024
  br i1 %54, label %shift-right-logical_convert_fusion_wrapped.exit, label %vector.body, !llvm.loop !10

shift-right-logical_convert_fusion_wrapped.exit:  ; preds = %vector.body
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 4}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 4096}
!5 = !{!6}
!6 = distinct !{!6, !7, !"shift-right-logical_convert_fusion_wrapped: argument 0"}
!7 = distinct !{!7, !"shift-right-logical_convert_fusion_wrapped"}
!8 = !{!9}
!9 = distinct !{!9, !7, !"shift-right-logical_convert_fusion_wrapped: argument 1"}
!10 = distinct !{!10, !11, !12}
!11 = !{!"llvm.loop.isvectorized", i32 1}
!12 = !{!"llvm.loop.unroll.runtime.disable"}
