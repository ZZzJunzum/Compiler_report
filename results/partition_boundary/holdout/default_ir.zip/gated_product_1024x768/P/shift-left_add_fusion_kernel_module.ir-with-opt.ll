; ModuleID = '__compute_module_shift-left_add_fusion_kernel_module'
source_filename = "__compute_module_shift-left_add_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @shift-left_add_fusion(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !5
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !4
  %9 = getelementptr inbounds nuw i8, ptr %3, i64 48
  %10 = load ptr, ptr %9, align 8, !invariant.load !3, !dereferenceable !5
  %11 = getelementptr inbounds nuw i8, ptr %3, i64 64
  %12 = load ptr, ptr %11, align 8, !invariant.load !3, !dereferenceable !5
  %13 = getelementptr inbounds nuw i8, ptr %3, i64 80
  %14 = load ptr, ptr %13, align 8, !invariant.load !3, !dereferenceable !5
  %15 = getelementptr inbounds nuw i8, ptr %3, i64 96
  %16 = load ptr, ptr %15, align 8, !invariant.load !3, !dereferenceable !4
  %17 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %18 = load ptr, ptr %17, align 8
  %19 = load i64, ptr %18, align 4, !invariant.load !3
  tail call void @llvm.experimental.noalias.scope.decl(metadata !6)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !11)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !13)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !15)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !17)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !19)
  %20 = icmp ult i64 %19, 4
  br i1 %20, label %21, label %shift-left_add_fusion_wrapped.exit

21:                                               ; preds = %1
  %22 = mul nuw nsw i64 %19, 196608
  br label %vector.ph

vector.ph:                                        ; preds = %21, %middle.block
  %23 = phi i64 [ 0, %21 ], [ %81, %middle.block ]
  %24 = mul nuw nsw i64 %23, 768
  %25 = add nuw nsw i64 %24, %22
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %vector.ph
  %index = phi i64 [ 0, %vector.ph ], [ %index.next.2, %vector.body ]
  %26 = getelementptr inbounds nuw float, ptr %10, i64 %index
  %wide.load = load <8 x float>, ptr %26, align 4, !invariant.load !3, !alias.scope !13, !noalias !21
  %27 = add nuw nsw i64 %25, %index
  %28 = getelementptr inbounds nuw float, ptr %8, i64 %27
  %wide.load5 = load <8 x float>, ptr %28, align 4, !invariant.load !3, !alias.scope !11, !noalias !22
  %29 = fmul <8 x float> %wide.load, %wide.load5
  %30 = getelementptr inbounds nuw float, ptr %6, i64 %index
  %wide.load6 = load <8 x float>, ptr %30, align 4, !invariant.load !3, !alias.scope !9, !noalias !23
  %31 = getelementptr inbounds nuw float, ptr %14, i64 %index
  %wide.load7 = load <8 x float>, ptr %31, align 4, !invariant.load !3, !alias.scope !17, !noalias !24
  %32 = getelementptr inbounds nuw float, ptr %4, i64 %27
  %wide.load8 = load <8 x float>, ptr %32, align 4, !invariant.load !3, !alias.scope !6, !noalias !25
  %33 = fadd <8 x float> %29, %wide.load6
  %34 = fmul <8 x float> %wide.load5, %wide.load7
  %35 = getelementptr inbounds nuw float, ptr %12, i64 %index
  %wide.load9 = load <8 x float>, ptr %35, align 4, !invariant.load !3, !alias.scope !15, !noalias !26
  %36 = fmul <8 x float> %33, %wide.load8
  %37 = fadd <8 x float> %34, %wide.load9
  %38 = fcmp ogt <8 x float> %36, zeroinitializer
  %39 = fcmp ogt <8 x float> %37, zeroinitializer
  %40 = zext <8 x i1> %39 to <8 x i32>
  %41 = select <8 x i1> %38, <8 x i32> splat (i32 1024), <8 x i32> zeroinitializer
  %42 = or disjoint <8 x i32> %41, %40
  %43 = getelementptr inbounds nuw i32, ptr %16, i64 %27
  store <8 x i32> %42, ptr %43, align 4, !alias.scope !19, !noalias !27
  %index.next = add nuw nsw i64 %index, 8
  %44 = getelementptr inbounds nuw float, ptr %10, i64 %index.next
  %wide.load.1 = load <8 x float>, ptr %44, align 4, !invariant.load !3, !alias.scope !13, !noalias !21
  %45 = add nuw nsw i64 %25, %index.next
  %46 = getelementptr inbounds nuw float, ptr %8, i64 %45
  %wide.load5.1 = load <8 x float>, ptr %46, align 4, !invariant.load !3, !alias.scope !11, !noalias !22
  %47 = fmul <8 x float> %wide.load.1, %wide.load5.1
  %48 = getelementptr inbounds nuw float, ptr %6, i64 %index.next
  %wide.load6.1 = load <8 x float>, ptr %48, align 4, !invariant.load !3, !alias.scope !9, !noalias !23
  %49 = getelementptr inbounds nuw float, ptr %14, i64 %index.next
  %wide.load7.1 = load <8 x float>, ptr %49, align 4, !invariant.load !3, !alias.scope !17, !noalias !24
  %50 = getelementptr inbounds nuw float, ptr %4, i64 %45
  %wide.load8.1 = load <8 x float>, ptr %50, align 4, !invariant.load !3, !alias.scope !6, !noalias !25
  %51 = fadd <8 x float> %47, %wide.load6.1
  %52 = fmul <8 x float> %wide.load5.1, %wide.load7.1
  %53 = getelementptr inbounds nuw float, ptr %12, i64 %index.next
  %wide.load9.1 = load <8 x float>, ptr %53, align 4, !invariant.load !3, !alias.scope !15, !noalias !26
  %54 = fmul <8 x float> %51, %wide.load8.1
  %55 = fadd <8 x float> %52, %wide.load9.1
  %56 = fcmp ogt <8 x float> %54, zeroinitializer
  %57 = fcmp ogt <8 x float> %55, zeroinitializer
  %58 = zext <8 x i1> %57 to <8 x i32>
  %59 = select <8 x i1> %56, <8 x i32> splat (i32 1024), <8 x i32> zeroinitializer
  %60 = or disjoint <8 x i32> %59, %58
  %61 = getelementptr inbounds nuw i32, ptr %16, i64 %45
  store <8 x i32> %60, ptr %61, align 4, !alias.scope !19, !noalias !27
  %index.next.1 = add nuw nsw i64 %index, 16
  %62 = getelementptr inbounds nuw float, ptr %10, i64 %index.next.1
  %wide.load.2 = load <8 x float>, ptr %62, align 4, !invariant.load !3, !alias.scope !13, !noalias !21
  %63 = add nuw nsw i64 %25, %index.next.1
  %64 = getelementptr inbounds nuw float, ptr %8, i64 %63
  %wide.load5.2 = load <8 x float>, ptr %64, align 4, !invariant.load !3, !alias.scope !11, !noalias !22
  %65 = fmul <8 x float> %wide.load.2, %wide.load5.2
  %66 = getelementptr inbounds nuw float, ptr %6, i64 %index.next.1
  %wide.load6.2 = load <8 x float>, ptr %66, align 4, !invariant.load !3, !alias.scope !9, !noalias !23
  %67 = getelementptr inbounds nuw float, ptr %14, i64 %index.next.1
  %wide.load7.2 = load <8 x float>, ptr %67, align 4, !invariant.load !3, !alias.scope !17, !noalias !24
  %68 = getelementptr inbounds nuw float, ptr %4, i64 %63
  %wide.load8.2 = load <8 x float>, ptr %68, align 4, !invariant.load !3, !alias.scope !6, !noalias !25
  %69 = fadd <8 x float> %65, %wide.load6.2
  %70 = fmul <8 x float> %wide.load5.2, %wide.load7.2
  %71 = getelementptr inbounds nuw float, ptr %12, i64 %index.next.1
  %wide.load9.2 = load <8 x float>, ptr %71, align 4, !invariant.load !3, !alias.scope !15, !noalias !26
  %72 = fmul <8 x float> %69, %wide.load8.2
  %73 = fadd <8 x float> %70, %wide.load9.2
  %74 = fcmp ogt <8 x float> %72, zeroinitializer
  %75 = fcmp ogt <8 x float> %73, zeroinitializer
  %76 = zext <8 x i1> %75 to <8 x i32>
  %77 = select <8 x i1> %74, <8 x i32> splat (i32 1024), <8 x i32> zeroinitializer
  %78 = or disjoint <8 x i32> %77, %76
  %79 = getelementptr inbounds nuw i32, ptr %16, i64 %63
  store <8 x i32> %78, ptr %79, align 4, !alias.scope !19, !noalias !27
  %index.next.2 = add nuw nsw i64 %index, 24
  %80 = icmp eq i64 %index.next.2, 768
  br i1 %80, label %middle.block, label %vector.body, !llvm.loop !28

middle.block:                                     ; preds = %vector.body
  %81 = add nuw nsw i64 %23, 1
  %exitcond3.not = icmp eq i64 %81, 256
  br i1 %exitcond3.not, label %shift-left_add_fusion_wrapped.exit, label %vector.ph, !llvm.loop !31

shift-left_add_fusion_wrapped.exit:               ; preds = %middle.block, %1
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 3}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 3145728}
!5 = !{i64 3072}
!6 = !{!7}
!7 = distinct !{!7, !8, !"shift-left_add_fusion_wrapped: argument 0"}
!8 = distinct !{!8, !"shift-left_add_fusion_wrapped"}
!9 = !{!10}
!10 = distinct !{!10, !8, !"shift-left_add_fusion_wrapped: argument 1"}
!11 = !{!12}
!12 = distinct !{!12, !8, !"shift-left_add_fusion_wrapped: argument 2"}
!13 = !{!14}
!14 = distinct !{!14, !8, !"shift-left_add_fusion_wrapped: argument 3"}
!15 = !{!16}
!16 = distinct !{!16, !8, !"shift-left_add_fusion_wrapped: argument 4"}
!17 = !{!18}
!18 = distinct !{!18, !8, !"shift-left_add_fusion_wrapped: argument 5"}
!19 = !{!20}
!20 = distinct !{!20, !8, !"shift-left_add_fusion_wrapped: argument 6"}
!21 = !{!7, !10, !12, !16, !18, !20}
!22 = !{!7, !10, !14, !16, !18, !20}
!23 = !{!7, !12, !14, !16, !18, !20}
!24 = !{!7, !10, !12, !14, !16, !20}
!25 = !{!10, !12, !14, !16, !18, !20}
!26 = !{!7, !10, !12, !14, !18, !20}
!27 = !{!7, !10, !12, !14, !16, !18}
!28 = distinct !{!28, !29, !30}
!29 = !{!"llvm.loop.isvectorized", i32 1}
!30 = !{!"llvm.loop.unroll.runtime.disable"}
!31 = distinct !{!31, !32}
!32 = !{!"llvm.loop.unroll.disable"}
