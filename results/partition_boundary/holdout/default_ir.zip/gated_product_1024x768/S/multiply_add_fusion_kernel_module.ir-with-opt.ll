; ModuleID = '__compute_module_multiply_add_fusion_kernel_module'
source_filename = "__compute_module_multiply_add_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @multiply_add_fusion(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !4
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !5
  %9 = getelementptr inbounds nuw i8, ptr %3, i64 48
  %10 = load ptr, ptr %9, align 8, !invariant.load !3, !dereferenceable !5
  %11 = getelementptr inbounds nuw i8, ptr %3, i64 64
  %12 = load ptr, ptr %11, align 8, !invariant.load !3, !dereferenceable !4
  %13 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %14 = load ptr, ptr %13, align 8
  %15 = load i64, ptr %14, align 4, !invariant.load !3
  tail call void @llvm.experimental.noalias.scope.decl(metadata !6)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !11)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !13)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !15)
  %16 = icmp ult i64 %15, 4
  br i1 %16, label %17, label %multiply_add_fusion_wrapped.exit

17:                                               ; preds = %1
  %18 = mul nuw nsw i64 %15, 196608
  br label %vector.ph

vector.ph:                                        ; preds = %17, %middle.block
  %19 = phi i64 [ 0, %17 ], [ %80, %middle.block ]
  %20 = mul nuw nsw i64 %19, 768
  %21 = add nuw nsw i64 %20, %18
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %vector.ph
  %index = phi i64 [ 0, %vector.ph ], [ %index.next.2, %vector.body ]
  %22 = getelementptr inbounds nuw float, ptr %10, i64 %index
  %23 = getelementptr inbounds nuw i8, ptr %22, i64 32
  %wide.load = load <8 x float>, ptr %22, align 4, !invariant.load !3, !alias.scope !13, !noalias !17
  %wide.load5 = load <8 x float>, ptr %23, align 4, !invariant.load !3, !alias.scope !13, !noalias !17
  %24 = add nuw nsw i64 %21, %index
  %25 = getelementptr inbounds nuw float, ptr %4, i64 %24
  %26 = getelementptr inbounds nuw i8, ptr %25, i64 32
  %wide.load6 = load <8 x float>, ptr %25, align 4, !invariant.load !3, !alias.scope !6, !noalias !18
  %wide.load7 = load <8 x float>, ptr %26, align 4, !invariant.load !3, !alias.scope !6, !noalias !18
  %27 = fmul <8 x float> %wide.load, %wide.load6
  %28 = fmul <8 x float> %wide.load5, %wide.load7
  %29 = getelementptr inbounds nuw float, ptr %8, i64 %index
  %30 = getelementptr inbounds nuw i8, ptr %29, i64 32
  %wide.load8 = load <8 x float>, ptr %29, align 4, !invariant.load !3, !alias.scope !11, !noalias !19
  %wide.load9 = load <8 x float>, ptr %30, align 4, !invariant.load !3, !alias.scope !11, !noalias !19
  %31 = getelementptr inbounds nuw float, ptr %6, i64 %24
  %32 = getelementptr inbounds nuw i8, ptr %31, i64 32
  %wide.load10 = load <8 x float>, ptr %31, align 4, !invariant.load !3, !alias.scope !9, !noalias !20
  %wide.load11 = load <8 x float>, ptr %32, align 4, !invariant.load !3, !alias.scope !9, !noalias !20
  %33 = fadd <8 x float> %27, %wide.load8
  %34 = fadd <8 x float> %28, %wide.load9
  %35 = fmul <8 x float> %wide.load10, %33
  %36 = fmul <8 x float> %wide.load11, %34
  %37 = fadd <8 x float> %wide.load6, %35
  %38 = fadd <8 x float> %wide.load7, %36
  %39 = getelementptr inbounds nuw float, ptr %12, i64 %24
  %40 = getelementptr inbounds nuw i8, ptr %39, i64 32
  store <8 x float> %37, ptr %39, align 4, !alias.scope !15, !noalias !21
  store <8 x float> %38, ptr %40, align 4, !alias.scope !15, !noalias !21
  %index.next = add nuw nsw i64 %index, 16
  %41 = getelementptr inbounds nuw float, ptr %10, i64 %index.next
  %42 = getelementptr inbounds nuw i8, ptr %41, i64 32
  %wide.load.1 = load <8 x float>, ptr %41, align 4, !invariant.load !3, !alias.scope !13, !noalias !17
  %wide.load5.1 = load <8 x float>, ptr %42, align 4, !invariant.load !3, !alias.scope !13, !noalias !17
  %43 = add nuw nsw i64 %21, %index.next
  %44 = getelementptr inbounds nuw float, ptr %4, i64 %43
  %45 = getelementptr inbounds nuw i8, ptr %44, i64 32
  %wide.load6.1 = load <8 x float>, ptr %44, align 4, !invariant.load !3, !alias.scope !6, !noalias !18
  %wide.load7.1 = load <8 x float>, ptr %45, align 4, !invariant.load !3, !alias.scope !6, !noalias !18
  %46 = fmul <8 x float> %wide.load.1, %wide.load6.1
  %47 = fmul <8 x float> %wide.load5.1, %wide.load7.1
  %48 = getelementptr inbounds nuw float, ptr %8, i64 %index.next
  %49 = getelementptr inbounds nuw i8, ptr %48, i64 32
  %wide.load8.1 = load <8 x float>, ptr %48, align 4, !invariant.load !3, !alias.scope !11, !noalias !19
  %wide.load9.1 = load <8 x float>, ptr %49, align 4, !invariant.load !3, !alias.scope !11, !noalias !19
  %50 = getelementptr inbounds nuw float, ptr %6, i64 %43
  %51 = getelementptr inbounds nuw i8, ptr %50, i64 32
  %wide.load10.1 = load <8 x float>, ptr %50, align 4, !invariant.load !3, !alias.scope !9, !noalias !20
  %wide.load11.1 = load <8 x float>, ptr %51, align 4, !invariant.load !3, !alias.scope !9, !noalias !20
  %52 = fadd <8 x float> %46, %wide.load8.1
  %53 = fadd <8 x float> %47, %wide.load9.1
  %54 = fmul <8 x float> %wide.load10.1, %52
  %55 = fmul <8 x float> %wide.load11.1, %53
  %56 = fadd <8 x float> %wide.load6.1, %54
  %57 = fadd <8 x float> %wide.load7.1, %55
  %58 = getelementptr inbounds nuw float, ptr %12, i64 %43
  %59 = getelementptr inbounds nuw i8, ptr %58, i64 32
  store <8 x float> %56, ptr %58, align 4, !alias.scope !15, !noalias !21
  store <8 x float> %57, ptr %59, align 4, !alias.scope !15, !noalias !21
  %index.next.1 = add nuw nsw i64 %index, 32
  %60 = getelementptr inbounds nuw float, ptr %10, i64 %index.next.1
  %61 = getelementptr inbounds nuw i8, ptr %60, i64 32
  %wide.load.2 = load <8 x float>, ptr %60, align 4, !invariant.load !3, !alias.scope !13, !noalias !17
  %wide.load5.2 = load <8 x float>, ptr %61, align 4, !invariant.load !3, !alias.scope !13, !noalias !17
  %62 = add nuw nsw i64 %21, %index.next.1
  %63 = getelementptr inbounds nuw float, ptr %4, i64 %62
  %64 = getelementptr inbounds nuw i8, ptr %63, i64 32
  %wide.load6.2 = load <8 x float>, ptr %63, align 4, !invariant.load !3, !alias.scope !6, !noalias !18
  %wide.load7.2 = load <8 x float>, ptr %64, align 4, !invariant.load !3, !alias.scope !6, !noalias !18
  %65 = fmul <8 x float> %wide.load.2, %wide.load6.2
  %66 = fmul <8 x float> %wide.load5.2, %wide.load7.2
  %67 = getelementptr inbounds nuw float, ptr %8, i64 %index.next.1
  %68 = getelementptr inbounds nuw i8, ptr %67, i64 32
  %wide.load8.2 = load <8 x float>, ptr %67, align 4, !invariant.load !3, !alias.scope !11, !noalias !19
  %wide.load9.2 = load <8 x float>, ptr %68, align 4, !invariant.load !3, !alias.scope !11, !noalias !19
  %69 = getelementptr inbounds nuw float, ptr %6, i64 %62
  %70 = getelementptr inbounds nuw i8, ptr %69, i64 32
  %wide.load10.2 = load <8 x float>, ptr %69, align 4, !invariant.load !3, !alias.scope !9, !noalias !20
  %wide.load11.2 = load <8 x float>, ptr %70, align 4, !invariant.load !3, !alias.scope !9, !noalias !20
  %71 = fadd <8 x float> %65, %wide.load8.2
  %72 = fadd <8 x float> %66, %wide.load9.2
  %73 = fmul <8 x float> %wide.load10.2, %71
  %74 = fmul <8 x float> %wide.load11.2, %72
  %75 = fadd <8 x float> %wide.load6.2, %73
  %76 = fadd <8 x float> %wide.load7.2, %74
  %77 = getelementptr inbounds nuw float, ptr %12, i64 %62
  %78 = getelementptr inbounds nuw i8, ptr %77, i64 32
  store <8 x float> %75, ptr %77, align 4, !alias.scope !15, !noalias !21
  store <8 x float> %76, ptr %78, align 4, !alias.scope !15, !noalias !21
  %index.next.2 = add nuw nsw i64 %index, 48
  %79 = icmp eq i64 %index.next.2, 768
  br i1 %79, label %middle.block, label %vector.body, !llvm.loop !22

middle.block:                                     ; preds = %vector.body
  %80 = add nuw nsw i64 %19, 1
  %exitcond3.not = icmp eq i64 %80, 256
  br i1 %exitcond3.not, label %multiply_add_fusion_wrapped.exit, label %vector.ph, !llvm.loop !25

multiply_add_fusion_wrapped.exit:                 ; preds = %middle.block, %1
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 3}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 3145728}
!5 = !{i64 3072}
!6 = !{!7}
!7 = distinct !{!7, !8, !"multiply_add_fusion_wrapped: argument 0"}
!8 = distinct !{!8, !"multiply_add_fusion_wrapped"}
!9 = !{!10}
!10 = distinct !{!10, !8, !"multiply_add_fusion_wrapped: argument 1"}
!11 = !{!12}
!12 = distinct !{!12, !8, !"multiply_add_fusion_wrapped: argument 2"}
!13 = !{!14}
!14 = distinct !{!14, !8, !"multiply_add_fusion_wrapped: argument 3"}
!15 = !{!16}
!16 = distinct !{!16, !8, !"multiply_add_fusion_wrapped: argument 4"}
!17 = !{!7, !10, !12, !16}
!18 = !{!10, !12, !14, !16}
!19 = !{!7, !10, !14, !16}
!20 = !{!7, !12, !14, !16}
!21 = !{!7, !10, !12, !14}
!22 = distinct !{!22, !23, !24}
!23 = !{!"llvm.loop.isvectorized", i32 1}
!24 = !{!"llvm.loop.unroll.runtime.disable"}
!25 = distinct !{!25, !26}
!26 = !{!"llvm.loop.unroll.disable"}
