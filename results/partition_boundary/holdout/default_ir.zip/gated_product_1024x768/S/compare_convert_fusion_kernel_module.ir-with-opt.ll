; ModuleID = '__compute_module_compare_convert_fusion_kernel_module'
source_filename = "__compute_module_compare_convert_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @compare_convert_fusion(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !5
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !4
  %9 = getelementptr inbounds nuw i8, ptr %3, i64 48
  %10 = load ptr, ptr %9, align 8, !invariant.load !3, !dereferenceable !5
  %11 = getelementptr inbounds nuw i8, ptr %3, i64 64
  %12 = load ptr, ptr %11, align 8, !invariant.load !3, !dereferenceable !4
  %13 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %14 = load ptr, ptr %13, align 8
  %15 = load i64, ptr %14, align 4, !invariant.load !3
  tail call void @llvm.experimental.noalias.scope.decl(metadata !6)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !11)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !13)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !15)
  %16 = icmp ult i64 %15, 4
  br i1 %16, label %17, label %compare_convert_fusion_wrapped.exit

17:                                               ; preds = %1
  %18 = mul nuw nsw i64 %15, 196608
  br label %vector.ph

vector.ph:                                        ; preds = %17, %middle.block
  %19 = phi i64 [ 0, %17 ], [ %86, %middle.block ]
  %20 = mul nuw nsw i64 %19, 768
  %21 = add nuw nsw i64 %20, %18
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %vector.ph
  %index = phi i64 [ 0, %vector.ph ], [ %index.next.2, %vector.body ]
  %22 = add nuw nsw i64 %21, %index
  %23 = getelementptr inbounds nuw float, ptr %8, i64 %22
  %24 = getelementptr inbounds nuw i8, ptr %23, i64 32
  %wide.load = load <8 x float>, ptr %23, align 4, !invariant.load !3, !alias.scope !11, !noalias !17
  %wide.load5 = load <8 x float>, ptr %24, align 4, !invariant.load !3, !alias.scope !11, !noalias !17
  %25 = getelementptr inbounds nuw float, ptr %10, i64 %index
  %26 = getelementptr inbounds nuw i8, ptr %25, i64 32
  %wide.load6 = load <8 x float>, ptr %25, align 4, !invariant.load !3, !alias.scope !13, !noalias !18
  %wide.load7 = load <8 x float>, ptr %26, align 4, !invariant.load !3, !alias.scope !13, !noalias !18
  %27 = fmul <8 x float> %wide.load, %wide.load6
  %28 = fmul <8 x float> %wide.load5, %wide.load7
  %29 = getelementptr inbounds nuw float, ptr %6, i64 %index
  %30 = getelementptr inbounds nuw i8, ptr %29, i64 32
  %wide.load8 = load <8 x float>, ptr %29, align 4, !invariant.load !3, !alias.scope !9, !noalias !19
  %wide.load9 = load <8 x float>, ptr %30, align 4, !invariant.load !3, !alias.scope !9, !noalias !19
  %31 = getelementptr inbounds nuw float, ptr %4, i64 %22
  %32 = getelementptr inbounds nuw i8, ptr %31, i64 32
  %wide.load10 = load <8 x float>, ptr %31, align 4, !invariant.load !3, !alias.scope !6, !noalias !20
  %wide.load11 = load <8 x float>, ptr %32, align 4, !invariant.load !3, !alias.scope !6, !noalias !20
  %33 = fadd <8 x float> %27, %wide.load8
  %34 = fadd <8 x float> %28, %wide.load9
  %35 = fmul <8 x float> %wide.load10, %33
  %36 = fmul <8 x float> %wide.load11, %34
  %37 = fcmp ogt <8 x float> %35, zeroinitializer
  %38 = fcmp ogt <8 x float> %36, zeroinitializer
  %39 = zext <8 x i1> %37 to <8 x i32>
  %40 = zext <8 x i1> %38 to <8 x i32>
  %41 = getelementptr inbounds nuw i32, ptr %12, i64 %22
  %42 = getelementptr inbounds nuw i8, ptr %41, i64 32
  store <8 x i32> %39, ptr %41, align 4, !alias.scope !15, !noalias !21
  store <8 x i32> %40, ptr %42, align 4, !alias.scope !15, !noalias !21
  %index.next = add nuw nsw i64 %index, 16
  %43 = add nuw nsw i64 %21, %index.next
  %44 = getelementptr inbounds nuw float, ptr %8, i64 %43
  %45 = getelementptr inbounds nuw i8, ptr %44, i64 32
  %wide.load.1 = load <8 x float>, ptr %44, align 4, !invariant.load !3, !alias.scope !11, !noalias !17
  %wide.load5.1 = load <8 x float>, ptr %45, align 4, !invariant.load !3, !alias.scope !11, !noalias !17
  %46 = getelementptr inbounds nuw float, ptr %10, i64 %index.next
  %47 = getelementptr inbounds nuw i8, ptr %46, i64 32
  %wide.load6.1 = load <8 x float>, ptr %46, align 4, !invariant.load !3, !alias.scope !13, !noalias !18
  %wide.load7.1 = load <8 x float>, ptr %47, align 4, !invariant.load !3, !alias.scope !13, !noalias !18
  %48 = fmul <8 x float> %wide.load.1, %wide.load6.1
  %49 = fmul <8 x float> %wide.load5.1, %wide.load7.1
  %50 = getelementptr inbounds nuw float, ptr %6, i64 %index.next
  %51 = getelementptr inbounds nuw i8, ptr %50, i64 32
  %wide.load8.1 = load <8 x float>, ptr %50, align 4, !invariant.load !3, !alias.scope !9, !noalias !19
  %wide.load9.1 = load <8 x float>, ptr %51, align 4, !invariant.load !3, !alias.scope !9, !noalias !19
  %52 = getelementptr inbounds nuw float, ptr %4, i64 %43
  %53 = getelementptr inbounds nuw i8, ptr %52, i64 32
  %wide.load10.1 = load <8 x float>, ptr %52, align 4, !invariant.load !3, !alias.scope !6, !noalias !20
  %wide.load11.1 = load <8 x float>, ptr %53, align 4, !invariant.load !3, !alias.scope !6, !noalias !20
  %54 = fadd <8 x float> %48, %wide.load8.1
  %55 = fadd <8 x float> %49, %wide.load9.1
  %56 = fmul <8 x float> %wide.load10.1, %54
  %57 = fmul <8 x float> %wide.load11.1, %55
  %58 = fcmp ogt <8 x float> %56, zeroinitializer
  %59 = fcmp ogt <8 x float> %57, zeroinitializer
  %60 = zext <8 x i1> %58 to <8 x i32>
  %61 = zext <8 x i1> %59 to <8 x i32>
  %62 = getelementptr inbounds nuw i32, ptr %12, i64 %43
  %63 = getelementptr inbounds nuw i8, ptr %62, i64 32
  store <8 x i32> %60, ptr %62, align 4, !alias.scope !15, !noalias !21
  store <8 x i32> %61, ptr %63, align 4, !alias.scope !15, !noalias !21
  %index.next.1 = add nuw nsw i64 %index, 32
  %64 = add nuw nsw i64 %21, %index.next.1
  %65 = getelementptr inbounds nuw float, ptr %8, i64 %64
  %66 = getelementptr inbounds nuw i8, ptr %65, i64 32
  %wide.load.2 = load <8 x float>, ptr %65, align 4, !invariant.load !3, !alias.scope !11, !noalias !17
  %wide.load5.2 = load <8 x float>, ptr %66, align 4, !invariant.load !3, !alias.scope !11, !noalias !17
  %67 = getelementptr inbounds nuw float, ptr %10, i64 %index.next.1
  %68 = getelementptr inbounds nuw i8, ptr %67, i64 32
  %wide.load6.2 = load <8 x float>, ptr %67, align 4, !invariant.load !3, !alias.scope !13, !noalias !18
  %wide.load7.2 = load <8 x float>, ptr %68, align 4, !invariant.load !3, !alias.scope !13, !noalias !18
  %69 = fmul <8 x float> %wide.load.2, %wide.load6.2
  %70 = fmul <8 x float> %wide.load5.2, %wide.load7.2
  %71 = getelementptr inbounds nuw float, ptr %6, i64 %index.next.1
  %72 = getelementptr inbounds nuw i8, ptr %71, i64 32
  %wide.load8.2 = load <8 x float>, ptr %71, align 4, !invariant.load !3, !alias.scope !9, !noalias !19
  %wide.load9.2 = load <8 x float>, ptr %72, align 4, !invariant.load !3, !alias.scope !9, !noalias !19
  %73 = getelementptr inbounds nuw float, ptr %4, i64 %64
  %74 = getelementptr inbounds nuw i8, ptr %73, i64 32
  %wide.load10.2 = load <8 x float>, ptr %73, align 4, !invariant.load !3, !alias.scope !6, !noalias !20
  %wide.load11.2 = load <8 x float>, ptr %74, align 4, !invariant.load !3, !alias.scope !6, !noalias !20
  %75 = fadd <8 x float> %69, %wide.load8.2
  %76 = fadd <8 x float> %70, %wide.load9.2
  %77 = fmul <8 x float> %wide.load10.2, %75
  %78 = fmul <8 x float> %wide.load11.2, %76
  %79 = fcmp ogt <8 x float> %77, zeroinitializer
  %80 = fcmp ogt <8 x float> %78, zeroinitializer
  %81 = zext <8 x i1> %79 to <8 x i32>
  %82 = zext <8 x i1> %80 to <8 x i32>
  %83 = getelementptr inbounds nuw i32, ptr %12, i64 %64
  %84 = getelementptr inbounds nuw i8, ptr %83, i64 32
  store <8 x i32> %81, ptr %83, align 4, !alias.scope !15, !noalias !21
  store <8 x i32> %82, ptr %84, align 4, !alias.scope !15, !noalias !21
  %index.next.2 = add nuw nsw i64 %index, 48
  %85 = icmp eq i64 %index.next.2, 768
  br i1 %85, label %middle.block, label %vector.body, !llvm.loop !22

middle.block:                                     ; preds = %vector.body
  %86 = add nuw nsw i64 %19, 1
  %exitcond3.not = icmp eq i64 %86, 256
  br i1 %exitcond3.not, label %compare_convert_fusion_wrapped.exit, label %vector.ph, !llvm.loop !25

compare_convert_fusion_wrapped.exit:              ; preds = %middle.block, %1
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 1}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 3145728}
!5 = !{i64 3072}
!6 = !{!7}
!7 = distinct !{!7, !8, !"compare_convert_fusion_wrapped: argument 0"}
!8 = distinct !{!8, !"compare_convert_fusion_wrapped"}
!9 = !{!10}
!10 = distinct !{!10, !8, !"compare_convert_fusion_wrapped: argument 1"}
!11 = !{!12}
!12 = distinct !{!12, !8, !"compare_convert_fusion_wrapped: argument 2"}
!13 = !{!14}
!14 = distinct !{!14, !8, !"compare_convert_fusion_wrapped: argument 3"}
!15 = !{!16}
!16 = distinct !{!16, !8, !"compare_convert_fusion_wrapped: argument 4"}
!17 = !{!7, !10, !14, !16}
!18 = !{!7, !10, !12, !16}
!19 = !{!7, !12, !14, !16}
!20 = !{!10, !12, !14, !16}
!21 = !{!7, !10, !12, !14}
!22 = distinct !{!22, !23, !24}
!23 = !{!"llvm.loop.isvectorized", i32 1}
!24 = !{!"llvm.loop.unroll.runtime.disable"}
!25 = distinct !{!25, !26}
!26 = !{!"llvm.loop.unroll.disable"}
