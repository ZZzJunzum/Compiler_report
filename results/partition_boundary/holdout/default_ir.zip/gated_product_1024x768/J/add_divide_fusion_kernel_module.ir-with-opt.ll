; ModuleID = '__compute_module_add_divide_fusion_kernel_module'
source_filename = "__compute_module_add_divide_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @add_divide_fusion(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !5
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !4
  %9 = getelementptr inbounds nuw i8, ptr %3, i64 48
  %10 = load ptr, ptr %9, align 8, !invariant.load !3, !dereferenceable !5
  %11 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %12 = load ptr, ptr %11, align 8
  %13 = load i64, ptr %12, align 4, !invariant.load !3
  tail call void @llvm.experimental.noalias.scope.decl(metadata !6)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !11)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !13)
  %14 = icmp ult i64 %13, 4
  br i1 %14, label %15, label %add_divide_fusion_wrapped.exit

15:                                               ; preds = %1
  %16 = mul nuw nsw i64 %13, 196608
  br label %vector.ph

vector.ph:                                        ; preds = %15, %middle.block
  %17 = phi i64 [ 0, %15 ], [ %46, %middle.block ]
  %18 = mul nuw nsw i64 %17, 768
  %19 = add nuw nsw i64 %18, %16
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %vector.ph
  %index = phi i64 [ 0, %vector.ph ], [ %index.next, %vector.body ]
  %20 = add nuw nsw i64 %19, %index
  %21 = getelementptr inbounds nuw float, ptr %6, i64 %20
  %wide.load = load <8 x float>, ptr %21, align 4, !invariant.load !3, !alias.scope !9, !noalias !15
  %22 = getelementptr inbounds nuw float, ptr %8, i64 %index
  %wide.load5 = load <8 x float>, ptr %22, align 4, !invariant.load !3, !alias.scope !11, !noalias !16
  %23 = fmul <8 x float> %wide.load, %wide.load5
  %24 = getelementptr inbounds nuw float, ptr %4, i64 %index
  %wide.load6 = load <8 x float>, ptr %24, align 4, !invariant.load !3, !alias.scope !6, !noalias !17
  %25 = fadd <8 x float> %23, %wide.load6
  %26 = fneg <8 x float> %25
  %27 = fcmp uge <8 x float> %26, splat (float 0xC055F33340000000)
  %28 = select <8 x i1> %27, <8 x float> %26, <8 x float> splat (float 0xC055F33340000000)
  %29 = fcmp ule <8 x float> %28, splat (float 0x4056333340000000)
  %30 = select <8 x i1> %29, <8 x float> %28, <8 x float> splat (float 0x4056333340000000)
  %exp_f32.i = fmul <8 x float> %30, splat (float 0x3FF7154760000000)
  %exp_f321.i = fadd <8 x float> splat (float 5.000000e-01), %exp_f32.i
  %31 = call <8 x float> @llvm.floor.v8f32(<8 x float> %exp_f321.i)
  %32 = fcmp uge <8 x float> %31, splat (float -1.270000e+02)
  %33 = select <8 x i1> %32, <8 x float> %31, <8 x float> splat (float -1.270000e+02)
  %34 = fcmp ule <8 x float> %33, splat (float 1.270000e+02)
  %35 = select <8 x i1> %34, <8 x float> %33, <8 x float> splat (float 1.270000e+02)
  %exp_f322.i = fmul <8 x float> splat (float 0x3FE6300000000000), %35
  %36 = fsub <8 x float> %30, %exp_f322.i
  %exp_f323.i = fmul <8 x float> splat (float 0xBF2BD01060000000), %35
  %37 = fsub <8 x float> %36, %exp_f323.i
  %exp_f324.i = fmul <8 x float> %37, splat (float 0x3F2A0D2CE0000000)
  %exp_f325.i = fadd <8 x float> splat (float 0x3F56E879C0000000), %exp_f324.i
  %exp_f326.i = fmul <8 x float> %exp_f325.i, %37
  %exp_f327.i = fadd <8 x float> splat (float 0x3F81112100000000), %exp_f326.i
  %exp_f328.i = fmul <8 x float> %exp_f327.i, %37
  %exp_f329.i = fadd <8 x float> splat (float 0x3FA5553820000000), %exp_f328.i
  %exp_f3210.i = fmul <8 x float> %exp_f329.i, %37
  %exp_f3211.i = fadd <8 x float> splat (float 0x3FC5555540000000), %exp_f3210.i
  %exp_f3212.i = fmul <8 x float> %exp_f3211.i, %37
  %exp_f3213.i = fadd <8 x float> splat (float 5.000000e-01), %exp_f3212.i
  %exp_f3214.i = fmul <8 x float> %37, %37
  %exp_f3215.i = fmul <8 x float> %exp_f3213.i, %exp_f3214.i
  %exp_f3216.i = fadd <8 x float> %37, %exp_f3215.i
  %exp_f3217.i = fadd <8 x float> splat (float 1.000000e+00), %exp_f3216.i
  %38 = fptosi <8 x float> %35 to <8 x i32>
  %39 = add <8 x i32> %38, splat (i32 127)
  %40 = shl <8 x i32> %39, splat (i32 23)
  %41 = bitcast <8 x i32> %40 to <8 x float>
  %exp_f3218.i = fmul <8 x float> %exp_f3217.i, %41
  %42 = fadd <8 x float> %exp_f3218.i, splat (float 1.000000e+00)
  %43 = fdiv <8 x float> splat (float 1.000000e+00), %42
  %44 = getelementptr inbounds nuw float, ptr %10, i64 %20
  store <8 x float> %43, ptr %44, align 4, !alias.scope !13, !noalias !18
  %index.next = add nuw i64 %index, 8
  %45 = icmp eq i64 %index.next, 768
  br i1 %45, label %middle.block, label %vector.body, !llvm.loop !19

middle.block:                                     ; preds = %vector.body
  %46 = add nuw nsw i64 %17, 1
  %exitcond3.not = icmp eq i64 %46, 256
  br i1 %exitcond3.not, label %add_divide_fusion_wrapped.exit, label %vector.ph, !llvm.loop !22

add_divide_fusion_wrapped.exit:                   ; preds = %middle.block, %1
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <4 x float> @llvm.floor.v4f32(<4 x float>) #2

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.floor.v8f32(<8 x float>) #2

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <16 x float> @llvm.floor.v16f32(<16 x float>) #2

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 0}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 3072}
!5 = !{i64 3145728}
!6 = !{!7}
!7 = distinct !{!7, !8, !"add_divide_fusion_wrapped: argument 0"}
!8 = distinct !{!8, !"add_divide_fusion_wrapped"}
!9 = !{!10}
!10 = distinct !{!10, !8, !"add_divide_fusion_wrapped: argument 1"}
!11 = !{!12}
!12 = distinct !{!12, !8, !"add_divide_fusion_wrapped: argument 2"}
!13 = !{!14}
!14 = distinct !{!14, !8, !"add_divide_fusion_wrapped: argument 3"}
!15 = !{!7, !12, !14}
!16 = !{!7, !10, !14}
!17 = !{!10, !12, !14}
!18 = !{!7, !10, !12}
!19 = distinct !{!19, !20, !21}
!20 = !{!"llvm.loop.isvectorized", i32 1}
!21 = !{!"llvm.loop.unroll.runtime.disable"}
!22 = distinct !{!22, !23}
!23 = !{!"llvm.loop.unroll.disable"}
