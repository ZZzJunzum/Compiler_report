; ModuleID = '__compute_module_convert_reduce_fusion_kernel_module'
source_filename = "__compute_module_convert_reduce_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @convert_reduce_fusion(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !5
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !4
  %9 = getelementptr inbounds nuw i8, ptr %3, i64 48
  %10 = load ptr, ptr %9, align 8, !invariant.load !3, !dereferenceable !5
  %11 = getelementptr inbounds nuw i8, ptr %3, i64 64
  %12 = load ptr, ptr %11, align 8, !invariant.load !3, !dereferenceable !5
  %13 = getelementptr inbounds nuw i8, ptr %3, i64 80
  %14 = load ptr, ptr %13, align 8, !invariant.load !3, !dereferenceable !5
  %15 = getelementptr inbounds nuw i8, ptr %3, i64 96
  %16 = load ptr, ptr %15, align 8, !invariant.load !3, !dereferenceable !6
  %17 = getelementptr inbounds nuw i8, ptr %3, i64 112
  %18 = load ptr, ptr %17, align 8, !invariant.load !3, !dereferenceable !6
  %19 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %20 = load ptr, ptr %19, align 8
  %21 = load i64, ptr %20, align 4, !invariant.load !3
  tail call void @llvm.experimental.noalias.scope.decl(metadata !7)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !10)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !12)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !14)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !16)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !18)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !20)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !22)
  %22 = icmp slt i64 %21, 11
  br i1 %22, label %23, label %73

23:                                               ; preds = %1
  %24 = icmp sgt i64 %21, -1
  br i1 %24, label %25, label %convert_reduce_fusion_wrapped.exit

25:                                               ; preds = %23
  %26 = mul nuw nsw i64 %21, 86
  %27 = mul nuw nsw i64 %21, 66048
  br label %vector.ph41

vector.ph41:                                      ; preds = %25, %middle.block61
  %28 = phi i64 [ 0, %25 ], [ %72, %middle.block61 ]
  %29 = mul nuw nsw i64 %28, 768
  %30 = add nuw nsw i64 %29, %27
  br label %vector.body42

vector.body42:                                    ; preds = %vector.body42, %vector.ph41
  %index43 = phi i64 [ 0, %vector.ph41 ], [ %index.next60, %vector.body42 ]
  %vec.phi44 = phi <8 x i32> [ zeroinitializer, %vector.ph41 ], [ %64, %vector.body42 ]
  %vec.phi45 = phi <8 x i32> [ zeroinitializer, %vector.ph41 ], [ %65, %vector.body42 ]
  %vec.phi46 = phi <8 x i32> [ zeroinitializer, %vector.ph41 ], [ %62, %vector.body42 ]
  %vec.phi47 = phi <8 x i32> [ zeroinitializer, %vector.ph41 ], [ %63, %vector.body42 ]
  %31 = add nuw nsw i64 %30, %index43
  %32 = getelementptr inbounds nuw float, ptr %8, i64 %31
  %33 = getelementptr inbounds nuw i8, ptr %32, i64 32
  %wide.load48 = load <8 x float>, ptr %32, align 4, !invariant.load !3, !alias.scope !12, !noalias !24
  %wide.load49 = load <8 x float>, ptr %33, align 4, !invariant.load !3, !alias.scope !12, !noalias !24
  %34 = getelementptr inbounds nuw float, ptr %14, i64 %index43
  %35 = getelementptr inbounds nuw i8, ptr %34, i64 32
  %wide.load50 = load <8 x float>, ptr %34, align 4, !invariant.load !3, !alias.scope !18, !noalias !25
  %wide.load51 = load <8 x float>, ptr %35, align 4, !invariant.load !3, !alias.scope !18, !noalias !25
  %36 = fmul <8 x float> %wide.load48, %wide.load50
  %37 = fmul <8 x float> %wide.load49, %wide.load51
  %38 = getelementptr inbounds nuw float, ptr %12, i64 %index43
  %39 = getelementptr inbounds nuw i8, ptr %38, i64 32
  %wide.load52 = load <8 x float>, ptr %38, align 4, !invariant.load !3, !alias.scope !16, !noalias !26
  %wide.load53 = load <8 x float>, ptr %39, align 4, !invariant.load !3, !alias.scope !16, !noalias !26
  %40 = fadd <8 x float> %36, %wide.load52
  %41 = fadd <8 x float> %37, %wide.load53
  %42 = fcmp ogt <8 x float> %40, zeroinitializer
  %43 = fcmp ogt <8 x float> %41, zeroinitializer
  %44 = zext <8 x i1> %42 to <8 x i32>
  %45 = zext <8 x i1> %43 to <8 x i32>
  %46 = getelementptr inbounds nuw float, ptr %10, i64 %index43
  %47 = getelementptr inbounds nuw i8, ptr %46, i64 32
  %wide.load54 = load <8 x float>, ptr %46, align 4, !invariant.load !3, !alias.scope !14, !noalias !27
  %wide.load55 = load <8 x float>, ptr %47, align 4, !invariant.load !3, !alias.scope !14, !noalias !27
  %48 = fmul <8 x float> %wide.load48, %wide.load54
  %49 = fmul <8 x float> %wide.load49, %wide.load55
  %50 = getelementptr inbounds nuw float, ptr %6, i64 %index43
  %51 = getelementptr inbounds nuw i8, ptr %50, i64 32
  %wide.load56 = load <8 x float>, ptr %50, align 4, !invariant.load !3, !alias.scope !10, !noalias !28
  %wide.load57 = load <8 x float>, ptr %51, align 4, !invariant.load !3, !alias.scope !10, !noalias !28
  %52 = getelementptr inbounds nuw float, ptr %4, i64 %31
  %53 = getelementptr inbounds nuw i8, ptr %52, i64 32
  %wide.load58 = load <8 x float>, ptr %52, align 4, !invariant.load !3, !alias.scope !7, !noalias !29
  %wide.load59 = load <8 x float>, ptr %53, align 4, !invariant.load !3, !alias.scope !7, !noalias !29
  %54 = fadd <8 x float> %48, %wide.load56
  %55 = fadd <8 x float> %49, %wide.load57
  %56 = fmul <8 x float> %wide.load58, %54
  %57 = fmul <8 x float> %wide.load59, %55
  %58 = fcmp ogt <8 x float> %56, zeroinitializer
  %59 = fcmp ogt <8 x float> %57, zeroinitializer
  %60 = zext <8 x i1> %58 to <8 x i32>
  %61 = zext <8 x i1> %59 to <8 x i32>
  %62 = add <8 x i32> %vec.phi46, %44
  %63 = add <8 x i32> %vec.phi47, %45
  %64 = add <8 x i32> %vec.phi44, %60
  %65 = add <8 x i32> %vec.phi45, %61
  %index.next60 = add nuw i64 %index43, 16
  %66 = icmp eq i64 %index.next60, 768
  br i1 %66, label %middle.block61, label %vector.body42, !llvm.loop !30

middle.block61:                                   ; preds = %vector.body42
  %bin.rdx63 = add <8 x i32> %63, %62
  %67 = tail call i32 @llvm.vector.reduce.add.v8i32(<8 x i32> %bin.rdx63)
  %bin.rdx62 = add <8 x i32> %65, %64
  %68 = tail call i32 @llvm.vector.reduce.add.v8i32(<8 x i32> %bin.rdx62)
  %69 = add nuw nsw i64 %28, %26
  %70 = getelementptr inbounds nuw i32, ptr %16, i64 %69
  store i32 %67, ptr %70, align 4, !alias.scope !20, !noalias !33
  %71 = getelementptr inbounds nuw i32, ptr %18, i64 %69
  store i32 %68, ptr %71, align 4, !alias.scope !22, !noalias !34
  %72 = add nuw nsw i64 %28, 1
  %exitcond15.not = icmp eq i64 %72, 86
  br i1 %exitcond15.not, label %convert_reduce_fusion_wrapped.exit, label %vector.ph41, !llvm.loop !35

73:                                               ; preds = %1
  %74 = icmp eq i64 %21, 11
  br i1 %74, label %.preheader, label %convert_reduce_fusion_wrapped.exit

.preheader:                                       ; preds = %73, %middle.block
  %75 = phi i64 [ %119, %middle.block ], [ 0, %73 ]
  %76 = mul nuw nsw i64 %75, 768
  %77 = add nuw nsw i64 %76, 726528
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %.preheader
  %index = phi i64 [ 0, %.preheader ], [ %index.next, %vector.body ]
  %vec.phi = phi <8 x i32> [ zeroinitializer, %.preheader ], [ %111, %vector.body ]
  %vec.phi26 = phi <8 x i32> [ zeroinitializer, %.preheader ], [ %112, %vector.body ]
  %vec.phi27 = phi <8 x i32> [ zeroinitializer, %.preheader ], [ %109, %vector.body ]
  %vec.phi28 = phi <8 x i32> [ zeroinitializer, %.preheader ], [ %110, %vector.body ]
  %78 = add nuw nsw i64 %77, %index
  %79 = getelementptr inbounds nuw float, ptr %8, i64 %78
  %80 = getelementptr inbounds nuw i8, ptr %79, i64 32
  %wide.load = load <8 x float>, ptr %79, align 4, !invariant.load !3, !alias.scope !12, !noalias !24
  %wide.load29 = load <8 x float>, ptr %80, align 4, !invariant.load !3, !alias.scope !12, !noalias !24
  %81 = getelementptr inbounds nuw float, ptr %14, i64 %index
  %82 = getelementptr inbounds nuw i8, ptr %81, i64 32
  %wide.load30 = load <8 x float>, ptr %81, align 4, !invariant.load !3, !alias.scope !18, !noalias !25
  %wide.load31 = load <8 x float>, ptr %82, align 4, !invariant.load !3, !alias.scope !18, !noalias !25
  %83 = fmul <8 x float> %wide.load, %wide.load30
  %84 = fmul <8 x float> %wide.load29, %wide.load31
  %85 = getelementptr inbounds nuw float, ptr %12, i64 %index
  %86 = getelementptr inbounds nuw i8, ptr %85, i64 32
  %wide.load32 = load <8 x float>, ptr %85, align 4, !invariant.load !3, !alias.scope !16, !noalias !26
  %wide.load33 = load <8 x float>, ptr %86, align 4, !invariant.load !3, !alias.scope !16, !noalias !26
  %87 = fadd <8 x float> %83, %wide.load32
  %88 = fadd <8 x float> %84, %wide.load33
  %89 = fcmp ogt <8 x float> %87, zeroinitializer
  %90 = fcmp ogt <8 x float> %88, zeroinitializer
  %91 = zext <8 x i1> %89 to <8 x i32>
  %92 = zext <8 x i1> %90 to <8 x i32>
  %93 = getelementptr inbounds nuw float, ptr %10, i64 %index
  %94 = getelementptr inbounds nuw i8, ptr %93, i64 32
  %wide.load34 = load <8 x float>, ptr %93, align 4, !invariant.load !3, !alias.scope !14, !noalias !27
  %wide.load35 = load <8 x float>, ptr %94, align 4, !invariant.load !3, !alias.scope !14, !noalias !27
  %95 = fmul <8 x float> %wide.load, %wide.load34
  %96 = fmul <8 x float> %wide.load29, %wide.load35
  %97 = getelementptr inbounds nuw float, ptr %6, i64 %index
  %98 = getelementptr inbounds nuw i8, ptr %97, i64 32
  %wide.load36 = load <8 x float>, ptr %97, align 4, !invariant.load !3, !alias.scope !10, !noalias !28
  %wide.load37 = load <8 x float>, ptr %98, align 4, !invariant.load !3, !alias.scope !10, !noalias !28
  %99 = getelementptr inbounds nuw float, ptr %4, i64 %78
  %100 = getelementptr inbounds nuw i8, ptr %99, i64 32
  %wide.load38 = load <8 x float>, ptr %99, align 4, !invariant.load !3, !alias.scope !7, !noalias !29
  %wide.load39 = load <8 x float>, ptr %100, align 4, !invariant.load !3, !alias.scope !7, !noalias !29
  %101 = fadd <8 x float> %95, %wide.load36
  %102 = fadd <8 x float> %96, %wide.load37
  %103 = fmul <8 x float> %wide.load38, %101
  %104 = fmul <8 x float> %wide.load39, %102
  %105 = fcmp ogt <8 x float> %103, zeroinitializer
  %106 = fcmp ogt <8 x float> %104, zeroinitializer
  %107 = zext <8 x i1> %105 to <8 x i32>
  %108 = zext <8 x i1> %106 to <8 x i32>
  %109 = add <8 x i32> %vec.phi27, %91
  %110 = add <8 x i32> %vec.phi28, %92
  %111 = add <8 x i32> %vec.phi, %107
  %112 = add <8 x i32> %vec.phi26, %108
  %index.next = add nuw i64 %index, 16
  %113 = icmp eq i64 %index.next, 768
  br i1 %113, label %middle.block, label %vector.body, !llvm.loop !37

middle.block:                                     ; preds = %vector.body
  %bin.rdx40 = add <8 x i32> %110, %109
  %114 = tail call i32 @llvm.vector.reduce.add.v8i32(<8 x i32> %bin.rdx40)
  %bin.rdx = add <8 x i32> %112, %111
  %115 = tail call i32 @llvm.vector.reduce.add.v8i32(<8 x i32> %bin.rdx)
  %116 = add nuw nsw i64 %75, 946
  %117 = getelementptr inbounds nuw i32, ptr %16, i64 %116
  store i32 %114, ptr %117, align 4, !alias.scope !20, !noalias !33
  %118 = getelementptr inbounds nuw i32, ptr %18, i64 %116
  store i32 %115, ptr %118, align 4, !alias.scope !22, !noalias !34
  %119 = add nuw nsw i64 %75, 1
  %exitcond13.not = icmp eq i64 %119, 78
  br i1 %exitcond13.not, label %convert_reduce_fusion_wrapped.exit, label %.preheader, !llvm.loop !35

convert_reduce_fusion_wrapped.exit:               ; preds = %middle.block, %middle.block61, %23, %73
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.vector.reduce.add.v8i32(<8 x i32>) #2

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #2 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 1}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 3145728}
!5 = !{i64 3072}
!6 = !{i64 4096}
!7 = !{!8}
!8 = distinct !{!8, !9, !"convert_reduce_fusion_wrapped: argument 0"}
!9 = distinct !{!9, !"convert_reduce_fusion_wrapped"}
!10 = !{!11}
!11 = distinct !{!11, !9, !"convert_reduce_fusion_wrapped: argument 1"}
!12 = !{!13}
!13 = distinct !{!13, !9, !"convert_reduce_fusion_wrapped: argument 2"}
!14 = !{!15}
!15 = distinct !{!15, !9, !"convert_reduce_fusion_wrapped: argument 3"}
!16 = !{!17}
!17 = distinct !{!17, !9, !"convert_reduce_fusion_wrapped: argument 4"}
!18 = !{!19}
!19 = distinct !{!19, !9, !"convert_reduce_fusion_wrapped: argument 5"}
!20 = !{!21}
!21 = distinct !{!21, !9, !"convert_reduce_fusion_wrapped: argument 6"}
!22 = !{!23}
!23 = distinct !{!23, !9, !"convert_reduce_fusion_wrapped: argument 7"}
!24 = !{!8, !11, !15, !17, !19, !21, !23}
!25 = !{!8, !11, !13, !15, !17, !21, !23}
!26 = !{!8, !11, !13, !15, !19, !21, !23}
!27 = !{!8, !11, !13, !17, !19, !21, !23}
!28 = !{!8, !13, !15, !17, !19, !21, !23}
!29 = !{!11, !13, !15, !17, !19, !21, !23}
!30 = distinct !{!30, !31, !32}
!31 = !{!"llvm.loop.isvectorized", i32 1}
!32 = !{!"llvm.loop.unroll.runtime.disable"}
!33 = !{!8, !11, !13, !15, !17, !19, !23}
!34 = !{!8, !11, !13, !15, !17, !19, !21}
!35 = distinct !{!35, !36}
!36 = !{!"llvm.loop.unroll.disable"}
!37 = distinct !{!37, !31, !32}
