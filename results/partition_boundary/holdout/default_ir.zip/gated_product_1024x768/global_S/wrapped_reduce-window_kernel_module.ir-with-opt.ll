; ModuleID = '__compute_module_wrapped_reduce-window_kernel_module'
source_filename = "__compute_module_wrapped_reduce-window_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @wrapped_reduce-window(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %3 = load ptr, ptr %2, align 8
  %4 = load i64, ptr %3, align 4, !invariant.load !3
  tail call void @llvm.experimental.noalias.scope.decl(metadata !4)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !7)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9)
  %5 = icmp ult i64 %4, 4
  br i1 %5, label %6, label %wrapped_reduce-window_wrapped.exit

6:                                                ; preds = %1
  %7 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %8 = load ptr, ptr %7, align 8, !invariant.load !3
  %9 = getelementptr inbounds nuw i8, ptr %8, i64 32
  %10 = load ptr, ptr %9, align 8, !invariant.load !3, !dereferenceable !11
  %11 = load ptr, ptr %8, align 8, !invariant.load !3, !dereferenceable !12
  %12 = getelementptr inbounds nuw i8, ptr %8, i64 16
  %13 = load ptr, ptr %12, align 8, !invariant.load !3, !dereferenceable !13
  %14 = load i32, ptr %13, align 4, !invariant.load !3, !alias.scope !7, !noalias !14
  %.idx2 = mul nuw nsw i64 %4, 786432
  %15 = getelementptr i8, ptr %11, i64 %.idx2
  %.idx = mul nuw nsw i64 %4, 768
  %16 = getelementptr i8, ptr %10, i64 %.idx
  %17 = insertelement <8 x i32> <i32 poison, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0>, i32 %14, i64 0
  br label %.preheader8

.preheader8:                                      ; preds = %6, %92
  %18 = phi i64 [ 0, %6 ], [ %93, %92 ]
  %.idx3 = mul nuw nsw i64 %18, 98304
  %19 = getelementptr i8, ptr %15, i64 %.idx3
  %.idx1 = mul nuw nsw i64 %18, 96
  %20 = getelementptr i8, ptr %16, i64 %.idx1
  br label %.preheader7

.preheader7:                                      ; preds = %.preheader8, %middle.block
  %21 = phi i64 [ 0, %.preheader8 ], [ %91, %middle.block ]
  %.idx4 = shl i64 %21, 7
  %22 = getelementptr i8, ptr %19, i64 %.idx4
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %.preheader7
  %index = phi i64 [ 0, %.preheader7 ], [ %index.next, %vector.body ]
  %vec.phi = phi <8 x i32> [ %17, %.preheader7 ], [ %87, %vector.body ]
  %vec.ind = phi <8 x i64> [ <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>, %.preheader7 ], [ %vec.ind.next, %vector.body ]
  %23 = mul nuw nsw <8 x i64> %vec.ind, splat (i64 3072)
  %24 = getelementptr i8, ptr %22, <8 x i64> %23
  %wide.masked.gather = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %24, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !4, !noalias !15
  %25 = add <8 x i32> %wide.masked.gather, %vec.phi
  %26 = getelementptr i8, <8 x ptr> %24, i64 4
  %wide.masked.gather14 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %26, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !4, !noalias !15
  %27 = add <8 x i32> %wide.masked.gather14, %25
  %28 = getelementptr i8, <8 x ptr> %24, i64 8
  %wide.masked.gather15 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %28, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !4, !noalias !15
  %29 = add <8 x i32> %wide.masked.gather15, %27
  %30 = getelementptr i8, <8 x ptr> %24, i64 12
  %wide.masked.gather16 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %30, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !4, !noalias !15
  %31 = add <8 x i32> %wide.masked.gather16, %29
  %32 = getelementptr i8, <8 x ptr> %24, i64 16
  %wide.masked.gather17 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %32, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !4, !noalias !15
  %33 = add <8 x i32> %wide.masked.gather17, %31
  %34 = getelementptr i8, <8 x ptr> %24, i64 20
  %wide.masked.gather18 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %34, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !4, !noalias !15
  %35 = add <8 x i32> %wide.masked.gather18, %33
  %36 = getelementptr i8, <8 x ptr> %24, i64 24
  %wide.masked.gather19 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %36, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !4, !noalias !15
  %37 = add <8 x i32> %wide.masked.gather19, %35
  %38 = getelementptr i8, <8 x ptr> %24, i64 28
  %wide.masked.gather20 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %38, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !4, !noalias !15
  %39 = add <8 x i32> %wide.masked.gather20, %37
  %40 = getelementptr i8, <8 x ptr> %24, i64 32
  %wide.masked.gather21 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %40, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !4, !noalias !15
  %41 = add <8 x i32> %wide.masked.gather21, %39
  %42 = getelementptr i8, <8 x ptr> %24, i64 36
  %wide.masked.gather22 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %42, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !4, !noalias !15
  %43 = add <8 x i32> %wide.masked.gather22, %41
  %44 = getelementptr i8, <8 x ptr> %24, i64 40
  %wide.masked.gather23 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %44, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !4, !noalias !15
  %45 = add <8 x i32> %wide.masked.gather23, %43
  %46 = getelementptr i8, <8 x ptr> %24, i64 44
  %wide.masked.gather24 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %46, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !4, !noalias !15
  %47 = add <8 x i32> %wide.masked.gather24, %45
  %48 = getelementptr i8, <8 x ptr> %24, i64 48
  %wide.masked.gather25 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %48, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !4, !noalias !15
  %49 = add <8 x i32> %wide.masked.gather25, %47
  %50 = getelementptr i8, <8 x ptr> %24, i64 52
  %wide.masked.gather26 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %50, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !4, !noalias !15
  %51 = add <8 x i32> %wide.masked.gather26, %49
  %52 = getelementptr i8, <8 x ptr> %24, i64 56
  %wide.masked.gather27 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %52, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !4, !noalias !15
  %53 = add <8 x i32> %wide.masked.gather27, %51
  %54 = getelementptr i8, <8 x ptr> %24, i64 60
  %wide.masked.gather28 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %54, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !4, !noalias !15
  %55 = add <8 x i32> %wide.masked.gather28, %53
  %56 = getelementptr i8, <8 x ptr> %24, i64 64
  %wide.masked.gather29 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %56, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !4, !noalias !15
  %57 = add <8 x i32> %wide.masked.gather29, %55
  %58 = getelementptr i8, <8 x ptr> %24, i64 68
  %wide.masked.gather30 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %58, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !4, !noalias !15
  %59 = add <8 x i32> %wide.masked.gather30, %57
  %60 = getelementptr i8, <8 x ptr> %24, i64 72
  %wide.masked.gather31 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %60, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !4, !noalias !15
  %61 = add <8 x i32> %wide.masked.gather31, %59
  %62 = getelementptr i8, <8 x ptr> %24, i64 76
  %wide.masked.gather32 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %62, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !4, !noalias !15
  %63 = add <8 x i32> %wide.masked.gather32, %61
  %64 = getelementptr i8, <8 x ptr> %24, i64 80
  %wide.masked.gather33 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %64, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !4, !noalias !15
  %65 = add <8 x i32> %wide.masked.gather33, %63
  %66 = getelementptr i8, <8 x ptr> %24, i64 84
  %wide.masked.gather34 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %66, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !4, !noalias !15
  %67 = add <8 x i32> %wide.masked.gather34, %65
  %68 = getelementptr i8, <8 x ptr> %24, i64 88
  %wide.masked.gather35 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %68, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !4, !noalias !15
  %69 = add <8 x i32> %wide.masked.gather35, %67
  %70 = getelementptr i8, <8 x ptr> %24, i64 92
  %wide.masked.gather36 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %70, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !4, !noalias !15
  %71 = add <8 x i32> %wide.masked.gather36, %69
  %72 = getelementptr i8, <8 x ptr> %24, i64 96
  %wide.masked.gather37 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %72, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !4, !noalias !15
  %73 = add <8 x i32> %wide.masked.gather37, %71
  %74 = getelementptr i8, <8 x ptr> %24, i64 100
  %wide.masked.gather38 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %74, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !4, !noalias !15
  %75 = add <8 x i32> %wide.masked.gather38, %73
  %76 = getelementptr i8, <8 x ptr> %24, i64 104
  %wide.masked.gather39 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %76, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !4, !noalias !15
  %77 = add <8 x i32> %wide.masked.gather39, %75
  %78 = getelementptr i8, <8 x ptr> %24, i64 108
  %wide.masked.gather40 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %78, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !4, !noalias !15
  %79 = add <8 x i32> %wide.masked.gather40, %77
  %80 = getelementptr i8, <8 x ptr> %24, i64 112
  %wide.masked.gather41 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %80, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !4, !noalias !15
  %81 = add <8 x i32> %wide.masked.gather41, %79
  %82 = getelementptr i8, <8 x ptr> %24, i64 116
  %wide.masked.gather42 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %82, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !4, !noalias !15
  %83 = add <8 x i32> %wide.masked.gather42, %81
  %84 = getelementptr i8, <8 x ptr> %24, i64 120
  %wide.masked.gather43 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %84, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !4, !noalias !15
  %85 = add <8 x i32> %wide.masked.gather43, %83
  %86 = getelementptr i8, <8 x ptr> %24, i64 124
  %wide.masked.gather44 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %86, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !4, !noalias !15
  %87 = add <8 x i32> %wide.masked.gather44, %85
  %index.next = add nuw i64 %index, 8
  %vec.ind.next = add nuw nsw <8 x i64> %vec.ind, splat (i64 8)
  %88 = icmp eq i64 %index.next, 32
  br i1 %88, label %middle.block, label %vector.body, !llvm.loop !16

middle.block:                                     ; preds = %vector.body
  %89 = tail call i32 @llvm.vector.reduce.add.v8i32(<8 x i32> %87)
  %90 = getelementptr i32, ptr %20, i64 %21
  store i32 %89, ptr %90, align 4, !alias.scope !9, !noalias !20
  %91 = add nuw nsw i64 %21, 1
  %exitcond10.not = icmp eq i64 %91, 24
  br i1 %exitcond10.not, label %92, label %.preheader7, !llvm.loop !21

92:                                               ; preds = %middle.block
  %93 = add nuw nsw i64 %18, 1
  %exitcond11.not = icmp eq i64 %93, 8
  br i1 %exitcond11.not, label %wrapped_reduce-window_wrapped.exit, label %.preheader8, !llvm.loop !21

wrapped_reduce-window_wrapped.exit:               ; preds = %92, %1
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr>, <8 x i1>, <8 x i32>) #2

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.vector.reduce.add.v8i32(<8 x i32>) #3

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #3 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 5}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{!5}
!5 = distinct !{!5, !6, !"wrapped_reduce-window_wrapped: argument 0"}
!6 = distinct !{!6, !"wrapped_reduce-window_wrapped"}
!7 = !{!8}
!8 = distinct !{!8, !6, !"wrapped_reduce-window_wrapped: argument 1"}
!9 = !{!10}
!10 = distinct !{!10, !6, !"wrapped_reduce-window_wrapped: argument 2"}
!11 = !{i64 3072}
!12 = !{i64 3145728}
!13 = !{i64 4}
!14 = !{!5, !10}
!15 = !{!8, !10}
!16 = distinct !{!16, !17, !18, !19}
!17 = !{!"llvm.loop.unroll.disable"}
!18 = !{!"llvm.loop.isvectorized", i32 1}
!19 = !{!"llvm.loop.unroll.runtime.disable"}
!20 = !{!5, !8}
!21 = distinct !{!21, !17}
