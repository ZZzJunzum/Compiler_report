; ModuleID = '__compute_module_multiply_add_fusion_kernel_module'
source_filename = "__compute_module_multiply_add_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @multiply_add_fusion(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !5
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !5
  %9 = getelementptr inbounds nuw i8, ptr %3, i64 48
  %10 = load ptr, ptr %9, align 8, !invariant.load !3, !dereferenceable !5
  %11 = getelementptr inbounds nuw i8, ptr %3, i64 64
  %12 = load ptr, ptr %11, align 8, !invariant.load !3, !dereferenceable !5
  %13 = getelementptr inbounds nuw i8, ptr %3, i64 80
  %14 = load ptr, ptr %13, align 8, !invariant.load !3, !dereferenceable !4
  %15 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %16 = load ptr, ptr %15, align 8
  %17 = load i64, ptr %16, align 4, !invariant.load !3
  tail call void @llvm.experimental.noalias.scope.decl(metadata !6)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !11)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !13)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !15)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !17)
  %18 = icmp slt i64 %17, 11
  br i1 %18, label %19, label %59

19:                                               ; preds = %1
  %20 = icmp sgt i64 %17, -1
  br i1 %20, label %21, label %multiply_add_fusion_wrapped.exit

21:                                               ; preds = %19
  %22 = mul nuw nsw i64 %17, 66048
  br label %vector.ph18

vector.ph18:                                      ; preds = %21, %middle.block27
  %23 = phi i64 [ 0, %21 ], [ %58, %middle.block27 ]
  %24 = mul nuw nsw i64 %23, 768
  %25 = add nuw nsw i64 %24, %22
  br label %vector.body19

vector.body19:                                    ; preds = %vector.body19, %vector.ph18
  %index20 = phi i64 [ 0, %vector.ph18 ], [ %index.next26, %vector.body19 ]
  %26 = getelementptr inbounds nuw float, ptr %12, i64 %index20
  %wide.load21 = load <8 x float>, ptr %26, align 4, !invariant.load !3, !alias.scope !15, !noalias !19
  %27 = add nuw nsw i64 %25, %index20
  %28 = getelementptr inbounds nuw float, ptr %4, i64 %27
  %wide.load22 = load <8 x float>, ptr %28, align 4, !invariant.load !3, !alias.scope !6, !noalias !20
  %29 = fmul <8 x float> %wide.load21, %wide.load22
  %30 = getelementptr inbounds nuw float, ptr %10, i64 %index20
  %wide.load23 = load <8 x float>, ptr %30, align 4, !invariant.load !3, !alias.scope !13, !noalias !21
  %31 = fadd <8 x float> %29, %wide.load23
  %32 = fneg <8 x float> %31
  %33 = fcmp uge <8 x float> %32, splat (float 0xC055F33340000000)
  %34 = select <8 x i1> %33, <8 x float> %32, <8 x float> splat (float 0xC055F33340000000)
  %35 = fcmp ule <8 x float> %34, splat (float 0x4056333340000000)
  %36 = select <8 x i1> %35, <8 x float> %34, <8 x float> splat (float 0x4056333340000000)
  %exp_f32.i = fmul <8 x float> %36, splat (float 0x3FF7154760000000)
  %exp_f321.i = fadd <8 x float> splat (float 5.000000e-01), %exp_f32.i
  %37 = call <8 x float> @llvm.floor.v8f32(<8 x float> %exp_f321.i)
  %38 = fcmp uge <8 x float> %37, splat (float -1.270000e+02)
  %39 = select <8 x i1> %38, <8 x float> %37, <8 x float> splat (float -1.270000e+02)
  %40 = fcmp ule <8 x float> %39, splat (float 1.270000e+02)
  %41 = select <8 x i1> %40, <8 x float> %39, <8 x float> splat (float 1.270000e+02)
  %exp_f322.i = fmul <8 x float> splat (float 0x3FE6300000000000), %41
  %42 = fsub <8 x float> %36, %exp_f322.i
  %exp_f323.i = fmul <8 x float> splat (float 0xBF2BD01060000000), %41
  %43 = fsub <8 x float> %42, %exp_f323.i
  %exp_f324.i = fmul <8 x float> %43, splat (float 0x3F2A0D2CE0000000)
  %exp_f325.i = fadd <8 x float> splat (float 0x3F56E879C0000000), %exp_f324.i
  %exp_f326.i = fmul <8 x float> %exp_f325.i, %43
  %exp_f327.i = fadd <8 x float> splat (float 0x3F81112100000000), %exp_f326.i
  %exp_f328.i = fmul <8 x float> %exp_f327.i, %43
  %exp_f329.i = fadd <8 x float> splat (float 0x3FA5553820000000), %exp_f328.i
  %exp_f3210.i = fmul <8 x float> %exp_f329.i, %43
  %exp_f3211.i = fadd <8 x float> splat (float 0x3FC5555540000000), %exp_f3210.i
  %exp_f3212.i = fmul <8 x float> %exp_f3211.i, %43
  %exp_f3213.i = fadd <8 x float> splat (float 5.000000e-01), %exp_f3212.i
  %exp_f3214.i = fmul <8 x float> %43, %43
  %exp_f3215.i = fmul <8 x float> %exp_f3213.i, %exp_f3214.i
  %exp_f3216.i = fadd <8 x float> %43, %exp_f3215.i
  %exp_f3217.i = fadd <8 x float> splat (float 1.000000e+00), %exp_f3216.i
  %44 = fptosi <8 x float> %41 to <8 x i32>
  %45 = add <8 x i32> %44, splat (i32 127)
  %46 = shl <8 x i32> %45, splat (i32 23)
  %47 = bitcast <8 x i32> %46 to <8 x float>
  %exp_f3218.i = fmul <8 x float> %exp_f3217.i, %47
  %48 = getelementptr inbounds nuw float, ptr %8, i64 %index20
  %wide.load24 = load <8 x float>, ptr %48, align 4, !invariant.load !3, !alias.scope !11, !noalias !22
  %49 = fadd <8 x float> %exp_f3218.i, splat (float 1.000000e+00)
  %50 = fmul <8 x float> %wide.load22, %wide.load24
  %51 = getelementptr inbounds nuw float, ptr %6, i64 %index20
  %wide.load25 = load <8 x float>, ptr %51, align 4, !invariant.load !3, !alias.scope !9, !noalias !23
  %52 = fdiv <8 x float> splat (float 1.000000e+00), %49
  %53 = fadd <8 x float> %50, %wide.load25
  %54 = fmul <8 x float> %53, %52
  %55 = fadd <8 x float> %wide.load22, %54
  %56 = getelementptr inbounds nuw float, ptr %14, i64 %27
  store <8 x float> %55, ptr %56, align 4, !alias.scope !17, !noalias !24
  %index.next26 = add nuw i64 %index20, 8
  %57 = icmp eq i64 %index.next26, 768
  br i1 %57, label %middle.block27, label %vector.body19, !llvm.loop !25

middle.block27:                                   ; preds = %vector.body19
  %58 = add nuw nsw i64 %23, 1
  %exitcond9.not = icmp eq i64 %58, 86
  br i1 %exitcond9.not, label %multiply_add_fusion_wrapped.exit, label %vector.ph18, !llvm.loop !28

59:                                               ; preds = %1
  %60 = icmp eq i64 %17, 11
  br i1 %60, label %.preheader, label %multiply_add_fusion_wrapped.exit

.preheader:                                       ; preds = %59, %middle.block
  %61 = phi i64 [ %96, %middle.block ], [ 0, %59 ]
  %62 = mul nuw nsw i64 %61, 768
  %63 = add nuw nsw i64 %62, 726528
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %.preheader
  %index = phi i64 [ 0, %.preheader ], [ %index.next, %vector.body ]
  %64 = getelementptr inbounds nuw float, ptr %12, i64 %index
  %wide.load = load <8 x float>, ptr %64, align 4, !invariant.load !3, !alias.scope !15, !noalias !19
  %65 = add nuw nsw i64 %63, %index
  %66 = getelementptr inbounds nuw float, ptr %4, i64 %65
  %wide.load14 = load <8 x float>, ptr %66, align 4, !invariant.load !3, !alias.scope !6, !noalias !20
  %67 = fmul <8 x float> %wide.load, %wide.load14
  %68 = getelementptr inbounds nuw float, ptr %10, i64 %index
  %wide.load15 = load <8 x float>, ptr %68, align 4, !invariant.load !3, !alias.scope !13, !noalias !21
  %69 = fadd <8 x float> %67, %wide.load15
  %70 = fneg <8 x float> %69
  %71 = fcmp uge <8 x float> %70, splat (float 0xC055F33340000000)
  %72 = select <8 x i1> %71, <8 x float> %70, <8 x float> splat (float 0xC055F33340000000)
  %73 = fcmp ule <8 x float> %72, splat (float 0x4056333340000000)
  %74 = select <8 x i1> %73, <8 x float> %72, <8 x float> splat (float 0x4056333340000000)
  %exp_f32.i29 = fmul <8 x float> %74, splat (float 0x3FF7154760000000)
  %exp_f321.i30 = fadd <8 x float> splat (float 5.000000e-01), %exp_f32.i29
  %75 = call <8 x float> @llvm.floor.v8f32(<8 x float> %exp_f321.i30)
  %76 = fcmp uge <8 x float> %75, splat (float -1.270000e+02)
  %77 = select <8 x i1> %76, <8 x float> %75, <8 x float> splat (float -1.270000e+02)
  %78 = fcmp ule <8 x float> %77, splat (float 1.270000e+02)
  %79 = select <8 x i1> %78, <8 x float> %77, <8 x float> splat (float 1.270000e+02)
  %exp_f322.i31 = fmul <8 x float> splat (float 0x3FE6300000000000), %79
  %80 = fsub <8 x float> %74, %exp_f322.i31
  %exp_f323.i32 = fmul <8 x float> splat (float 0xBF2BD01060000000), %79
  %81 = fsub <8 x float> %80, %exp_f323.i32
  %exp_f324.i33 = fmul <8 x float> %81, splat (float 0x3F2A0D2CE0000000)
  %exp_f325.i34 = fadd <8 x float> splat (float 0x3F56E879C0000000), %exp_f324.i33
  %exp_f326.i35 = fmul <8 x float> %exp_f325.i34, %81
  %exp_f327.i36 = fadd <8 x float> splat (float 0x3F81112100000000), %exp_f326.i35
  %exp_f328.i37 = fmul <8 x float> %exp_f327.i36, %81
  %exp_f329.i38 = fadd <8 x float> splat (float 0x3FA5553820000000), %exp_f328.i37
  %exp_f3210.i39 = fmul <8 x float> %exp_f329.i38, %81
  %exp_f3211.i40 = fadd <8 x float> splat (float 0x3FC5555540000000), %exp_f3210.i39
  %exp_f3212.i41 = fmul <8 x float> %exp_f3211.i40, %81
  %exp_f3213.i42 = fadd <8 x float> splat (float 5.000000e-01), %exp_f3212.i41
  %exp_f3214.i43 = fmul <8 x float> %81, %81
  %exp_f3215.i44 = fmul <8 x float> %exp_f3213.i42, %exp_f3214.i43
  %exp_f3216.i45 = fadd <8 x float> %81, %exp_f3215.i44
  %exp_f3217.i46 = fadd <8 x float> splat (float 1.000000e+00), %exp_f3216.i45
  %82 = fptosi <8 x float> %79 to <8 x i32>
  %83 = add <8 x i32> %82, splat (i32 127)
  %84 = shl <8 x i32> %83, splat (i32 23)
  %85 = bitcast <8 x i32> %84 to <8 x float>
  %exp_f3218.i47 = fmul <8 x float> %exp_f3217.i46, %85
  %86 = getelementptr inbounds nuw float, ptr %8, i64 %index
  %wide.load16 = load <8 x float>, ptr %86, align 4, !invariant.load !3, !alias.scope !11, !noalias !22
  %87 = fadd <8 x float> %exp_f3218.i47, splat (float 1.000000e+00)
  %88 = fmul <8 x float> %wide.load14, %wide.load16
  %89 = getelementptr inbounds nuw float, ptr %6, i64 %index
  %wide.load17 = load <8 x float>, ptr %89, align 4, !invariant.load !3, !alias.scope !9, !noalias !23
  %90 = fdiv <8 x float> splat (float 1.000000e+00), %87
  %91 = fadd <8 x float> %88, %wide.load17
  %92 = fmul <8 x float> %91, %90
  %93 = fadd <8 x float> %wide.load14, %92
  %94 = getelementptr inbounds nuw float, ptr %14, i64 %65
  store <8 x float> %93, ptr %94, align 4, !alias.scope !17, !noalias !24
  %index.next = add nuw i64 %index, 8
  %95 = icmp eq i64 %index.next, 768
  br i1 %95, label %middle.block, label %vector.body, !llvm.loop !30

middle.block:                                     ; preds = %vector.body
  %96 = add nuw nsw i64 %61, 1
  %exitcond7.not = icmp eq i64 %96, 78
  br i1 %exitcond7.not, label %multiply_add_fusion_wrapped.exit, label %.preheader, !llvm.loop !28

multiply_add_fusion_wrapped.exit:                 ; preds = %middle.block, %middle.block27, %19, %59
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <4 x float> @llvm.floor.v4f32(<4 x float>) #2

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.floor.v8f32(<8 x float>) #2

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <16 x float> @llvm.floor.v16f32(<16 x float>) #2

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 0}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 3145728}
!5 = !{i64 3072}
!6 = !{!7}
!7 = distinct !{!7, !8, !"multiply_add_fusion_wrapped: argument 0"}
!8 = distinct !{!8, !"multiply_add_fusion_wrapped"}
!9 = !{!10}
!10 = distinct !{!10, !8, !"multiply_add_fusion_wrapped: argument 1"}
!11 = !{!12}
!12 = distinct !{!12, !8, !"multiply_add_fusion_wrapped: argument 2"}
!13 = !{!14}
!14 = distinct !{!14, !8, !"multiply_add_fusion_wrapped: argument 3"}
!15 = !{!16}
!16 = distinct !{!16, !8, !"multiply_add_fusion_wrapped: argument 4"}
!17 = !{!18}
!18 = distinct !{!18, !8, !"multiply_add_fusion_wrapped: argument 5"}
!19 = !{!7, !10, !12, !14, !18}
!20 = !{!10, !12, !14, !16, !18}
!21 = !{!7, !10, !12, !16, !18}
!22 = !{!7, !10, !14, !16, !18}
!23 = !{!7, !12, !14, !16, !18}
!24 = !{!7, !10, !12, !14, !16}
!25 = distinct !{!25, !26, !27}
!26 = !{!"llvm.loop.isvectorized", i32 1}
!27 = !{!"llvm.loop.unroll.runtime.disable"}
!28 = distinct !{!28, !29}
!29 = !{!"llvm.loop.unroll.disable"}
!30 = distinct !{!30, !26, !27}
