; ModuleID = '__compute_module_and_convert_fusion_kernel_module'
source_filename = "__compute_module_and_convert_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @and_convert_fusion(ptr readonly captures(none) %0) local_unnamed_addr #0 {
iter.check:
  %1 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %2 = load ptr, ptr %1, align 8, !invariant.load !3
  %3 = load ptr, ptr %2, align 8, !invariant.load !3, !dereferenceable !4
  %4 = getelementptr inbounds nuw i8, ptr %2, i64 16
  %5 = load ptr, ptr %4, align 8, !invariant.load !3, !dereferenceable !4
  tail call void @llvm.experimental.noalias.scope.decl(metadata !5)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !8)
  %6 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 64
  %8 = getelementptr inbounds nuw i8, ptr %3, i64 96
  %wide.load = load <8 x i32>, ptr %3, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %wide.load1 = load <8 x i32>, ptr %6, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %wide.load2 = load <8 x i32>, ptr %7, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %wide.load3 = load <8 x i32>, ptr %8, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %9 = and <8 x i32> %wide.load, splat (i32 511)
  %10 = and <8 x i32> %wide.load1, splat (i32 511)
  %11 = and <8 x i32> %wide.load2, splat (i32 511)
  %12 = and <8 x i32> %wide.load3, splat (i32 511)
  %13 = getelementptr inbounds nuw i8, ptr %5, i64 32
  %14 = getelementptr inbounds nuw i8, ptr %5, i64 64
  %15 = getelementptr inbounds nuw i8, ptr %5, i64 96
  store <8 x i32> %9, ptr %5, align 4, !alias.scope !8, !noalias !5
  store <8 x i32> %10, ptr %13, align 4, !alias.scope !8, !noalias !5
  store <8 x i32> %11, ptr %14, align 4, !alias.scope !8, !noalias !5
  store <8 x i32> %12, ptr %15, align 4, !alias.scope !8, !noalias !5
  %16 = getelementptr inbounds nuw i8, ptr %3, i64 128
  %17 = getelementptr inbounds nuw i8, ptr %3, i64 160
  %18 = getelementptr inbounds nuw i8, ptr %3, i64 192
  %19 = getelementptr inbounds nuw i8, ptr %3, i64 224
  %wide.load.1 = load <8 x i32>, ptr %16, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %wide.load1.1 = load <8 x i32>, ptr %17, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %wide.load2.1 = load <8 x i32>, ptr %18, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %wide.load3.1 = load <8 x i32>, ptr %19, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %20 = and <8 x i32> %wide.load.1, splat (i32 511)
  %21 = and <8 x i32> %wide.load1.1, splat (i32 511)
  %22 = and <8 x i32> %wide.load2.1, splat (i32 511)
  %23 = and <8 x i32> %wide.load3.1, splat (i32 511)
  %24 = getelementptr inbounds nuw i8, ptr %5, i64 128
  %25 = getelementptr inbounds nuw i8, ptr %5, i64 160
  %26 = getelementptr inbounds nuw i8, ptr %5, i64 192
  %27 = getelementptr inbounds nuw i8, ptr %5, i64 224
  store <8 x i32> %20, ptr %24, align 4, !alias.scope !8, !noalias !5
  store <8 x i32> %21, ptr %25, align 4, !alias.scope !8, !noalias !5
  store <8 x i32> %22, ptr %26, align 4, !alias.scope !8, !noalias !5
  store <8 x i32> %23, ptr %27, align 4, !alias.scope !8, !noalias !5
  %28 = getelementptr inbounds nuw i8, ptr %3, i64 256
  %29 = getelementptr inbounds nuw i8, ptr %3, i64 288
  %30 = getelementptr inbounds nuw i8, ptr %3, i64 320
  %31 = getelementptr inbounds nuw i8, ptr %3, i64 352
  %wide.load.2 = load <8 x i32>, ptr %28, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %wide.load1.2 = load <8 x i32>, ptr %29, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %wide.load2.2 = load <8 x i32>, ptr %30, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %wide.load3.2 = load <8 x i32>, ptr %31, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %32 = and <8 x i32> %wide.load.2, splat (i32 511)
  %33 = and <8 x i32> %wide.load1.2, splat (i32 511)
  %34 = and <8 x i32> %wide.load2.2, splat (i32 511)
  %35 = and <8 x i32> %wide.load3.2, splat (i32 511)
  %36 = getelementptr inbounds nuw i8, ptr %5, i64 256
  %37 = getelementptr inbounds nuw i8, ptr %5, i64 288
  %38 = getelementptr inbounds nuw i8, ptr %5, i64 320
  %39 = getelementptr inbounds nuw i8, ptr %5, i64 352
  store <8 x i32> %32, ptr %36, align 4, !alias.scope !8, !noalias !5
  store <8 x i32> %33, ptr %37, align 4, !alias.scope !8, !noalias !5
  store <8 x i32> %34, ptr %38, align 4, !alias.scope !8, !noalias !5
  store <8 x i32> %35, ptr %39, align 4, !alias.scope !8, !noalias !5
  %40 = getelementptr inbounds nuw i8, ptr %3, i64 384
  %41 = getelementptr inbounds nuw i8, ptr %3, i64 416
  %42 = getelementptr inbounds nuw i8, ptr %3, i64 448
  %43 = getelementptr inbounds nuw i8, ptr %3, i64 480
  %wide.load.3 = load <8 x i32>, ptr %40, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %wide.load1.3 = load <8 x i32>, ptr %41, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %wide.load2.3 = load <8 x i32>, ptr %42, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %wide.load3.3 = load <8 x i32>, ptr %43, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %44 = and <8 x i32> %wide.load.3, splat (i32 511)
  %45 = and <8 x i32> %wide.load1.3, splat (i32 511)
  %46 = and <8 x i32> %wide.load2.3, splat (i32 511)
  %47 = and <8 x i32> %wide.load3.3, splat (i32 511)
  %48 = getelementptr inbounds nuw i8, ptr %5, i64 384
  %49 = getelementptr inbounds nuw i8, ptr %5, i64 416
  %50 = getelementptr inbounds nuw i8, ptr %5, i64 448
  %51 = getelementptr inbounds nuw i8, ptr %5, i64 480
  store <8 x i32> %44, ptr %48, align 4, !alias.scope !8, !noalias !5
  store <8 x i32> %45, ptr %49, align 4, !alias.scope !8, !noalias !5
  store <8 x i32> %46, ptr %50, align 4, !alias.scope !8, !noalias !5
  store <8 x i32> %47, ptr %51, align 4, !alias.scope !8, !noalias !5
  %52 = getelementptr inbounds nuw i8, ptr %3, i64 512
  %wide.load5 = load <8 x i32>, ptr %52, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %53 = and <8 x i32> %wide.load5, splat (i32 511)
  %54 = getelementptr inbounds nuw i8, ptr %5, i64 512
  store <8 x i32> %53, ptr %54, align 4, !alias.scope !8, !noalias !5
  %55 = getelementptr inbounds nuw i8, ptr %3, i64 544
  %wide.load5.1 = load <8 x i32>, ptr %55, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %56 = and <8 x i32> %wide.load5.1, splat (i32 511)
  %57 = getelementptr inbounds nuw i8, ptr %5, i64 544
  store <8 x i32> %56, ptr %57, align 4, !alias.scope !8, !noalias !5
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 0}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 576}
!5 = !{!6}
!6 = distinct !{!6, !7, !"and_convert_fusion_wrapped: argument 0"}
!7 = distinct !{!7, !"and_convert_fusion_wrapped"}
!8 = !{!9}
!9 = distinct !{!9, !7, !"and_convert_fusion_wrapped: argument 1"}
