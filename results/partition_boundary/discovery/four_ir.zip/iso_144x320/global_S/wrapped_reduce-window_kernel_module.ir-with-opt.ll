; ModuleID = '__compute_module_wrapped_reduce-window_kernel_module'
source_filename = "__compute_module_wrapped_reduce-window_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @wrapped_reduce-window(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !5
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !6
  tail call void @llvm.experimental.noalias.scope.decl(metadata !7)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !10)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !12)
  %9 = load i32, ptr %6, align 4, !invariant.load !3, !alias.scope !10, !noalias !14
  br label %10

10:                                               ; preds = %1, %125
  %11 = phi i64 [ 0, %1 ], [ %126, %125 ]
  %12 = shl nuw nsw i64 %11, 5
  %13 = add nsw i64 %12, -8
  %.idx1 = mul nuw nsw i64 %11, 40960
  %14 = getelementptr i8, ptr %4, i64 %.idx1
  %.idx = mul nuw nsw i64 %11, 40
  %15 = getelementptr i8, ptr %8, i64 %.idx
  br label %.preheader6

.preheader6:                                      ; preds = %10, %122
  %16 = phi i64 [ 0, %10 ], [ %124, %122 ]
  %.idx2 = shl i64 %16, 7
  %17 = getelementptr i8, ptr %14, i64 %.idx2
  br label %18

18:                                               ; preds = %.preheader6, %.loopexit
  %19 = phi i32 [ %9, %.preheader6 ], [ %120, %.loopexit ]
  %20 = phi i64 [ 0, %.preheader6 ], [ %121, %.loopexit ]
  %21 = add nsw i64 %13, %20
  %22 = icmp ult i64 %21, 144
  br i1 %22, label %.preheader, label %.loopexit

.preheader:                                       ; preds = %18
  %.idx3 = mul nuw nsw i64 %20, 1280
  %23 = getelementptr i8, ptr %17, i64 %.idx3
  %24 = getelementptr i8, ptr %23, i64 -10240
  %25 = load i32, ptr %24, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %26 = add i32 %25, %19
  %27 = getelementptr i8, ptr %23, i64 -10236
  %28 = load i32, ptr %27, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %29 = add i32 %28, %26
  %30 = getelementptr i8, ptr %23, i64 -10232
  %31 = load i32, ptr %30, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %32 = add i32 %31, %29
  %33 = getelementptr i8, ptr %23, i64 -10228
  %34 = load i32, ptr %33, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %35 = add i32 %34, %32
  %36 = getelementptr i8, ptr %23, i64 -10224
  %37 = load i32, ptr %36, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %38 = add i32 %37, %35
  %39 = getelementptr i8, ptr %23, i64 -10220
  %40 = load i32, ptr %39, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %41 = add i32 %40, %38
  %42 = getelementptr i8, ptr %23, i64 -10216
  %43 = load i32, ptr %42, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %44 = add i32 %43, %41
  %45 = getelementptr i8, ptr %23, i64 -10212
  %46 = load i32, ptr %45, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %47 = add i32 %46, %44
  %48 = getelementptr i8, ptr %23, i64 -10208
  %49 = load i32, ptr %48, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %50 = add i32 %49, %47
  %51 = getelementptr i8, ptr %23, i64 -10204
  %52 = load i32, ptr %51, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %53 = add i32 %52, %50
  %54 = getelementptr i8, ptr %23, i64 -10200
  %55 = load i32, ptr %54, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %56 = add i32 %55, %53
  %57 = getelementptr i8, ptr %23, i64 -10196
  %58 = load i32, ptr %57, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %59 = add i32 %58, %56
  %60 = getelementptr i8, ptr %23, i64 -10192
  %61 = load i32, ptr %60, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %62 = add i32 %61, %59
  %63 = getelementptr i8, ptr %23, i64 -10188
  %64 = load i32, ptr %63, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %65 = add i32 %64, %62
  %66 = getelementptr i8, ptr %23, i64 -10184
  %67 = load i32, ptr %66, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %68 = add i32 %67, %65
  %69 = getelementptr i8, ptr %23, i64 -10180
  %70 = load i32, ptr %69, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %71 = add i32 %70, %68
  %72 = getelementptr i8, ptr %23, i64 -10176
  %73 = load i32, ptr %72, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %74 = add i32 %73, %71
  %75 = getelementptr i8, ptr %23, i64 -10172
  %76 = load i32, ptr %75, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %77 = add i32 %76, %74
  %78 = getelementptr i8, ptr %23, i64 -10168
  %79 = load i32, ptr %78, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %80 = add i32 %79, %77
  %81 = getelementptr i8, ptr %23, i64 -10164
  %82 = load i32, ptr %81, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %83 = add i32 %82, %80
  %84 = getelementptr i8, ptr %23, i64 -10160
  %85 = load i32, ptr %84, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %86 = add i32 %85, %83
  %87 = getelementptr i8, ptr %23, i64 -10156
  %88 = load i32, ptr %87, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %89 = add i32 %88, %86
  %90 = getelementptr i8, ptr %23, i64 -10152
  %91 = load i32, ptr %90, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %92 = add i32 %91, %89
  %93 = getelementptr i8, ptr %23, i64 -10148
  %94 = load i32, ptr %93, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %95 = add i32 %94, %92
  %96 = getelementptr i8, ptr %23, i64 -10144
  %97 = load i32, ptr %96, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %98 = add i32 %97, %95
  %99 = getelementptr i8, ptr %23, i64 -10140
  %100 = load i32, ptr %99, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %101 = add i32 %100, %98
  %102 = getelementptr i8, ptr %23, i64 -10136
  %103 = load i32, ptr %102, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %104 = add i32 %103, %101
  %105 = getelementptr i8, ptr %23, i64 -10132
  %106 = load i32, ptr %105, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %107 = add i32 %106, %104
  %108 = getelementptr i8, ptr %23, i64 -10128
  %109 = load i32, ptr %108, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %110 = add i32 %109, %107
  %111 = getelementptr i8, ptr %23, i64 -10124
  %112 = load i32, ptr %111, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %113 = add i32 %112, %110
  %114 = getelementptr i8, ptr %23, i64 -10120
  %115 = load i32, ptr %114, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %116 = add i32 %115, %113
  %117 = getelementptr i8, ptr %23, i64 -10116
  %118 = load i32, ptr %117, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %119 = add i32 %118, %116
  br label %.loopexit

.loopexit:                                        ; preds = %.preheader, %18
  %120 = phi i32 [ %19, %18 ], [ %119, %.preheader ]
  %121 = add nuw nsw i64 %20, 1
  %exitcond.not = icmp eq i64 %121, 32
  br i1 %exitcond.not, label %122, label %18, !llvm.loop !16

122:                                              ; preds = %.loopexit
  %123 = getelementptr i32, ptr %15, i64 %16
  store i32 %120, ptr %123, align 4, !alias.scope !12, !noalias !18
  %124 = add nuw nsw i64 %16, 1
  %exitcond9.not = icmp eq i64 %124, 10
  br i1 %exitcond9.not, label %125, label %.preheader6, !llvm.loop !16

125:                                              ; preds = %122
  %126 = add nuw nsw i64 %11, 1
  %exitcond10.not = icmp eq i64 %126, 5
  br i1 %exitcond10.not, label %wrapped_reduce-window_wrapped.exit, label %10, !llvm.loop !16

wrapped_reduce-window_wrapped.exit:               ; preds = %125
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 3}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 184320}
!5 = !{i64 4}
!6 = !{i64 200}
!7 = !{!8}
!8 = distinct !{!8, !9, !"wrapped_reduce-window_wrapped: argument 0"}
!9 = distinct !{!9, !"wrapped_reduce-window_wrapped"}
!10 = !{!11}
!11 = distinct !{!11, !9, !"wrapped_reduce-window_wrapped: argument 1"}
!12 = !{!13}
!13 = distinct !{!13, !9, !"wrapped_reduce-window_wrapped: argument 2"}
!14 = !{!8, !13}
!15 = !{!11, !13}
!16 = distinct !{!16, !17}
!17 = !{!"llvm.loop.unroll.disable"}
!18 = !{!8, !11}
