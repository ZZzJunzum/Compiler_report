; ModuleID = '__compute_module_shift-left_add_fusion_kernel_module'
source_filename = "__compute_module_shift-left_add_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @shift-left_add_fusion(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !4
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !4
  %9 = getelementptr inbounds nuw i8, ptr %3, i64 48
  %10 = load ptr, ptr %9, align 8, !invariant.load !3, !dereferenceable !4
  %11 = getelementptr inbounds nuw i8, ptr %3, i64 64
  %12 = load ptr, ptr %11, align 8, !invariant.load !3, !dereferenceable !4
  %13 = getelementptr inbounds nuw i8, ptr %3, i64 80
  %14 = load ptr, ptr %13, align 8, !invariant.load !3, !dereferenceable !4
  %15 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %16 = load ptr, ptr %15, align 8
  %17 = load i64, ptr %16, align 4, !invariant.load !3
  tail call void @llvm.experimental.noalias.scope.decl(metadata !5)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !8)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !10)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !12)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !14)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !16)
  %18 = icmp ult i64 %17, 4
  br i1 %18, label %vector.ph, label %shift-left_add_fusion_wrapped.exit

vector.ph:                                        ; preds = %1
  %19 = mul nuw nsw i64 %17, 11520
  %invariant.op = add nuw nsw i64 8, %19
  %invariant.op6 = add nuw nsw i64 16, %19
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %vector.ph
  %index = phi i64 [ 0, %vector.ph ], [ %index.next.2, %vector.body ]
  %20 = add nuw nsw i64 %index, %19
  %21 = getelementptr inbounds nuw float, ptr %10, i64 %20
  %wide.load = load <8 x float>, ptr %21, align 4, !invariant.load !3, !alias.scope !12, !noalias !18
  %22 = getelementptr inbounds nuw float, ptr %12, i64 %20
  %wide.load2 = load <8 x float>, ptr %22, align 4, !invariant.load !3, !alias.scope !14, !noalias !19
  %23 = fmul <8 x float> %wide.load, %wide.load2
  %24 = getelementptr inbounds nuw float, ptr %8, i64 %20
  %wide.load3 = load <8 x float>, ptr %24, align 4, !invariant.load !3, !alias.scope !10, !noalias !20
  %25 = fadd <8 x float> %23, %wide.load3
  %26 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %25, <8 x float> zeroinitializer)
  %27 = getelementptr inbounds nuw float, ptr %6, i64 %20
  %wide.load4 = load <8 x float>, ptr %27, align 4, !invariant.load !3, !alias.scope !8, !noalias !21
  %28 = fmul <8 x float> %wide.load4, %26
  %29 = getelementptr inbounds nuw float, ptr %4, i64 %20
  %wide.load5 = load <8 x float>, ptr %29, align 4, !invariant.load !3, !alias.scope !5, !noalias !22
  %30 = fadd <8 x float> %wide.load5, %28
  %31 = fcmp ogt <8 x float> %30, zeroinitializer
  %32 = fcmp ogt <8 x float> %25, zeroinitializer
  %33 = zext <8 x i1> %32 to <8 x i32>
  %34 = select <8 x i1> %31, <8 x i32> splat (i32 65536), <8 x i32> zeroinitializer
  %35 = or disjoint <8 x i32> %34, %33
  %36 = getelementptr inbounds nuw i32, ptr %14, i64 %20
  store <8 x i32> %35, ptr %36, align 4, !alias.scope !16, !noalias !23
  %.reass = add nuw nsw i64 %index, %invariant.op
  %37 = getelementptr inbounds nuw float, ptr %10, i64 %.reass
  %wide.load.1 = load <8 x float>, ptr %37, align 4, !invariant.load !3, !alias.scope !12, !noalias !18
  %38 = getelementptr inbounds nuw float, ptr %12, i64 %.reass
  %wide.load2.1 = load <8 x float>, ptr %38, align 4, !invariant.load !3, !alias.scope !14, !noalias !19
  %39 = fmul <8 x float> %wide.load.1, %wide.load2.1
  %40 = getelementptr inbounds nuw float, ptr %8, i64 %.reass
  %wide.load3.1 = load <8 x float>, ptr %40, align 4, !invariant.load !3, !alias.scope !10, !noalias !20
  %41 = fadd <8 x float> %39, %wide.load3.1
  %42 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %41, <8 x float> zeroinitializer)
  %43 = getelementptr inbounds nuw float, ptr %6, i64 %.reass
  %wide.load4.1 = load <8 x float>, ptr %43, align 4, !invariant.load !3, !alias.scope !8, !noalias !21
  %44 = fmul <8 x float> %wide.load4.1, %42
  %45 = getelementptr inbounds nuw float, ptr %4, i64 %.reass
  %wide.load5.1 = load <8 x float>, ptr %45, align 4, !invariant.load !3, !alias.scope !5, !noalias !22
  %46 = fadd <8 x float> %wide.load5.1, %44
  %47 = fcmp ogt <8 x float> %46, zeroinitializer
  %48 = fcmp ogt <8 x float> %41, zeroinitializer
  %49 = zext <8 x i1> %48 to <8 x i32>
  %50 = select <8 x i1> %47, <8 x i32> splat (i32 65536), <8 x i32> zeroinitializer
  %51 = or disjoint <8 x i32> %50, %49
  %52 = getelementptr inbounds nuw i32, ptr %14, i64 %.reass
  store <8 x i32> %51, ptr %52, align 4, !alias.scope !16, !noalias !23
  %.reass7 = add nuw nsw i64 %index, %invariant.op6
  %53 = getelementptr inbounds nuw float, ptr %10, i64 %.reass7
  %wide.load.2 = load <8 x float>, ptr %53, align 4, !invariant.load !3, !alias.scope !12, !noalias !18
  %54 = getelementptr inbounds nuw float, ptr %12, i64 %.reass7
  %wide.load2.2 = load <8 x float>, ptr %54, align 4, !invariant.load !3, !alias.scope !14, !noalias !19
  %55 = fmul <8 x float> %wide.load.2, %wide.load2.2
  %56 = getelementptr inbounds nuw float, ptr %8, i64 %.reass7
  %wide.load3.2 = load <8 x float>, ptr %56, align 4, !invariant.load !3, !alias.scope !10, !noalias !20
  %57 = fadd <8 x float> %55, %wide.load3.2
  %58 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %57, <8 x float> zeroinitializer)
  %59 = getelementptr inbounds nuw float, ptr %6, i64 %.reass7
  %wide.load4.2 = load <8 x float>, ptr %59, align 4, !invariant.load !3, !alias.scope !8, !noalias !21
  %60 = fmul <8 x float> %wide.load4.2, %58
  %61 = getelementptr inbounds nuw float, ptr %4, i64 %.reass7
  %wide.load5.2 = load <8 x float>, ptr %61, align 4, !invariant.load !3, !alias.scope !5, !noalias !22
  %62 = fadd <8 x float> %wide.load5.2, %60
  %63 = fcmp ogt <8 x float> %62, zeroinitializer
  %64 = fcmp ogt <8 x float> %57, zeroinitializer
  %65 = zext <8 x i1> %64 to <8 x i32>
  %66 = select <8 x i1> %63, <8 x i32> splat (i32 65536), <8 x i32> zeroinitializer
  %67 = or disjoint <8 x i32> %66, %65
  %68 = getelementptr inbounds nuw i32, ptr %14, i64 %.reass7
  store <8 x i32> %67, ptr %68, align 4, !alias.scope !16, !noalias !23
  %index.next.2 = add nuw nsw i64 %index, 24
  %69 = icmp eq i64 %index.next.2, 11520
  br i1 %69, label %shift-left_add_fusion_wrapped.exit, label %vector.body, !llvm.loop !24

shift-left_add_fusion_wrapped.exit:               ; preds = %vector.body, %1
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.maximum.v8f32(<8 x float>, <8 x float>) #2

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 1}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 184320}
!5 = !{!6}
!6 = distinct !{!6, !7, !"shift-left_add_fusion_wrapped: argument 0"}
!7 = distinct !{!7, !"shift-left_add_fusion_wrapped"}
!8 = !{!9}
!9 = distinct !{!9, !7, !"shift-left_add_fusion_wrapped: argument 1"}
!10 = !{!11}
!11 = distinct !{!11, !7, !"shift-left_add_fusion_wrapped: argument 2"}
!12 = !{!13}
!13 = distinct !{!13, !7, !"shift-left_add_fusion_wrapped: argument 3"}
!14 = !{!15}
!15 = distinct !{!15, !7, !"shift-left_add_fusion_wrapped: argument 4"}
!16 = !{!17}
!17 = distinct !{!17, !7, !"shift-left_add_fusion_wrapped: argument 5"}
!18 = !{!6, !9, !11, !15, !17}
!19 = !{!6, !9, !11, !13, !17}
!20 = !{!6, !9, !13, !15, !17}
!21 = !{!6, !11, !13, !15, !17}
!22 = !{!9, !11, !13, !15, !17}
!23 = !{!6, !9, !11, !13, !15}
!24 = distinct !{!24, !25, !26}
!25 = !{!"llvm.loop.isvectorized", i32 1}
!26 = !{!"llvm.loop.unroll.runtime.disable"}
