; ModuleID = '__compute_module_convert_reduce_fusion_kernel_module'
source_filename = "__compute_module_convert_reduce_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @convert_reduce_fusion(ptr readonly captures(none) %0) local_unnamed_addr #0 {
vector.ph:
  %1 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %2 = load ptr, ptr %1, align 8, !invariant.load !3
  %3 = load ptr, ptr %2, align 8, !invariant.load !3, !dereferenceable !4
  %4 = getelementptr inbounds nuw i8, ptr %2, i64 16
  %5 = load ptr, ptr %4, align 8, !invariant.load !3, !dereferenceable !4
  %6 = getelementptr inbounds nuw i8, ptr %2, i64 32
  %7 = load ptr, ptr %6, align 8, !invariant.load !3, !dereferenceable !4
  %8 = getelementptr inbounds nuw i8, ptr %2, i64 48
  %9 = load ptr, ptr %8, align 8, !invariant.load !3, !dereferenceable !4
  %10 = getelementptr inbounds nuw i8, ptr %2, i64 64
  %11 = load ptr, ptr %10, align 8, !invariant.load !3, !dereferenceable !4
  tail call void @llvm.experimental.noalias.scope.decl(metadata !5)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !8)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !10)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !12)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !14)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !16)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !18)
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %vector.ph
  %index = phi i64 [ 0, %vector.ph ], [ %index.next.1, %vector.body ]
  %vec.phi = phi <8 x i32> [ zeroinitializer, %vector.ph ], [ %74, %vector.body ]
  %vec.phi5 = phi <8 x i32> [ zeroinitializer, %vector.ph ], [ %75, %vector.body ]
  %vec.phi6 = phi <8 x i32> [ zeroinitializer, %vector.ph ], [ %72, %vector.body ]
  %vec.phi7 = phi <8 x i32> [ zeroinitializer, %vector.ph ], [ %73, %vector.body ]
  %12 = getelementptr inbounds nuw float, ptr %9, i64 %index
  %13 = getelementptr inbounds nuw i8, ptr %12, i64 32
  %wide.load = load <8 x float>, ptr %12, align 4, !invariant.load !3, !alias.scope !12, !noalias !20
  %wide.load8 = load <8 x float>, ptr %13, align 4, !invariant.load !3, !alias.scope !12, !noalias !20
  %14 = getelementptr inbounds nuw float, ptr %11, i64 %index
  %15 = getelementptr inbounds nuw i8, ptr %14, i64 32
  %wide.load9 = load <8 x float>, ptr %14, align 4, !invariant.load !3, !alias.scope !14, !noalias !21
  %wide.load10 = load <8 x float>, ptr %15, align 4, !invariant.load !3, !alias.scope !14, !noalias !21
  %16 = fmul <8 x float> %wide.load, %wide.load9
  %17 = fmul <8 x float> %wide.load8, %wide.load10
  %18 = getelementptr inbounds nuw float, ptr %7, i64 %index
  %19 = getelementptr inbounds nuw i8, ptr %18, i64 32
  %wide.load11 = load <8 x float>, ptr %18, align 4, !invariant.load !3, !alias.scope !10, !noalias !22
  %wide.load12 = load <8 x float>, ptr %19, align 4, !invariant.load !3, !alias.scope !10, !noalias !22
  %20 = fadd <8 x float> %16, %wide.load11
  %21 = fadd <8 x float> %17, %wide.load12
  %22 = fcmp ogt <8 x float> %20, zeroinitializer
  %23 = fcmp ogt <8 x float> %21, zeroinitializer
  %24 = zext <8 x i1> %22 to <8 x i32>
  %25 = zext <8 x i1> %23 to <8 x i32>
  %26 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %20, <8 x float> zeroinitializer)
  %27 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %21, <8 x float> zeroinitializer)
  %28 = getelementptr inbounds nuw float, ptr %5, i64 %index
  %29 = getelementptr inbounds nuw i8, ptr %28, i64 32
  %wide.load13 = load <8 x float>, ptr %28, align 4, !invariant.load !3, !alias.scope !8, !noalias !23
  %wide.load14 = load <8 x float>, ptr %29, align 4, !invariant.load !3, !alias.scope !8, !noalias !23
  %30 = fmul <8 x float> %wide.load13, %26
  %31 = fmul <8 x float> %wide.load14, %27
  %32 = getelementptr inbounds nuw float, ptr %3, i64 %index
  %33 = getelementptr inbounds nuw i8, ptr %32, i64 32
  %wide.load15 = load <8 x float>, ptr %32, align 4, !invariant.load !3, !alias.scope !5, !noalias !24
  %wide.load16 = load <8 x float>, ptr %33, align 4, !invariant.load !3, !alias.scope !5, !noalias !24
  %34 = fadd <8 x float> %wide.load15, %30
  %35 = fadd <8 x float> %wide.load16, %31
  %36 = fcmp ogt <8 x float> %34, zeroinitializer
  %37 = fcmp ogt <8 x float> %35, zeroinitializer
  %38 = zext <8 x i1> %36 to <8 x i32>
  %39 = zext <8 x i1> %37 to <8 x i32>
  %40 = add <8 x i32> %vec.phi6, %24
  %41 = add <8 x i32> %vec.phi7, %25
  %42 = add <8 x i32> %vec.phi, %38
  %43 = add <8 x i32> %vec.phi5, %39
  %index.next = or disjoint i64 %index, 16
  %44 = getelementptr inbounds nuw float, ptr %9, i64 %index.next
  %45 = getelementptr inbounds nuw i8, ptr %44, i64 32
  %wide.load.1 = load <8 x float>, ptr %44, align 4, !invariant.load !3, !alias.scope !12, !noalias !20
  %wide.load8.1 = load <8 x float>, ptr %45, align 4, !invariant.load !3, !alias.scope !12, !noalias !20
  %46 = getelementptr inbounds nuw float, ptr %11, i64 %index.next
  %47 = getelementptr inbounds nuw i8, ptr %46, i64 32
  %wide.load9.1 = load <8 x float>, ptr %46, align 4, !invariant.load !3, !alias.scope !14, !noalias !21
  %wide.load10.1 = load <8 x float>, ptr %47, align 4, !invariant.load !3, !alias.scope !14, !noalias !21
  %48 = fmul <8 x float> %wide.load.1, %wide.load9.1
  %49 = fmul <8 x float> %wide.load8.1, %wide.load10.1
  %50 = getelementptr inbounds nuw float, ptr %7, i64 %index.next
  %51 = getelementptr inbounds nuw i8, ptr %50, i64 32
  %wide.load11.1 = load <8 x float>, ptr %50, align 4, !invariant.load !3, !alias.scope !10, !noalias !22
  %wide.load12.1 = load <8 x float>, ptr %51, align 4, !invariant.load !3, !alias.scope !10, !noalias !22
  %52 = fadd <8 x float> %48, %wide.load11.1
  %53 = fadd <8 x float> %49, %wide.load12.1
  %54 = fcmp ogt <8 x float> %52, zeroinitializer
  %55 = fcmp ogt <8 x float> %53, zeroinitializer
  %56 = zext <8 x i1> %54 to <8 x i32>
  %57 = zext <8 x i1> %55 to <8 x i32>
  %58 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %52, <8 x float> zeroinitializer)
  %59 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %53, <8 x float> zeroinitializer)
  %60 = getelementptr inbounds nuw float, ptr %5, i64 %index.next
  %61 = getelementptr inbounds nuw i8, ptr %60, i64 32
  %wide.load13.1 = load <8 x float>, ptr %60, align 4, !invariant.load !3, !alias.scope !8, !noalias !23
  %wide.load14.1 = load <8 x float>, ptr %61, align 4, !invariant.load !3, !alias.scope !8, !noalias !23
  %62 = fmul <8 x float> %wide.load13.1, %58
  %63 = fmul <8 x float> %wide.load14.1, %59
  %64 = getelementptr inbounds nuw float, ptr %3, i64 %index.next
  %65 = getelementptr inbounds nuw i8, ptr %64, i64 32
  %wide.load15.1 = load <8 x float>, ptr %64, align 4, !invariant.load !3, !alias.scope !5, !noalias !24
  %wide.load16.1 = load <8 x float>, ptr %65, align 4, !invariant.load !3, !alias.scope !5, !noalias !24
  %66 = fadd <8 x float> %wide.load15.1, %62
  %67 = fadd <8 x float> %wide.load16.1, %63
  %68 = fcmp ogt <8 x float> %66, zeroinitializer
  %69 = fcmp ogt <8 x float> %67, zeroinitializer
  %70 = zext <8 x i1> %68 to <8 x i32>
  %71 = zext <8 x i1> %69 to <8 x i32>
  %72 = add <8 x i32> %40, %56
  %73 = add <8 x i32> %41, %57
  %74 = add <8 x i32> %42, %70
  %75 = add <8 x i32> %43, %71
  %index.next.1 = add nuw nsw i64 %index, 32
  %76 = icmp eq i64 %index.next.1, 46080
  br i1 %76, label %convert_reduce_fusion_wrapped.exit, label %vector.body, !llvm.loop !25

convert_reduce_fusion_wrapped.exit:               ; preds = %vector.body
  %bin.rdx17 = add <8 x i32> %73, %72
  %77 = tail call i32 @llvm.vector.reduce.add.v8i32(<8 x i32> %bin.rdx17)
  %bin.rdx = add <8 x i32> %75, %74
  %78 = tail call i32 @llvm.vector.reduce.add.v8i32(<8 x i32> %bin.rdx)
  %79 = getelementptr inbounds nuw i8, ptr %2, i64 96
  %80 = load ptr, ptr %79, align 8, !invariant.load !3, !dereferenceable !28
  %81 = getelementptr inbounds nuw i8, ptr %2, i64 80
  %82 = load ptr, ptr %81, align 8, !invariant.load !3, !dereferenceable !28
  store i32 %77, ptr %82, align 4, !alias.scope !16, !noalias !29
  store i32 %78, ptr %80, align 4, !alias.scope !18, !noalias !30
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.maximum.v8f32(<8 x float>, <8 x float>) #2

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.vector.reduce.add.v8i32(<8 x i32>) #3

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #3 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 0}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 184320}
!5 = !{!6}
!6 = distinct !{!6, !7, !"convert_reduce_fusion_wrapped: argument 0"}
!7 = distinct !{!7, !"convert_reduce_fusion_wrapped"}
!8 = !{!9}
!9 = distinct !{!9, !7, !"convert_reduce_fusion_wrapped: argument 1"}
!10 = !{!11}
!11 = distinct !{!11, !7, !"convert_reduce_fusion_wrapped: argument 2"}
!12 = !{!13}
!13 = distinct !{!13, !7, !"convert_reduce_fusion_wrapped: argument 3"}
!14 = !{!15}
!15 = distinct !{!15, !7, !"convert_reduce_fusion_wrapped: argument 4"}
!16 = !{!17}
!17 = distinct !{!17, !7, !"convert_reduce_fusion_wrapped: argument 5"}
!18 = !{!19}
!19 = distinct !{!19, !7, !"convert_reduce_fusion_wrapped: argument 6"}
!20 = !{!6, !9, !11, !15, !17, !19}
!21 = !{!6, !9, !11, !13, !17, !19}
!22 = !{!6, !9, !13, !15, !17, !19}
!23 = !{!6, !11, !13, !15, !17, !19}
!24 = !{!9, !11, !13, !15, !17, !19}
!25 = distinct !{!25, !26, !27}
!26 = !{!"llvm.loop.isvectorized", i32 1}
!27 = !{!"llvm.loop.unroll.runtime.disable"}
!28 = !{i64 4}
!29 = !{!6, !9, !11, !13, !15, !19}
!30 = !{!6, !9, !11, !13, !15, !17}
