; ModuleID = '__compute_module_wrapped_reduce-window.2_kernel_module'
source_filename = "__compute_module_wrapped_reduce-window.2_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @wrapped_reduce-window.2(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !5
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !6
  tail call void @llvm.experimental.noalias.scope.decl(metadata !7)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !10)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !12)
  %9 = load i32, ptr %6, align 4, !invariant.load !3, !alias.scope !10, !noalias !14
  br label %10

10:                                               ; preds = %.thread30, %1
  %.not.not = phi i1 [ true, %1 ], [ false, %.thread30 ]
  %11 = phi i64 [ 0, %1 ], [ 1, %.thread30 ]
  %12 = shl nuw nsw i64 %11, 5
  %13 = add nsw i64 %12, -9
  %14 = icmp ult i64 %13, 45
  br i1 %14, label %.thread, label %19

.thread:                                          ; preds = %10
  %15 = getelementptr i32, ptr %4, i64 %12
  %16 = getelementptr i8, ptr %15, i64 -36
  %17 = load i32, ptr %16, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %18 = add i32 %17, %9
  br label %.thread14

19:                                               ; preds = %10
  %20 = add nsw i64 %12, -8
  %21 = icmp ult i64 %20, 45
  br i1 %21, label %.thread14, label %27

.thread14:                                        ; preds = %19, %.thread
  %22 = phi i32 [ %18, %.thread ], [ %9, %19 ]
  %23 = getelementptr i32, ptr %4, i64 %12
  %24 = getelementptr i8, ptr %23, i64 -32
  %25 = load i32, ptr %24, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %26 = add i32 %25, %22
  br label %.thread15

27:                                               ; preds = %19
  %28 = add nsw i64 %12, -7
  %29 = icmp ult i64 %28, 45
  br i1 %29, label %.thread15, label %35

.thread15:                                        ; preds = %27, %.thread14
  %30 = phi i32 [ %26, %.thread14 ], [ %9, %27 ]
  %31 = getelementptr i32, ptr %4, i64 %12
  %32 = getelementptr i8, ptr %31, i64 -28
  %33 = load i32, ptr %32, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %34 = add i32 %33, %30
  br label %.thread16

35:                                               ; preds = %27
  %36 = add nsw i64 %12, -6
  %37 = icmp ult i64 %36, 45
  br i1 %37, label %.thread16, label %43

.thread16:                                        ; preds = %35, %.thread15
  %38 = phi i32 [ %34, %.thread15 ], [ %9, %35 ]
  %39 = getelementptr i32, ptr %4, i64 %12
  %40 = getelementptr i8, ptr %39, i64 -24
  %41 = load i32, ptr %40, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %42 = add i32 %41, %38
  br label %.thread17

43:                                               ; preds = %35
  %44 = add nsw i64 %12, -5
  %45 = icmp ult i64 %44, 45
  br i1 %45, label %.thread17, label %51

.thread17:                                        ; preds = %43, %.thread16
  %46 = phi i32 [ %42, %.thread16 ], [ %9, %43 ]
  %47 = getelementptr i32, ptr %4, i64 %12
  %48 = getelementptr i8, ptr %47, i64 -20
  %49 = load i32, ptr %48, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %50 = add i32 %49, %46
  br label %.thread18

51:                                               ; preds = %43
  %52 = add nsw i64 %12, -4
  %53 = icmp ult i64 %52, 45
  br i1 %53, label %.thread18, label %59

.thread18:                                        ; preds = %51, %.thread17
  %54 = phi i32 [ %50, %.thread17 ], [ %9, %51 ]
  %55 = getelementptr i32, ptr %4, i64 %12
  %56 = getelementptr i8, ptr %55, i64 -16
  %57 = load i32, ptr %56, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %58 = add i32 %57, %54
  br label %.thread19

59:                                               ; preds = %51
  %60 = add nsw i64 %12, -3
  %61 = icmp ult i64 %60, 45
  br i1 %61, label %.thread19, label %67

.thread19:                                        ; preds = %59, %.thread18
  %62 = phi i32 [ %58, %.thread18 ], [ %9, %59 ]
  %63 = getelementptr i32, ptr %4, i64 %12
  %64 = getelementptr i8, ptr %63, i64 -12
  %65 = load i32, ptr %64, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %66 = add i32 %65, %62
  br label %.thread20

67:                                               ; preds = %59
  %68 = add nsw i64 %12, -2
  %69 = icmp ult i64 %68, 45
  br i1 %69, label %.thread20, label %75

.thread20:                                        ; preds = %67, %.thread19
  %70 = phi i32 [ %66, %.thread19 ], [ %9, %67 ]
  %71 = getelementptr i32, ptr %4, i64 %12
  %72 = getelementptr i8, ptr %71, i64 -8
  %73 = load i32, ptr %72, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %74 = add i32 %73, %70
  br label %78

75:                                               ; preds = %67
  %76 = add nsw i64 %12, -1
  %77 = icmp ult i64 %76, 45
  br i1 %77, label %78, label %84

78:                                               ; preds = %.thread20, %75
  %79 = phi i32 [ %74, %.thread20 ], [ %9, %75 ]
  %80 = getelementptr i32, ptr %4, i64 %12
  %81 = getelementptr i8, ptr %80, i64 -4
  %82 = load i32, ptr %81, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %83 = add i32 %82, %79
  br label %84

84:                                               ; preds = %78, %75
  %85 = phi i32 [ %83, %78 ], [ %9, %75 ]
  %86 = getelementptr i32, ptr %4, i64 %12
  %87 = load i32, ptr %86, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %88 = add i32 %87, %85
  %89 = getelementptr i32, ptr %4, i64 %12
  %90 = getelementptr i8, ptr %89, i64 4
  %91 = load i32, ptr %90, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %92 = add i32 %91, %88
  %93 = getelementptr i32, ptr %4, i64 %12
  %94 = getelementptr i8, ptr %93, i64 8
  %95 = load i32, ptr %94, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %96 = add i32 %95, %92
  %97 = getelementptr i32, ptr %4, i64 %12
  %98 = getelementptr i8, ptr %97, i64 12
  %99 = load i32, ptr %98, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %100 = add i32 %99, %96
  %101 = getelementptr i32, ptr %4, i64 %12
  %102 = getelementptr i8, ptr %101, i64 16
  %103 = load i32, ptr %102, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %104 = add i32 %103, %100
  %105 = getelementptr i32, ptr %4, i64 %12
  %106 = getelementptr i8, ptr %105, i64 20
  %107 = load i32, ptr %106, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %108 = add i32 %107, %104
  %109 = getelementptr i32, ptr %4, i64 %12
  %110 = getelementptr i8, ptr %109, i64 24
  %111 = load i32, ptr %110, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %112 = add i32 %111, %108
  %113 = getelementptr i32, ptr %4, i64 %12
  %114 = getelementptr i8, ptr %113, i64 28
  %115 = load i32, ptr %114, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %116 = add i32 %115, %112
  %117 = getelementptr i32, ptr %4, i64 %12
  %118 = getelementptr i8, ptr %117, i64 32
  %119 = load i32, ptr %118, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %120 = add i32 %119, %116
  %121 = getelementptr i32, ptr %4, i64 %12
  %122 = getelementptr i8, ptr %121, i64 36
  %123 = load i32, ptr %122, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %124 = add i32 %123, %120
  %125 = getelementptr i32, ptr %4, i64 %12
  %126 = getelementptr i8, ptr %125, i64 40
  %127 = load i32, ptr %126, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %128 = add i32 %127, %124
  %129 = getelementptr i32, ptr %4, i64 %12
  %130 = getelementptr i8, ptr %129, i64 44
  %131 = load i32, ptr %130, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %132 = add i32 %131, %128
  %133 = getelementptr i32, ptr %4, i64 %12
  %134 = getelementptr i8, ptr %133, i64 48
  %135 = load i32, ptr %134, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %136 = add i32 %135, %132
  br i1 %.not.not, label %.thread30, label %wrapped_reduce-window.2_wrapped.exit.critedge

.thread30:                                        ; preds = %84
  %137 = getelementptr i32, ptr %4, i64 %12
  %138 = getelementptr i8, ptr %137, i64 52
  %139 = load i32, ptr %138, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %140 = add i32 %139, %136
  %141 = getelementptr i32, ptr %4, i64 %12
  %142 = getelementptr i8, ptr %141, i64 56
  %143 = load i32, ptr %142, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %144 = add i32 %143, %140
  %145 = getelementptr i32, ptr %4, i64 %12
  %146 = getelementptr i8, ptr %145, i64 60
  %147 = load i32, ptr %146, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %148 = add i32 %147, %144
  %149 = getelementptr i32, ptr %4, i64 %12
  %150 = getelementptr i8, ptr %149, i64 64
  %151 = load i32, ptr %150, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %152 = add i32 %151, %148
  %153 = getelementptr i32, ptr %4, i64 %12
  %154 = getelementptr i8, ptr %153, i64 68
  %155 = load i32, ptr %154, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %156 = add i32 %155, %152
  %157 = getelementptr i32, ptr %4, i64 %12
  %158 = getelementptr i8, ptr %157, i64 72
  %159 = load i32, ptr %158, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %160 = add i32 %159, %156
  %161 = getelementptr i32, ptr %4, i64 %12
  %162 = getelementptr i8, ptr %161, i64 76
  %163 = load i32, ptr %162, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %164 = add i32 %163, %160
  %165 = getelementptr i32, ptr %4, i64 %12
  %166 = getelementptr i8, ptr %165, i64 80
  %167 = load i32, ptr %166, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %168 = add i32 %167, %164
  %169 = getelementptr i32, ptr %4, i64 %12
  %170 = getelementptr i8, ptr %169, i64 84
  %171 = load i32, ptr %170, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %172 = add i32 %171, %168
  %173 = getelementptr i32, ptr %4, i64 %12
  %174 = getelementptr i8, ptr %173, i64 88
  %175 = load i32, ptr %174, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %176 = add i32 %175, %172
  %177 = getelementptr inbounds nuw i32, ptr %8, i64 %11
  store i32 %176, ptr %177, align 4, !alias.scope !12, !noalias !16
  br label %10, !llvm.loop !17

wrapped_reduce-window.2_wrapped.exit.critedge:    ; preds = %84
  %178 = getelementptr inbounds nuw i32, ptr %8, i64 %11
  store i32 %136, ptr %178, align 4, !alias.scope !12, !noalias !16
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 5}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 180}
!5 = !{i64 4}
!6 = !{i64 8}
!7 = !{!8}
!8 = distinct !{!8, !9, !"wrapped_reduce-window.2_wrapped: argument 0"}
!9 = distinct !{!9, !"wrapped_reduce-window.2_wrapped"}
!10 = !{!11}
!11 = distinct !{!11, !9, !"wrapped_reduce-window.2_wrapped: argument 1"}
!12 = !{!13}
!13 = distinct !{!13, !9, !"wrapped_reduce-window.2_wrapped: argument 2"}
!14 = !{!8, !13}
!15 = !{!11, !13}
!16 = !{!8, !11}
!17 = distinct !{!17, !18}
!18 = !{!"llvm.loop.unroll.disable"}
