; ModuleID = '__compute_module_compare_convert_fusion_kernel_module'
source_filename = "__compute_module_compare_convert_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @compare_convert_fusion(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !4
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !4
  %9 = getelementptr inbounds nuw i8, ptr %3, i64 48
  %10 = load ptr, ptr %9, align 8, !invariant.load !3, !dereferenceable !4
  %11 = getelementptr inbounds nuw i8, ptr %3, i64 64
  %12 = load ptr, ptr %11, align 8, !invariant.load !3, !dereferenceable !4
  %13 = getelementptr inbounds nuw i8, ptr %3, i64 80
  %14 = load ptr, ptr %13, align 8, !invariant.load !3, !dereferenceable !4
  %15 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %16 = load ptr, ptr %15, align 8
  %17 = load i64, ptr %16, align 4, !invariant.load !3
  tail call void @llvm.experimental.noalias.scope.decl(metadata !5)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !8)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !10)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !12)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !14)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !16)
  %18 = icmp ult i64 %17, 4
  br i1 %18, label %vector.ph, label %compare_convert_fusion_wrapped.exit

vector.ph:                                        ; preds = %1
  %19 = mul nuw nsw i64 %17, 11520
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %vector.ph
  %index = phi i64 [ 0, %vector.ph ], [ %index.next.1, %vector.body ]
  %20 = add nuw nsw i64 %index, %19
  %21 = getelementptr inbounds nuw float, ptr %10, i64 %20
  %22 = getelementptr inbounds nuw i8, ptr %21, i64 32
  %wide.load = load <8 x float>, ptr %21, align 4, !invariant.load !3, !alias.scope !12, !noalias !18
  %wide.load2 = load <8 x float>, ptr %22, align 4, !invariant.load !3, !alias.scope !12, !noalias !18
  %23 = getelementptr inbounds nuw float, ptr %12, i64 %20
  %24 = getelementptr inbounds nuw i8, ptr %23, i64 32
  %wide.load3 = load <8 x float>, ptr %23, align 4, !invariant.load !3, !alias.scope !14, !noalias !19
  %wide.load4 = load <8 x float>, ptr %24, align 4, !invariant.load !3, !alias.scope !14, !noalias !19
  %25 = fmul <8 x float> %wide.load, %wide.load3
  %26 = fmul <8 x float> %wide.load2, %wide.load4
  %27 = getelementptr inbounds nuw float, ptr %8, i64 %20
  %28 = getelementptr inbounds nuw i8, ptr %27, i64 32
  %wide.load5 = load <8 x float>, ptr %27, align 4, !invariant.load !3, !alias.scope !10, !noalias !20
  %wide.load6 = load <8 x float>, ptr %28, align 4, !invariant.load !3, !alias.scope !10, !noalias !20
  %29 = fadd <8 x float> %25, %wide.load5
  %30 = fadd <8 x float> %26, %wide.load6
  %31 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %29, <8 x float> zeroinitializer)
  %32 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %30, <8 x float> zeroinitializer)
  %33 = getelementptr inbounds nuw float, ptr %6, i64 %20
  %34 = getelementptr inbounds nuw i8, ptr %33, i64 32
  %wide.load7 = load <8 x float>, ptr %33, align 4, !invariant.load !3, !alias.scope !8, !noalias !21
  %wide.load8 = load <8 x float>, ptr %34, align 4, !invariant.load !3, !alias.scope !8, !noalias !21
  %35 = fmul <8 x float> %wide.load7, %31
  %36 = fmul <8 x float> %wide.load8, %32
  %37 = getelementptr inbounds nuw float, ptr %4, i64 %20
  %38 = getelementptr inbounds nuw i8, ptr %37, i64 32
  %wide.load9 = load <8 x float>, ptr %37, align 4, !invariant.load !3, !alias.scope !5, !noalias !22
  %wide.load10 = load <8 x float>, ptr %38, align 4, !invariant.load !3, !alias.scope !5, !noalias !22
  %39 = fadd <8 x float> %wide.load9, %35
  %40 = fadd <8 x float> %wide.load10, %36
  %41 = fcmp ogt <8 x float> %39, zeroinitializer
  %42 = fcmp ogt <8 x float> %40, zeroinitializer
  %43 = zext <8 x i1> %41 to <8 x i32>
  %44 = zext <8 x i1> %42 to <8 x i32>
  %45 = getelementptr inbounds nuw i32, ptr %14, i64 %20
  %46 = getelementptr inbounds nuw i8, ptr %45, i64 32
  store <8 x i32> %43, ptr %45, align 4, !alias.scope !16, !noalias !23
  store <8 x i32> %44, ptr %46, align 4, !alias.scope !16, !noalias !23
  %index.next = or disjoint i64 %index, 16
  %47 = add nuw nsw i64 %index.next, %19
  %48 = getelementptr inbounds nuw float, ptr %10, i64 %47
  %49 = getelementptr inbounds nuw i8, ptr %48, i64 32
  %wide.load.1 = load <8 x float>, ptr %48, align 4, !invariant.load !3, !alias.scope !12, !noalias !18
  %wide.load2.1 = load <8 x float>, ptr %49, align 4, !invariant.load !3, !alias.scope !12, !noalias !18
  %50 = getelementptr inbounds nuw float, ptr %12, i64 %47
  %51 = getelementptr inbounds nuw i8, ptr %50, i64 32
  %wide.load3.1 = load <8 x float>, ptr %50, align 4, !invariant.load !3, !alias.scope !14, !noalias !19
  %wide.load4.1 = load <8 x float>, ptr %51, align 4, !invariant.load !3, !alias.scope !14, !noalias !19
  %52 = fmul <8 x float> %wide.load.1, %wide.load3.1
  %53 = fmul <8 x float> %wide.load2.1, %wide.load4.1
  %54 = getelementptr inbounds nuw float, ptr %8, i64 %47
  %55 = getelementptr inbounds nuw i8, ptr %54, i64 32
  %wide.load5.1 = load <8 x float>, ptr %54, align 4, !invariant.load !3, !alias.scope !10, !noalias !20
  %wide.load6.1 = load <8 x float>, ptr %55, align 4, !invariant.load !3, !alias.scope !10, !noalias !20
  %56 = fadd <8 x float> %52, %wide.load5.1
  %57 = fadd <8 x float> %53, %wide.load6.1
  %58 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %56, <8 x float> zeroinitializer)
  %59 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %57, <8 x float> zeroinitializer)
  %60 = getelementptr inbounds nuw float, ptr %6, i64 %47
  %61 = getelementptr inbounds nuw i8, ptr %60, i64 32
  %wide.load7.1 = load <8 x float>, ptr %60, align 4, !invariant.load !3, !alias.scope !8, !noalias !21
  %wide.load8.1 = load <8 x float>, ptr %61, align 4, !invariant.load !3, !alias.scope !8, !noalias !21
  %62 = fmul <8 x float> %wide.load7.1, %58
  %63 = fmul <8 x float> %wide.load8.1, %59
  %64 = getelementptr inbounds nuw float, ptr %4, i64 %47
  %65 = getelementptr inbounds nuw i8, ptr %64, i64 32
  %wide.load9.1 = load <8 x float>, ptr %64, align 4, !invariant.load !3, !alias.scope !5, !noalias !22
  %wide.load10.1 = load <8 x float>, ptr %65, align 4, !invariant.load !3, !alias.scope !5, !noalias !22
  %66 = fadd <8 x float> %wide.load9.1, %62
  %67 = fadd <8 x float> %wide.load10.1, %63
  %68 = fcmp ogt <8 x float> %66, zeroinitializer
  %69 = fcmp ogt <8 x float> %67, zeroinitializer
  %70 = zext <8 x i1> %68 to <8 x i32>
  %71 = zext <8 x i1> %69 to <8 x i32>
  %72 = getelementptr inbounds nuw i32, ptr %14, i64 %47
  %73 = getelementptr inbounds nuw i8, ptr %72, i64 32
  store <8 x i32> %70, ptr %72, align 4, !alias.scope !16, !noalias !23
  store <8 x i32> %71, ptr %73, align 4, !alias.scope !16, !noalias !23
  %index.next.1 = add nuw nsw i64 %index, 32
  %74 = icmp eq i64 %index.next.1, 11520
  br i1 %74, label %compare_convert_fusion_wrapped.exit, label %vector.body, !llvm.loop !24

compare_convert_fusion_wrapped.exit:              ; preds = %vector.body, %1
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.maximum.v8f32(<8 x float>, <8 x float>) #2

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 0}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 184320}
!5 = !{!6}
!6 = distinct !{!6, !7, !"compare_convert_fusion_wrapped: argument 0"}
!7 = distinct !{!7, !"compare_convert_fusion_wrapped"}
!8 = !{!9}
!9 = distinct !{!9, !7, !"compare_convert_fusion_wrapped: argument 1"}
!10 = !{!11}
!11 = distinct !{!11, !7, !"compare_convert_fusion_wrapped: argument 2"}
!12 = !{!13}
!13 = distinct !{!13, !7, !"compare_convert_fusion_wrapped: argument 3"}
!14 = !{!15}
!15 = distinct !{!15, !7, !"compare_convert_fusion_wrapped: argument 4"}
!16 = !{!17}
!17 = distinct !{!17, !7, !"compare_convert_fusion_wrapped: argument 5"}
!18 = !{!6, !9, !11, !15, !17}
!19 = !{!6, !9, !11, !13, !17}
!20 = !{!6, !9, !13, !15, !17}
!21 = !{!6, !11, !13, !15, !17}
!22 = !{!9, !11, !13, !15, !17}
!23 = !{!6, !9, !11, !13, !15}
!24 = distinct !{!24, !25, !26}
!25 = !{!"llvm.loop.isvectorized", i32 1}
!26 = !{!"llvm.loop.unroll.runtime.disable"}
