; ModuleID = '__compute_module_wrapped_reduce-window.1_kernel_module'
source_filename = "__compute_module_wrapped_reduce-window.1_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @wrapped_reduce-window.1(ptr readonly captures(none) %0) local_unnamed_addr #0 {
vector.ph:
  %1 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %2 = load ptr, ptr %1, align 8, !invariant.load !3
  %3 = load ptr, ptr %2, align 8, !invariant.load !3, !dereferenceable !4
  %4 = getelementptr inbounds nuw i8, ptr %2, i64 16
  %5 = load ptr, ptr %4, align 8, !invariant.load !3, !dereferenceable !5
  %6 = getelementptr inbounds nuw i8, ptr %2, i64 32
  %7 = load ptr, ptr %6, align 8, !invariant.load !3, !dereferenceable !6
  tail call void @llvm.experimental.noalias.scope.decl(metadata !7)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !10)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !12)
  %8 = load i32, ptr %5, align 4, !invariant.load !3, !alias.scope !10, !noalias !14
  %broadcast.splatinsert = insertelement <8 x i32> poison, i32 %8, i64 0
  %broadcast.splat = shufflevector <8 x i32> %broadcast.splatinsert, <8 x i32> poison, <8 x i32> zeroinitializer
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %vector.ph
  %index = phi i64 [ 0, %vector.ph ], [ %index.next, %vector.body ]
  %vec.ind = phi <8 x i64> [ <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>, %vector.ph ], [ %vec.ind.next, %vector.body ]
  %9 = shl <8 x i64> %vec.ind, splat (i64 7)
  %10 = getelementptr i8, ptr %3, <8 x i64> %9
  %wide.masked.gather = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %10, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %11 = add <8 x i32> %wide.masked.gather, %broadcast.splat
  %12 = getelementptr i8, <8 x ptr> %10, i64 4
  %wide.masked.gather1 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %12, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %13 = add <8 x i32> %wide.masked.gather1, %11
  %14 = getelementptr i8, <8 x ptr> %10, i64 8
  %wide.masked.gather2 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %14, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %15 = add <8 x i32> %wide.masked.gather2, %13
  %16 = getelementptr i8, <8 x ptr> %10, i64 12
  %wide.masked.gather3 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %16, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %17 = add <8 x i32> %wide.masked.gather3, %15
  %18 = getelementptr i8, <8 x ptr> %10, i64 16
  %wide.masked.gather4 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %18, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %19 = add <8 x i32> %wide.masked.gather4, %17
  %20 = getelementptr i8, <8 x ptr> %10, i64 20
  %wide.masked.gather5 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %20, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %21 = add <8 x i32> %wide.masked.gather5, %19
  %22 = getelementptr i8, <8 x ptr> %10, i64 24
  %wide.masked.gather6 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %22, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %23 = add <8 x i32> %wide.masked.gather6, %21
  %24 = getelementptr i8, <8 x ptr> %10, i64 28
  %wide.masked.gather7 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %24, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %25 = add <8 x i32> %wide.masked.gather7, %23
  %26 = getelementptr i8, <8 x ptr> %10, i64 32
  %wide.masked.gather8 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %26, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %27 = add <8 x i32> %wide.masked.gather8, %25
  %28 = getelementptr i8, <8 x ptr> %10, i64 36
  %wide.masked.gather9 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %28, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %29 = add <8 x i32> %wide.masked.gather9, %27
  %30 = getelementptr i8, <8 x ptr> %10, i64 40
  %wide.masked.gather10 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %30, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %31 = add <8 x i32> %wide.masked.gather10, %29
  %32 = getelementptr i8, <8 x ptr> %10, i64 44
  %wide.masked.gather11 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %32, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %33 = add <8 x i32> %wide.masked.gather11, %31
  %34 = getelementptr i8, <8 x ptr> %10, i64 48
  %wide.masked.gather12 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %34, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %35 = add <8 x i32> %wide.masked.gather12, %33
  %36 = getelementptr i8, <8 x ptr> %10, i64 52
  %wide.masked.gather13 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %36, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %37 = add <8 x i32> %wide.masked.gather13, %35
  %38 = getelementptr i8, <8 x ptr> %10, i64 56
  %wide.masked.gather14 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %38, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %39 = add <8 x i32> %wide.masked.gather14, %37
  %40 = getelementptr i8, <8 x ptr> %10, i64 60
  %wide.masked.gather15 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %40, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %41 = add <8 x i32> %wide.masked.gather15, %39
  %42 = getelementptr i8, <8 x ptr> %10, i64 64
  %wide.masked.gather16 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %42, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %43 = add <8 x i32> %wide.masked.gather16, %41
  %44 = getelementptr i8, <8 x ptr> %10, i64 68
  %wide.masked.gather17 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %44, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %45 = add <8 x i32> %wide.masked.gather17, %43
  %46 = getelementptr i8, <8 x ptr> %10, i64 72
  %wide.masked.gather18 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %46, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %47 = add <8 x i32> %wide.masked.gather18, %45
  %48 = getelementptr i8, <8 x ptr> %10, i64 76
  %wide.masked.gather19 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %48, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %49 = add <8 x i32> %wide.masked.gather19, %47
  %50 = getelementptr i8, <8 x ptr> %10, i64 80
  %wide.masked.gather20 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %50, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %51 = add <8 x i32> %wide.masked.gather20, %49
  %52 = getelementptr i8, <8 x ptr> %10, i64 84
  %wide.masked.gather21 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %52, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %53 = add <8 x i32> %wide.masked.gather21, %51
  %54 = getelementptr i8, <8 x ptr> %10, i64 88
  %wide.masked.gather22 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %54, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %55 = add <8 x i32> %wide.masked.gather22, %53
  %56 = getelementptr i8, <8 x ptr> %10, i64 92
  %wide.masked.gather23 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %56, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %57 = add <8 x i32> %wide.masked.gather23, %55
  %58 = getelementptr i8, <8 x ptr> %10, i64 96
  %wide.masked.gather24 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %58, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %59 = add <8 x i32> %wide.masked.gather24, %57
  %60 = getelementptr i8, <8 x ptr> %10, i64 100
  %wide.masked.gather25 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %60, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %61 = add <8 x i32> %wide.masked.gather25, %59
  %62 = getelementptr i8, <8 x ptr> %10, i64 104
  %wide.masked.gather26 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %62, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %63 = add <8 x i32> %wide.masked.gather26, %61
  %64 = getelementptr i8, <8 x ptr> %10, i64 108
  %wide.masked.gather27 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %64, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %65 = add <8 x i32> %wide.masked.gather27, %63
  %66 = getelementptr i8, <8 x ptr> %10, i64 112
  %wide.masked.gather28 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %66, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %67 = add <8 x i32> %wide.masked.gather28, %65
  %68 = getelementptr i8, <8 x ptr> %10, i64 116
  %wide.masked.gather29 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %68, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %69 = add <8 x i32> %wide.masked.gather29, %67
  %70 = getelementptr i8, <8 x ptr> %10, i64 120
  %wide.masked.gather30 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %70, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %71 = add <8 x i32> %wide.masked.gather30, %69
  %72 = getelementptr i8, <8 x ptr> %10, i64 124
  %wide.masked.gather31 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %72, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %73 = add <8 x i32> %wide.masked.gather31, %71
  %74 = getelementptr inbounds nuw i32, ptr %7, i64 %index
  store <8 x i32> %73, ptr %74, align 4, !alias.scope !12, !noalias !16
  %index.next = add nuw i64 %index, 8
  %vec.ind.next = add nuw nsw <8 x i64> %vec.ind, splat (i64 8)
  %75 = icmp eq i64 %index.next, 40
  br i1 %75, label %.preheader, label %vector.body, !llvm.loop !17

.preheader:                                       ; preds = %vector.body, %.preheader
  %76 = phi i64 [ %174, %.preheader ], [ 40, %vector.body ]
  %.idx = shl i64 %76, 7
  %77 = getelementptr i8, ptr %3, i64 %.idx
  %78 = load i32, ptr %77, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %79 = add i32 %78, %8
  %80 = getelementptr i8, ptr %77, i64 4
  %81 = load i32, ptr %80, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %82 = add i32 %81, %79
  %83 = getelementptr i8, ptr %77, i64 8
  %84 = load i32, ptr %83, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %85 = add i32 %84, %82
  %86 = getelementptr i8, ptr %77, i64 12
  %87 = load i32, ptr %86, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %88 = add i32 %87, %85
  %89 = getelementptr i8, ptr %77, i64 16
  %90 = load i32, ptr %89, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %91 = add i32 %90, %88
  %92 = getelementptr i8, ptr %77, i64 20
  %93 = load i32, ptr %92, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %94 = add i32 %93, %91
  %95 = getelementptr i8, ptr %77, i64 24
  %96 = load i32, ptr %95, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %97 = add i32 %96, %94
  %98 = getelementptr i8, ptr %77, i64 28
  %99 = load i32, ptr %98, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %100 = add i32 %99, %97
  %101 = getelementptr i8, ptr %77, i64 32
  %102 = load i32, ptr %101, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %103 = add i32 %102, %100
  %104 = getelementptr i8, ptr %77, i64 36
  %105 = load i32, ptr %104, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %106 = add i32 %105, %103
  %107 = getelementptr i8, ptr %77, i64 40
  %108 = load i32, ptr %107, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %109 = add i32 %108, %106
  %110 = getelementptr i8, ptr %77, i64 44
  %111 = load i32, ptr %110, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %112 = add i32 %111, %109
  %113 = getelementptr i8, ptr %77, i64 48
  %114 = load i32, ptr %113, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %115 = add i32 %114, %112
  %116 = getelementptr i8, ptr %77, i64 52
  %117 = load i32, ptr %116, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %118 = add i32 %117, %115
  %119 = getelementptr i8, ptr %77, i64 56
  %120 = load i32, ptr %119, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %121 = add i32 %120, %118
  %122 = getelementptr i8, ptr %77, i64 60
  %123 = load i32, ptr %122, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %124 = add i32 %123, %121
  %125 = getelementptr i8, ptr %77, i64 64
  %126 = load i32, ptr %125, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %127 = add i32 %126, %124
  %128 = getelementptr i8, ptr %77, i64 68
  %129 = load i32, ptr %128, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %130 = add i32 %129, %127
  %131 = getelementptr i8, ptr %77, i64 72
  %132 = load i32, ptr %131, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %133 = add i32 %132, %130
  %134 = getelementptr i8, ptr %77, i64 76
  %135 = load i32, ptr %134, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %136 = add i32 %135, %133
  %137 = getelementptr i8, ptr %77, i64 80
  %138 = load i32, ptr %137, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %139 = add i32 %138, %136
  %140 = getelementptr i8, ptr %77, i64 84
  %141 = load i32, ptr %140, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %142 = add i32 %141, %139
  %143 = getelementptr i8, ptr %77, i64 88
  %144 = load i32, ptr %143, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %145 = add i32 %144, %142
  %146 = getelementptr i8, ptr %77, i64 92
  %147 = load i32, ptr %146, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %148 = add i32 %147, %145
  %149 = getelementptr i8, ptr %77, i64 96
  %150 = load i32, ptr %149, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %151 = add i32 %150, %148
  %152 = getelementptr i8, ptr %77, i64 100
  %153 = load i32, ptr %152, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %154 = add i32 %153, %151
  %155 = getelementptr i8, ptr %77, i64 104
  %156 = load i32, ptr %155, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %157 = add i32 %156, %154
  %158 = getelementptr i8, ptr %77, i64 108
  %159 = load i32, ptr %158, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %160 = add i32 %159, %157
  %161 = getelementptr i8, ptr %77, i64 112
  %162 = load i32, ptr %161, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %163 = add i32 %162, %160
  %164 = getelementptr i8, ptr %77, i64 116
  %165 = load i32, ptr %164, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %166 = add i32 %165, %163
  %167 = getelementptr i8, ptr %77, i64 120
  %168 = load i32, ptr %167, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %169 = add i32 %168, %166
  %170 = getelementptr i8, ptr %77, i64 124
  %171 = load i32, ptr %170, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %172 = add i32 %171, %169
  %173 = getelementptr inbounds nuw i32, ptr %7, i64 %76
  store i32 %172, ptr %173, align 4, !alias.scope !12, !noalias !16
  %174 = add nuw nsw i64 %76, 1
  %exitcond.not = icmp eq i64 %174, 45
  br i1 %exitcond.not, label %wrapped_reduce-window.1_wrapped.exit, label %.preheader, !llvm.loop !21

wrapped_reduce-window.1_wrapped.exit:             ; preds = %.preheader
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr>, <8 x i1>, <8 x i32>) #2

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(read) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 4}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 5760}
!5 = !{i64 4}
!6 = !{i64 180}
!7 = !{!8}
!8 = distinct !{!8, !9, !"wrapped_reduce-window.1_wrapped: argument 0"}
!9 = distinct !{!9, !"wrapped_reduce-window.1_wrapped"}
!10 = !{!11}
!11 = distinct !{!11, !9, !"wrapped_reduce-window.1_wrapped: argument 1"}
!12 = !{!13}
!13 = distinct !{!13, !9, !"wrapped_reduce-window.1_wrapped: argument 2"}
!14 = !{!8, !13}
!15 = !{!11, !13}
!16 = !{!8, !11}
!17 = distinct !{!17, !18, !19, !20}
!18 = !{!"llvm.loop.unroll.disable"}
!19 = !{!"llvm.loop.isvectorized", i32 1}
!20 = !{!"llvm.loop.unroll.runtime.disable"}
!21 = distinct !{!21, !18, !19}
