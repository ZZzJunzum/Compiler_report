; ModuleID = '__compute_module_compare_convert_fusion.1_kernel_module'
source_filename = "__compute_module_compare_convert_fusion.1_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @compare_convert_fusion.1(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !4
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !4
  %9 = getelementptr inbounds nuw i8, ptr %3, i64 48
  %10 = load ptr, ptr %9, align 8, !invariant.load !3, !dereferenceable !4
  %11 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %12 = load ptr, ptr %11, align 8
  %13 = load i64, ptr %12, align 4, !invariant.load !3
  tail call void @llvm.experimental.noalias.scope.decl(metadata !5)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !8)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !10)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !12)
  %14 = icmp ult i64 %13, 2
  br i1 %14, label %vector.ph, label %compare_convert_fusion.1_wrapped.exit

vector.ph:                                        ; preds = %1
  %15 = mul nuw nsw i64 %13, 23040
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %vector.ph
  %index = phi i64 [ 0, %vector.ph ], [ %index.next.1, %vector.body ]
  %16 = add nuw nsw i64 %index, %15
  %17 = getelementptr inbounds nuw float, ptr %6, i64 %16
  %18 = getelementptr inbounds nuw i8, ptr %17, i64 32
  %19 = getelementptr inbounds nuw i8, ptr %17, i64 64
  %20 = getelementptr inbounds nuw i8, ptr %17, i64 96
  %wide.load = load <8 x float>, ptr %17, align 4, !invariant.load !3, !alias.scope !8, !noalias !14
  %wide.load2 = load <8 x float>, ptr %18, align 4, !invariant.load !3, !alias.scope !8, !noalias !14
  %wide.load3 = load <8 x float>, ptr %19, align 4, !invariant.load !3, !alias.scope !8, !noalias !14
  %wide.load4 = load <8 x float>, ptr %20, align 4, !invariant.load !3, !alias.scope !8, !noalias !14
  %21 = getelementptr inbounds nuw float, ptr %8, i64 %16
  %22 = getelementptr inbounds nuw i8, ptr %21, i64 32
  %23 = getelementptr inbounds nuw i8, ptr %21, i64 64
  %24 = getelementptr inbounds nuw i8, ptr %21, i64 96
  %wide.load5 = load <8 x float>, ptr %21, align 4, !invariant.load !3, !alias.scope !10, !noalias !15
  %wide.load6 = load <8 x float>, ptr %22, align 4, !invariant.load !3, !alias.scope !10, !noalias !15
  %wide.load7 = load <8 x float>, ptr %23, align 4, !invariant.load !3, !alias.scope !10, !noalias !15
  %wide.load8 = load <8 x float>, ptr %24, align 4, !invariant.load !3, !alias.scope !10, !noalias !15
  %25 = fmul <8 x float> %wide.load, %wide.load5
  %26 = fmul <8 x float> %wide.load2, %wide.load6
  %27 = fmul <8 x float> %wide.load3, %wide.load7
  %28 = fmul <8 x float> %wide.load4, %wide.load8
  %29 = getelementptr inbounds nuw float, ptr %4, i64 %16
  %30 = getelementptr inbounds nuw i8, ptr %29, i64 32
  %31 = getelementptr inbounds nuw i8, ptr %29, i64 64
  %32 = getelementptr inbounds nuw i8, ptr %29, i64 96
  %wide.load9 = load <8 x float>, ptr %29, align 4, !invariant.load !3, !alias.scope !5, !noalias !16
  %wide.load10 = load <8 x float>, ptr %30, align 4, !invariant.load !3, !alias.scope !5, !noalias !16
  %wide.load11 = load <8 x float>, ptr %31, align 4, !invariant.load !3, !alias.scope !5, !noalias !16
  %wide.load12 = load <8 x float>, ptr %32, align 4, !invariant.load !3, !alias.scope !5, !noalias !16
  %33 = fadd <8 x float> %25, %wide.load9
  %34 = fadd <8 x float> %26, %wide.load10
  %35 = fadd <8 x float> %27, %wide.load11
  %36 = fadd <8 x float> %28, %wide.load12
  %37 = fcmp ogt <8 x float> %33, zeroinitializer
  %38 = fcmp ogt <8 x float> %34, zeroinitializer
  %39 = fcmp ogt <8 x float> %35, zeroinitializer
  %40 = fcmp ogt <8 x float> %36, zeroinitializer
  %41 = zext <8 x i1> %37 to <8 x i32>
  %42 = zext <8 x i1> %38 to <8 x i32>
  %43 = zext <8 x i1> %39 to <8 x i32>
  %44 = zext <8 x i1> %40 to <8 x i32>
  %45 = getelementptr inbounds nuw i32, ptr %10, i64 %16
  %46 = getelementptr inbounds nuw i8, ptr %45, i64 32
  %47 = getelementptr inbounds nuw i8, ptr %45, i64 64
  %48 = getelementptr inbounds nuw i8, ptr %45, i64 96
  store <8 x i32> %41, ptr %45, align 4, !alias.scope !12, !noalias !17
  store <8 x i32> %42, ptr %46, align 4, !alias.scope !12, !noalias !17
  store <8 x i32> %43, ptr %47, align 4, !alias.scope !12, !noalias !17
  store <8 x i32> %44, ptr %48, align 4, !alias.scope !12, !noalias !17
  %index.next = or disjoint i64 %index, 32
  %49 = add nuw nsw i64 %index.next, %15
  %50 = getelementptr inbounds nuw float, ptr %6, i64 %49
  %51 = getelementptr inbounds nuw i8, ptr %50, i64 32
  %52 = getelementptr inbounds nuw i8, ptr %50, i64 64
  %53 = getelementptr inbounds nuw i8, ptr %50, i64 96
  %wide.load.1 = load <8 x float>, ptr %50, align 4, !invariant.load !3, !alias.scope !8, !noalias !14
  %wide.load2.1 = load <8 x float>, ptr %51, align 4, !invariant.load !3, !alias.scope !8, !noalias !14
  %wide.load3.1 = load <8 x float>, ptr %52, align 4, !invariant.load !3, !alias.scope !8, !noalias !14
  %wide.load4.1 = load <8 x float>, ptr %53, align 4, !invariant.load !3, !alias.scope !8, !noalias !14
  %54 = getelementptr inbounds nuw float, ptr %8, i64 %49
  %55 = getelementptr inbounds nuw i8, ptr %54, i64 32
  %56 = getelementptr inbounds nuw i8, ptr %54, i64 64
  %57 = getelementptr inbounds nuw i8, ptr %54, i64 96
  %wide.load5.1 = load <8 x float>, ptr %54, align 4, !invariant.load !3, !alias.scope !10, !noalias !15
  %wide.load6.1 = load <8 x float>, ptr %55, align 4, !invariant.load !3, !alias.scope !10, !noalias !15
  %wide.load7.1 = load <8 x float>, ptr %56, align 4, !invariant.load !3, !alias.scope !10, !noalias !15
  %wide.load8.1 = load <8 x float>, ptr %57, align 4, !invariant.load !3, !alias.scope !10, !noalias !15
  %58 = fmul <8 x float> %wide.load.1, %wide.load5.1
  %59 = fmul <8 x float> %wide.load2.1, %wide.load6.1
  %60 = fmul <8 x float> %wide.load3.1, %wide.load7.1
  %61 = fmul <8 x float> %wide.load4.1, %wide.load8.1
  %62 = getelementptr inbounds nuw float, ptr %4, i64 %49
  %63 = getelementptr inbounds nuw i8, ptr %62, i64 32
  %64 = getelementptr inbounds nuw i8, ptr %62, i64 64
  %65 = getelementptr inbounds nuw i8, ptr %62, i64 96
  %wide.load9.1 = load <8 x float>, ptr %62, align 4, !invariant.load !3, !alias.scope !5, !noalias !16
  %wide.load10.1 = load <8 x float>, ptr %63, align 4, !invariant.load !3, !alias.scope !5, !noalias !16
  %wide.load11.1 = load <8 x float>, ptr %64, align 4, !invariant.load !3, !alias.scope !5, !noalias !16
  %wide.load12.1 = load <8 x float>, ptr %65, align 4, !invariant.load !3, !alias.scope !5, !noalias !16
  %66 = fadd <8 x float> %58, %wide.load9.1
  %67 = fadd <8 x float> %59, %wide.load10.1
  %68 = fadd <8 x float> %60, %wide.load11.1
  %69 = fadd <8 x float> %61, %wide.load12.1
  %70 = fcmp ogt <8 x float> %66, zeroinitializer
  %71 = fcmp ogt <8 x float> %67, zeroinitializer
  %72 = fcmp ogt <8 x float> %68, zeroinitializer
  %73 = fcmp ogt <8 x float> %69, zeroinitializer
  %74 = zext <8 x i1> %70 to <8 x i32>
  %75 = zext <8 x i1> %71 to <8 x i32>
  %76 = zext <8 x i1> %72 to <8 x i32>
  %77 = zext <8 x i1> %73 to <8 x i32>
  %78 = getelementptr inbounds nuw i32, ptr %10, i64 %49
  %79 = getelementptr inbounds nuw i8, ptr %78, i64 32
  %80 = getelementptr inbounds nuw i8, ptr %78, i64 64
  %81 = getelementptr inbounds nuw i8, ptr %78, i64 96
  store <8 x i32> %74, ptr %78, align 4, !alias.scope !12, !noalias !17
  store <8 x i32> %75, ptr %79, align 4, !alias.scope !12, !noalias !17
  store <8 x i32> %76, ptr %80, align 4, !alias.scope !12, !noalias !17
  store <8 x i32> %77, ptr %81, align 4, !alias.scope !12, !noalias !17
  %index.next.1 = add nuw nsw i64 %index, 64
  %82 = icmp eq i64 %index.next.1, 23040
  br i1 %82, label %compare_convert_fusion.1_wrapped.exit, label %vector.body, !llvm.loop !18

compare_convert_fusion.1_wrapped.exit:            ; preds = %vector.body, %1
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 1}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 184320}
!5 = !{!6}
!6 = distinct !{!6, !7, !"compare_convert_fusion.1_wrapped: argument 0"}
!7 = distinct !{!7, !"compare_convert_fusion.1_wrapped"}
!8 = !{!9}
!9 = distinct !{!9, !7, !"compare_convert_fusion.1_wrapped: argument 1"}
!10 = !{!11}
!11 = distinct !{!11, !7, !"compare_convert_fusion.1_wrapped: argument 2"}
!12 = !{!13}
!13 = distinct !{!13, !7, !"compare_convert_fusion.1_wrapped: argument 3"}
!14 = !{!6, !11, !13}
!15 = !{!6, !9, !13}
!16 = !{!9, !11, !13}
!17 = !{!6, !9, !11}
!18 = distinct !{!18, !19, !20}
!19 = !{!"llvm.loop.isvectorized", i32 1}
!20 = !{!"llvm.loop.unroll.runtime.disable"}
