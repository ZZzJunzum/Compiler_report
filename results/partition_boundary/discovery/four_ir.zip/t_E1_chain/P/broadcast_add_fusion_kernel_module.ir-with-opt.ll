; ModuleID = '__compute_module_broadcast_add_fusion_kernel_module'
source_filename = "__compute_module_broadcast_add_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @broadcast_add_fusion(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !4
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !4
  %9 = getelementptr inbounds nuw i8, ptr %3, i64 48
  %10 = load ptr, ptr %9, align 8, !invariant.load !3, !dereferenceable !4
  %11 = getelementptr inbounds nuw i8, ptr %3, i64 64
  %12 = load ptr, ptr %11, align 8, !invariant.load !3, !dereferenceable !4
  %13 = getelementptr inbounds nuw i8, ptr %3, i64 80
  %14 = load ptr, ptr %13, align 8, !invariant.load !3, !dereferenceable !5
  %15 = getelementptr inbounds nuw i8, ptr %3, i64 96
  %16 = load ptr, ptr %15, align 8, !invariant.load !3, !dereferenceable !4
  %17 = getelementptr inbounds nuw i8, ptr %3, i64 112
  %18 = load ptr, ptr %17, align 8, !invariant.load !3, !dereferenceable !5
  %19 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %20 = load ptr, ptr %19, align 8
  %21 = load i64, ptr %20, align 4, !invariant.load !3
  tail call void @llvm.experimental.noalias.scope.decl(metadata !6)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !11)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !13)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !15)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !17)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !19)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !21)
  %22 = icmp slt i64 %21, 11
  br i1 %22, label %23, label %72

23:                                               ; preds = %1
  %24 = icmp sgt i64 %21, -1
  br i1 %24, label %25, label %broadcast_add_fusion_wrapped.exit

25:                                               ; preds = %23
  %26 = mul nuw nsw i64 %21, 4320
  br label %vector.ph20

vector.ph20:                                      ; preds = %25, %middle.block31
  %27 = phi i64 [ 0, %25 ], [ %71, %middle.block31 ]
  %28 = mul nuw nsw i64 %27, 160
  %29 = add nuw nsw i64 %28, %26
  br label %vector.body21

vector.body21:                                    ; preds = %vector.body21, %vector.ph20
  %index22 = phi i64 [ 0, %vector.ph20 ], [ %index.next30.1, %vector.body21 ]
  %30 = add nuw nsw i64 %29, %index22
  %31 = getelementptr inbounds nuw float, ptr %14, i64 %30
  %wide.load23 = load <8 x float>, ptr %31, align 4, !invariant.load !3, !alias.scope !17, !noalias !23
  %32 = getelementptr inbounds nuw float, ptr %16, i64 %index22
  %wide.load24 = load <8 x float>, ptr %32, align 4, !invariant.load !3, !alias.scope !19, !noalias !24
  %33 = fmul <8 x float> %wide.load23, %wide.load24
  %34 = getelementptr inbounds nuw float, ptr %12, i64 %index22
  %wide.load25 = load <8 x float>, ptr %34, align 4, !invariant.load !3, !alias.scope !15, !noalias !25
  %35 = fadd <8 x float> %33, %wide.load25
  %36 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %35, <8 x float> zeroinitializer)
  %37 = getelementptr inbounds nuw float, ptr %10, i64 %index22
  %wide.load26 = load <8 x float>, ptr %37, align 4, !invariant.load !3, !alias.scope !13, !noalias !26
  %38 = fmul <8 x float> %wide.load26, %36
  %39 = getelementptr inbounds nuw float, ptr %8, i64 %index22
  %wide.load27 = load <8 x float>, ptr %39, align 4, !invariant.load !3, !alias.scope !11, !noalias !27
  %40 = fadd <8 x float> %wide.load27, %38
  %41 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %40, <8 x float> zeroinitializer)
  %42 = getelementptr inbounds nuw float, ptr %6, i64 %index22
  %wide.load28 = load <8 x float>, ptr %42, align 4, !invariant.load !3, !alias.scope !9, !noalias !28
  %43 = fmul <8 x float> %wide.load28, %41
  %44 = getelementptr inbounds nuw float, ptr %4, i64 %index22
  %wide.load29 = load <8 x float>, ptr %44, align 4, !invariant.load !3, !alias.scope !6, !noalias !29
  %45 = fadd <8 x float> %wide.load29, %43
  %46 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %45, <8 x float> zeroinitializer)
  %47 = fmul <8 x float> %46, splat (float 7.500000e-01)
  %48 = fadd <8 x float> %47, splat (float 1.250000e-01)
  %49 = getelementptr inbounds nuw float, ptr %18, i64 %30
  store <8 x float> %48, ptr %49, align 4, !alias.scope !21, !noalias !30
  %index.next30 = or disjoint i64 %index22, 8
  %50 = add nuw nsw i64 %29, %index.next30
  %51 = getelementptr inbounds nuw float, ptr %14, i64 %50
  %wide.load23.1 = load <8 x float>, ptr %51, align 4, !invariant.load !3, !alias.scope !17, !noalias !23
  %52 = getelementptr inbounds nuw float, ptr %16, i64 %index.next30
  %wide.load24.1 = load <8 x float>, ptr %52, align 4, !invariant.load !3, !alias.scope !19, !noalias !24
  %53 = fmul <8 x float> %wide.load23.1, %wide.load24.1
  %54 = getelementptr inbounds nuw float, ptr %12, i64 %index.next30
  %wide.load25.1 = load <8 x float>, ptr %54, align 4, !invariant.load !3, !alias.scope !15, !noalias !25
  %55 = fadd <8 x float> %53, %wide.load25.1
  %56 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %55, <8 x float> zeroinitializer)
  %57 = getelementptr inbounds nuw float, ptr %10, i64 %index.next30
  %wide.load26.1 = load <8 x float>, ptr %57, align 4, !invariant.load !3, !alias.scope !13, !noalias !26
  %58 = fmul <8 x float> %wide.load26.1, %56
  %59 = getelementptr inbounds nuw float, ptr %8, i64 %index.next30
  %wide.load27.1 = load <8 x float>, ptr %59, align 4, !invariant.load !3, !alias.scope !11, !noalias !27
  %60 = fadd <8 x float> %wide.load27.1, %58
  %61 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %60, <8 x float> zeroinitializer)
  %62 = getelementptr inbounds nuw float, ptr %6, i64 %index.next30
  %wide.load28.1 = load <8 x float>, ptr %62, align 4, !invariant.load !3, !alias.scope !9, !noalias !28
  %63 = fmul <8 x float> %wide.load28.1, %61
  %64 = getelementptr inbounds nuw float, ptr %4, i64 %index.next30
  %wide.load29.1 = load <8 x float>, ptr %64, align 4, !invariant.load !3, !alias.scope !6, !noalias !29
  %65 = fadd <8 x float> %wide.load29.1, %63
  %66 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %65, <8 x float> zeroinitializer)
  %67 = fmul <8 x float> %66, splat (float 7.500000e-01)
  %68 = fadd <8 x float> %67, splat (float 1.250000e-01)
  %69 = getelementptr inbounds nuw float, ptr %18, i64 %50
  store <8 x float> %68, ptr %69, align 4, !alias.scope !21, !noalias !30
  %index.next30.1 = add nuw nsw i64 %index22, 16
  %70 = icmp eq i64 %index.next30.1, 160
  br i1 %70, label %middle.block31, label %vector.body21, !llvm.loop !31

middle.block31:                                   ; preds = %vector.body21
  %71 = add nuw nsw i64 %27, 1
  %exitcond9.not = icmp eq i64 %71, 27
  br i1 %exitcond9.not, label %broadcast_add_fusion_wrapped.exit, label %vector.ph20, !llvm.loop !34

72:                                               ; preds = %1
  %73 = icmp eq i64 %21, 11
  br i1 %73, label %.preheader, label %broadcast_add_fusion_wrapped.exit

.preheader:                                       ; preds = %72, %middle.block
  %74 = phi i64 [ %118, %middle.block ], [ 0, %72 ]
  %75 = mul nuw nsw i64 %74, 160
  %76 = add nuw nsw i64 %75, 47520
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %.preheader
  %index = phi i64 [ 0, %.preheader ], [ %index.next.1, %vector.body ]
  %77 = add nuw nsw i64 %76, %index
  %78 = getelementptr inbounds nuw float, ptr %14, i64 %77
  %wide.load = load <8 x float>, ptr %78, align 4, !invariant.load !3, !alias.scope !17, !noalias !23
  %79 = getelementptr inbounds nuw float, ptr %16, i64 %index
  %wide.load14 = load <8 x float>, ptr %79, align 4, !invariant.load !3, !alias.scope !19, !noalias !24
  %80 = fmul <8 x float> %wide.load, %wide.load14
  %81 = getelementptr inbounds nuw float, ptr %12, i64 %index
  %wide.load15 = load <8 x float>, ptr %81, align 4, !invariant.load !3, !alias.scope !15, !noalias !25
  %82 = fadd <8 x float> %80, %wide.load15
  %83 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %82, <8 x float> zeroinitializer)
  %84 = getelementptr inbounds nuw float, ptr %10, i64 %index
  %wide.load16 = load <8 x float>, ptr %84, align 4, !invariant.load !3, !alias.scope !13, !noalias !26
  %85 = fmul <8 x float> %wide.load16, %83
  %86 = getelementptr inbounds nuw float, ptr %8, i64 %index
  %wide.load17 = load <8 x float>, ptr %86, align 4, !invariant.load !3, !alias.scope !11, !noalias !27
  %87 = fadd <8 x float> %wide.load17, %85
  %88 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %87, <8 x float> zeroinitializer)
  %89 = getelementptr inbounds nuw float, ptr %6, i64 %index
  %wide.load18 = load <8 x float>, ptr %89, align 4, !invariant.load !3, !alias.scope !9, !noalias !28
  %90 = fmul <8 x float> %wide.load18, %88
  %91 = getelementptr inbounds nuw float, ptr %4, i64 %index
  %wide.load19 = load <8 x float>, ptr %91, align 4, !invariant.load !3, !alias.scope !6, !noalias !29
  %92 = fadd <8 x float> %wide.load19, %90
  %93 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %92, <8 x float> zeroinitializer)
  %94 = fmul <8 x float> %93, splat (float 7.500000e-01)
  %95 = fadd <8 x float> %94, splat (float 1.250000e-01)
  %96 = getelementptr inbounds nuw float, ptr %18, i64 %77
  store <8 x float> %95, ptr %96, align 4, !alias.scope !21, !noalias !30
  %index.next = or disjoint i64 %index, 8
  %97 = add nuw nsw i64 %76, %index.next
  %98 = getelementptr inbounds nuw float, ptr %14, i64 %97
  %wide.load.1 = load <8 x float>, ptr %98, align 4, !invariant.load !3, !alias.scope !17, !noalias !23
  %99 = getelementptr inbounds nuw float, ptr %16, i64 %index.next
  %wide.load14.1 = load <8 x float>, ptr %99, align 4, !invariant.load !3, !alias.scope !19, !noalias !24
  %100 = fmul <8 x float> %wide.load.1, %wide.load14.1
  %101 = getelementptr inbounds nuw float, ptr %12, i64 %index.next
  %wide.load15.1 = load <8 x float>, ptr %101, align 4, !invariant.load !3, !alias.scope !15, !noalias !25
  %102 = fadd <8 x float> %100, %wide.load15.1
  %103 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %102, <8 x float> zeroinitializer)
  %104 = getelementptr inbounds nuw float, ptr %10, i64 %index.next
  %wide.load16.1 = load <8 x float>, ptr %104, align 4, !invariant.load !3, !alias.scope !13, !noalias !26
  %105 = fmul <8 x float> %wide.load16.1, %103
  %106 = getelementptr inbounds nuw float, ptr %8, i64 %index.next
  %wide.load17.1 = load <8 x float>, ptr %106, align 4, !invariant.load !3, !alias.scope !11, !noalias !27
  %107 = fadd <8 x float> %wide.load17.1, %105
  %108 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %107, <8 x float> zeroinitializer)
  %109 = getelementptr inbounds nuw float, ptr %6, i64 %index.next
  %wide.load18.1 = load <8 x float>, ptr %109, align 4, !invariant.load !3, !alias.scope !9, !noalias !28
  %110 = fmul <8 x float> %wide.load18.1, %108
  %111 = getelementptr inbounds nuw float, ptr %4, i64 %index.next
  %wide.load19.1 = load <8 x float>, ptr %111, align 4, !invariant.load !3, !alias.scope !6, !noalias !29
  %112 = fadd <8 x float> %wide.load19.1, %110
  %113 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %112, <8 x float> zeroinitializer)
  %114 = fmul <8 x float> %113, splat (float 7.500000e-01)
  %115 = fadd <8 x float> %114, splat (float 1.250000e-01)
  %116 = getelementptr inbounds nuw float, ptr %18, i64 %97
  store <8 x float> %115, ptr %116, align 4, !alias.scope !21, !noalias !30
  %index.next.1 = add nuw nsw i64 %index, 16
  %117 = icmp eq i64 %index.next.1, 160
  br i1 %117, label %middle.block, label %vector.body, !llvm.loop !36

middle.block:                                     ; preds = %vector.body
  %118 = add nuw nsw i64 %74, 1
  %exitcond7.not = icmp eq i64 %118, 23
  br i1 %exitcond7.not, label %broadcast_add_fusion_wrapped.exit, label %.preheader, !llvm.loop !34

broadcast_add_fusion_wrapped.exit:                ; preds = %middle.block, %middle.block31, %23, %72
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.maximum.v8f32(<8 x float>, <8 x float>) #2

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 1}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 640}
!5 = !{i64 204800}
!6 = !{!7}
!7 = distinct !{!7, !8, !"broadcast_add_fusion_wrapped: argument 0"}
!8 = distinct !{!8, !"broadcast_add_fusion_wrapped"}
!9 = !{!10}
!10 = distinct !{!10, !8, !"broadcast_add_fusion_wrapped: argument 1"}
!11 = !{!12}
!12 = distinct !{!12, !8, !"broadcast_add_fusion_wrapped: argument 2"}
!13 = !{!14}
!14 = distinct !{!14, !8, !"broadcast_add_fusion_wrapped: argument 3"}
!15 = !{!16}
!16 = distinct !{!16, !8, !"broadcast_add_fusion_wrapped: argument 4"}
!17 = !{!18}
!18 = distinct !{!18, !8, !"broadcast_add_fusion_wrapped: argument 5"}
!19 = !{!20}
!20 = distinct !{!20, !8, !"broadcast_add_fusion_wrapped: argument 6"}
!21 = !{!22}
!22 = distinct !{!22, !8, !"broadcast_add_fusion_wrapped: argument 7"}
!23 = !{!7, !10, !12, !14, !16, !20, !22}
!24 = !{!7, !10, !12, !14, !16, !18, !22}
!25 = !{!7, !10, !12, !14, !18, !20, !22}
!26 = !{!7, !10, !12, !16, !18, !20, !22}
!27 = !{!7, !10, !14, !16, !18, !20, !22}
!28 = !{!7, !12, !14, !16, !18, !20, !22}
!29 = !{!10, !12, !14, !16, !18, !20, !22}
!30 = !{!7, !10, !12, !14, !16, !18, !20}
!31 = distinct !{!31, !32, !33}
!32 = !{!"llvm.loop.isvectorized", i32 1}
!33 = !{!"llvm.loop.unroll.runtime.disable"}
!34 = distinct !{!34, !35}
!35 = !{!"llvm.loop.unroll.disable"}
!36 = distinct !{!36, !32, !33}
