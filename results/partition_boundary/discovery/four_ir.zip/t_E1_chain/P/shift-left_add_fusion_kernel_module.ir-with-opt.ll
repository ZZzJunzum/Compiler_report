; ModuleID = '__compute_module_shift-left_add_fusion_kernel_module'
source_filename = "__compute_module_shift-left_add_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @shift-left_add_fusion(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !4
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !4
  %9 = getelementptr inbounds nuw i8, ptr %3, i64 48
  %10 = load ptr, ptr %9, align 8, !invariant.load !3, !dereferenceable !5
  %11 = getelementptr inbounds nuw i8, ptr %3, i64 64
  %12 = load ptr, ptr %11, align 8, !invariant.load !3, !dereferenceable !4
  %13 = getelementptr inbounds nuw i8, ptr %3, i64 80
  %14 = load ptr, ptr %13, align 8, !invariant.load !3, !dereferenceable !5
  %15 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %16 = load ptr, ptr %15, align 8
  %17 = load i64, ptr %16, align 4, !invariant.load !3
  tail call void @llvm.experimental.noalias.scope.decl(metadata !6)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !11)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !13)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !15)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !17)
  %18 = icmp slt i64 %17, 11
  br i1 %18, label %19, label %62

19:                                               ; preds = %1
  %20 = icmp sgt i64 %17, -1
  br i1 %20, label %21, label %shift-left_add_fusion_wrapped.exit

21:                                               ; preds = %19
  %22 = mul nuw nsw i64 %17, 4320
  br label %vector.ph18

vector.ph18:                                      ; preds = %21, %middle.block27
  %23 = phi i64 [ 0, %21 ], [ %61, %middle.block27 ]
  %24 = mul nuw nsw i64 %23, 160
  %25 = add nuw nsw i64 %24, %22
  br label %vector.body19

vector.body19:                                    ; preds = %vector.body19, %vector.ph18
  %index20 = phi i64 [ 0, %vector.ph18 ], [ %index.next26.1, %vector.body19 ]
  %26 = add nuw nsw i64 %25, %index20
  %27 = getelementptr inbounds nuw float, ptr %10, i64 %26
  %wide.load21 = load <8 x float>, ptr %27, align 4, !invariant.load !3, !alias.scope !13, !noalias !19
  %28 = getelementptr inbounds nuw float, ptr %12, i64 %index20
  %wide.load22 = load <8 x float>, ptr %28, align 4, !invariant.load !3, !alias.scope !15, !noalias !20
  %29 = fmul <8 x float> %wide.load21, %wide.load22
  %30 = getelementptr inbounds nuw float, ptr %8, i64 %index20
  %wide.load23 = load <8 x float>, ptr %30, align 4, !invariant.load !3, !alias.scope !11, !noalias !21
  %31 = fadd <8 x float> %29, %wide.load23
  %32 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %31, <8 x float> zeroinitializer)
  %33 = getelementptr inbounds nuw float, ptr %6, i64 %index20
  %wide.load24 = load <8 x float>, ptr %33, align 4, !invariant.load !3, !alias.scope !9, !noalias !22
  %34 = fmul <8 x float> %wide.load24, %32
  %35 = getelementptr inbounds nuw float, ptr %4, i64 %index20
  %wide.load25 = load <8 x float>, ptr %35, align 4, !invariant.load !3, !alias.scope !6, !noalias !23
  %36 = fadd <8 x float> %wide.load25, %34
  %37 = fcmp ogt <8 x float> %36, zeroinitializer
  %38 = fcmp ogt <8 x float> %31, zeroinitializer
  %39 = zext <8 x i1> %38 to <8 x i32>
  %40 = select <8 x i1> %37, <8 x i32> splat (i32 256), <8 x i32> zeroinitializer
  %41 = or disjoint <8 x i32> %40, %39
  %42 = getelementptr inbounds nuw i32, ptr %14, i64 %26
  store <8 x i32> %41, ptr %42, align 4, !alias.scope !17, !noalias !24
  %index.next26 = or disjoint i64 %index20, 8
  %43 = add nuw nsw i64 %25, %index.next26
  %44 = getelementptr inbounds nuw float, ptr %10, i64 %43
  %wide.load21.1 = load <8 x float>, ptr %44, align 4, !invariant.load !3, !alias.scope !13, !noalias !19
  %45 = getelementptr inbounds nuw float, ptr %12, i64 %index.next26
  %wide.load22.1 = load <8 x float>, ptr %45, align 4, !invariant.load !3, !alias.scope !15, !noalias !20
  %46 = fmul <8 x float> %wide.load21.1, %wide.load22.1
  %47 = getelementptr inbounds nuw float, ptr %8, i64 %index.next26
  %wide.load23.1 = load <8 x float>, ptr %47, align 4, !invariant.load !3, !alias.scope !11, !noalias !21
  %48 = fadd <8 x float> %46, %wide.load23.1
  %49 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %48, <8 x float> zeroinitializer)
  %50 = getelementptr inbounds nuw float, ptr %6, i64 %index.next26
  %wide.load24.1 = load <8 x float>, ptr %50, align 4, !invariant.load !3, !alias.scope !9, !noalias !22
  %51 = fmul <8 x float> %wide.load24.1, %49
  %52 = getelementptr inbounds nuw float, ptr %4, i64 %index.next26
  %wide.load25.1 = load <8 x float>, ptr %52, align 4, !invariant.load !3, !alias.scope !6, !noalias !23
  %53 = fadd <8 x float> %wide.load25.1, %51
  %54 = fcmp ogt <8 x float> %53, zeroinitializer
  %55 = fcmp ogt <8 x float> %48, zeroinitializer
  %56 = zext <8 x i1> %55 to <8 x i32>
  %57 = select <8 x i1> %54, <8 x i32> splat (i32 256), <8 x i32> zeroinitializer
  %58 = or disjoint <8 x i32> %57, %56
  %59 = getelementptr inbounds nuw i32, ptr %14, i64 %43
  store <8 x i32> %58, ptr %59, align 4, !alias.scope !17, !noalias !24
  %index.next26.1 = add nuw nsw i64 %index20, 16
  %60 = icmp eq i64 %index.next26.1, 160
  br i1 %60, label %middle.block27, label %vector.body19, !llvm.loop !25

middle.block27:                                   ; preds = %vector.body19
  %61 = add nuw nsw i64 %23, 1
  %exitcond9.not = icmp eq i64 %61, 27
  br i1 %exitcond9.not, label %shift-left_add_fusion_wrapped.exit, label %vector.ph18, !llvm.loop !28

62:                                               ; preds = %1
  %63 = icmp eq i64 %17, 11
  br i1 %63, label %.preheader, label %shift-left_add_fusion_wrapped.exit

.preheader:                                       ; preds = %62, %middle.block
  %64 = phi i64 [ %102, %middle.block ], [ 0, %62 ]
  %65 = mul nuw nsw i64 %64, 160
  %66 = add nuw nsw i64 %65, 47520
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %.preheader
  %index = phi i64 [ 0, %.preheader ], [ %index.next.1, %vector.body ]
  %67 = add nuw nsw i64 %66, %index
  %68 = getelementptr inbounds nuw float, ptr %10, i64 %67
  %wide.load = load <8 x float>, ptr %68, align 4, !invariant.load !3, !alias.scope !13, !noalias !19
  %69 = getelementptr inbounds nuw float, ptr %12, i64 %index
  %wide.load14 = load <8 x float>, ptr %69, align 4, !invariant.load !3, !alias.scope !15, !noalias !20
  %70 = fmul <8 x float> %wide.load, %wide.load14
  %71 = getelementptr inbounds nuw float, ptr %8, i64 %index
  %wide.load15 = load <8 x float>, ptr %71, align 4, !invariant.load !3, !alias.scope !11, !noalias !21
  %72 = fadd <8 x float> %70, %wide.load15
  %73 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %72, <8 x float> zeroinitializer)
  %74 = getelementptr inbounds nuw float, ptr %6, i64 %index
  %wide.load16 = load <8 x float>, ptr %74, align 4, !invariant.load !3, !alias.scope !9, !noalias !22
  %75 = fmul <8 x float> %wide.load16, %73
  %76 = getelementptr inbounds nuw float, ptr %4, i64 %index
  %wide.load17 = load <8 x float>, ptr %76, align 4, !invariant.load !3, !alias.scope !6, !noalias !23
  %77 = fadd <8 x float> %wide.load17, %75
  %78 = fcmp ogt <8 x float> %77, zeroinitializer
  %79 = fcmp ogt <8 x float> %72, zeroinitializer
  %80 = zext <8 x i1> %79 to <8 x i32>
  %81 = select <8 x i1> %78, <8 x i32> splat (i32 256), <8 x i32> zeroinitializer
  %82 = or disjoint <8 x i32> %81, %80
  %83 = getelementptr inbounds nuw i32, ptr %14, i64 %67
  store <8 x i32> %82, ptr %83, align 4, !alias.scope !17, !noalias !24
  %index.next = or disjoint i64 %index, 8
  %84 = add nuw nsw i64 %66, %index.next
  %85 = getelementptr inbounds nuw float, ptr %10, i64 %84
  %wide.load.1 = load <8 x float>, ptr %85, align 4, !invariant.load !3, !alias.scope !13, !noalias !19
  %86 = getelementptr inbounds nuw float, ptr %12, i64 %index.next
  %wide.load14.1 = load <8 x float>, ptr %86, align 4, !invariant.load !3, !alias.scope !15, !noalias !20
  %87 = fmul <8 x float> %wide.load.1, %wide.load14.1
  %88 = getelementptr inbounds nuw float, ptr %8, i64 %index.next
  %wide.load15.1 = load <8 x float>, ptr %88, align 4, !invariant.load !3, !alias.scope !11, !noalias !21
  %89 = fadd <8 x float> %87, %wide.load15.1
  %90 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %89, <8 x float> zeroinitializer)
  %91 = getelementptr inbounds nuw float, ptr %6, i64 %index.next
  %wide.load16.1 = load <8 x float>, ptr %91, align 4, !invariant.load !3, !alias.scope !9, !noalias !22
  %92 = fmul <8 x float> %wide.load16.1, %90
  %93 = getelementptr inbounds nuw float, ptr %4, i64 %index.next
  %wide.load17.1 = load <8 x float>, ptr %93, align 4, !invariant.load !3, !alias.scope !6, !noalias !23
  %94 = fadd <8 x float> %wide.load17.1, %92
  %95 = fcmp ogt <8 x float> %94, zeroinitializer
  %96 = fcmp ogt <8 x float> %89, zeroinitializer
  %97 = zext <8 x i1> %96 to <8 x i32>
  %98 = select <8 x i1> %95, <8 x i32> splat (i32 256), <8 x i32> zeroinitializer
  %99 = or disjoint <8 x i32> %98, %97
  %100 = getelementptr inbounds nuw i32, ptr %14, i64 %84
  store <8 x i32> %99, ptr %100, align 4, !alias.scope !17, !noalias !24
  %index.next.1 = add nuw nsw i64 %index, 16
  %101 = icmp eq i64 %index.next.1, 160
  br i1 %101, label %middle.block, label %vector.body, !llvm.loop !30

middle.block:                                     ; preds = %vector.body
  %102 = add nuw nsw i64 %64, 1
  %exitcond7.not = icmp eq i64 %102, 23
  br i1 %exitcond7.not, label %shift-left_add_fusion_wrapped.exit, label %.preheader, !llvm.loop !28

shift-left_add_fusion_wrapped.exit:               ; preds = %middle.block, %middle.block27, %19, %62
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.maximum.v8f32(<8 x float>, <8 x float>) #2

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 2}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 640}
!5 = !{i64 204800}
!6 = !{!7}
!7 = distinct !{!7, !8, !"shift-left_add_fusion_wrapped: argument 0"}
!8 = distinct !{!8, !"shift-left_add_fusion_wrapped"}
!9 = !{!10}
!10 = distinct !{!10, !8, !"shift-left_add_fusion_wrapped: argument 1"}
!11 = !{!12}
!12 = distinct !{!12, !8, !"shift-left_add_fusion_wrapped: argument 2"}
!13 = !{!14}
!14 = distinct !{!14, !8, !"shift-left_add_fusion_wrapped: argument 3"}
!15 = !{!16}
!16 = distinct !{!16, !8, !"shift-left_add_fusion_wrapped: argument 4"}
!17 = !{!18}
!18 = distinct !{!18, !8, !"shift-left_add_fusion_wrapped: argument 5"}
!19 = !{!7, !10, !12, !16, !18}
!20 = !{!7, !10, !12, !14, !18}
!21 = !{!7, !10, !14, !16, !18}
!22 = !{!7, !12, !14, !16, !18}
!23 = !{!10, !12, !14, !16, !18}
!24 = !{!7, !10, !12, !14, !16}
!25 = distinct !{!25, !26, !27}
!26 = !{!"llvm.loop.isvectorized", i32 1}
!27 = !{!"llvm.loop.unroll.runtime.disable"}
!28 = distinct !{!28, !29}
!29 = !{!"llvm.loop.unroll.disable"}
!30 = distinct !{!30, !26, !27}
