; ModuleID = '__compute_module_broadcast_add_fusion_kernel_module'
source_filename = "__compute_module_broadcast_add_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @broadcast_add_fusion(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !4
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !4
  %9 = getelementptr inbounds nuw i8, ptr %3, i64 48
  %10 = load ptr, ptr %9, align 8, !invariant.load !3, !dereferenceable !4
  %11 = getelementptr inbounds nuw i8, ptr %3, i64 64
  %12 = load ptr, ptr %11, align 8, !invariant.load !3, !dereferenceable !4
  %13 = getelementptr inbounds nuw i8, ptr %3, i64 80
  %14 = load ptr, ptr %13, align 8, !invariant.load !3, !dereferenceable !5
  %15 = getelementptr inbounds nuw i8, ptr %3, i64 96
  %16 = load ptr, ptr %15, align 8, !invariant.load !3, !dereferenceable !4
  %17 = getelementptr inbounds nuw i8, ptr %3, i64 112
  %18 = load ptr, ptr %17, align 8, !invariant.load !3, !dereferenceable !5
  tail call void @llvm.experimental.noalias.scope.decl(metadata !6)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !11)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !13)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !15)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !17)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !19)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !21)
  br label %vector.ph

vector.ph:                                        ; preds = %1, %middle.block
  %19 = phi i64 [ 0, %1 ], [ %62, %middle.block ]
  %20 = mul nuw nsw i64 %19, 160
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %vector.ph
  %index = phi i64 [ 0, %vector.ph ], [ %index.next.1, %vector.body ]
  %21 = add nuw nsw i64 %index, %20
  %22 = getelementptr inbounds nuw float, ptr %14, i64 %21
  %wide.load = load <8 x float>, ptr %22, align 4, !invariant.load !3, !alias.scope !17, !noalias !23
  %23 = getelementptr inbounds nuw float, ptr %16, i64 %index
  %wide.load3 = load <8 x float>, ptr %23, align 4, !invariant.load !3, !alias.scope !19, !noalias !24
  %24 = fmul <8 x float> %wide.load, %wide.load3
  %25 = getelementptr inbounds nuw float, ptr %12, i64 %index
  %wide.load4 = load <8 x float>, ptr %25, align 4, !invariant.load !3, !alias.scope !15, !noalias !25
  %26 = fadd <8 x float> %24, %wide.load4
  %27 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %26, <8 x float> zeroinitializer)
  %28 = getelementptr inbounds nuw float, ptr %10, i64 %index
  %wide.load5 = load <8 x float>, ptr %28, align 4, !invariant.load !3, !alias.scope !13, !noalias !26
  %29 = fmul <8 x float> %wide.load5, %27
  %30 = getelementptr inbounds nuw float, ptr %8, i64 %index
  %wide.load6 = load <8 x float>, ptr %30, align 4, !invariant.load !3, !alias.scope !11, !noalias !27
  %31 = fadd <8 x float> %wide.load6, %29
  %32 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %31, <8 x float> zeroinitializer)
  %33 = getelementptr inbounds nuw float, ptr %6, i64 %index
  %wide.load7 = load <8 x float>, ptr %33, align 4, !invariant.load !3, !alias.scope !9, !noalias !28
  %34 = fmul <8 x float> %wide.load7, %32
  %35 = getelementptr inbounds nuw float, ptr %4, i64 %index
  %wide.load8 = load <8 x float>, ptr %35, align 4, !invariant.load !3, !alias.scope !6, !noalias !29
  %36 = fadd <8 x float> %wide.load8, %34
  %37 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %36, <8 x float> zeroinitializer)
  %38 = fmul <8 x float> %37, splat (float 7.500000e-01)
  %39 = fadd <8 x float> %38, splat (float 1.250000e-01)
  %40 = getelementptr inbounds nuw float, ptr %18, i64 %21
  store <8 x float> %39, ptr %40, align 4, !alias.scope !21, !noalias !30
  %index.next = or disjoint i64 %index, 8
  %41 = add nuw nsw i64 %index.next, %20
  %42 = getelementptr inbounds nuw float, ptr %14, i64 %41
  %wide.load.1 = load <8 x float>, ptr %42, align 4, !invariant.load !3, !alias.scope !17, !noalias !23
  %43 = getelementptr inbounds nuw float, ptr %16, i64 %index.next
  %wide.load3.1 = load <8 x float>, ptr %43, align 4, !invariant.load !3, !alias.scope !19, !noalias !24
  %44 = fmul <8 x float> %wide.load.1, %wide.load3.1
  %45 = getelementptr inbounds nuw float, ptr %12, i64 %index.next
  %wide.load4.1 = load <8 x float>, ptr %45, align 4, !invariant.load !3, !alias.scope !15, !noalias !25
  %46 = fadd <8 x float> %44, %wide.load4.1
  %47 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %46, <8 x float> zeroinitializer)
  %48 = getelementptr inbounds nuw float, ptr %10, i64 %index.next
  %wide.load5.1 = load <8 x float>, ptr %48, align 4, !invariant.load !3, !alias.scope !13, !noalias !26
  %49 = fmul <8 x float> %wide.load5.1, %47
  %50 = getelementptr inbounds nuw float, ptr %8, i64 %index.next
  %wide.load6.1 = load <8 x float>, ptr %50, align 4, !invariant.load !3, !alias.scope !11, !noalias !27
  %51 = fadd <8 x float> %wide.load6.1, %49
  %52 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %51, <8 x float> zeroinitializer)
  %53 = getelementptr inbounds nuw float, ptr %6, i64 %index.next
  %wide.load7.1 = load <8 x float>, ptr %53, align 4, !invariant.load !3, !alias.scope !9, !noalias !28
  %54 = fmul <8 x float> %wide.load7.1, %52
  %55 = getelementptr inbounds nuw float, ptr %4, i64 %index.next
  %wide.load8.1 = load <8 x float>, ptr %55, align 4, !invariant.load !3, !alias.scope !6, !noalias !29
  %56 = fadd <8 x float> %wide.load8.1, %54
  %57 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %56, <8 x float> zeroinitializer)
  %58 = fmul <8 x float> %57, splat (float 7.500000e-01)
  %59 = fadd <8 x float> %58, splat (float 1.250000e-01)
  %60 = getelementptr inbounds nuw float, ptr %18, i64 %41
  store <8 x float> %59, ptr %60, align 4, !alias.scope !21, !noalias !30
  %index.next.1 = add nuw nsw i64 %index, 16
  %61 = icmp eq i64 %index.next.1, 160
  br i1 %61, label %middle.block, label %vector.body, !llvm.loop !31

middle.block:                                     ; preds = %vector.body
  %62 = add nuw nsw i64 %19, 1
  %exitcond2.not = icmp eq i64 %62, 320
  br i1 %exitcond2.not, label %broadcast_add_fusion_wrapped.exit, label %vector.ph, !llvm.loop !34

broadcast_add_fusion_wrapped.exit:                ; preds = %middle.block
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.maximum.v8f32(<8 x float>, <8 x float>) #2

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 0}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 640}
!5 = !{i64 204800}
!6 = !{!7}
!7 = distinct !{!7, !8, !"broadcast_add_fusion_wrapped: argument 0"}
!8 = distinct !{!8, !"broadcast_add_fusion_wrapped"}
!9 = !{!10}
!10 = distinct !{!10, !8, !"broadcast_add_fusion_wrapped: argument 1"}
!11 = !{!12}
!12 = distinct !{!12, !8, !"broadcast_add_fusion_wrapped: argument 2"}
!13 = !{!14}
!14 = distinct !{!14, !8, !"broadcast_add_fusion_wrapped: argument 3"}
!15 = !{!16}
!16 = distinct !{!16, !8, !"broadcast_add_fusion_wrapped: argument 4"}
!17 = !{!18}
!18 = distinct !{!18, !8, !"broadcast_add_fusion_wrapped: argument 5"}
!19 = !{!20}
!20 = distinct !{!20, !8, !"broadcast_add_fusion_wrapped: argument 6"}
!21 = !{!22}
!22 = distinct !{!22, !8, !"broadcast_add_fusion_wrapped: argument 7"}
!23 = !{!7, !10, !12, !14, !16, !20, !22}
!24 = !{!7, !10, !12, !14, !16, !18, !22}
!25 = !{!7, !10, !12, !14, !18, !20, !22}
!26 = !{!7, !10, !12, !16, !18, !20, !22}
!27 = !{!7, !10, !14, !16, !18, !20, !22}
!28 = !{!7, !12, !14, !16, !18, !20, !22}
!29 = !{!10, !12, !14, !16, !18, !20, !22}
!30 = !{!7, !10, !12, !14, !16, !18, !20}
!31 = distinct !{!31, !32, !33}
!32 = !{!"llvm.loop.isvectorized", i32 1}
!33 = !{!"llvm.loop.unroll.runtime.disable"}
!34 = distinct !{!34, !35}
!35 = !{!"llvm.loop.unroll.disable"}
