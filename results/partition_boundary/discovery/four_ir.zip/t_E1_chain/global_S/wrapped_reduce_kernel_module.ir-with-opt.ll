; ModuleID = '__compute_module_wrapped_reduce_kernel_module'
source_filename = "__compute_module_wrapped_reduce_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @wrapped_reduce(ptr readonly captures(none) %0) local_unnamed_addr #0 {
vector.ph:
  %1 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %2 = load ptr, ptr %1, align 8, !invariant.load !3
  %3 = load ptr, ptr %2, align 8, !invariant.load !3, !dereferenceable !4
  tail call void @llvm.experimental.noalias.scope.decl(metadata !5)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !8)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !10)
  %4 = getelementptr inbounds nuw i8, ptr %2, i64 16
  %5 = load ptr, ptr %4, align 8, !invariant.load !3, !dereferenceable !12
  %6 = load i32, ptr %5, align 4, !invariant.load !3, !alias.scope !8, !noalias !13
  %7 = insertelement <4 x i32> <i32 poison, i32 0, i32 0, i32 0>, i32 %6, i64 0
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %vector.ph
  %index = phi i64 [ 0, %vector.ph ], [ %index.next, %vector.body ]
  %vec.phi = phi <4 x i32> [ %7, %vector.ph ], [ %19, %vector.body ]
  %vec.ind = phi <4 x i64> [ <i64 0, i64 1, i64 2, i64 3>, %vector.ph ], [ %vec.ind.next, %vector.body ]
  %8 = icmp ult <4 x i64> %vec.ind, splat (i64 10)
  %9 = mul nuw nsw <4 x i64> %vec.ind, splat (i64 20)
  %10 = getelementptr i8, ptr %3, <4 x i64> %9
  %wide.masked.gather = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %10, <4 x i1> %8, <4 x i32> poison), !invariant.load !3, !alias.scope !5, !noalias !14
  %11 = add <4 x i32> %wide.masked.gather, %vec.phi
  %12 = getelementptr i8, <4 x ptr> %10, i64 4
  %wide.masked.gather2 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %12, <4 x i1> %8, <4 x i32> poison), !invariant.load !3, !alias.scope !5, !noalias !14
  %13 = add <4 x i32> %wide.masked.gather2, %11
  %14 = getelementptr i8, <4 x ptr> %10, i64 8
  %wide.masked.gather3 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %14, <4 x i1> %8, <4 x i32> poison), !invariant.load !3, !alias.scope !5, !noalias !14
  %15 = add <4 x i32> %wide.masked.gather3, %13
  %16 = getelementptr i8, <4 x ptr> %10, i64 12
  %wide.masked.gather4 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %16, <4 x i1> %8, <4 x i32> poison), !invariant.load !3, !alias.scope !5, !noalias !14
  %17 = add <4 x i32> %wide.masked.gather4, %15
  %18 = getelementptr i8, <4 x ptr> %10, i64 16
  %wide.masked.gather5 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %18, <4 x i1> %8, <4 x i32> poison), !invariant.load !3, !alias.scope !5, !noalias !14
  %19 = add <4 x i32> %wide.masked.gather5, %17
  %index.next = add nuw i64 %index, 4
  %vec.ind.next = add <4 x i64> %vec.ind, splat (i64 4)
  %20 = icmp eq i64 %index.next, 12
  br i1 %20, label %wrapped_reduce_wrapped.exit, label %vector.body, !llvm.loop !15

wrapped_reduce_wrapped.exit:                      ; preds = %vector.body
  %21 = select <4 x i1> %8, <4 x i32> %19, <4 x i32> %vec.phi
  %22 = tail call i32 @llvm.vector.reduce.add.v4i32(<4 x i32> %21)
  %23 = getelementptr inbounds nuw i8, ptr %2, i64 32
  %24 = load ptr, ptr %23, align 8, !invariant.load !3, !dereferenceable !12
  store i32 %22, ptr %24, align 4, !alias.scope !10, !noalias !19
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr>, <4 x i1>, <4 x i32>) #2

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.vector.reduce.add.v4i32(<4 x i32>) #3

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #3 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 3}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 200}
!5 = !{!6}
!6 = distinct !{!6, !7, !"wrapped_reduce_wrapped: argument 0"}
!7 = distinct !{!7, !"wrapped_reduce_wrapped"}
!8 = !{!9}
!9 = distinct !{!9, !7, !"wrapped_reduce_wrapped: argument 1"}
!10 = !{!11}
!11 = distinct !{!11, !7, !"wrapped_reduce_wrapped: argument 2"}
!12 = !{i64 4}
!13 = !{!6, !11}
!14 = !{!9, !11}
!15 = distinct !{!15, !16, !17, !18}
!16 = !{!"llvm.loop.unroll.disable"}
!17 = !{!"llvm.loop.isvectorized", i32 1}
!18 = !{!"llvm.loop.unroll.runtime.disable"}
!19 = !{!6, !9}
