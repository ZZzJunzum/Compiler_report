; ModuleID = '__compute_module_and_convert_fusion_kernel_module'
source_filename = "__compute_module_and_convert_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @and_convert_fusion(ptr readonly captures(none) %0) local_unnamed_addr #0 {
and_convert_fusion_wrapped.exit:
  %1 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %2 = load ptr, ptr %1, align 8, !invariant.load !3
  %3 = load ptr, ptr %2, align 8, !invariant.load !3, !dereferenceable !4
  %4 = getelementptr inbounds nuw i8, ptr %2, i64 16
  %5 = load ptr, ptr %4, align 8, !invariant.load !3, !dereferenceable !4
  tail call void @llvm.experimental.noalias.scope.decl(metadata !5)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !8)
  %6 = load i32, ptr %3, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %7 = and i32 %6, 1023
  store i32 %7, ptr %5, align 4, !alias.scope !8, !noalias !5
  %8 = getelementptr inbounds nuw i8, ptr %3, i64 4
  %9 = load i32, ptr %8, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %10 = and i32 %9, 1023
  %11 = getelementptr inbounds nuw i8, ptr %5, i64 4
  store i32 %10, ptr %11, align 4, !alias.scope !8, !noalias !5
  %12 = getelementptr inbounds nuw i8, ptr %3, i64 8
  %13 = load i32, ptr %12, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %14 = and i32 %13, 1023
  %15 = getelementptr inbounds nuw i8, ptr %5, i64 8
  store i32 %14, ptr %15, align 4, !alias.scope !8, !noalias !5
  %16 = getelementptr inbounds nuw i8, ptr %3, i64 12
  %17 = load i32, ptr %16, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %18 = and i32 %17, 1023
  %19 = getelementptr inbounds nuw i8, ptr %5, i64 12
  store i32 %18, ptr %19, align 4, !alias.scope !8, !noalias !5
  %20 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %21 = load i32, ptr %20, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %22 = and i32 %21, 1023
  %23 = getelementptr inbounds nuw i8, ptr %5, i64 16
  store i32 %22, ptr %23, align 4, !alias.scope !8, !noalias !5
  %24 = getelementptr inbounds nuw i8, ptr %3, i64 20
  %25 = load i32, ptr %24, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %26 = and i32 %25, 1023
  %27 = getelementptr inbounds nuw i8, ptr %5, i64 20
  store i32 %26, ptr %27, align 4, !alias.scope !8, !noalias !5
  %28 = getelementptr inbounds nuw i8, ptr %3, i64 24
  %29 = load i32, ptr %28, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %30 = and i32 %29, 1023
  %31 = getelementptr inbounds nuw i8, ptr %5, i64 24
  store i32 %30, ptr %31, align 4, !alias.scope !8, !noalias !5
  %32 = getelementptr inbounds nuw i8, ptr %3, i64 28
  %33 = load i32, ptr %32, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %34 = and i32 %33, 1023
  %35 = getelementptr inbounds nuw i8, ptr %5, i64 28
  store i32 %34, ptr %35, align 4, !alias.scope !8, !noalias !5
  %36 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %37 = load i32, ptr %36, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %38 = and i32 %37, 1023
  %39 = getelementptr inbounds nuw i8, ptr %5, i64 32
  store i32 %38, ptr %39, align 4, !alias.scope !8, !noalias !5
  %40 = getelementptr inbounds nuw i8, ptr %3, i64 36
  %41 = load i32, ptr %40, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %42 = and i32 %41, 1023
  %43 = getelementptr inbounds nuw i8, ptr %5, i64 36
  store i32 %42, ptr %43, align 4, !alias.scope !8, !noalias !5
  %44 = getelementptr inbounds nuw i8, ptr %3, i64 40
  %45 = load i32, ptr %44, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %46 = and i32 %45, 1023
  %47 = getelementptr inbounds nuw i8, ptr %5, i64 40
  store i32 %46, ptr %47, align 4, !alias.scope !8, !noalias !5
  %48 = getelementptr inbounds nuw i8, ptr %3, i64 44
  %49 = load i32, ptr %48, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %50 = and i32 %49, 1023
  %51 = getelementptr inbounds nuw i8, ptr %5, i64 44
  store i32 %50, ptr %51, align 4, !alias.scope !8, !noalias !5
  %52 = getelementptr inbounds nuw i8, ptr %3, i64 48
  %53 = load i32, ptr %52, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %54 = and i32 %53, 1023
  %55 = getelementptr inbounds nuw i8, ptr %5, i64 48
  store i32 %54, ptr %55, align 4, !alias.scope !8, !noalias !5
  %56 = getelementptr inbounds nuw i8, ptr %3, i64 52
  %57 = load i32, ptr %56, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %58 = and i32 %57, 1023
  %59 = getelementptr inbounds nuw i8, ptr %5, i64 52
  store i32 %58, ptr %59, align 4, !alias.scope !8, !noalias !5
  %60 = getelementptr inbounds nuw i8, ptr %3, i64 56
  %61 = load i32, ptr %60, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %62 = and i32 %61, 1023
  %63 = getelementptr inbounds nuw i8, ptr %5, i64 56
  store i32 %62, ptr %63, align 4, !alias.scope !8, !noalias !5
  %64 = getelementptr inbounds nuw i8, ptr %3, i64 60
  %65 = load i32, ptr %64, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %66 = and i32 %65, 1023
  %67 = getelementptr inbounds nuw i8, ptr %5, i64 60
  store i32 %66, ptr %67, align 4, !alias.scope !8, !noalias !5
  %68 = getelementptr inbounds nuw i8, ptr %3, i64 64
  %69 = load i32, ptr %68, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %70 = and i32 %69, 1023
  %71 = getelementptr inbounds nuw i8, ptr %5, i64 64
  store i32 %70, ptr %71, align 4, !alias.scope !8, !noalias !5
  %72 = getelementptr inbounds nuw i8, ptr %3, i64 68
  %73 = load i32, ptr %72, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %74 = and i32 %73, 1023
  %75 = getelementptr inbounds nuw i8, ptr %5, i64 68
  store i32 %74, ptr %75, align 4, !alias.scope !8, !noalias !5
  %76 = getelementptr inbounds nuw i8, ptr %3, i64 72
  %77 = load i32, ptr %76, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %78 = and i32 %77, 1023
  %79 = getelementptr inbounds nuw i8, ptr %5, i64 72
  store i32 %78, ptr %79, align 4, !alias.scope !8, !noalias !5
  %80 = getelementptr inbounds nuw i8, ptr %3, i64 76
  %81 = load i32, ptr %80, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %82 = and i32 %81, 1023
  %83 = getelementptr inbounds nuw i8, ptr %5, i64 76
  store i32 %82, ptr %83, align 4, !alias.scope !8, !noalias !5
  %84 = getelementptr inbounds nuw i8, ptr %3, i64 80
  %85 = load i32, ptr %84, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %86 = and i32 %85, 1023
  %87 = getelementptr inbounds nuw i8, ptr %5, i64 80
  store i32 %86, ptr %87, align 4, !alias.scope !8, !noalias !5
  %88 = getelementptr inbounds nuw i8, ptr %3, i64 84
  %89 = load i32, ptr %88, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %90 = and i32 %89, 1023
  %91 = getelementptr inbounds nuw i8, ptr %5, i64 84
  store i32 %90, ptr %91, align 4, !alias.scope !8, !noalias !5
  %92 = getelementptr inbounds nuw i8, ptr %3, i64 88
  %93 = load i32, ptr %92, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %94 = and i32 %93, 1023
  %95 = getelementptr inbounds nuw i8, ptr %5, i64 88
  store i32 %94, ptr %95, align 4, !alias.scope !8, !noalias !5
  %96 = getelementptr inbounds nuw i8, ptr %3, i64 92
  %97 = load i32, ptr %96, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %98 = and i32 %97, 1023
  %99 = getelementptr inbounds nuw i8, ptr %5, i64 92
  store i32 %98, ptr %99, align 4, !alias.scope !8, !noalias !5
  %100 = getelementptr inbounds nuw i8, ptr %3, i64 96
  %101 = load i32, ptr %100, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %102 = and i32 %101, 1023
  %103 = getelementptr inbounds nuw i8, ptr %5, i64 96
  store i32 %102, ptr %103, align 4, !alias.scope !8, !noalias !5
  %104 = getelementptr inbounds nuw i8, ptr %3, i64 100
  %105 = load i32, ptr %104, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %106 = and i32 %105, 1023
  %107 = getelementptr inbounds nuw i8, ptr %5, i64 100
  store i32 %106, ptr %107, align 4, !alias.scope !8, !noalias !5
  %108 = getelementptr inbounds nuw i8, ptr %3, i64 104
  %109 = load i32, ptr %108, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %110 = and i32 %109, 1023
  %111 = getelementptr inbounds nuw i8, ptr %5, i64 104
  store i32 %110, ptr %111, align 4, !alias.scope !8, !noalias !5
  %112 = getelementptr inbounds nuw i8, ptr %3, i64 108
  %113 = load i32, ptr %112, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %114 = and i32 %113, 1023
  %115 = getelementptr inbounds nuw i8, ptr %5, i64 108
  store i32 %114, ptr %115, align 4, !alias.scope !8, !noalias !5
  %116 = getelementptr inbounds nuw i8, ptr %3, i64 112
  %117 = load i32, ptr %116, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %118 = and i32 %117, 1023
  %119 = getelementptr inbounds nuw i8, ptr %5, i64 112
  store i32 %118, ptr %119, align 4, !alias.scope !8, !noalias !5
  %120 = getelementptr inbounds nuw i8, ptr %3, i64 116
  %121 = load i32, ptr %120, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %122 = and i32 %121, 1023
  %123 = getelementptr inbounds nuw i8, ptr %5, i64 116
  store i32 %122, ptr %123, align 4, !alias.scope !8, !noalias !5
  %124 = getelementptr inbounds nuw i8, ptr %3, i64 120
  %125 = load i32, ptr %124, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %126 = and i32 %125, 1023
  %127 = getelementptr inbounds nuw i8, ptr %5, i64 120
  store i32 %126, ptr %127, align 4, !alias.scope !8, !noalias !5
  %128 = getelementptr inbounds nuw i8, ptr %3, i64 124
  %129 = load i32, ptr %128, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %130 = and i32 %129, 1023
  %131 = getelementptr inbounds nuw i8, ptr %5, i64 124
  store i32 %130, ptr %131, align 4, !alias.scope !8, !noalias !5
  %132 = getelementptr inbounds nuw i8, ptr %3, i64 128
  %133 = load i32, ptr %132, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %134 = and i32 %133, 1023
  %135 = getelementptr inbounds nuw i8, ptr %5, i64 128
  store i32 %134, ptr %135, align 4, !alias.scope !8, !noalias !5
  %136 = getelementptr inbounds nuw i8, ptr %3, i64 132
  %137 = load i32, ptr %136, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %138 = and i32 %137, 1023
  %139 = getelementptr inbounds nuw i8, ptr %5, i64 132
  store i32 %138, ptr %139, align 4, !alias.scope !8, !noalias !5
  %140 = getelementptr inbounds nuw i8, ptr %3, i64 136
  %141 = load i32, ptr %140, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %142 = and i32 %141, 1023
  %143 = getelementptr inbounds nuw i8, ptr %5, i64 136
  store i32 %142, ptr %143, align 4, !alias.scope !8, !noalias !5
  %144 = getelementptr inbounds nuw i8, ptr %3, i64 140
  %145 = load i32, ptr %144, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %146 = and i32 %145, 1023
  %147 = getelementptr inbounds nuw i8, ptr %5, i64 140
  store i32 %146, ptr %147, align 4, !alias.scope !8, !noalias !5
  %148 = getelementptr inbounds nuw i8, ptr %3, i64 144
  %149 = load i32, ptr %148, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %150 = and i32 %149, 1023
  %151 = getelementptr inbounds nuw i8, ptr %5, i64 144
  store i32 %150, ptr %151, align 4, !alias.scope !8, !noalias !5
  %152 = getelementptr inbounds nuw i8, ptr %3, i64 148
  %153 = load i32, ptr %152, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %154 = and i32 %153, 1023
  %155 = getelementptr inbounds nuw i8, ptr %5, i64 148
  store i32 %154, ptr %155, align 4, !alias.scope !8, !noalias !5
  %156 = getelementptr inbounds nuw i8, ptr %3, i64 152
  %157 = load i32, ptr %156, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %158 = and i32 %157, 1023
  %159 = getelementptr inbounds nuw i8, ptr %5, i64 152
  store i32 %158, ptr %159, align 4, !alias.scope !8, !noalias !5
  %160 = getelementptr inbounds nuw i8, ptr %3, i64 156
  %161 = load i32, ptr %160, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %162 = and i32 %161, 1023
  %163 = getelementptr inbounds nuw i8, ptr %5, i64 156
  store i32 %162, ptr %163, align 4, !alias.scope !8, !noalias !5
  %164 = getelementptr inbounds nuw i8, ptr %3, i64 160
  %165 = load i32, ptr %164, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %166 = and i32 %165, 1023
  %167 = getelementptr inbounds nuw i8, ptr %5, i64 160
  store i32 %166, ptr %167, align 4, !alias.scope !8, !noalias !5
  %168 = getelementptr inbounds nuw i8, ptr %3, i64 164
  %169 = load i32, ptr %168, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %170 = and i32 %169, 1023
  %171 = getelementptr inbounds nuw i8, ptr %5, i64 164
  store i32 %170, ptr %171, align 4, !alias.scope !8, !noalias !5
  %172 = getelementptr inbounds nuw i8, ptr %3, i64 168
  %173 = load i32, ptr %172, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %174 = and i32 %173, 1023
  %175 = getelementptr inbounds nuw i8, ptr %5, i64 168
  store i32 %174, ptr %175, align 4, !alias.scope !8, !noalias !5
  %176 = getelementptr inbounds nuw i8, ptr %3, i64 172
  %177 = load i32, ptr %176, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %178 = and i32 %177, 1023
  %179 = getelementptr inbounds nuw i8, ptr %5, i64 172
  store i32 %178, ptr %179, align 4, !alias.scope !8, !noalias !5
  %180 = getelementptr inbounds nuw i8, ptr %3, i64 176
  %181 = load i32, ptr %180, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %182 = and i32 %181, 1023
  %183 = getelementptr inbounds nuw i8, ptr %5, i64 176
  store i32 %182, ptr %183, align 4, !alias.scope !8, !noalias !5
  %184 = getelementptr inbounds nuw i8, ptr %3, i64 180
  %185 = load i32, ptr %184, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %186 = and i32 %185, 1023
  %187 = getelementptr inbounds nuw i8, ptr %5, i64 180
  store i32 %186, ptr %187, align 4, !alias.scope !8, !noalias !5
  %188 = getelementptr inbounds nuw i8, ptr %3, i64 184
  %189 = load i32, ptr %188, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %190 = and i32 %189, 1023
  %191 = getelementptr inbounds nuw i8, ptr %5, i64 184
  store i32 %190, ptr %191, align 4, !alias.scope !8, !noalias !5
  %192 = getelementptr inbounds nuw i8, ptr %3, i64 188
  %193 = load i32, ptr %192, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %194 = and i32 %193, 1023
  %195 = getelementptr inbounds nuw i8, ptr %5, i64 188
  store i32 %194, ptr %195, align 4, !alias.scope !8, !noalias !5
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

attributes #0 = { mustprogress nofree norecurse nosync nounwind willreturn memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 0}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 192}
!5 = !{!6}
!6 = distinct !{!6, !7, !"and_convert_fusion_wrapped: argument 0"}
!7 = distinct !{!7, !"and_convert_fusion_wrapped"}
!8 = !{!9}
!9 = distinct !{!9, !7, !"and_convert_fusion_wrapped: argument 1"}
