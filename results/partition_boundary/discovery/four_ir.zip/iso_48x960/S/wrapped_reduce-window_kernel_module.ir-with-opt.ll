; ModuleID = '__compute_module_wrapped_reduce-window_kernel_module'
source_filename = "__compute_module_wrapped_reduce-window_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @wrapped_reduce-window(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !5
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !6
  tail call void @llvm.experimental.noalias.scope.decl(metadata !7)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !10)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !12)
  %9 = load i32, ptr %6, align 4, !invariant.load !3, !alias.scope !10, !noalias !14
  %broadcast.splatinsert = insertelement <8 x i32> poison, i32 %9, i64 0
  %broadcast.splat = shufflevector <8 x i32> %broadcast.splatinsert, <8 x i32> poison, <8 x i32> zeroinitializer
  br label %.preheader3

.preheader3:                                      ; preds = %1, %179
  %10 = phi i64 [ 0, %1 ], [ %180, %179 ]
  %.idx1 = mul nuw nsw i64 %10, 3840
  %11 = getelementptr i8, ptr %4, i64 %.idx1
  %.idx = mul nuw nsw i64 %10, 120
  %12 = getelementptr i8, ptr %8, i64 %.idx
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %.preheader3
  %index = phi i64 [ 0, %.preheader3 ], [ %index.next, %vector.body ]
  %vec.ind = phi <8 x i64> [ <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>, %.preheader3 ], [ %vec.ind.next, %vector.body ]
  %13 = shl <8 x i64> %vec.ind, splat (i64 7)
  %14 = getelementptr i8, ptr %11, <8 x i64> %13
  %wide.masked.gather = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %14, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %15 = add <8 x i32> %wide.masked.gather, %broadcast.splat
  %16 = getelementptr i8, <8 x ptr> %14, i64 4
  %wide.masked.gather5 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %16, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %17 = add <8 x i32> %wide.masked.gather5, %15
  %18 = getelementptr i8, <8 x ptr> %14, i64 8
  %wide.masked.gather6 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %18, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %19 = add <8 x i32> %wide.masked.gather6, %17
  %20 = getelementptr i8, <8 x ptr> %14, i64 12
  %wide.masked.gather7 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %20, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %21 = add <8 x i32> %wide.masked.gather7, %19
  %22 = getelementptr i8, <8 x ptr> %14, i64 16
  %wide.masked.gather8 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %22, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %23 = add <8 x i32> %wide.masked.gather8, %21
  %24 = getelementptr i8, <8 x ptr> %14, i64 20
  %wide.masked.gather9 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %24, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %25 = add <8 x i32> %wide.masked.gather9, %23
  %26 = getelementptr i8, <8 x ptr> %14, i64 24
  %wide.masked.gather10 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %26, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %27 = add <8 x i32> %wide.masked.gather10, %25
  %28 = getelementptr i8, <8 x ptr> %14, i64 28
  %wide.masked.gather11 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %28, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %29 = add <8 x i32> %wide.masked.gather11, %27
  %30 = getelementptr i8, <8 x ptr> %14, i64 32
  %wide.masked.gather12 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %30, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %31 = add <8 x i32> %wide.masked.gather12, %29
  %32 = getelementptr i8, <8 x ptr> %14, i64 36
  %wide.masked.gather13 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %32, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %33 = add <8 x i32> %wide.masked.gather13, %31
  %34 = getelementptr i8, <8 x ptr> %14, i64 40
  %wide.masked.gather14 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %34, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %35 = add <8 x i32> %wide.masked.gather14, %33
  %36 = getelementptr i8, <8 x ptr> %14, i64 44
  %wide.masked.gather15 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %36, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %37 = add <8 x i32> %wide.masked.gather15, %35
  %38 = getelementptr i8, <8 x ptr> %14, i64 48
  %wide.masked.gather16 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %38, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %39 = add <8 x i32> %wide.masked.gather16, %37
  %40 = getelementptr i8, <8 x ptr> %14, i64 52
  %wide.masked.gather17 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %40, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %41 = add <8 x i32> %wide.masked.gather17, %39
  %42 = getelementptr i8, <8 x ptr> %14, i64 56
  %wide.masked.gather18 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %42, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %43 = add <8 x i32> %wide.masked.gather18, %41
  %44 = getelementptr i8, <8 x ptr> %14, i64 60
  %wide.masked.gather19 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %44, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %45 = add <8 x i32> %wide.masked.gather19, %43
  %46 = getelementptr i8, <8 x ptr> %14, i64 64
  %wide.masked.gather20 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %46, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %47 = add <8 x i32> %wide.masked.gather20, %45
  %48 = getelementptr i8, <8 x ptr> %14, i64 68
  %wide.masked.gather21 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %48, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %49 = add <8 x i32> %wide.masked.gather21, %47
  %50 = getelementptr i8, <8 x ptr> %14, i64 72
  %wide.masked.gather22 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %50, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %51 = add <8 x i32> %wide.masked.gather22, %49
  %52 = getelementptr i8, <8 x ptr> %14, i64 76
  %wide.masked.gather23 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %52, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %53 = add <8 x i32> %wide.masked.gather23, %51
  %54 = getelementptr i8, <8 x ptr> %14, i64 80
  %wide.masked.gather24 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %54, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %55 = add <8 x i32> %wide.masked.gather24, %53
  %56 = getelementptr i8, <8 x ptr> %14, i64 84
  %wide.masked.gather25 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %56, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %57 = add <8 x i32> %wide.masked.gather25, %55
  %58 = getelementptr i8, <8 x ptr> %14, i64 88
  %wide.masked.gather26 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %58, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %59 = add <8 x i32> %wide.masked.gather26, %57
  %60 = getelementptr i8, <8 x ptr> %14, i64 92
  %wide.masked.gather27 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %60, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %61 = add <8 x i32> %wide.masked.gather27, %59
  %62 = getelementptr i8, <8 x ptr> %14, i64 96
  %wide.masked.gather28 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %62, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %63 = add <8 x i32> %wide.masked.gather28, %61
  %64 = getelementptr i8, <8 x ptr> %14, i64 100
  %wide.masked.gather29 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %64, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %65 = add <8 x i32> %wide.masked.gather29, %63
  %66 = getelementptr i8, <8 x ptr> %14, i64 104
  %wide.masked.gather30 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %66, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %67 = add <8 x i32> %wide.masked.gather30, %65
  %68 = getelementptr i8, <8 x ptr> %14, i64 108
  %wide.masked.gather31 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %68, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %69 = add <8 x i32> %wide.masked.gather31, %67
  %70 = getelementptr i8, <8 x ptr> %14, i64 112
  %wide.masked.gather32 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %70, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %71 = add <8 x i32> %wide.masked.gather32, %69
  %72 = getelementptr i8, <8 x ptr> %14, i64 116
  %wide.masked.gather33 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %72, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %73 = add <8 x i32> %wide.masked.gather33, %71
  %74 = getelementptr i8, <8 x ptr> %14, i64 120
  %wide.masked.gather34 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %74, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %75 = add <8 x i32> %wide.masked.gather34, %73
  %76 = getelementptr i8, <8 x ptr> %14, i64 124
  %wide.masked.gather35 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %76, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %77 = add <8 x i32> %wide.masked.gather35, %75
  %78 = getelementptr i32, ptr %12, i64 %index
  store <8 x i32> %77, ptr %78, align 4, !alias.scope !12, !noalias !16
  %index.next = add nuw i64 %index, 8
  %vec.ind.next = add nuw nsw <8 x i64> %vec.ind, splat (i64 8)
  %79 = icmp eq i64 %index.next, 24
  br i1 %79, label %.preheader, label %vector.body, !llvm.loop !17

.preheader:                                       ; preds = %vector.body, %.preheader
  %80 = phi i64 [ %178, %.preheader ], [ 24, %vector.body ]
  %.idx2 = shl i64 %80, 7
  %81 = getelementptr i8, ptr %11, i64 %.idx2
  %82 = load i32, ptr %81, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %83 = add i32 %82, %9
  %84 = getelementptr i8, ptr %81, i64 4
  %85 = load i32, ptr %84, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %86 = add i32 %85, %83
  %87 = getelementptr i8, ptr %81, i64 8
  %88 = load i32, ptr %87, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %89 = add i32 %88, %86
  %90 = getelementptr i8, ptr %81, i64 12
  %91 = load i32, ptr %90, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %92 = add i32 %91, %89
  %93 = getelementptr i8, ptr %81, i64 16
  %94 = load i32, ptr %93, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %95 = add i32 %94, %92
  %96 = getelementptr i8, ptr %81, i64 20
  %97 = load i32, ptr %96, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %98 = add i32 %97, %95
  %99 = getelementptr i8, ptr %81, i64 24
  %100 = load i32, ptr %99, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %101 = add i32 %100, %98
  %102 = getelementptr i8, ptr %81, i64 28
  %103 = load i32, ptr %102, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %104 = add i32 %103, %101
  %105 = getelementptr i8, ptr %81, i64 32
  %106 = load i32, ptr %105, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %107 = add i32 %106, %104
  %108 = getelementptr i8, ptr %81, i64 36
  %109 = load i32, ptr %108, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %110 = add i32 %109, %107
  %111 = getelementptr i8, ptr %81, i64 40
  %112 = load i32, ptr %111, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %113 = add i32 %112, %110
  %114 = getelementptr i8, ptr %81, i64 44
  %115 = load i32, ptr %114, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %116 = add i32 %115, %113
  %117 = getelementptr i8, ptr %81, i64 48
  %118 = load i32, ptr %117, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %119 = add i32 %118, %116
  %120 = getelementptr i8, ptr %81, i64 52
  %121 = load i32, ptr %120, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %122 = add i32 %121, %119
  %123 = getelementptr i8, ptr %81, i64 56
  %124 = load i32, ptr %123, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %125 = add i32 %124, %122
  %126 = getelementptr i8, ptr %81, i64 60
  %127 = load i32, ptr %126, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %128 = add i32 %127, %125
  %129 = getelementptr i8, ptr %81, i64 64
  %130 = load i32, ptr %129, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %131 = add i32 %130, %128
  %132 = getelementptr i8, ptr %81, i64 68
  %133 = load i32, ptr %132, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %134 = add i32 %133, %131
  %135 = getelementptr i8, ptr %81, i64 72
  %136 = load i32, ptr %135, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %137 = add i32 %136, %134
  %138 = getelementptr i8, ptr %81, i64 76
  %139 = load i32, ptr %138, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %140 = add i32 %139, %137
  %141 = getelementptr i8, ptr %81, i64 80
  %142 = load i32, ptr %141, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %143 = add i32 %142, %140
  %144 = getelementptr i8, ptr %81, i64 84
  %145 = load i32, ptr %144, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %146 = add i32 %145, %143
  %147 = getelementptr i8, ptr %81, i64 88
  %148 = load i32, ptr %147, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %149 = add i32 %148, %146
  %150 = getelementptr i8, ptr %81, i64 92
  %151 = load i32, ptr %150, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %152 = add i32 %151, %149
  %153 = getelementptr i8, ptr %81, i64 96
  %154 = load i32, ptr %153, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %155 = add i32 %154, %152
  %156 = getelementptr i8, ptr %81, i64 100
  %157 = load i32, ptr %156, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %158 = add i32 %157, %155
  %159 = getelementptr i8, ptr %81, i64 104
  %160 = load i32, ptr %159, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %161 = add i32 %160, %158
  %162 = getelementptr i8, ptr %81, i64 108
  %163 = load i32, ptr %162, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %164 = add i32 %163, %161
  %165 = getelementptr i8, ptr %81, i64 112
  %166 = load i32, ptr %165, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %167 = add i32 %166, %164
  %168 = getelementptr i8, ptr %81, i64 116
  %169 = load i32, ptr %168, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %170 = add i32 %169, %167
  %171 = getelementptr i8, ptr %81, i64 120
  %172 = load i32, ptr %171, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %173 = add i32 %172, %170
  %174 = getelementptr i8, ptr %81, i64 124
  %175 = load i32, ptr %174, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %176 = add i32 %175, %173
  %177 = getelementptr i32, ptr %12, i64 %80
  store i32 %176, ptr %177, align 4, !alias.scope !12, !noalias !16
  %178 = add nuw nsw i64 %80, 1
  %exitcond.not = icmp eq i64 %178, 30
  br i1 %exitcond.not, label %179, label %.preheader, !llvm.loop !21

179:                                              ; preds = %.preheader
  %180 = add nuw nsw i64 %10, 1
  %exitcond4.not = icmp eq i64 %180, 48
  br i1 %exitcond4.not, label %wrapped_reduce-window_wrapped.exit, label %.preheader3, !llvm.loop !22

wrapped_reduce-window_wrapped.exit:               ; preds = %179
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr>, <8 x i1>, <8 x i32>) #2

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(read) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 3}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 184320}
!5 = !{i64 4}
!6 = !{i64 5760}
!7 = !{!8}
!8 = distinct !{!8, !9, !"wrapped_reduce-window_wrapped: argument 0"}
!9 = distinct !{!9, !"wrapped_reduce-window_wrapped"}
!10 = !{!11}
!11 = distinct !{!11, !9, !"wrapped_reduce-window_wrapped: argument 1"}
!12 = !{!13}
!13 = distinct !{!13, !9, !"wrapped_reduce-window_wrapped: argument 2"}
!14 = !{!8, !13}
!15 = !{!11, !13}
!16 = !{!8, !11}
!17 = distinct !{!17, !18, !19, !20}
!18 = !{!"llvm.loop.unroll.disable"}
!19 = !{!"llvm.loop.isvectorized", i32 1}
!20 = !{!"llvm.loop.unroll.runtime.disable"}
!21 = distinct !{!21, !18, !19}
!22 = distinct !{!22, !18}
