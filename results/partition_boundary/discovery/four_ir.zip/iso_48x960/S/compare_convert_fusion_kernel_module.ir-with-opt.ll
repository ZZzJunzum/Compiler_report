; ModuleID = '__compute_module_compare_convert_fusion_kernel_module'
source_filename = "__compute_module_compare_convert_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @compare_convert_fusion(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !4
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !4
  %9 = getelementptr inbounds nuw i8, ptr %3, i64 48
  %10 = load ptr, ptr %9, align 8, !invariant.load !3, !dereferenceable !5
  %11 = getelementptr inbounds nuw i8, ptr %3, i64 64
  %12 = load ptr, ptr %11, align 8, !invariant.load !3, !dereferenceable !4
  %13 = getelementptr inbounds nuw i8, ptr %3, i64 80
  %14 = load ptr, ptr %13, align 8, !invariant.load !3, !dereferenceable !5
  tail call void @llvm.experimental.noalias.scope.decl(metadata !6)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !11)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !13)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !15)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !17)
  br label %vector.ph

vector.ph:                                        ; preds = %1, %middle.block
  %15 = phi i64 [ 0, %1 ], [ %72, %middle.block ]
  %16 = mul nuw nsw i64 %15, 960
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %vector.ph
  %index = phi i64 [ 0, %vector.ph ], [ %index.next.1, %vector.body ]
  %17 = add nuw nsw i64 %index, %16
  %18 = getelementptr inbounds nuw float, ptr %10, i64 %17
  %19 = getelementptr inbounds nuw i8, ptr %18, i64 32
  %wide.load = load <8 x float>, ptr %18, align 4, !invariant.load !3, !alias.scope !13, !noalias !19
  %wide.load3 = load <8 x float>, ptr %19, align 4, !invariant.load !3, !alias.scope !13, !noalias !19
  %20 = getelementptr inbounds nuw float, ptr %12, i64 %index
  %21 = getelementptr inbounds nuw i8, ptr %20, i64 32
  %wide.load4 = load <8 x float>, ptr %20, align 4, !invariant.load !3, !alias.scope !15, !noalias !20
  %wide.load5 = load <8 x float>, ptr %21, align 4, !invariant.load !3, !alias.scope !15, !noalias !20
  %22 = fmul <8 x float> %wide.load, %wide.load4
  %23 = fmul <8 x float> %wide.load3, %wide.load5
  %24 = getelementptr inbounds nuw float, ptr %8, i64 %index
  %25 = getelementptr inbounds nuw i8, ptr %24, i64 32
  %wide.load6 = load <8 x float>, ptr %24, align 4, !invariant.load !3, !alias.scope !11, !noalias !21
  %wide.load7 = load <8 x float>, ptr %25, align 4, !invariant.load !3, !alias.scope !11, !noalias !21
  %26 = fadd <8 x float> %22, %wide.load6
  %27 = fadd <8 x float> %23, %wide.load7
  %28 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %26, <8 x float> zeroinitializer)
  %29 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %27, <8 x float> zeroinitializer)
  %30 = getelementptr inbounds nuw float, ptr %6, i64 %index
  %31 = getelementptr inbounds nuw i8, ptr %30, i64 32
  %wide.load8 = load <8 x float>, ptr %30, align 4, !invariant.load !3, !alias.scope !9, !noalias !22
  %wide.load9 = load <8 x float>, ptr %31, align 4, !invariant.load !3, !alias.scope !9, !noalias !22
  %32 = fmul <8 x float> %wide.load8, %28
  %33 = fmul <8 x float> %wide.load9, %29
  %34 = getelementptr inbounds nuw float, ptr %4, i64 %index
  %35 = getelementptr inbounds nuw i8, ptr %34, i64 32
  %wide.load10 = load <8 x float>, ptr %34, align 4, !invariant.load !3, !alias.scope !6, !noalias !23
  %wide.load11 = load <8 x float>, ptr %35, align 4, !invariant.load !3, !alias.scope !6, !noalias !23
  %36 = fadd <8 x float> %wide.load10, %32
  %37 = fadd <8 x float> %wide.load11, %33
  %38 = fcmp ogt <8 x float> %36, zeroinitializer
  %39 = fcmp ogt <8 x float> %37, zeroinitializer
  %40 = zext <8 x i1> %38 to <8 x i32>
  %41 = zext <8 x i1> %39 to <8 x i32>
  %42 = getelementptr inbounds nuw i32, ptr %14, i64 %17
  %43 = getelementptr inbounds nuw i8, ptr %42, i64 32
  store <8 x i32> %40, ptr %42, align 4, !alias.scope !17, !noalias !24
  store <8 x i32> %41, ptr %43, align 4, !alias.scope !17, !noalias !24
  %index.next = or disjoint i64 %index, 16
  %44 = add nuw nsw i64 %index.next, %16
  %45 = getelementptr inbounds nuw float, ptr %10, i64 %44
  %46 = getelementptr inbounds nuw i8, ptr %45, i64 32
  %wide.load.1 = load <8 x float>, ptr %45, align 4, !invariant.load !3, !alias.scope !13, !noalias !19
  %wide.load3.1 = load <8 x float>, ptr %46, align 4, !invariant.load !3, !alias.scope !13, !noalias !19
  %47 = getelementptr inbounds nuw float, ptr %12, i64 %index.next
  %48 = getelementptr inbounds nuw i8, ptr %47, i64 32
  %wide.load4.1 = load <8 x float>, ptr %47, align 4, !invariant.load !3, !alias.scope !15, !noalias !20
  %wide.load5.1 = load <8 x float>, ptr %48, align 4, !invariant.load !3, !alias.scope !15, !noalias !20
  %49 = fmul <8 x float> %wide.load.1, %wide.load4.1
  %50 = fmul <8 x float> %wide.load3.1, %wide.load5.1
  %51 = getelementptr inbounds nuw float, ptr %8, i64 %index.next
  %52 = getelementptr inbounds nuw i8, ptr %51, i64 32
  %wide.load6.1 = load <8 x float>, ptr %51, align 4, !invariant.load !3, !alias.scope !11, !noalias !21
  %wide.load7.1 = load <8 x float>, ptr %52, align 4, !invariant.load !3, !alias.scope !11, !noalias !21
  %53 = fadd <8 x float> %49, %wide.load6.1
  %54 = fadd <8 x float> %50, %wide.load7.1
  %55 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %53, <8 x float> zeroinitializer)
  %56 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %54, <8 x float> zeroinitializer)
  %57 = getelementptr inbounds nuw float, ptr %6, i64 %index.next
  %58 = getelementptr inbounds nuw i8, ptr %57, i64 32
  %wide.load8.1 = load <8 x float>, ptr %57, align 4, !invariant.load !3, !alias.scope !9, !noalias !22
  %wide.load9.1 = load <8 x float>, ptr %58, align 4, !invariant.load !3, !alias.scope !9, !noalias !22
  %59 = fmul <8 x float> %wide.load8.1, %55
  %60 = fmul <8 x float> %wide.load9.1, %56
  %61 = getelementptr inbounds nuw float, ptr %4, i64 %index.next
  %62 = getelementptr inbounds nuw i8, ptr %61, i64 32
  %wide.load10.1 = load <8 x float>, ptr %61, align 4, !invariant.load !3, !alias.scope !6, !noalias !23
  %wide.load11.1 = load <8 x float>, ptr %62, align 4, !invariant.load !3, !alias.scope !6, !noalias !23
  %63 = fadd <8 x float> %wide.load10.1, %59
  %64 = fadd <8 x float> %wide.load11.1, %60
  %65 = fcmp ogt <8 x float> %63, zeroinitializer
  %66 = fcmp ogt <8 x float> %64, zeroinitializer
  %67 = zext <8 x i1> %65 to <8 x i32>
  %68 = zext <8 x i1> %66 to <8 x i32>
  %69 = getelementptr inbounds nuw i32, ptr %14, i64 %44
  %70 = getelementptr inbounds nuw i8, ptr %69, i64 32
  store <8 x i32> %67, ptr %69, align 4, !alias.scope !17, !noalias !24
  store <8 x i32> %68, ptr %70, align 4, !alias.scope !17, !noalias !24
  %index.next.1 = add nuw nsw i64 %index, 32
  %71 = icmp eq i64 %index.next.1, 960
  br i1 %71, label %middle.block, label %vector.body, !llvm.loop !25

middle.block:                                     ; preds = %vector.body
  %72 = add nuw nsw i64 %15, 1
  %exitcond2.not = icmp eq i64 %72, 48
  br i1 %exitcond2.not, label %compare_convert_fusion_wrapped.exit, label %vector.ph, !llvm.loop !28

compare_convert_fusion_wrapped.exit:              ; preds = %middle.block
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.maximum.v8f32(<8 x float>, <8 x float>) #2

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 0}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 3840}
!5 = !{i64 184320}
!6 = !{!7}
!7 = distinct !{!7, !8, !"compare_convert_fusion_wrapped: argument 0"}
!8 = distinct !{!8, !"compare_convert_fusion_wrapped"}
!9 = !{!10}
!10 = distinct !{!10, !8, !"compare_convert_fusion_wrapped: argument 1"}
!11 = !{!12}
!12 = distinct !{!12, !8, !"compare_convert_fusion_wrapped: argument 2"}
!13 = !{!14}
!14 = distinct !{!14, !8, !"compare_convert_fusion_wrapped: argument 3"}
!15 = !{!16}
!16 = distinct !{!16, !8, !"compare_convert_fusion_wrapped: argument 4"}
!17 = !{!18}
!18 = distinct !{!18, !8, !"compare_convert_fusion_wrapped: argument 5"}
!19 = !{!7, !10, !12, !16, !18}
!20 = !{!7, !10, !12, !14, !18}
!21 = !{!7, !10, !14, !16, !18}
!22 = !{!7, !12, !14, !16, !18}
!23 = !{!10, !12, !14, !16, !18}
!24 = !{!7, !10, !12, !14, !16}
!25 = distinct !{!25, !26, !27}
!26 = !{!"llvm.loop.isvectorized", i32 1}
!27 = !{!"llvm.loop.unroll.runtime.disable"}
!28 = distinct !{!28, !29}
!29 = !{!"llvm.loop.unroll.disable"}
