; ModuleID = '__compute_module_compare_convert_fusion.1_kernel_module'
source_filename = "__compute_module_compare_convert_fusion.1_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @compare_convert_fusion.1(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !5
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !4
  %9 = getelementptr inbounds nuw i8, ptr %3, i64 48
  %10 = load ptr, ptr %9, align 8, !invariant.load !3, !dereferenceable !5
  tail call void @llvm.experimental.noalias.scope.decl(metadata !6)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !11)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !13)
  br label %vector.ph

vector.ph:                                        ; preds = %1, %middle.block
  %11 = phi i64 [ 0, %1 ], [ %65, %middle.block ]
  %12 = mul nuw nsw i64 %11, 960
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %vector.ph
  %index = phi i64 [ 0, %vector.ph ], [ %index.next.2, %vector.body ]
  %13 = add nuw nsw i64 %index, %12
  %14 = getelementptr inbounds nuw float, ptr %6, i64 %13
  %15 = getelementptr inbounds nuw i8, ptr %14, i64 32
  %wide.load = load <8 x float>, ptr %14, align 4, !invariant.load !3, !alias.scope !9, !noalias !15
  %wide.load3 = load <8 x float>, ptr %15, align 4, !invariant.load !3, !alias.scope !9, !noalias !15
  %16 = getelementptr inbounds nuw float, ptr %8, i64 %index
  %17 = getelementptr inbounds nuw i8, ptr %16, i64 32
  %wide.load4 = load <8 x float>, ptr %16, align 4, !invariant.load !3, !alias.scope !11, !noalias !16
  %wide.load5 = load <8 x float>, ptr %17, align 4, !invariant.load !3, !alias.scope !11, !noalias !16
  %18 = fmul <8 x float> %wide.load, %wide.load4
  %19 = fmul <8 x float> %wide.load3, %wide.load5
  %20 = getelementptr inbounds nuw float, ptr %4, i64 %index
  %21 = getelementptr inbounds nuw i8, ptr %20, i64 32
  %wide.load6 = load <8 x float>, ptr %20, align 4, !invariant.load !3, !alias.scope !6, !noalias !17
  %wide.load7 = load <8 x float>, ptr %21, align 4, !invariant.load !3, !alias.scope !6, !noalias !17
  %22 = fadd <8 x float> %18, %wide.load6
  %23 = fadd <8 x float> %19, %wide.load7
  %24 = fcmp ogt <8 x float> %22, zeroinitializer
  %25 = fcmp ogt <8 x float> %23, zeroinitializer
  %26 = zext <8 x i1> %24 to <8 x i32>
  %27 = zext <8 x i1> %25 to <8 x i32>
  %28 = getelementptr inbounds nuw i32, ptr %10, i64 %13
  %29 = getelementptr inbounds nuw i8, ptr %28, i64 32
  store <8 x i32> %26, ptr %28, align 4, !alias.scope !13, !noalias !18
  store <8 x i32> %27, ptr %29, align 4, !alias.scope !13, !noalias !18
  %index.next = add nuw nsw i64 %index, 16
  %30 = add nuw nsw i64 %index.next, %12
  %31 = getelementptr inbounds nuw float, ptr %6, i64 %30
  %32 = getelementptr inbounds nuw i8, ptr %31, i64 32
  %wide.load.1 = load <8 x float>, ptr %31, align 4, !invariant.load !3, !alias.scope !9, !noalias !15
  %wide.load3.1 = load <8 x float>, ptr %32, align 4, !invariant.load !3, !alias.scope !9, !noalias !15
  %33 = getelementptr inbounds nuw float, ptr %8, i64 %index.next
  %34 = getelementptr inbounds nuw i8, ptr %33, i64 32
  %wide.load4.1 = load <8 x float>, ptr %33, align 4, !invariant.load !3, !alias.scope !11, !noalias !16
  %wide.load5.1 = load <8 x float>, ptr %34, align 4, !invariant.load !3, !alias.scope !11, !noalias !16
  %35 = fmul <8 x float> %wide.load.1, %wide.load4.1
  %36 = fmul <8 x float> %wide.load3.1, %wide.load5.1
  %37 = getelementptr inbounds nuw float, ptr %4, i64 %index.next
  %38 = getelementptr inbounds nuw i8, ptr %37, i64 32
  %wide.load6.1 = load <8 x float>, ptr %37, align 4, !invariant.load !3, !alias.scope !6, !noalias !17
  %wide.load7.1 = load <8 x float>, ptr %38, align 4, !invariant.load !3, !alias.scope !6, !noalias !17
  %39 = fadd <8 x float> %35, %wide.load6.1
  %40 = fadd <8 x float> %36, %wide.load7.1
  %41 = fcmp ogt <8 x float> %39, zeroinitializer
  %42 = fcmp ogt <8 x float> %40, zeroinitializer
  %43 = zext <8 x i1> %41 to <8 x i32>
  %44 = zext <8 x i1> %42 to <8 x i32>
  %45 = getelementptr inbounds nuw i32, ptr %10, i64 %30
  %46 = getelementptr inbounds nuw i8, ptr %45, i64 32
  store <8 x i32> %43, ptr %45, align 4, !alias.scope !13, !noalias !18
  store <8 x i32> %44, ptr %46, align 4, !alias.scope !13, !noalias !18
  %index.next.1 = add nuw nsw i64 %index, 32
  %47 = add nuw nsw i64 %index.next.1, %12
  %48 = getelementptr inbounds nuw float, ptr %6, i64 %47
  %49 = getelementptr inbounds nuw i8, ptr %48, i64 32
  %wide.load.2 = load <8 x float>, ptr %48, align 4, !invariant.load !3, !alias.scope !9, !noalias !15
  %wide.load3.2 = load <8 x float>, ptr %49, align 4, !invariant.load !3, !alias.scope !9, !noalias !15
  %50 = getelementptr inbounds nuw float, ptr %8, i64 %index.next.1
  %51 = getelementptr inbounds nuw i8, ptr %50, i64 32
  %wide.load4.2 = load <8 x float>, ptr %50, align 4, !invariant.load !3, !alias.scope !11, !noalias !16
  %wide.load5.2 = load <8 x float>, ptr %51, align 4, !invariant.load !3, !alias.scope !11, !noalias !16
  %52 = fmul <8 x float> %wide.load.2, %wide.load4.2
  %53 = fmul <8 x float> %wide.load3.2, %wide.load5.2
  %54 = getelementptr inbounds nuw float, ptr %4, i64 %index.next.1
  %55 = getelementptr inbounds nuw i8, ptr %54, i64 32
  %wide.load6.2 = load <8 x float>, ptr %54, align 4, !invariant.load !3, !alias.scope !6, !noalias !17
  %wide.load7.2 = load <8 x float>, ptr %55, align 4, !invariant.load !3, !alias.scope !6, !noalias !17
  %56 = fadd <8 x float> %52, %wide.load6.2
  %57 = fadd <8 x float> %53, %wide.load7.2
  %58 = fcmp ogt <8 x float> %56, zeroinitializer
  %59 = fcmp ogt <8 x float> %57, zeroinitializer
  %60 = zext <8 x i1> %58 to <8 x i32>
  %61 = zext <8 x i1> %59 to <8 x i32>
  %62 = getelementptr inbounds nuw i32, ptr %10, i64 %47
  %63 = getelementptr inbounds nuw i8, ptr %62, i64 32
  store <8 x i32> %60, ptr %62, align 4, !alias.scope !13, !noalias !18
  store <8 x i32> %61, ptr %63, align 4, !alias.scope !13, !noalias !18
  %index.next.2 = add nuw nsw i64 %index, 48
  %64 = icmp eq i64 %index.next.2, 960
  br i1 %64, label %middle.block, label %vector.body, !llvm.loop !19

middle.block:                                     ; preds = %vector.body
  %65 = add nuw nsw i64 %11, 1
  %exitcond2.not = icmp eq i64 %65, 48
  br i1 %exitcond2.not, label %compare_convert_fusion.1_wrapped.exit, label %vector.ph, !llvm.loop !22

compare_convert_fusion.1_wrapped.exit:            ; preds = %middle.block
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 1}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 3840}
!5 = !{i64 184320}
!6 = !{!7}
!7 = distinct !{!7, !8, !"compare_convert_fusion.1_wrapped: argument 0"}
!8 = distinct !{!8, !"compare_convert_fusion.1_wrapped"}
!9 = !{!10}
!10 = distinct !{!10, !8, !"compare_convert_fusion.1_wrapped: argument 1"}
!11 = !{!12}
!12 = distinct !{!12, !8, !"compare_convert_fusion.1_wrapped: argument 2"}
!13 = !{!14}
!14 = distinct !{!14, !8, !"compare_convert_fusion.1_wrapped: argument 3"}
!15 = !{!7, !12, !14}
!16 = !{!7, !10, !14}
!17 = !{!10, !12, !14}
!18 = !{!7, !10, !12}
!19 = distinct !{!19, !20, !21}
!20 = !{!"llvm.loop.isvectorized", i32 1}
!21 = !{!"llvm.loop.unroll.runtime.disable"}
!22 = distinct !{!22, !23}
!23 = !{!"llvm.loop.unroll.disable"}
