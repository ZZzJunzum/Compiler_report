; ModuleID = '__compute_module_wrapped_reduce-window_kernel_module'
source_filename = "__compute_module_wrapped_reduce-window_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @wrapped_reduce-window(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !5
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !6
  tail call void @llvm.experimental.noalias.scope.decl(metadata !7)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !10)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !12)
  %9 = load i32, ptr %6, align 4, !invariant.load !3, !alias.scope !10, !noalias !14
  br label %10

10:                                               ; preds = %1, %126
  %11 = phi i1 [ true, %1 ], [ false, %126 ]
  %12 = phi i64 [ 0, %1 ], [ 1, %126 ]
  %13 = shl nuw nsw i64 %12, 5
  %14 = add nsw i64 %13, -8
  %.idx1 = mul nuw nsw i64 %12, 122880
  %15 = getelementptr i8, ptr %4, i64 %.idx1
  %.idx = mul nuw nsw i64 %12, 120
  %16 = getelementptr i8, ptr %8, i64 %.idx
  br label %.preheader6

.preheader6:                                      ; preds = %10, %123
  %17 = phi i64 [ 0, %10 ], [ %125, %123 ]
  %.idx2 = shl i64 %17, 7
  %18 = getelementptr i8, ptr %15, i64 %.idx2
  br label %19

19:                                               ; preds = %.preheader6, %.loopexit
  %20 = phi i32 [ %9, %.preheader6 ], [ %121, %.loopexit ]
  %21 = phi i64 [ 0, %.preheader6 ], [ %122, %.loopexit ]
  %22 = add nsw i64 %14, %21
  %23 = icmp ult i64 %22, 48
  br i1 %23, label %.preheader, label %.loopexit

.preheader:                                       ; preds = %19
  %.idx3 = mul nuw nsw i64 %21, 3840
  %24 = getelementptr i8, ptr %18, i64 %.idx3
  %25 = getelementptr i8, ptr %24, i64 -30720
  %26 = load i32, ptr %25, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %27 = add i32 %26, %20
  %28 = getelementptr i8, ptr %24, i64 -30716
  %29 = load i32, ptr %28, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %30 = add i32 %29, %27
  %31 = getelementptr i8, ptr %24, i64 -30712
  %32 = load i32, ptr %31, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %33 = add i32 %32, %30
  %34 = getelementptr i8, ptr %24, i64 -30708
  %35 = load i32, ptr %34, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %36 = add i32 %35, %33
  %37 = getelementptr i8, ptr %24, i64 -30704
  %38 = load i32, ptr %37, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %39 = add i32 %38, %36
  %40 = getelementptr i8, ptr %24, i64 -30700
  %41 = load i32, ptr %40, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %42 = add i32 %41, %39
  %43 = getelementptr i8, ptr %24, i64 -30696
  %44 = load i32, ptr %43, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %45 = add i32 %44, %42
  %46 = getelementptr i8, ptr %24, i64 -30692
  %47 = load i32, ptr %46, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %48 = add i32 %47, %45
  %49 = getelementptr i8, ptr %24, i64 -30688
  %50 = load i32, ptr %49, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %51 = add i32 %50, %48
  %52 = getelementptr i8, ptr %24, i64 -30684
  %53 = load i32, ptr %52, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %54 = add i32 %53, %51
  %55 = getelementptr i8, ptr %24, i64 -30680
  %56 = load i32, ptr %55, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %57 = add i32 %56, %54
  %58 = getelementptr i8, ptr %24, i64 -30676
  %59 = load i32, ptr %58, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %60 = add i32 %59, %57
  %61 = getelementptr i8, ptr %24, i64 -30672
  %62 = load i32, ptr %61, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %63 = add i32 %62, %60
  %64 = getelementptr i8, ptr %24, i64 -30668
  %65 = load i32, ptr %64, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %66 = add i32 %65, %63
  %67 = getelementptr i8, ptr %24, i64 -30664
  %68 = load i32, ptr %67, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %69 = add i32 %68, %66
  %70 = getelementptr i8, ptr %24, i64 -30660
  %71 = load i32, ptr %70, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %72 = add i32 %71, %69
  %73 = getelementptr i8, ptr %24, i64 -30656
  %74 = load i32, ptr %73, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %75 = add i32 %74, %72
  %76 = getelementptr i8, ptr %24, i64 -30652
  %77 = load i32, ptr %76, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %78 = add i32 %77, %75
  %79 = getelementptr i8, ptr %24, i64 -30648
  %80 = load i32, ptr %79, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %81 = add i32 %80, %78
  %82 = getelementptr i8, ptr %24, i64 -30644
  %83 = load i32, ptr %82, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %84 = add i32 %83, %81
  %85 = getelementptr i8, ptr %24, i64 -30640
  %86 = load i32, ptr %85, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %87 = add i32 %86, %84
  %88 = getelementptr i8, ptr %24, i64 -30636
  %89 = load i32, ptr %88, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %90 = add i32 %89, %87
  %91 = getelementptr i8, ptr %24, i64 -30632
  %92 = load i32, ptr %91, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %93 = add i32 %92, %90
  %94 = getelementptr i8, ptr %24, i64 -30628
  %95 = load i32, ptr %94, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %96 = add i32 %95, %93
  %97 = getelementptr i8, ptr %24, i64 -30624
  %98 = load i32, ptr %97, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %99 = add i32 %98, %96
  %100 = getelementptr i8, ptr %24, i64 -30620
  %101 = load i32, ptr %100, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %102 = add i32 %101, %99
  %103 = getelementptr i8, ptr %24, i64 -30616
  %104 = load i32, ptr %103, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %105 = add i32 %104, %102
  %106 = getelementptr i8, ptr %24, i64 -30612
  %107 = load i32, ptr %106, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %108 = add i32 %107, %105
  %109 = getelementptr i8, ptr %24, i64 -30608
  %110 = load i32, ptr %109, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %111 = add i32 %110, %108
  %112 = getelementptr i8, ptr %24, i64 -30604
  %113 = load i32, ptr %112, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %114 = add i32 %113, %111
  %115 = getelementptr i8, ptr %24, i64 -30600
  %116 = load i32, ptr %115, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %117 = add i32 %116, %114
  %118 = getelementptr i8, ptr %24, i64 -30596
  %119 = load i32, ptr %118, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %120 = add i32 %119, %117
  br label %.loopexit

.loopexit:                                        ; preds = %.preheader, %19
  %121 = phi i32 [ %20, %19 ], [ %120, %.preheader ]
  %122 = add nuw nsw i64 %21, 1
  %exitcond.not = icmp eq i64 %122, 32
  br i1 %exitcond.not, label %123, label %19, !llvm.loop !16

123:                                              ; preds = %.loopexit
  %124 = getelementptr i32, ptr %16, i64 %17
  store i32 %121, ptr %124, align 4, !alias.scope !12, !noalias !18
  %125 = add nuw nsw i64 %17, 1
  %exitcond9.not = icmp eq i64 %125, 30
  br i1 %exitcond9.not, label %126, label %.preheader6, !llvm.loop !16

126:                                              ; preds = %123
  br i1 %11, label %10, label %wrapped_reduce-window_wrapped.exit, !llvm.loop !16

wrapped_reduce-window_wrapped.exit:               ; preds = %126
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 3}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 184320}
!5 = !{i64 4}
!6 = !{i64 240}
!7 = !{!8}
!8 = distinct !{!8, !9, !"wrapped_reduce-window_wrapped: argument 0"}
!9 = distinct !{!9, !"wrapped_reduce-window_wrapped"}
!10 = !{!11}
!11 = distinct !{!11, !9, !"wrapped_reduce-window_wrapped: argument 1"}
!12 = !{!13}
!13 = distinct !{!13, !9, !"wrapped_reduce-window_wrapped: argument 2"}
!14 = !{!8, !13}
!15 = !{!11, !13}
!16 = distinct !{!16, !17}
!17 = !{!"llvm.loop.unroll.disable"}
!18 = !{!8, !11}
