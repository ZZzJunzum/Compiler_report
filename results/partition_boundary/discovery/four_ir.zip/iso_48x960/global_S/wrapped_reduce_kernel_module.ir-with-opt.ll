; ModuleID = '__compute_module_wrapped_reduce_kernel_module'
source_filename = "__compute_module_wrapped_reduce_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @wrapped_reduce(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !5
  tail call void @llvm.experimental.noalias.scope.decl(metadata !6)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !11)
  %7 = load i32, ptr %6, align 4, !invariant.load !3, !alias.scope !9, !noalias !13
  br label %.preheader

.preheader:                                       ; preds = %1, %.preheader
  %8 = phi i32 [ %7, %1 ], [ %99, %.preheader ]
  %9 = phi i64 [ 0, %1 ], [ %100, %.preheader ]
  %.idx = mul nuw nsw i64 %9, 120
  %10 = getelementptr i8, ptr %4, i64 %.idx
  %11 = load i32, ptr %10, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %12 = add i32 %11, %8
  %13 = getelementptr i8, ptr %10, i64 4
  %14 = load i32, ptr %13, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %15 = add i32 %14, %12
  %16 = getelementptr i8, ptr %10, i64 8
  %17 = load i32, ptr %16, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %18 = add i32 %17, %15
  %19 = getelementptr i8, ptr %10, i64 12
  %20 = load i32, ptr %19, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %21 = add i32 %20, %18
  %22 = getelementptr i8, ptr %10, i64 16
  %23 = load i32, ptr %22, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %24 = add i32 %23, %21
  %25 = getelementptr i8, ptr %10, i64 20
  %26 = load i32, ptr %25, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %27 = add i32 %26, %24
  %28 = getelementptr i8, ptr %10, i64 24
  %29 = load i32, ptr %28, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %30 = add i32 %29, %27
  %31 = getelementptr i8, ptr %10, i64 28
  %32 = load i32, ptr %31, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %33 = add i32 %32, %30
  %34 = getelementptr i8, ptr %10, i64 32
  %35 = load i32, ptr %34, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %36 = add i32 %35, %33
  %37 = getelementptr i8, ptr %10, i64 36
  %38 = load i32, ptr %37, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %39 = add i32 %38, %36
  %40 = getelementptr i8, ptr %10, i64 40
  %41 = load i32, ptr %40, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %42 = add i32 %41, %39
  %43 = getelementptr i8, ptr %10, i64 44
  %44 = load i32, ptr %43, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %45 = add i32 %44, %42
  %46 = getelementptr i8, ptr %10, i64 48
  %47 = load i32, ptr %46, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %48 = add i32 %47, %45
  %49 = getelementptr i8, ptr %10, i64 52
  %50 = load i32, ptr %49, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %51 = add i32 %50, %48
  %52 = getelementptr i8, ptr %10, i64 56
  %53 = load i32, ptr %52, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %54 = add i32 %53, %51
  %55 = getelementptr i8, ptr %10, i64 60
  %56 = load i32, ptr %55, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %57 = add i32 %56, %54
  %58 = getelementptr i8, ptr %10, i64 64
  %59 = load i32, ptr %58, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %60 = add i32 %59, %57
  %61 = getelementptr i8, ptr %10, i64 68
  %62 = load i32, ptr %61, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %63 = add i32 %62, %60
  %64 = getelementptr i8, ptr %10, i64 72
  %65 = load i32, ptr %64, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %66 = add i32 %65, %63
  %67 = getelementptr i8, ptr %10, i64 76
  %68 = load i32, ptr %67, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %69 = add i32 %68, %66
  %70 = getelementptr i8, ptr %10, i64 80
  %71 = load i32, ptr %70, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %72 = add i32 %71, %69
  %73 = getelementptr i8, ptr %10, i64 84
  %74 = load i32, ptr %73, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %75 = add i32 %74, %72
  %76 = getelementptr i8, ptr %10, i64 88
  %77 = load i32, ptr %76, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %78 = add i32 %77, %75
  %79 = getelementptr i8, ptr %10, i64 92
  %80 = load i32, ptr %79, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %81 = add i32 %80, %78
  %82 = getelementptr i8, ptr %10, i64 96
  %83 = load i32, ptr %82, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %84 = add i32 %83, %81
  %85 = getelementptr i8, ptr %10, i64 100
  %86 = load i32, ptr %85, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %87 = add i32 %86, %84
  %88 = getelementptr i8, ptr %10, i64 104
  %89 = load i32, ptr %88, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %90 = add i32 %89, %87
  %91 = getelementptr i8, ptr %10, i64 108
  %92 = load i32, ptr %91, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %93 = add i32 %92, %90
  %94 = getelementptr i8, ptr %10, i64 112
  %95 = load i32, ptr %94, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %96 = add i32 %95, %93
  %97 = getelementptr i8, ptr %10, i64 116
  %98 = load i32, ptr %97, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %99 = add i32 %98, %96
  %100 = add nuw nsw i64 %9, 1
  %exitcond.not = icmp eq i64 %100, 2
  br i1 %exitcond.not, label %wrapped_reduce_wrapped.exit, label %.preheader, !llvm.loop !15

wrapped_reduce_wrapped.exit:                      ; preds = %.preheader
  %101 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %102 = load ptr, ptr %101, align 8, !invariant.load !3, !dereferenceable !5
  store i32 %99, ptr %102, align 4, !alias.scope !11, !noalias !17
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 2}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 240}
!5 = !{i64 4}
!6 = !{!7}
!7 = distinct !{!7, !8, !"wrapped_reduce_wrapped: argument 0"}
!8 = distinct !{!8, !"wrapped_reduce_wrapped"}
!9 = !{!10}
!10 = distinct !{!10, !8, !"wrapped_reduce_wrapped: argument 1"}
!11 = !{!12}
!12 = distinct !{!12, !8, !"wrapped_reduce_wrapped: argument 2"}
!13 = !{!7, !12}
!14 = !{!10, !12}
!15 = distinct !{!15, !16}
!16 = !{!"llvm.loop.unroll.disable"}
!17 = !{!7, !10}
