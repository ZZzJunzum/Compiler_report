; ModuleID = '__compute_module_wrapped_reduce_kernel_module'
source_filename = "__compute_module_wrapped_reduce_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @wrapped_reduce(ptr readonly captures(none) %0) local_unnamed_addr #0 {
vector.ph:
  %1 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %2 = load ptr, ptr %1, align 8, !invariant.load !3
  %3 = load ptr, ptr %2, align 8, !invariant.load !3, !dereferenceable !4
  %4 = getelementptr inbounds nuw i8, ptr %2, i64 32
  %5 = load ptr, ptr %4, align 8, !invariant.load !3, !dereferenceable !5
  tail call void @llvm.experimental.noalias.scope.decl(metadata !6)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !11)
  %6 = getelementptr inbounds nuw i8, ptr %2, i64 16
  %7 = load ptr, ptr %6, align 8, !invariant.load !3, !dereferenceable !13
  %8 = load i32, ptr %7, align 4, !invariant.load !3, !alias.scope !9, !noalias !14
  %broadcast.splatinsert = insertelement <4 x i32> poison, i32 %8, i64 0
  %broadcast.splat = shufflevector <4 x i32> %broadcast.splatinsert, <4 x i32> poison, <4 x i32> zeroinitializer
  %9 = getelementptr i8, ptr %3, <4 x i64> <i64 0, i64 20, i64 40, i64 60>
  %wide.masked.gather = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %9, <4 x i1> splat (i1 true), <4 x i32> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %10 = add <4 x i32> %wide.masked.gather, %broadcast.splat
  %11 = getelementptr i8, <4 x ptr> %9, i64 4
  %wide.masked.gather1 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %11, <4 x i1> splat (i1 true), <4 x i32> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %12 = add <4 x i32> %wide.masked.gather1, %10
  %13 = getelementptr i8, <4 x ptr> %9, i64 8
  %wide.masked.gather2 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %13, <4 x i1> splat (i1 true), <4 x i32> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %14 = add <4 x i32> %wide.masked.gather2, %12
  %15 = getelementptr i8, <4 x ptr> %9, i64 12
  %wide.masked.gather3 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %15, <4 x i1> splat (i1 true), <4 x i32> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %16 = add <4 x i32> %wide.masked.gather3, %14
  %17 = getelementptr i8, <4 x ptr> %9, i64 16
  %wide.masked.gather4 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %17, <4 x i1> splat (i1 true), <4 x i32> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %18 = add <4 x i32> %wide.masked.gather4, %16
  store <4 x i32> %18, ptr %5, align 4, !alias.scope !11, !noalias !16
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr>, <4 x i1>, <4 x i32>) #2

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(read) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 3}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 80}
!5 = !{i64 16}
!6 = !{!7}
!7 = distinct !{!7, !8, !"wrapped_reduce_wrapped: argument 0"}
!8 = distinct !{!8, !"wrapped_reduce_wrapped"}
!9 = !{!10}
!10 = distinct !{!10, !8, !"wrapped_reduce_wrapped: argument 1"}
!11 = !{!12}
!12 = distinct !{!12, !8, !"wrapped_reduce_wrapped: argument 2"}
!13 = !{i64 4}
!14 = !{!7, !12}
!15 = !{!10, !12}
!16 = !{!7, !10}
