; ModuleID = '__compute_module_convert_reduce_fusion_kernel_module'
source_filename = "__compute_module_convert_reduce_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @convert_reduce_fusion(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !4
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !4
  %9 = getelementptr inbounds nuw i8, ptr %3, i64 48
  %10 = load ptr, ptr %9, align 8, !invariant.load !3, !dereferenceable !5
  %11 = getelementptr inbounds nuw i8, ptr %3, i64 64
  %12 = load ptr, ptr %11, align 8, !invariant.load !3, !dereferenceable !4
  tail call void @llvm.experimental.noalias.scope.decl(metadata !6)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !11)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !13)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !15)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !17)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !19)
  br label %.preheader

.preheader:                                       ; preds = %1, %middle.block
  %13 = phi i32 [ 0, %1 ], [ %85, %middle.block ]
  %14 = phi i32 [ 0, %1 ], [ %84, %middle.block ]
  %15 = phi i64 [ 0, %1 ], [ %86, %middle.block ]
  %.idx = mul nuw nsw i64 %15, 640
  %16 = getelementptr i8, ptr %10, i64 %.idx
  %17 = insertelement <8 x i32> <i32 poison, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0>, i32 %13, i64 0
  %18 = insertelement <8 x i32> <i32 poison, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0>, i32 %14, i64 0
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %.preheader
  %index = phi i64 [ 0, %.preheader ], [ %index.next.1, %vector.body ]
  %vec.phi = phi <8 x i32> [ %17, %.preheader ], [ %81, %vector.body ]
  %vec.phi8 = phi <8 x i32> [ zeroinitializer, %.preheader ], [ %82, %vector.body ]
  %vec.phi9 = phi <8 x i32> [ %18, %.preheader ], [ %79, %vector.body ]
  %vec.phi10 = phi <8 x i32> [ zeroinitializer, %.preheader ], [ %80, %vector.body ]
  %19 = getelementptr float, ptr %16, i64 %index
  %20 = getelementptr i8, ptr %19, i64 32
  %wide.load = load <8 x float>, ptr %19, align 4, !invariant.load !3, !alias.scope !13, !noalias !21
  %wide.load11 = load <8 x float>, ptr %20, align 4, !invariant.load !3, !alias.scope !13, !noalias !21
  %21 = getelementptr inbounds nuw float, ptr %12, i64 %index
  %22 = getelementptr inbounds nuw i8, ptr %21, i64 32
  %wide.load12 = load <8 x float>, ptr %21, align 4, !invariant.load !3, !alias.scope !15, !noalias !22
  %wide.load13 = load <8 x float>, ptr %22, align 4, !invariant.load !3, !alias.scope !15, !noalias !22
  %23 = fmul <8 x float> %wide.load, %wide.load12
  %24 = fmul <8 x float> %wide.load11, %wide.load13
  %25 = getelementptr inbounds nuw float, ptr %8, i64 %index
  %26 = getelementptr inbounds nuw i8, ptr %25, i64 32
  %wide.load14 = load <8 x float>, ptr %25, align 4, !invariant.load !3, !alias.scope !11, !noalias !23
  %wide.load15 = load <8 x float>, ptr %26, align 4, !invariant.load !3, !alias.scope !11, !noalias !23
  %27 = fadd <8 x float> %23, %wide.load14
  %28 = fadd <8 x float> %24, %wide.load15
  %29 = fcmp ogt <8 x float> %27, zeroinitializer
  %30 = fcmp ogt <8 x float> %28, zeroinitializer
  %31 = zext <8 x i1> %29 to <8 x i32>
  %32 = zext <8 x i1> %30 to <8 x i32>
  %33 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %27, <8 x float> zeroinitializer)
  %34 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %28, <8 x float> zeroinitializer)
  %35 = getelementptr inbounds nuw float, ptr %6, i64 %index
  %36 = getelementptr inbounds nuw i8, ptr %35, i64 32
  %wide.load16 = load <8 x float>, ptr %35, align 4, !invariant.load !3, !alias.scope !9, !noalias !24
  %wide.load17 = load <8 x float>, ptr %36, align 4, !invariant.load !3, !alias.scope !9, !noalias !24
  %37 = fmul <8 x float> %wide.load16, %33
  %38 = fmul <8 x float> %wide.load17, %34
  %39 = getelementptr inbounds nuw float, ptr %4, i64 %index
  %40 = getelementptr inbounds nuw i8, ptr %39, i64 32
  %wide.load18 = load <8 x float>, ptr %39, align 4, !invariant.load !3, !alias.scope !6, !noalias !25
  %wide.load19 = load <8 x float>, ptr %40, align 4, !invariant.load !3, !alias.scope !6, !noalias !25
  %41 = fadd <8 x float> %wide.load18, %37
  %42 = fadd <8 x float> %wide.load19, %38
  %43 = fcmp ogt <8 x float> %41, zeroinitializer
  %44 = fcmp ogt <8 x float> %42, zeroinitializer
  %45 = zext <8 x i1> %43 to <8 x i32>
  %46 = zext <8 x i1> %44 to <8 x i32>
  %47 = add <8 x i32> %vec.phi9, %31
  %48 = add <8 x i32> %vec.phi10, %32
  %49 = add <8 x i32> %vec.phi, %45
  %50 = add <8 x i32> %vec.phi8, %46
  %index.next = or disjoint i64 %index, 16
  %51 = getelementptr float, ptr %16, i64 %index.next
  %52 = getelementptr i8, ptr %51, i64 32
  %wide.load.1 = load <8 x float>, ptr %51, align 4, !invariant.load !3, !alias.scope !13, !noalias !21
  %wide.load11.1 = load <8 x float>, ptr %52, align 4, !invariant.load !3, !alias.scope !13, !noalias !21
  %53 = getelementptr inbounds nuw float, ptr %12, i64 %index.next
  %54 = getelementptr inbounds nuw i8, ptr %53, i64 32
  %wide.load12.1 = load <8 x float>, ptr %53, align 4, !invariant.load !3, !alias.scope !15, !noalias !22
  %wide.load13.1 = load <8 x float>, ptr %54, align 4, !invariant.load !3, !alias.scope !15, !noalias !22
  %55 = fmul <8 x float> %wide.load.1, %wide.load12.1
  %56 = fmul <8 x float> %wide.load11.1, %wide.load13.1
  %57 = getelementptr inbounds nuw float, ptr %8, i64 %index.next
  %58 = getelementptr inbounds nuw i8, ptr %57, i64 32
  %wide.load14.1 = load <8 x float>, ptr %57, align 4, !invariant.load !3, !alias.scope !11, !noalias !23
  %wide.load15.1 = load <8 x float>, ptr %58, align 4, !invariant.load !3, !alias.scope !11, !noalias !23
  %59 = fadd <8 x float> %55, %wide.load14.1
  %60 = fadd <8 x float> %56, %wide.load15.1
  %61 = fcmp ogt <8 x float> %59, zeroinitializer
  %62 = fcmp ogt <8 x float> %60, zeroinitializer
  %63 = zext <8 x i1> %61 to <8 x i32>
  %64 = zext <8 x i1> %62 to <8 x i32>
  %65 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %59, <8 x float> zeroinitializer)
  %66 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %60, <8 x float> zeroinitializer)
  %67 = getelementptr inbounds nuw float, ptr %6, i64 %index.next
  %68 = getelementptr inbounds nuw i8, ptr %67, i64 32
  %wide.load16.1 = load <8 x float>, ptr %67, align 4, !invariant.load !3, !alias.scope !9, !noalias !24
  %wide.load17.1 = load <8 x float>, ptr %68, align 4, !invariant.load !3, !alias.scope !9, !noalias !24
  %69 = fmul <8 x float> %wide.load16.1, %65
  %70 = fmul <8 x float> %wide.load17.1, %66
  %71 = getelementptr inbounds nuw float, ptr %4, i64 %index.next
  %72 = getelementptr inbounds nuw i8, ptr %71, i64 32
  %wide.load18.1 = load <8 x float>, ptr %71, align 4, !invariant.load !3, !alias.scope !6, !noalias !25
  %wide.load19.1 = load <8 x float>, ptr %72, align 4, !invariant.load !3, !alias.scope !6, !noalias !25
  %73 = fadd <8 x float> %wide.load18.1, %69
  %74 = fadd <8 x float> %wide.load19.1, %70
  %75 = fcmp ogt <8 x float> %73, zeroinitializer
  %76 = fcmp ogt <8 x float> %74, zeroinitializer
  %77 = zext <8 x i1> %75 to <8 x i32>
  %78 = zext <8 x i1> %76 to <8 x i32>
  %79 = add <8 x i32> %47, %63
  %80 = add <8 x i32> %48, %64
  %81 = add <8 x i32> %49, %77
  %82 = add <8 x i32> %50, %78
  %index.next.1 = add nuw nsw i64 %index, 32
  %83 = icmp eq i64 %index.next.1, 160
  br i1 %83, label %middle.block, label %vector.body, !llvm.loop !26

middle.block:                                     ; preds = %vector.body
  %bin.rdx20 = add <8 x i32> %80, %79
  %84 = tail call i32 @llvm.vector.reduce.add.v8i32(<8 x i32> %bin.rdx20)
  %bin.rdx = add <8 x i32> %82, %81
  %85 = tail call i32 @llvm.vector.reduce.add.v8i32(<8 x i32> %bin.rdx)
  %86 = add nuw nsw i64 %15, 1
  %exitcond5.not = icmp eq i64 %86, 4
  br i1 %exitcond5.not, label %convert_reduce_fusion_wrapped.exit, label %.preheader, !llvm.loop !29

convert_reduce_fusion_wrapped.exit:               ; preds = %middle.block
  %87 = getelementptr inbounds nuw i8, ptr %3, i64 96
  %88 = load ptr, ptr %87, align 8, !invariant.load !3, !dereferenceable !31
  %89 = getelementptr inbounds nuw i8, ptr %3, i64 80
  %90 = load ptr, ptr %89, align 8, !invariant.load !3, !dereferenceable !31
  store i32 %84, ptr %90, align 4, !alias.scope !17, !noalias !32
  store i32 %85, ptr %88, align 4, !alias.scope !19, !noalias !33
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.maximum.v8f32(<8 x float>, <8 x float>) #2

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.vector.reduce.add.v8i32(<8 x i32>) #3

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #3 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 0}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 640}
!5 = !{i64 2560}
!6 = !{!7}
!7 = distinct !{!7, !8, !"convert_reduce_fusion_wrapped: argument 0"}
!8 = distinct !{!8, !"convert_reduce_fusion_wrapped"}
!9 = !{!10}
!10 = distinct !{!10, !8, !"convert_reduce_fusion_wrapped: argument 1"}
!11 = !{!12}
!12 = distinct !{!12, !8, !"convert_reduce_fusion_wrapped: argument 2"}
!13 = !{!14}
!14 = distinct !{!14, !8, !"convert_reduce_fusion_wrapped: argument 3"}
!15 = !{!16}
!16 = distinct !{!16, !8, !"convert_reduce_fusion_wrapped: argument 4"}
!17 = !{!18}
!18 = distinct !{!18, !8, !"convert_reduce_fusion_wrapped: argument 5"}
!19 = !{!20}
!20 = distinct !{!20, !8, !"convert_reduce_fusion_wrapped: argument 6"}
!21 = !{!7, !10, !12, !16, !18, !20}
!22 = !{!7, !10, !12, !14, !18, !20}
!23 = !{!7, !10, !14, !16, !18, !20}
!24 = !{!7, !12, !14, !16, !18, !20}
!25 = !{!10, !12, !14, !16, !18, !20}
!26 = distinct !{!26, !27, !28}
!27 = !{!"llvm.loop.isvectorized", i32 1}
!28 = !{!"llvm.loop.unroll.runtime.disable"}
!29 = distinct !{!29, !30}
!30 = !{!"llvm.loop.unroll.disable"}
!31 = !{i64 4}
!32 = !{!7, !10, !12, !14, !16, !20}
!33 = !{!7, !10, !12, !14, !16, !18}
