; ModuleID = '__compute_module_wrapped_reduce-window_kernel_module'
source_filename = "__compute_module_wrapped_reduce-window_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @wrapped_reduce-window(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !5
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !6
  tail call void @llvm.experimental.noalias.scope.decl(metadata !7)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !10)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !12)
  %9 = load i32, ptr %6, align 4, !invariant.load !3, !alias.scope !10, !noalias !14
  %10 = insertelement <4 x i32> <i32 poison, i32 0, i32 0, i32 0>, i32 %9, i64 0
  %invariant.gep = getelementptr i8, ptr %4, <4 x i64> <i64 0, i64 46080, i64 92160, i64 138240>
  br label %.preheader2

.preheader2:                                      ; preds = %1, %.preheader2
  %11 = phi i64 [ 0, %1 ], [ %77, %.preheader2 ]
  %.idx = shl i64 %11, 7
  %gep = getelementptr i8, <4 x ptr> %invariant.gep, i64 %.idx
  %12 = getelementptr i8, <4 x ptr> %gep, i64 124
  %wide.masked.gather35 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %12, <4 x i1> splat (i1 true), <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %13 = getelementptr i8, <4 x ptr> %gep, i64 120
  %wide.masked.gather34 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %13, <4 x i1> splat (i1 true), <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %14 = getelementptr i8, <4 x ptr> %gep, i64 116
  %wide.masked.gather33 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %14, <4 x i1> splat (i1 true), <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %15 = getelementptr i8, <4 x ptr> %gep, i64 112
  %wide.masked.gather32 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %15, <4 x i1> splat (i1 true), <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %16 = getelementptr i8, <4 x ptr> %gep, i64 108
  %wide.masked.gather31 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %16, <4 x i1> splat (i1 true), <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %17 = getelementptr i8, <4 x ptr> %gep, i64 104
  %wide.masked.gather30 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %17, <4 x i1> splat (i1 true), <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %18 = getelementptr i8, <4 x ptr> %gep, i64 100
  %wide.masked.gather29 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %18, <4 x i1> splat (i1 true), <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %19 = getelementptr i8, <4 x ptr> %gep, i64 96
  %wide.masked.gather28 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %19, <4 x i1> splat (i1 true), <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %20 = getelementptr i8, <4 x ptr> %gep, i64 92
  %wide.masked.gather27 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %20, <4 x i1> splat (i1 true), <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %21 = getelementptr i8, <4 x ptr> %gep, i64 88
  %wide.masked.gather26 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %21, <4 x i1> splat (i1 true), <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %22 = getelementptr i8, <4 x ptr> %gep, i64 84
  %wide.masked.gather25 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %22, <4 x i1> splat (i1 true), <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %23 = getelementptr i8, <4 x ptr> %gep, i64 80
  %wide.masked.gather24 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %23, <4 x i1> splat (i1 true), <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %24 = getelementptr i8, <4 x ptr> %gep, i64 76
  %wide.masked.gather23 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %24, <4 x i1> splat (i1 true), <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %25 = getelementptr i8, <4 x ptr> %gep, i64 72
  %wide.masked.gather22 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %25, <4 x i1> splat (i1 true), <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %26 = getelementptr i8, <4 x ptr> %gep, i64 68
  %wide.masked.gather21 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %26, <4 x i1> splat (i1 true), <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %27 = getelementptr i8, <4 x ptr> %gep, i64 64
  %wide.masked.gather20 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %27, <4 x i1> splat (i1 true), <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %28 = getelementptr i8, <4 x ptr> %gep, i64 60
  %wide.masked.gather19 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %28, <4 x i1> splat (i1 true), <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %29 = getelementptr i8, <4 x ptr> %gep, i64 56
  %wide.masked.gather18 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %29, <4 x i1> splat (i1 true), <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %30 = getelementptr i8, <4 x ptr> %gep, i64 52
  %wide.masked.gather17 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %30, <4 x i1> splat (i1 true), <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %31 = getelementptr i8, <4 x ptr> %gep, i64 48
  %wide.masked.gather16 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %31, <4 x i1> splat (i1 true), <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %32 = getelementptr i8, <4 x ptr> %gep, i64 44
  %wide.masked.gather15 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %32, <4 x i1> splat (i1 true), <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %33 = getelementptr i8, <4 x ptr> %gep, i64 40
  %wide.masked.gather14 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %33, <4 x i1> splat (i1 true), <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %34 = getelementptr i8, <4 x ptr> %gep, i64 36
  %wide.masked.gather13 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %34, <4 x i1> splat (i1 true), <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %35 = getelementptr i8, <4 x ptr> %gep, i64 32
  %wide.masked.gather12 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %35, <4 x i1> splat (i1 true), <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %36 = getelementptr i8, <4 x ptr> %gep, i64 28
  %wide.masked.gather11 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %36, <4 x i1> splat (i1 true), <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %37 = getelementptr i8, <4 x ptr> %gep, i64 24
  %wide.masked.gather10 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %37, <4 x i1> splat (i1 true), <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %38 = getelementptr i8, <4 x ptr> %gep, i64 20
  %wide.masked.gather9 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %38, <4 x i1> splat (i1 true), <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %39 = getelementptr i8, <4 x ptr> %gep, i64 16
  %wide.masked.gather8 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %39, <4 x i1> splat (i1 true), <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %40 = getelementptr i8, <4 x ptr> %gep, i64 12
  %wide.masked.gather7 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %40, <4 x i1> splat (i1 true), <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %41 = getelementptr i8, <4 x ptr> %gep, i64 8
  %wide.masked.gather6 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %41, <4 x i1> splat (i1 true), <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %42 = getelementptr i8, <4 x ptr> %gep, i64 4
  %wide.masked.gather5 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %42, <4 x i1> splat (i1 true), <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %wide.masked.gather = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %gep, <4 x i1> splat (i1 true), <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %43 = add <4 x i32> %wide.masked.gather, %10
  %44 = add <4 x i32> %wide.masked.gather5, %43
  %45 = add <4 x i32> %wide.masked.gather6, %44
  %46 = add <4 x i32> %wide.masked.gather7, %45
  %47 = add <4 x i32> %wide.masked.gather8, %46
  %48 = add <4 x i32> %wide.masked.gather9, %47
  %49 = add <4 x i32> %wide.masked.gather10, %48
  %50 = add <4 x i32> %wide.masked.gather11, %49
  %51 = add <4 x i32> %wide.masked.gather12, %50
  %52 = add <4 x i32> %wide.masked.gather13, %51
  %53 = add <4 x i32> %wide.masked.gather14, %52
  %54 = add <4 x i32> %wide.masked.gather15, %53
  %55 = add <4 x i32> %wide.masked.gather16, %54
  %56 = add <4 x i32> %wide.masked.gather17, %55
  %57 = add <4 x i32> %wide.masked.gather18, %56
  %58 = add <4 x i32> %wide.masked.gather19, %57
  %59 = add <4 x i32> %wide.masked.gather20, %58
  %60 = add <4 x i32> %wide.masked.gather21, %59
  %61 = add <4 x i32> %wide.masked.gather22, %60
  %62 = add <4 x i32> %wide.masked.gather23, %61
  %63 = add <4 x i32> %wide.masked.gather24, %62
  %64 = add <4 x i32> %wide.masked.gather25, %63
  %65 = add <4 x i32> %wide.masked.gather26, %64
  %66 = add <4 x i32> %wide.masked.gather27, %65
  %67 = add <4 x i32> %wide.masked.gather28, %66
  %68 = add <4 x i32> %wide.masked.gather29, %67
  %69 = add <4 x i32> %wide.masked.gather30, %68
  %70 = add <4 x i32> %wide.masked.gather31, %69
  %71 = add <4 x i32> %wide.masked.gather32, %70
  %72 = add <4 x i32> %wide.masked.gather33, %71
  %73 = add <4 x i32> %wide.masked.gather34, %72
  %74 = add <4 x i32> %wide.masked.gather35, %73
  %75 = tail call i32 @llvm.vector.reduce.add.v4i32(<4 x i32> %74)
  %76 = getelementptr inbounds nuw i32, ptr %8, i64 %11
  store i32 %75, ptr %76, align 4, !alias.scope !12, !noalias !16
  %77 = add nuw nsw i64 %11, 1
  %exitcond4.not = icmp eq i64 %77, 360
  br i1 %exitcond4.not, label %wrapped_reduce-window_wrapped.exit, label %.preheader2, !llvm.loop !17

wrapped_reduce-window_wrapped.exit:               ; preds = %.preheader2
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr>, <4 x i1>, <4 x i32>) #2

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.vector.reduce.add.v4i32(<4 x i32>) #3

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #3 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 3}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 184320}
!5 = !{i64 4}
!6 = !{i64 1440}
!7 = !{!8}
!8 = distinct !{!8, !9, !"wrapped_reduce-window_wrapped: argument 0"}
!9 = distinct !{!9, !"wrapped_reduce-window_wrapped"}
!10 = !{!11}
!11 = distinct !{!11, !9, !"wrapped_reduce-window_wrapped: argument 1"}
!12 = !{!13}
!13 = distinct !{!13, !9, !"wrapped_reduce-window_wrapped: argument 2"}
!14 = !{!8, !13}
!15 = !{!11, !13}
!16 = !{!8, !11}
!17 = distinct !{!17, !18}
!18 = !{!"llvm.loop.unroll.disable"}
