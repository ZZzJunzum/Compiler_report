; ModuleID = '__compute_module_wrapped_reduce-window.1_kernel_module'
source_filename = "__compute_module_wrapped_reduce-window.1_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @wrapped_reduce-window.1(ptr readonly captures(none) %0) local_unnamed_addr #0 {
vector.ph:
  %1 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %2 = load ptr, ptr %1, align 8, !invariant.load !3
  %3 = load ptr, ptr %2, align 8, !invariant.load !3, !dereferenceable !4
  %4 = getelementptr inbounds nuw i8, ptr %2, i64 32
  %5 = load ptr, ptr %4, align 8, !invariant.load !3, !dereferenceable !5
  tail call void @llvm.experimental.noalias.scope.decl(metadata !6)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !11)
  %6 = getelementptr inbounds nuw i8, ptr %2, i64 16
  %7 = load ptr, ptr %6, align 8, !invariant.load !3, !dereferenceable !13
  %8 = load i32, ptr %7, align 4, !invariant.load !3, !alias.scope !9, !noalias !14
  %broadcast.splatinsert = insertelement <4 x i32> poison, i32 %8, i64 0
  %broadcast.splat = shufflevector <4 x i32> %broadcast.splatinsert, <4 x i32> poison, <4 x i32> zeroinitializer
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %vector.ph
  %index = phi i64 [ 0, %vector.ph ], [ %index.next, %vector.body ]
  %vec.ind = phi <4 x i64> [ <i64 0, i64 1, i64 2, i64 3>, %vector.ph ], [ %vec.ind.next, %vector.body ]
  %9 = icmp ult <4 x i64> %vec.ind, splat (i64 12)
  %10 = shl nuw nsw <4 x i64> %vec.ind, splat (i64 5)
  %11 = add nsw <4 x i64> %10, splat (i64 -12)
  %12 = icmp ult <4 x i64> %11, splat (i64 360)
  %13 = select <4 x i1> %9, <4 x i1> %12, <4 x i1> zeroinitializer
  %14 = getelementptr i32, ptr %3, <4 x i64> %10
  %15 = getelementptr i8, <4 x ptr> %14, i64 -48
  %wide.masked.gather = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %15, <4 x i1> %13, <4 x i32> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %16 = select <4 x i1> %12, <4 x i32> %wide.masked.gather, <4 x i32> zeroinitializer
  %predphi = add <4 x i32> %broadcast.splat, %16
  %17 = add nsw <4 x i64> %10, splat (i64 -11)
  %18 = icmp ult <4 x i64> %17, splat (i64 360)
  %19 = select <4 x i1> %9, <4 x i1> %18, <4 x i1> zeroinitializer
  %20 = getelementptr i8, <4 x ptr> %14, i64 -44
  %wide.masked.gather9 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %20, <4 x i1> %19, <4 x i32> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %21 = select <4 x i1> %18, <4 x i32> %wide.masked.gather9, <4 x i32> zeroinitializer
  %predphi10 = add <4 x i32> %predphi, %21
  %22 = add nsw <4 x i64> %10, splat (i64 -10)
  %23 = icmp ult <4 x i64> %22, splat (i64 360)
  %24 = select <4 x i1> %9, <4 x i1> %23, <4 x i1> zeroinitializer
  %25 = getelementptr i8, <4 x ptr> %14, i64 -40
  %wide.masked.gather11 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %25, <4 x i1> %24, <4 x i32> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %26 = select <4 x i1> %23, <4 x i32> %wide.masked.gather11, <4 x i32> zeroinitializer
  %predphi12 = add <4 x i32> %predphi10, %26
  %27 = add nsw <4 x i64> %10, splat (i64 -9)
  %28 = icmp ult <4 x i64> %27, splat (i64 360)
  %29 = select <4 x i1> %9, <4 x i1> %28, <4 x i1> zeroinitializer
  %30 = getelementptr i8, <4 x ptr> %14, i64 -36
  %wide.masked.gather13 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %30, <4 x i1> %29, <4 x i32> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %31 = select <4 x i1> %28, <4 x i32> %wide.masked.gather13, <4 x i32> zeroinitializer
  %predphi14 = add <4 x i32> %predphi12, %31
  %32 = add nsw <4 x i64> %10, splat (i64 -8)
  %33 = icmp ult <4 x i64> %32, splat (i64 360)
  %34 = select <4 x i1> %9, <4 x i1> %33, <4 x i1> zeroinitializer
  %35 = getelementptr i8, <4 x ptr> %14, i64 -32
  %wide.masked.gather15 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %35, <4 x i1> %34, <4 x i32> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %36 = select <4 x i1> %33, <4 x i32> %wide.masked.gather15, <4 x i32> zeroinitializer
  %predphi16 = add <4 x i32> %predphi14, %36
  %37 = add nsw <4 x i64> %10, splat (i64 -7)
  %38 = icmp ult <4 x i64> %37, splat (i64 360)
  %39 = select <4 x i1> %9, <4 x i1> %38, <4 x i1> zeroinitializer
  %40 = getelementptr i8, <4 x ptr> %14, i64 -28
  %wide.masked.gather17 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %40, <4 x i1> %39, <4 x i32> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %41 = select <4 x i1> %38, <4 x i32> %wide.masked.gather17, <4 x i32> zeroinitializer
  %predphi18 = add <4 x i32> %predphi16, %41
  %42 = add nsw <4 x i64> %10, splat (i64 -6)
  %43 = icmp ult <4 x i64> %42, splat (i64 360)
  %44 = select <4 x i1> %9, <4 x i1> %43, <4 x i1> zeroinitializer
  %45 = getelementptr i8, <4 x ptr> %14, i64 -24
  %wide.masked.gather19 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %45, <4 x i1> %44, <4 x i32> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %46 = select <4 x i1> %43, <4 x i32> %wide.masked.gather19, <4 x i32> zeroinitializer
  %predphi20 = add <4 x i32> %predphi18, %46
  %47 = add nsw <4 x i64> %10, splat (i64 -5)
  %48 = icmp ult <4 x i64> %47, splat (i64 360)
  %49 = select <4 x i1> %9, <4 x i1> %48, <4 x i1> zeroinitializer
  %50 = getelementptr i8, <4 x ptr> %14, i64 -20
  %wide.masked.gather21 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %50, <4 x i1> %49, <4 x i32> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %51 = select <4 x i1> %48, <4 x i32> %wide.masked.gather21, <4 x i32> zeroinitializer
  %predphi22 = add <4 x i32> %predphi20, %51
  %52 = add nsw <4 x i64> %10, splat (i64 -4)
  %53 = icmp ult <4 x i64> %52, splat (i64 360)
  %54 = select <4 x i1> %9, <4 x i1> %53, <4 x i1> zeroinitializer
  %55 = getelementptr i8, <4 x ptr> %14, i64 -16
  %wide.masked.gather23 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %55, <4 x i1> %54, <4 x i32> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %56 = select <4 x i1> %53, <4 x i32> %wide.masked.gather23, <4 x i32> zeroinitializer
  %predphi24 = add <4 x i32> %predphi22, %56
  %57 = add nsw <4 x i64> %10, splat (i64 -3)
  %58 = icmp ult <4 x i64> %57, splat (i64 360)
  %59 = select <4 x i1> %9, <4 x i1> %58, <4 x i1> zeroinitializer
  %60 = getelementptr i8, <4 x ptr> %14, i64 -12
  %wide.masked.gather25 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %60, <4 x i1> %59, <4 x i32> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %61 = select <4 x i1> %58, <4 x i32> %wide.masked.gather25, <4 x i32> zeroinitializer
  %predphi26 = add <4 x i32> %predphi24, %61
  %62 = add nsw <4 x i64> %10, splat (i64 -2)
  %63 = icmp ult <4 x i64> %62, splat (i64 360)
  %64 = select <4 x i1> %9, <4 x i1> %63, <4 x i1> zeroinitializer
  %65 = getelementptr i8, <4 x ptr> %14, i64 -8
  %wide.masked.gather27 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %65, <4 x i1> %64, <4 x i32> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %66 = select <4 x i1> %63, <4 x i32> %wide.masked.gather27, <4 x i32> zeroinitializer
  %predphi28 = add <4 x i32> %predphi26, %66
  %67 = add nsw <4 x i64> %10, splat (i64 -1)
  %68 = icmp ult <4 x i64> %67, splat (i64 360)
  %69 = select <4 x i1> %9, <4 x i1> %68, <4 x i1> zeroinitializer
  %70 = getelementptr i8, <4 x ptr> %14, i64 -4
  %wide.masked.gather29 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %70, <4 x i1> %69, <4 x i32> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %71 = select <4 x i1> %68, <4 x i32> %wide.masked.gather29, <4 x i32> zeroinitializer
  %predphi30 = add <4 x i32> %predphi28, %71
  %wide.masked.gather31 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %14, <4 x i1> %9, <4 x i32> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %72 = add <4 x i32> %wide.masked.gather31, %predphi30
  %73 = getelementptr i8, <4 x ptr> %14, i64 4
  %wide.masked.gather32 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %73, <4 x i1> %9, <4 x i32> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %74 = add <4 x i32> %wide.masked.gather32, %72
  %75 = getelementptr i8, <4 x ptr> %14, i64 8
  %wide.masked.gather33 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %75, <4 x i1> %9, <4 x i32> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %76 = add <4 x i32> %wide.masked.gather33, %74
  %77 = getelementptr i8, <4 x ptr> %14, i64 12
  %wide.masked.gather34 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %77, <4 x i1> %9, <4 x i32> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %78 = add <4 x i32> %wide.masked.gather34, %76
  %79 = getelementptr i8, <4 x ptr> %14, i64 16
  %wide.masked.gather35 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %79, <4 x i1> %9, <4 x i32> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %80 = add <4 x i32> %wide.masked.gather35, %78
  %81 = getelementptr i8, <4 x ptr> %14, i64 20
  %wide.masked.gather36 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %81, <4 x i1> %9, <4 x i32> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %82 = add <4 x i32> %wide.masked.gather36, %80
  %83 = getelementptr i8, <4 x ptr> %14, i64 24
  %wide.masked.gather37 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %83, <4 x i1> %9, <4 x i32> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %84 = add <4 x i32> %wide.masked.gather37, %82
  %85 = getelementptr i8, <4 x ptr> %14, i64 28
  %wide.masked.gather38 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %85, <4 x i1> %9, <4 x i32> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %86 = add <4 x i32> %wide.masked.gather38, %84
  %87 = or disjoint <4 x i64> %10, splat (i64 8)
  %88 = icmp samesign ult <4 x i64> %87, splat (i64 360)
  %89 = select <4 x i1> %9, <4 x i1> %88, <4 x i1> zeroinitializer
  %90 = getelementptr i8, <4 x ptr> %14, i64 32
  %wide.masked.gather39 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %90, <4 x i1> %89, <4 x i32> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %91 = select <4 x i1> %88, <4 x i32> %wide.masked.gather39, <4 x i32> zeroinitializer
  %predphi40 = add <4 x i32> %86, %91
  %92 = getelementptr i8, <4 x ptr> %14, i64 36
  %wide.masked.gather41 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %92, <4 x i1> %89, <4 x i32> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %93 = add <4 x i32> %wide.masked.gather41, %predphi40
  %94 = getelementptr i8, <4 x ptr> %14, i64 40
  %wide.masked.gather43 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %94, <4 x i1> %89, <4 x i32> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %95 = add <4 x i32> %wide.masked.gather43, %93
  %96 = getelementptr i8, <4 x ptr> %14, i64 44
  %wide.masked.gather45 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %96, <4 x i1> %89, <4 x i32> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %97 = add <4 x i32> %wide.masked.gather45, %95
  %98 = getelementptr i8, <4 x ptr> %14, i64 48
  %wide.masked.gather47 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %98, <4 x i1> %89, <4 x i32> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %99 = add <4 x i32> %wide.masked.gather47, %97
  %100 = getelementptr i8, <4 x ptr> %14, i64 52
  %wide.masked.gather49 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %100, <4 x i1> %89, <4 x i32> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %101 = add <4 x i32> %wide.masked.gather49, %99
  %102 = getelementptr i8, <4 x ptr> %14, i64 56
  %wide.masked.gather51 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %102, <4 x i1> %89, <4 x i32> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %103 = add <4 x i32> %wide.masked.gather51, %101
  %104 = getelementptr i8, <4 x ptr> %14, i64 60
  %wide.masked.gather53 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %104, <4 x i1> %89, <4 x i32> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %105 = add <4 x i32> %wide.masked.gather53, %103
  %predphi54 = select <4 x i1> %88, <4 x i32> %105, <4 x i32> %86
  %106 = or disjoint <4 x i64> %10, splat (i64 16)
  %107 = icmp samesign ult <4 x i64> %106, splat (i64 360)
  %108 = select <4 x i1> %9, <4 x i1> %107, <4 x i1> zeroinitializer
  %109 = getelementptr i8, <4 x ptr> %14, i64 64
  %wide.masked.gather55 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %109, <4 x i1> %108, <4 x i32> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %110 = select <4 x i1> %107, <4 x i32> %wide.masked.gather55, <4 x i32> zeroinitializer
  %predphi56 = add <4 x i32> %predphi54, %110
  %111 = getelementptr i8, <4 x ptr> %14, i64 68
  %wide.masked.gather57 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %111, <4 x i1> %108, <4 x i32> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %112 = add <4 x i32> %wide.masked.gather57, %predphi56
  %113 = getelementptr i8, <4 x ptr> %14, i64 72
  %wide.masked.gather59 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %113, <4 x i1> %108, <4 x i32> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %114 = add <4 x i32> %wide.masked.gather59, %112
  %predphi60 = select <4 x i1> %107, <4 x i32> %114, <4 x i32> %predphi54
  %115 = or disjoint <4 x i64> %10, splat (i64 31)
  %116 = icmp samesign ult <4 x i64> %115, splat (i64 372)
  %117 = select <4 x i1> %9, <4 x i1> %116, <4 x i1> zeroinitializer
  %118 = getelementptr i32, ptr %3, <4 x i64> %115
  %119 = getelementptr i8, <4 x ptr> %118, i64 -48
  %wide.masked.gather61 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %119, <4 x i1> %117, <4 x i32> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %120 = select <4 x i1> %116, <4 x i32> %wide.masked.gather61, <4 x i32> zeroinitializer
  %predphi62 = add <4 x i32> %predphi60, %120
  %121 = getelementptr inbounds nuw i32, ptr %5, i64 %index
  tail call void @llvm.masked.store.v4i32.p0(<4 x i32> %predphi62, ptr align 4 %121, <4 x i1> %9), !alias.scope !11, !noalias !16
  %index.next = add nuw i64 %index, 4
  %vec.ind.next = add <4 x i64> %vec.ind, splat (i64 4)
  %122 = icmp eq i64 %index.next, 12
  br i1 %122, label %wrapped_reduce-window.1_wrapped.exit, label %vector.body, !llvm.loop !17

wrapped_reduce-window.1_wrapped.exit:             ; preds = %vector.body
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr>, <4 x i1>, <4 x i32>) #2

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.masked.store.v4i32.p0(<4 x i32>, ptr captures(none), <4 x i1>) #3

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 4}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 1440}
!5 = !{i64 48}
!6 = !{!7}
!7 = distinct !{!7, !8, !"wrapped_reduce-window.1_wrapped: argument 0"}
!8 = distinct !{!8, !"wrapped_reduce-window.1_wrapped"}
!9 = !{!10}
!10 = distinct !{!10, !8, !"wrapped_reduce-window.1_wrapped: argument 1"}
!11 = !{!12}
!12 = distinct !{!12, !8, !"wrapped_reduce-window.1_wrapped: argument 2"}
!13 = !{i64 4}
!14 = !{!7, !12}
!15 = !{!10, !12}
!16 = !{!7, !10}
!17 = distinct !{!17, !18, !19, !20}
!18 = !{!"llvm.loop.unroll.disable"}
!19 = !{!"llvm.loop.isvectorized", i32 1}
!20 = !{!"llvm.loop.unroll.runtime.disable"}
