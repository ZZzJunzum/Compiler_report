; ModuleID = '__compute_module_wrapped_reduce_kernel_module'
source_filename = "__compute_module_wrapped_reduce_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @wrapped_reduce(ptr readonly captures(none) %0) local_unnamed_addr #0 {
wrapped_reduce_wrapped.exit:
  %1 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %2 = load ptr, ptr %1, align 8, !invariant.load !3
  %3 = load ptr, ptr %2, align 8, !invariant.load !3, !dereferenceable !4
  %4 = getelementptr inbounds nuw i8, ptr %2, i64 16
  %5 = load ptr, ptr %4, align 8, !invariant.load !3, !dereferenceable !5
  tail call void @llvm.experimental.noalias.scope.decl(metadata !6)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !11)
  %6 = load i32, ptr %5, align 4, !invariant.load !3, !alias.scope !9, !noalias !13
  %7 = load i32, ptr %3, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %8 = add i32 %7, %6
  %9 = getelementptr inbounds nuw i8, ptr %3, i64 4
  %10 = load i32, ptr %9, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %11 = add i32 %10, %8
  %12 = getelementptr inbounds nuw i8, ptr %3, i64 8
  %13 = load i32, ptr %12, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %14 = add i32 %13, %11
  %15 = getelementptr inbounds nuw i8, ptr %3, i64 12
  %16 = load i32, ptr %15, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %17 = add i32 %16, %14
  %18 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %19 = load i32, ptr %18, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %20 = add i32 %19, %17
  %21 = getelementptr inbounds nuw i8, ptr %3, i64 20
  %22 = load i32, ptr %21, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %23 = add i32 %22, %20
  %24 = getelementptr inbounds nuw i8, ptr %3, i64 24
  %25 = load i32, ptr %24, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %26 = add i32 %25, %23
  %27 = getelementptr inbounds nuw i8, ptr %3, i64 28
  %28 = load i32, ptr %27, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %29 = add i32 %28, %26
  %30 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %31 = load i32, ptr %30, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %32 = add i32 %31, %29
  %33 = getelementptr inbounds nuw i8, ptr %3, i64 36
  %34 = load i32, ptr %33, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %35 = add i32 %34, %32
  %36 = getelementptr inbounds nuw i8, ptr %3, i64 40
  %37 = load i32, ptr %36, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %38 = add i32 %37, %35
  %39 = getelementptr inbounds nuw i8, ptr %3, i64 44
  %40 = load i32, ptr %39, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %41 = add i32 %40, %38
  %42 = getelementptr inbounds nuw i8, ptr %2, i64 32
  %43 = load ptr, ptr %42, align 8, !invariant.load !3, !dereferenceable !5
  store i32 %41, ptr %43, align 4, !alias.scope !11, !noalias !15
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

attributes #0 = { mustprogress nofree norecurse nosync nounwind willreturn memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 2}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 48}
!5 = !{i64 4}
!6 = !{!7}
!7 = distinct !{!7, !8, !"wrapped_reduce_wrapped: argument 0"}
!8 = distinct !{!8, !"wrapped_reduce_wrapped"}
!9 = !{!10}
!10 = distinct !{!10, !8, !"wrapped_reduce_wrapped: argument 1"}
!11 = !{!12}
!12 = distinct !{!12, !8, !"wrapped_reduce_wrapped: argument 2"}
!13 = !{!7, !12}
!14 = !{!10, !12}
!15 = !{!7, !10}
