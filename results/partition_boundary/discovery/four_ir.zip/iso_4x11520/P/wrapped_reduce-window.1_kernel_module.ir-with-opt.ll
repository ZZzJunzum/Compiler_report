; ModuleID = '__compute_module_wrapped_reduce-window.1_kernel_module'
source_filename = "__compute_module_wrapped_reduce-window.1_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @wrapped_reduce-window.1(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !5
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !6
  tail call void @llvm.experimental.noalias.scope.decl(metadata !7)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !10)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !12)
  %9 = load i32, ptr %6, align 4, !invariant.load !3, !alias.scope !10, !noalias !14
  br label %.preheader

.preheader:                                       ; preds = %1, %176
  %10 = phi i64 [ 0, %1 ], [ %177, %176 ]
  %.idx1 = mul nuw nsw i64 %10, 1440
  %invariant.gep3 = getelementptr i8, ptr %4, i64 %.idx1
  %.idx = mul nuw nsw i64 %10, 48
  %11 = getelementptr i8, ptr %8, i64 %.idx
  br label %12

12:                                               ; preds = %.preheader, %172
  %13 = phi i64 [ 0, %.preheader ], [ %175, %172 ]
  %14 = shl nuw nsw i64 %13, 5
  %15 = add nsw i64 %14, -12
  %gep4 = getelementptr i32, ptr %invariant.gep3, i64 %14
  %16 = icmp ult i64 %15, 360
  br i1 %16, label %17, label %21

17:                                               ; preds = %12
  %18 = getelementptr i8, ptr %gep4, i64 -48
  %19 = load i32, ptr %18, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %20 = add i32 %19, %9
  br label %21

21:                                               ; preds = %12, %17
  %22 = phi i32 [ %20, %17 ], [ %9, %12 ]
  %23 = add nsw i64 %14, -11
  %24 = icmp ult i64 %23, 360
  br i1 %24, label %25, label %29

25:                                               ; preds = %21
  %26 = getelementptr i8, ptr %gep4, i64 -44
  %27 = load i32, ptr %26, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %28 = add i32 %27, %22
  br label %29

29:                                               ; preds = %25, %21
  %30 = phi i32 [ %28, %25 ], [ %22, %21 ]
  %31 = add nsw i64 %14, -10
  %32 = icmp ult i64 %31, 360
  br i1 %32, label %33, label %37

33:                                               ; preds = %29
  %34 = getelementptr i8, ptr %gep4, i64 -40
  %35 = load i32, ptr %34, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %36 = add i32 %35, %30
  br label %37

37:                                               ; preds = %33, %29
  %38 = phi i32 [ %36, %33 ], [ %30, %29 ]
  %39 = add nsw i64 %14, -9
  %40 = icmp ult i64 %39, 360
  br i1 %40, label %41, label %45

41:                                               ; preds = %37
  %42 = getelementptr i8, ptr %gep4, i64 -36
  %43 = load i32, ptr %42, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %44 = add i32 %43, %38
  br label %45

45:                                               ; preds = %41, %37
  %46 = phi i32 [ %44, %41 ], [ %38, %37 ]
  %47 = add nsw i64 %14, -8
  %48 = icmp ult i64 %47, 360
  br i1 %48, label %49, label %53

49:                                               ; preds = %45
  %50 = getelementptr i8, ptr %gep4, i64 -32
  %51 = load i32, ptr %50, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %52 = add i32 %51, %46
  br label %53

53:                                               ; preds = %49, %45
  %54 = phi i32 [ %52, %49 ], [ %46, %45 ]
  %55 = add nsw i64 %14, -7
  %56 = icmp ult i64 %55, 360
  br i1 %56, label %57, label %61

57:                                               ; preds = %53
  %58 = getelementptr i8, ptr %gep4, i64 -28
  %59 = load i32, ptr %58, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %60 = add i32 %59, %54
  br label %61

61:                                               ; preds = %57, %53
  %62 = phi i32 [ %60, %57 ], [ %54, %53 ]
  %63 = add nsw i64 %14, -6
  %64 = icmp ult i64 %63, 360
  br i1 %64, label %65, label %69

65:                                               ; preds = %61
  %66 = getelementptr i8, ptr %gep4, i64 -24
  %67 = load i32, ptr %66, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %68 = add i32 %67, %62
  br label %69

69:                                               ; preds = %65, %61
  %70 = phi i32 [ %68, %65 ], [ %62, %61 ]
  %71 = add nsw i64 %14, -5
  %72 = icmp ult i64 %71, 360
  br i1 %72, label %73, label %77

73:                                               ; preds = %69
  %74 = getelementptr i8, ptr %gep4, i64 -20
  %75 = load i32, ptr %74, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %76 = add i32 %75, %70
  br label %77

77:                                               ; preds = %73, %69
  %78 = phi i32 [ %76, %73 ], [ %70, %69 ]
  %79 = add nsw i64 %14, -4
  %80 = icmp ult i64 %79, 360
  br i1 %80, label %81, label %85

81:                                               ; preds = %77
  %82 = getelementptr i8, ptr %gep4, i64 -16
  %83 = load i32, ptr %82, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %84 = add i32 %83, %78
  br label %85

85:                                               ; preds = %81, %77
  %86 = phi i32 [ %84, %81 ], [ %78, %77 ]
  %87 = add nsw i64 %14, -3
  %88 = icmp ult i64 %87, 360
  br i1 %88, label %89, label %93

89:                                               ; preds = %85
  %90 = getelementptr i8, ptr %gep4, i64 -12
  %91 = load i32, ptr %90, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %92 = add i32 %91, %86
  br label %93

93:                                               ; preds = %89, %85
  %94 = phi i32 [ %92, %89 ], [ %86, %85 ]
  %95 = add nsw i64 %14, -2
  %96 = icmp ult i64 %95, 360
  br i1 %96, label %97, label %101

97:                                               ; preds = %93
  %98 = getelementptr i8, ptr %gep4, i64 -8
  %99 = load i32, ptr %98, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %100 = add i32 %99, %94
  br label %101

101:                                              ; preds = %97, %93
  %102 = phi i32 [ %100, %97 ], [ %94, %93 ]
  %103 = add nsw i64 %14, -1
  %104 = icmp ult i64 %103, 360
  br i1 %104, label %105, label %109

105:                                              ; preds = %101
  %106 = getelementptr i8, ptr %gep4, i64 -4
  %107 = load i32, ptr %106, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %108 = add i32 %107, %102
  br label %109

109:                                              ; preds = %105, %101
  %110 = phi i32 [ %108, %105 ], [ %102, %101 ]
  %111 = load i32, ptr %gep4, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %112 = add i32 %111, %110
  %113 = getelementptr i8, ptr %gep4, i64 4
  %114 = load i32, ptr %113, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %115 = add i32 %114, %112
  %116 = getelementptr i8, ptr %gep4, i64 8
  %117 = load i32, ptr %116, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %118 = add i32 %117, %115
  %119 = getelementptr i8, ptr %gep4, i64 12
  %120 = load i32, ptr %119, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %121 = add i32 %120, %118
  %122 = getelementptr i8, ptr %gep4, i64 16
  %123 = load i32, ptr %122, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %124 = add i32 %123, %121
  %125 = getelementptr i8, ptr %gep4, i64 20
  %126 = load i32, ptr %125, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %127 = add i32 %126, %124
  %128 = getelementptr i8, ptr %gep4, i64 24
  %129 = load i32, ptr %128, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %130 = add i32 %129, %127
  %131 = getelementptr i8, ptr %gep4, i64 28
  %132 = load i32, ptr %131, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %133 = add i32 %132, %130
  %134 = icmp samesign ult i64 %13, 11
  br i1 %134, label %135, label %172

135:                                              ; preds = %109
  %136 = getelementptr i8, ptr %gep4, i64 32
  %137 = load i32, ptr %136, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %138 = add i32 %137, %133
  %139 = getelementptr i8, ptr %gep4, i64 36
  %140 = load i32, ptr %139, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %141 = add i32 %140, %138
  %142 = getelementptr i8, ptr %gep4, i64 40
  %143 = load i32, ptr %142, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %144 = add i32 %143, %141
  %145 = getelementptr i8, ptr %gep4, i64 44
  %146 = load i32, ptr %145, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %147 = add i32 %146, %144
  %148 = getelementptr i8, ptr %gep4, i64 48
  %149 = load i32, ptr %148, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %150 = add i32 %149, %147
  %151 = getelementptr i8, ptr %gep4, i64 52
  %152 = load i32, ptr %151, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %153 = add i32 %152, %150
  %154 = getelementptr i8, ptr %gep4, i64 56
  %155 = load i32, ptr %154, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %156 = add i32 %155, %153
  %157 = getelementptr i8, ptr %gep4, i64 60
  %158 = load i32, ptr %157, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %159 = add i32 %158, %156
  %160 = getelementptr i8, ptr %gep4, i64 64
  %161 = load i32, ptr %160, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %162 = add i32 %161, %159
  %163 = getelementptr i8, ptr %gep4, i64 68
  %164 = load i32, ptr %163, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %165 = add i32 %164, %162
  %166 = getelementptr i8, ptr %gep4, i64 72
  %167 = load i32, ptr %166, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %168 = add i32 %167, %165
  %169 = getelementptr i8, ptr %gep4, i64 76
  %170 = load i32, ptr %169, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %171 = add i32 %170, %168
  br label %172

172:                                              ; preds = %109, %135
  %173 = phi i32 [ %171, %135 ], [ %133, %109 ]
  %174 = getelementptr i32, ptr %11, i64 %13
  store i32 %173, ptr %174, align 4, !alias.scope !12, !noalias !16
  %175 = add nuw nsw i64 %13, 1
  %exitcond.not = icmp eq i64 %175, 12
  br i1 %exitcond.not, label %176, label %12, !llvm.loop !17

176:                                              ; preds = %172
  %177 = add nuw nsw i64 %10, 1
  %exitcond5.not = icmp eq i64 %177, 4
  br i1 %exitcond5.not, label %wrapped_reduce-window.1_wrapped.exit, label %.preheader, !llvm.loop !17

wrapped_reduce-window.1_wrapped.exit:             ; preds = %176
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 5}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 5760}
!5 = !{i64 4}
!6 = !{i64 192}
!7 = !{!8}
!8 = distinct !{!8, !9, !"wrapped_reduce-window.1_wrapped: argument 0"}
!9 = distinct !{!9, !"wrapped_reduce-window.1_wrapped"}
!10 = !{!11}
!11 = distinct !{!11, !9, !"wrapped_reduce-window.1_wrapped: argument 1"}
!12 = !{!13}
!13 = distinct !{!13, !9, !"wrapped_reduce-window.1_wrapped: argument 2"}
!14 = !{!8, !13}
!15 = !{!11, !13}
!16 = !{!8, !11}
!17 = distinct !{!17, !18}
!18 = !{!"llvm.loop.unroll.disable"}
