; ModuleID = '__compute_module_shift-left_add_fusion_kernel_module'
source_filename = "__compute_module_shift-left_add_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @shift-left_add_fusion(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !4
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !4
  %9 = getelementptr inbounds nuw i8, ptr %3, i64 48
  %10 = load ptr, ptr %9, align 8, !invariant.load !3, !dereferenceable !5
  %11 = getelementptr inbounds nuw i8, ptr %3, i64 64
  %12 = load ptr, ptr %11, align 8, !invariant.load !3, !dereferenceable !4
  %13 = getelementptr inbounds nuw i8, ptr %3, i64 80
  %14 = load ptr, ptr %13, align 8, !invariant.load !3, !dereferenceable !5
  %15 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %16 = load ptr, ptr %15, align 8
  %17 = load i64, ptr %16, align 4, !invariant.load !3
  tail call void @llvm.experimental.noalias.scope.decl(metadata !6)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !11)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !13)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !15)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !17)
  %18 = icmp ult i64 %17, 2
  br i1 %18, label %19, label %shift-left_add_fusion_wrapped.exit

19:                                               ; preds = %1
  %20 = mul nuw nsw i64 %17, 23040
  br label %vector.ph

vector.ph:                                        ; preds = %19, %middle.block
  %21 = phi i1 [ true, %19 ], [ false, %middle.block ]
  %22 = phi i64 [ 0, %19 ], [ 11520, %middle.block ]
  %23 = add nuw nsw i64 %22, %20
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %vector.ph
  %index = phi i64 [ 0, %vector.ph ], [ %index.next.2, %vector.body ]
  %24 = add nuw nsw i64 %23, %index
  %25 = getelementptr inbounds nuw float, ptr %10, i64 %24
  %wide.load = load <8 x float>, ptr %25, align 4, !invariant.load !3, !alias.scope !13, !noalias !19
  %26 = getelementptr inbounds nuw float, ptr %12, i64 %index
  %wide.load3 = load <8 x float>, ptr %26, align 4, !invariant.load !3, !alias.scope !15, !noalias !20
  %27 = fmul <8 x float> %wide.load, %wide.load3
  %28 = getelementptr inbounds nuw float, ptr %8, i64 %index
  %wide.load4 = load <8 x float>, ptr %28, align 4, !invariant.load !3, !alias.scope !11, !noalias !21
  %29 = fadd <8 x float> %27, %wide.load4
  %30 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %29, <8 x float> zeroinitializer)
  %31 = getelementptr inbounds nuw float, ptr %6, i64 %index
  %wide.load5 = load <8 x float>, ptr %31, align 4, !invariant.load !3, !alias.scope !9, !noalias !22
  %32 = fmul <8 x float> %wide.load5, %30
  %33 = getelementptr inbounds nuw float, ptr %4, i64 %index
  %wide.load6 = load <8 x float>, ptr %33, align 4, !invariant.load !3, !alias.scope !6, !noalias !23
  %34 = fadd <8 x float> %wide.load6, %32
  %35 = fcmp ogt <8 x float> %34, zeroinitializer
  %36 = fcmp ogt <8 x float> %29, zeroinitializer
  %37 = zext <8 x i1> %36 to <8 x i32>
  %38 = select <8 x i1> %35, <8 x i32> splat (i32 16384), <8 x i32> zeroinitializer
  %39 = or disjoint <8 x i32> %38, %37
  %40 = getelementptr inbounds nuw i32, ptr %14, i64 %24
  store <8 x i32> %39, ptr %40, align 4, !alias.scope !17, !noalias !24
  %index.next = add nuw nsw i64 %index, 8
  %41 = add nuw nsw i64 %23, %index.next
  %42 = getelementptr inbounds nuw float, ptr %10, i64 %41
  %wide.load.1 = load <8 x float>, ptr %42, align 4, !invariant.load !3, !alias.scope !13, !noalias !19
  %43 = getelementptr inbounds nuw float, ptr %12, i64 %index.next
  %wide.load3.1 = load <8 x float>, ptr %43, align 4, !invariant.load !3, !alias.scope !15, !noalias !20
  %44 = fmul <8 x float> %wide.load.1, %wide.load3.1
  %45 = getelementptr inbounds nuw float, ptr %8, i64 %index.next
  %wide.load4.1 = load <8 x float>, ptr %45, align 4, !invariant.load !3, !alias.scope !11, !noalias !21
  %46 = fadd <8 x float> %44, %wide.load4.1
  %47 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %46, <8 x float> zeroinitializer)
  %48 = getelementptr inbounds nuw float, ptr %6, i64 %index.next
  %wide.load5.1 = load <8 x float>, ptr %48, align 4, !invariant.load !3, !alias.scope !9, !noalias !22
  %49 = fmul <8 x float> %wide.load5.1, %47
  %50 = getelementptr inbounds nuw float, ptr %4, i64 %index.next
  %wide.load6.1 = load <8 x float>, ptr %50, align 4, !invariant.load !3, !alias.scope !6, !noalias !23
  %51 = fadd <8 x float> %wide.load6.1, %49
  %52 = fcmp ogt <8 x float> %51, zeroinitializer
  %53 = fcmp ogt <8 x float> %46, zeroinitializer
  %54 = zext <8 x i1> %53 to <8 x i32>
  %55 = select <8 x i1> %52, <8 x i32> splat (i32 16384), <8 x i32> zeroinitializer
  %56 = or disjoint <8 x i32> %55, %54
  %57 = getelementptr inbounds nuw i32, ptr %14, i64 %41
  store <8 x i32> %56, ptr %57, align 4, !alias.scope !17, !noalias !24
  %index.next.1 = add nuw nsw i64 %index, 16
  %58 = add nuw nsw i64 %23, %index.next.1
  %59 = getelementptr inbounds nuw float, ptr %10, i64 %58
  %wide.load.2 = load <8 x float>, ptr %59, align 4, !invariant.load !3, !alias.scope !13, !noalias !19
  %60 = getelementptr inbounds nuw float, ptr %12, i64 %index.next.1
  %wide.load3.2 = load <8 x float>, ptr %60, align 4, !invariant.load !3, !alias.scope !15, !noalias !20
  %61 = fmul <8 x float> %wide.load.2, %wide.load3.2
  %62 = getelementptr inbounds nuw float, ptr %8, i64 %index.next.1
  %wide.load4.2 = load <8 x float>, ptr %62, align 4, !invariant.load !3, !alias.scope !11, !noalias !21
  %63 = fadd <8 x float> %61, %wide.load4.2
  %64 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %63, <8 x float> zeroinitializer)
  %65 = getelementptr inbounds nuw float, ptr %6, i64 %index.next.1
  %wide.load5.2 = load <8 x float>, ptr %65, align 4, !invariant.load !3, !alias.scope !9, !noalias !22
  %66 = fmul <8 x float> %wide.load5.2, %64
  %67 = getelementptr inbounds nuw float, ptr %4, i64 %index.next.1
  %wide.load6.2 = load <8 x float>, ptr %67, align 4, !invariant.load !3, !alias.scope !6, !noalias !23
  %68 = fadd <8 x float> %wide.load6.2, %66
  %69 = fcmp ogt <8 x float> %68, zeroinitializer
  %70 = fcmp ogt <8 x float> %63, zeroinitializer
  %71 = zext <8 x i1> %70 to <8 x i32>
  %72 = select <8 x i1> %69, <8 x i32> splat (i32 16384), <8 x i32> zeroinitializer
  %73 = or disjoint <8 x i32> %72, %71
  %74 = getelementptr inbounds nuw i32, ptr %14, i64 %58
  store <8 x i32> %73, ptr %74, align 4, !alias.scope !17, !noalias !24
  %index.next.2 = add nuw nsw i64 %index, 24
  %75 = icmp eq i64 %index.next.2, 11520
  br i1 %75, label %middle.block, label %vector.body, !llvm.loop !25

middle.block:                                     ; preds = %vector.body
  br i1 %21, label %vector.ph, label %shift-left_add_fusion_wrapped.exit, !llvm.loop !28

shift-left_add_fusion_wrapped.exit:               ; preds = %middle.block, %1
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.maximum.v8f32(<8 x float>, <8 x float>) #2

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 1}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 46080}
!5 = !{i64 184320}
!6 = !{!7}
!7 = distinct !{!7, !8, !"shift-left_add_fusion_wrapped: argument 0"}
!8 = distinct !{!8, !"shift-left_add_fusion_wrapped"}
!9 = !{!10}
!10 = distinct !{!10, !8, !"shift-left_add_fusion_wrapped: argument 1"}
!11 = !{!12}
!12 = distinct !{!12, !8, !"shift-left_add_fusion_wrapped: argument 2"}
!13 = !{!14}
!14 = distinct !{!14, !8, !"shift-left_add_fusion_wrapped: argument 3"}
!15 = !{!16}
!16 = distinct !{!16, !8, !"shift-left_add_fusion_wrapped: argument 4"}
!17 = !{!18}
!18 = distinct !{!18, !8, !"shift-left_add_fusion_wrapped: argument 5"}
!19 = !{!7, !10, !12, !16, !18}
!20 = !{!7, !10, !12, !14, !18}
!21 = !{!7, !10, !14, !16, !18}
!22 = !{!7, !12, !14, !16, !18}
!23 = !{!10, !12, !14, !16, !18}
!24 = !{!7, !10, !12, !14, !16}
!25 = distinct !{!25, !26, !27}
!26 = !{!"llvm.loop.isvectorized", i32 1}
!27 = !{!"llvm.loop.unroll.runtime.disable"}
!28 = distinct !{!28, !29}
!29 = !{!"llvm.loop.unroll.disable"}
