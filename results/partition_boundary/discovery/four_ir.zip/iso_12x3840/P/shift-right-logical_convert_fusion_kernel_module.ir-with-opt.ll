; ModuleID = '__compute_module_shift-right-logical_convert_fusion_kernel_module'
source_filename = "__compute_module_shift-right-logical_convert_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @shift-right-logical_convert_fusion(ptr readonly captures(none) %0) local_unnamed_addr #0 {
shift-right-logical_convert_fusion_wrapped.exit:
  %1 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %2 = load ptr, ptr %1, align 8, !invariant.load !3
  %3 = load ptr, ptr %2, align 8, !invariant.load !3, !dereferenceable !4
  %4 = getelementptr inbounds nuw i8, ptr %2, i64 16
  %5 = load ptr, ptr %4, align 8, !invariant.load !3, !dereferenceable !4
  tail call void @llvm.experimental.noalias.scope.decl(metadata !5)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !8)
  %6 = load i32, ptr %3, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %7 = lshr i32 %6, 12
  store i32 %7, ptr %5, align 4, !alias.scope !8, !noalias !5
  %8 = getelementptr inbounds nuw i8, ptr %3, i64 4
  %9 = load i32, ptr %8, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %10 = lshr i32 %9, 12
  %11 = getelementptr inbounds nuw i8, ptr %5, i64 4
  store i32 %10, ptr %11, align 4, !alias.scope !8, !noalias !5
  %12 = getelementptr inbounds nuw i8, ptr %3, i64 8
  %13 = load i32, ptr %12, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %14 = lshr i32 %13, 12
  %15 = getelementptr inbounds nuw i8, ptr %5, i64 8
  store i32 %14, ptr %15, align 4, !alias.scope !8, !noalias !5
  %16 = getelementptr inbounds nuw i8, ptr %3, i64 12
  %17 = load i32, ptr %16, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %18 = lshr i32 %17, 12
  %19 = getelementptr inbounds nuw i8, ptr %5, i64 12
  store i32 %18, ptr %19, align 4, !alias.scope !8, !noalias !5
  %20 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %21 = load i32, ptr %20, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %22 = lshr i32 %21, 12
  %23 = getelementptr inbounds nuw i8, ptr %5, i64 16
  store i32 %22, ptr %23, align 4, !alias.scope !8, !noalias !5
  %24 = getelementptr inbounds nuw i8, ptr %3, i64 20
  %25 = load i32, ptr %24, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %26 = lshr i32 %25, 12
  %27 = getelementptr inbounds nuw i8, ptr %5, i64 20
  store i32 %26, ptr %27, align 4, !alias.scope !8, !noalias !5
  %28 = getelementptr inbounds nuw i8, ptr %3, i64 24
  %29 = load i32, ptr %28, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %30 = lshr i32 %29, 12
  %31 = getelementptr inbounds nuw i8, ptr %5, i64 24
  store i32 %30, ptr %31, align 4, !alias.scope !8, !noalias !5
  %32 = getelementptr inbounds nuw i8, ptr %3, i64 28
  %33 = load i32, ptr %32, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %34 = lshr i32 %33, 12
  %35 = getelementptr inbounds nuw i8, ptr %5, i64 28
  store i32 %34, ptr %35, align 4, !alias.scope !8, !noalias !5
  %36 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %37 = load i32, ptr %36, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %38 = lshr i32 %37, 12
  %39 = getelementptr inbounds nuw i8, ptr %5, i64 32
  store i32 %38, ptr %39, align 4, !alias.scope !8, !noalias !5
  %40 = getelementptr inbounds nuw i8, ptr %3, i64 36
  %41 = load i32, ptr %40, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %42 = lshr i32 %41, 12
  %43 = getelementptr inbounds nuw i8, ptr %5, i64 36
  store i32 %42, ptr %43, align 4, !alias.scope !8, !noalias !5
  %44 = getelementptr inbounds nuw i8, ptr %3, i64 40
  %45 = load i32, ptr %44, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %46 = lshr i32 %45, 12
  %47 = getelementptr inbounds nuw i8, ptr %5, i64 40
  store i32 %46, ptr %47, align 4, !alias.scope !8, !noalias !5
  %48 = getelementptr inbounds nuw i8, ptr %3, i64 44
  %49 = load i32, ptr %48, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %50 = lshr i32 %49, 12
  %51 = getelementptr inbounds nuw i8, ptr %5, i64 44
  store i32 %50, ptr %51, align 4, !alias.scope !8, !noalias !5
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

attributes #0 = { mustprogress nofree norecurse nosync nounwind willreturn memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 2}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 48}
!5 = !{!6}
!6 = distinct !{!6, !7, !"shift-right-logical_convert_fusion_wrapped: argument 0"}
!7 = distinct !{!7, !"shift-right-logical_convert_fusion_wrapped"}
!8 = !{!9}
!9 = distinct !{!9, !7, !"shift-right-logical_convert_fusion_wrapped: argument 1"}
