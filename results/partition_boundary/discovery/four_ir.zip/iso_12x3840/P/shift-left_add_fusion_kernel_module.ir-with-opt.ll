; ModuleID = '__compute_module_shift-left_add_fusion_kernel_module'
source_filename = "__compute_module_shift-left_add_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @shift-left_add_fusion(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !4
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !4
  %9 = getelementptr inbounds nuw i8, ptr %3, i64 48
  %10 = load ptr, ptr %9, align 8, !invariant.load !3, !dereferenceable !5
  %11 = getelementptr inbounds nuw i8, ptr %3, i64 64
  %12 = load ptr, ptr %11, align 8, !invariant.load !3, !dereferenceable !4
  %13 = getelementptr inbounds nuw i8, ptr %3, i64 80
  %14 = load ptr, ptr %13, align 8, !invariant.load !3, !dereferenceable !5
  %15 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %16 = load ptr, ptr %15, align 8
  %17 = load i64, ptr %16, align 4, !invariant.load !3
  tail call void @llvm.experimental.noalias.scope.decl(metadata !6)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !11)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !13)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !15)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !17)
  %18 = icmp ult i64 %17, 12
  br i1 %18, label %vector.ph, label %shift-left_add_fusion_wrapped.exit

vector.ph:                                        ; preds = %1
  %19 = mul nuw nsw i64 %17, 3840
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %vector.ph
  %index = phi i64 [ 0, %vector.ph ], [ %index.next.2, %vector.body ]
  %20 = add nuw nsw i64 %index, %19
  %21 = getelementptr inbounds nuw float, ptr %10, i64 %20
  %wide.load = load <8 x float>, ptr %21, align 4, !invariant.load !3, !alias.scope !13, !noalias !19
  %22 = getelementptr inbounds nuw float, ptr %12, i64 %index
  %wide.load2 = load <8 x float>, ptr %22, align 4, !invariant.load !3, !alias.scope !15, !noalias !20
  %23 = fmul <8 x float> %wide.load, %wide.load2
  %24 = getelementptr inbounds nuw float, ptr %8, i64 %index
  %wide.load3 = load <8 x float>, ptr %24, align 4, !invariant.load !3, !alias.scope !11, !noalias !21
  %25 = fadd <8 x float> %23, %wide.load3
  %26 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %25, <8 x float> zeroinitializer)
  %27 = getelementptr inbounds nuw float, ptr %6, i64 %index
  %wide.load4 = load <8 x float>, ptr %27, align 4, !invariant.load !3, !alias.scope !9, !noalias !22
  %28 = fmul <8 x float> %wide.load4, %26
  %29 = getelementptr inbounds nuw float, ptr %4, i64 %index
  %wide.load5 = load <8 x float>, ptr %29, align 4, !invariant.load !3, !alias.scope !6, !noalias !23
  %30 = fadd <8 x float> %wide.load5, %28
  %31 = fcmp ogt <8 x float> %30, zeroinitializer
  %32 = fcmp ogt <8 x float> %25, zeroinitializer
  %33 = zext <8 x i1> %32 to <8 x i32>
  %34 = select <8 x i1> %31, <8 x i32> splat (i32 4096), <8 x i32> zeroinitializer
  %35 = or disjoint <8 x i32> %34, %33
  %36 = getelementptr inbounds nuw i32, ptr %14, i64 %20
  store <8 x i32> %35, ptr %36, align 4, !alias.scope !17, !noalias !24
  %index.next = add nuw nsw i64 %index, 8
  %37 = add nuw nsw i64 %index.next, %19
  %38 = getelementptr inbounds nuw float, ptr %10, i64 %37
  %wide.load.1 = load <8 x float>, ptr %38, align 4, !invariant.load !3, !alias.scope !13, !noalias !19
  %39 = getelementptr inbounds nuw float, ptr %12, i64 %index.next
  %wide.load2.1 = load <8 x float>, ptr %39, align 4, !invariant.load !3, !alias.scope !15, !noalias !20
  %40 = fmul <8 x float> %wide.load.1, %wide.load2.1
  %41 = getelementptr inbounds nuw float, ptr %8, i64 %index.next
  %wide.load3.1 = load <8 x float>, ptr %41, align 4, !invariant.load !3, !alias.scope !11, !noalias !21
  %42 = fadd <8 x float> %40, %wide.load3.1
  %43 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %42, <8 x float> zeroinitializer)
  %44 = getelementptr inbounds nuw float, ptr %6, i64 %index.next
  %wide.load4.1 = load <8 x float>, ptr %44, align 4, !invariant.load !3, !alias.scope !9, !noalias !22
  %45 = fmul <8 x float> %wide.load4.1, %43
  %46 = getelementptr inbounds nuw float, ptr %4, i64 %index.next
  %wide.load5.1 = load <8 x float>, ptr %46, align 4, !invariant.load !3, !alias.scope !6, !noalias !23
  %47 = fadd <8 x float> %wide.load5.1, %45
  %48 = fcmp ogt <8 x float> %47, zeroinitializer
  %49 = fcmp ogt <8 x float> %42, zeroinitializer
  %50 = zext <8 x i1> %49 to <8 x i32>
  %51 = select <8 x i1> %48, <8 x i32> splat (i32 4096), <8 x i32> zeroinitializer
  %52 = or disjoint <8 x i32> %51, %50
  %53 = getelementptr inbounds nuw i32, ptr %14, i64 %37
  store <8 x i32> %52, ptr %53, align 4, !alias.scope !17, !noalias !24
  %index.next.1 = add nuw nsw i64 %index, 16
  %54 = add nuw nsw i64 %index.next.1, %19
  %55 = getelementptr inbounds nuw float, ptr %10, i64 %54
  %wide.load.2 = load <8 x float>, ptr %55, align 4, !invariant.load !3, !alias.scope !13, !noalias !19
  %56 = getelementptr inbounds nuw float, ptr %12, i64 %index.next.1
  %wide.load2.2 = load <8 x float>, ptr %56, align 4, !invariant.load !3, !alias.scope !15, !noalias !20
  %57 = fmul <8 x float> %wide.load.2, %wide.load2.2
  %58 = getelementptr inbounds nuw float, ptr %8, i64 %index.next.1
  %wide.load3.2 = load <8 x float>, ptr %58, align 4, !invariant.load !3, !alias.scope !11, !noalias !21
  %59 = fadd <8 x float> %57, %wide.load3.2
  %60 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %59, <8 x float> zeroinitializer)
  %61 = getelementptr inbounds nuw float, ptr %6, i64 %index.next.1
  %wide.load4.2 = load <8 x float>, ptr %61, align 4, !invariant.load !3, !alias.scope !9, !noalias !22
  %62 = fmul <8 x float> %wide.load4.2, %60
  %63 = getelementptr inbounds nuw float, ptr %4, i64 %index.next.1
  %wide.load5.2 = load <8 x float>, ptr %63, align 4, !invariant.load !3, !alias.scope !6, !noalias !23
  %64 = fadd <8 x float> %wide.load5.2, %62
  %65 = fcmp ogt <8 x float> %64, zeroinitializer
  %66 = fcmp ogt <8 x float> %59, zeroinitializer
  %67 = zext <8 x i1> %66 to <8 x i32>
  %68 = select <8 x i1> %65, <8 x i32> splat (i32 4096), <8 x i32> zeroinitializer
  %69 = or disjoint <8 x i32> %68, %67
  %70 = getelementptr inbounds nuw i32, ptr %14, i64 %54
  store <8 x i32> %69, ptr %70, align 4, !alias.scope !17, !noalias !24
  %index.next.2 = add nuw nsw i64 %index, 24
  %71 = icmp eq i64 %index.next.2, 3840
  br i1 %71, label %shift-left_add_fusion_wrapped.exit, label %vector.body, !llvm.loop !25

shift-left_add_fusion_wrapped.exit:               ; preds = %vector.body, %1
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.maximum.v8f32(<8 x float>, <8 x float>) #2

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 1}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 15360}
!5 = !{i64 184320}
!6 = !{!7}
!7 = distinct !{!7, !8, !"shift-left_add_fusion_wrapped: argument 0"}
!8 = distinct !{!8, !"shift-left_add_fusion_wrapped"}
!9 = !{!10}
!10 = distinct !{!10, !8, !"shift-left_add_fusion_wrapped: argument 1"}
!11 = !{!12}
!12 = distinct !{!12, !8, !"shift-left_add_fusion_wrapped: argument 2"}
!13 = !{!14}
!14 = distinct !{!14, !8, !"shift-left_add_fusion_wrapped: argument 3"}
!15 = !{!16}
!16 = distinct !{!16, !8, !"shift-left_add_fusion_wrapped: argument 4"}
!17 = !{!18}
!18 = distinct !{!18, !8, !"shift-left_add_fusion_wrapped: argument 5"}
!19 = !{!7, !10, !12, !16, !18}
!20 = !{!7, !10, !12, !14, !18}
!21 = !{!7, !10, !14, !16, !18}
!22 = !{!7, !12, !14, !16, !18}
!23 = !{!10, !12, !14, !16, !18}
!24 = !{!7, !10, !12, !14, !16}
!25 = distinct !{!25, !26, !27}
!26 = !{!"llvm.loop.isvectorized", i32 1}
!27 = !{!"llvm.loop.unroll.runtime.disable"}
