; ModuleID = '__compute_module_wrapped_reduce-window.1_kernel_module'
source_filename = "__compute_module_wrapped_reduce-window.1_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @wrapped_reduce-window.1(ptr readonly captures(none) %0) local_unnamed_addr #0 {
vector.ph:
  %1 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %2 = load ptr, ptr %1, align 8, !invariant.load !3
  %3 = load ptr, ptr %2, align 8, !invariant.load !3, !dereferenceable !4
  %4 = getelementptr inbounds nuw i8, ptr %2, i64 32
  %5 = load ptr, ptr %4, align 8, !invariant.load !3, !dereferenceable !5
  tail call void @llvm.experimental.noalias.scope.decl(metadata !6)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !11)
  %6 = getelementptr inbounds nuw i8, ptr %2, i64 16
  %7 = load ptr, ptr %6, align 8, !invariant.load !3, !dereferenceable !13
  %8 = load i32, ptr %7, align 4, !invariant.load !3, !alias.scope !9, !noalias !14
  %broadcast.splatinsert = insertelement <4 x i32> poison, i32 %8, i64 0
  %broadcast.splat = shufflevector <4 x i32> %broadcast.splatinsert, <4 x i32> poison, <4 x i32> <i32 poison, i32 0, i32 0, i32 0>
  %9 = getelementptr i32, ptr %3, <4 x i64> <i64 0, i64 32, i64 64, i64 96>
  %10 = getelementptr i8, <4 x ptr> %9, i64 -16
  %wide.masked.gather = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %10, <4 x i1> <i1 false, i1 true, i1 true, i1 true>, <4 x i32> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %11 = add <4 x i32> %wide.masked.gather, %broadcast.splat
  %12 = getelementptr i8, <4 x ptr> %9, i64 -12
  %wide.masked.gather25 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %12, <4 x i1> <i1 false, i1 true, i1 true, i1 true>, <4 x i32> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %13 = add <4 x i32> %wide.masked.gather25, %11
  %14 = getelementptr i8, <4 x ptr> %9, i64 -8
  %wide.masked.gather27 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %14, <4 x i1> <i1 false, i1 true, i1 true, i1 true>, <4 x i32> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %15 = add <4 x i32> %wide.masked.gather27, %13
  %16 = getelementptr i8, <4 x ptr> %9, i64 -4
  %wide.masked.gather29 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %16, <4 x i1> <i1 false, i1 true, i1 true, i1 true>, <4 x i32> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %17 = add <4 x i32> %wide.masked.gather29, %15
  %predphi30 = insertelement <4 x i32> %17, i32 %8, i64 0
  %wide.masked.gather31 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %9, <4 x i1> splat (i1 true), <4 x i32> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %18 = add <4 x i32> %wide.masked.gather31, %predphi30
  %19 = getelementptr i8, <4 x ptr> %9, i64 4
  %wide.masked.gather32 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %19, <4 x i1> splat (i1 true), <4 x i32> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %20 = add <4 x i32> %wide.masked.gather32, %18
  %21 = getelementptr i8, <4 x ptr> %9, i64 8
  %wide.masked.gather33 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %21, <4 x i1> splat (i1 true), <4 x i32> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %22 = add <4 x i32> %wide.masked.gather33, %20
  %23 = getelementptr i8, <4 x ptr> %9, i64 12
  %wide.masked.gather34 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %23, <4 x i1> splat (i1 true), <4 x i32> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %24 = add <4 x i32> %wide.masked.gather34, %22
  %25 = getelementptr i8, <4 x ptr> %9, i64 16
  %wide.masked.gather35 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %25, <4 x i1> splat (i1 true), <4 x i32> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %26 = add <4 x i32> %wide.masked.gather35, %24
  %27 = getelementptr i8, <4 x ptr> %9, i64 20
  %wide.masked.gather36 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %27, <4 x i1> splat (i1 true), <4 x i32> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %28 = add <4 x i32> %wide.masked.gather36, %26
  %29 = getelementptr i8, <4 x ptr> %9, i64 24
  %wide.masked.gather37 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %29, <4 x i1> splat (i1 true), <4 x i32> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %30 = add <4 x i32> %wide.masked.gather37, %28
  %31 = getelementptr i8, <4 x ptr> %9, i64 28
  %wide.masked.gather38 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %31, <4 x i1> splat (i1 true), <4 x i32> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %32 = add <4 x i32> %wide.masked.gather38, %30
  %33 = getelementptr i8, <4 x ptr> %9, i64 32
  %wide.masked.gather39 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %33, <4 x i1> splat (i1 true), <4 x i32> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %34 = add <4 x i32> %wide.masked.gather39, %32
  %35 = getelementptr i8, <4 x ptr> %9, i64 36
  %wide.masked.gather40 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %35, <4 x i1> splat (i1 true), <4 x i32> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %36 = add <4 x i32> %wide.masked.gather40, %34
  %37 = getelementptr i8, <4 x ptr> %9, i64 40
  %wide.masked.gather41 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %37, <4 x i1> splat (i1 true), <4 x i32> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %38 = add <4 x i32> %wide.masked.gather41, %36
  %39 = getelementptr i8, <4 x ptr> %9, i64 44
  %wide.masked.gather42 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %39, <4 x i1> splat (i1 true), <4 x i32> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %40 = add <4 x i32> %wide.masked.gather42, %38
  %41 = getelementptr i8, <4 x ptr> %9, i64 48
  %wide.masked.gather43 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %41, <4 x i1> splat (i1 true), <4 x i32> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %42 = add <4 x i32> %wide.masked.gather43, %40
  %43 = getelementptr i8, <4 x ptr> %9, i64 52
  %wide.masked.gather44 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %43, <4 x i1> splat (i1 true), <4 x i32> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %44 = add <4 x i32> %wide.masked.gather44, %42
  %45 = getelementptr i8, <4 x ptr> %9, i64 56
  %wide.masked.gather45 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %45, <4 x i1> splat (i1 true), <4 x i32> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %46 = add <4 x i32> %wide.masked.gather45, %44
  %47 = getelementptr i8, <4 x ptr> %9, i64 60
  %wide.masked.gather46 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %47, <4 x i1> splat (i1 true), <4 x i32> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %48 = add <4 x i32> %wide.masked.gather46, %46
  %49 = getelementptr i8, <4 x ptr> %9, i64 64
  %wide.masked.gather47 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %49, <4 x i1> splat (i1 true), <4 x i32> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %50 = add <4 x i32> %wide.masked.gather47, %48
  %51 = getelementptr i8, <4 x ptr> %9, i64 68
  %wide.masked.gather48 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %51, <4 x i1> splat (i1 true), <4 x i32> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %52 = add <4 x i32> %wide.masked.gather48, %50
  %53 = getelementptr i8, <4 x ptr> %9, i64 72
  %wide.masked.gather49 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %53, <4 x i1> splat (i1 true), <4 x i32> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %54 = add <4 x i32> %wide.masked.gather49, %52
  %55 = getelementptr i8, <4 x ptr> %9, i64 76
  %wide.masked.gather50 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %55, <4 x i1> splat (i1 true), <4 x i32> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %56 = add <4 x i32> %wide.masked.gather50, %54
  %57 = getelementptr i8, <4 x ptr> %9, i64 80
  %wide.masked.gather51 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %57, <4 x i1> splat (i1 true), <4 x i32> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %58 = add <4 x i32> %wide.masked.gather51, %56
  %59 = getelementptr i8, <4 x ptr> %9, i64 84
  %wide.masked.gather52 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %59, <4 x i1> splat (i1 true), <4 x i32> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %60 = add <4 x i32> %wide.masked.gather52, %58
  %61 = getelementptr i8, <4 x ptr> %9, i64 88
  %wide.masked.gather53 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %61, <4 x i1> splat (i1 true), <4 x i32> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %62 = add <4 x i32> %wide.masked.gather53, %60
  %63 = getelementptr i8, <4 x ptr> %9, i64 92
  %wide.masked.gather54 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %63, <4 x i1> splat (i1 true), <4 x i32> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %64 = add <4 x i32> %wide.masked.gather54, %62
  %65 = getelementptr i8, <4 x ptr> %9, i64 96
  %wide.masked.gather55 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %65, <4 x i1> <i1 true, i1 true, i1 true, i1 false>, <4 x i32> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %66 = add <4 x i32> %wide.masked.gather55, %64
  %67 = getelementptr i8, <4 x ptr> %9, i64 100
  %wide.masked.gather57 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %67, <4 x i1> <i1 true, i1 true, i1 true, i1 false>, <4 x i32> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %68 = add <4 x i32> %wide.masked.gather57, %66
  %69 = getelementptr i8, <4 x ptr> %9, i64 104
  %wide.masked.gather59 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %69, <4 x i1> <i1 true, i1 true, i1 true, i1 false>, <4 x i32> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %70 = add <4 x i32> %wide.masked.gather59, %68
  %71 = getelementptr i32, ptr %3, <4 x i64> <i64 31, i64 63, i64 95, i64 poison>
  %72 = getelementptr i8, <4 x ptr> %71, i64 -16
  %wide.masked.gather61 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %72, <4 x i1> <i1 true, i1 true, i1 true, i1 false>, <4 x i32> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %73 = add <4 x i32> %wide.masked.gather61, %70
  %predphi62 = shufflevector <4 x i32> %73, <4 x i32> %64, <4 x i32> <i32 0, i32 1, i32 2, i32 7>
  store <4 x i32> %predphi62, ptr %5, align 4, !alias.scope !11, !noalias !16
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr>, <4 x i1>, <4 x i32>) #2

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(read) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 4}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 480}
!5 = !{i64 16}
!6 = !{!7}
!7 = distinct !{!7, !8, !"wrapped_reduce-window.1_wrapped: argument 0"}
!8 = distinct !{!8, !"wrapped_reduce-window.1_wrapped"}
!9 = !{!10}
!10 = distinct !{!10, !8, !"wrapped_reduce-window.1_wrapped: argument 1"}
!11 = !{!12}
!12 = distinct !{!12, !8, !"wrapped_reduce-window.1_wrapped: argument 2"}
!13 = !{i64 4}
!14 = !{!7, !12}
!15 = !{!10, !12}
!16 = !{!7, !10}
