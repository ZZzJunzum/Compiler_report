; ModuleID = '__compute_module_wrapped_reduce-window_kernel_module'
source_filename = "__compute_module_wrapped_reduce-window_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @wrapped_reduce-window(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !5
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !6
  tail call void @llvm.experimental.noalias.scope.decl(metadata !7)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !10)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !12)
  %9 = load i32, ptr %6, align 4, !invariant.load !3, !alias.scope !10, !noalias !14
  %10 = insertelement <4 x i32> <i32 poison, i32 0, i32 0, i32 0>, i32 %9, i64 0
  br label %.preheader2

.preheader2:                                      ; preds = %1, %middle.block
  %11 = phi i64 [ 0, %1 ], [ %83, %middle.block ]
  %.idx = shl i64 %11, 7
  %12 = getelementptr i8, ptr %4, i64 %.idx
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %.preheader2
  %index = phi i64 [ 0, %.preheader2 ], [ %index.next, %vector.body ]
  %vec.phi = phi <4 x i32> [ %10, %.preheader2 ], [ %78, %vector.body ]
  %vec.ind = phi <4 x i64> [ <i64 0, i64 1, i64 2, i64 3>, %.preheader2 ], [ %vec.ind.next, %vector.body ]
  %13 = icmp ult <4 x i64> %vec.ind, splat (i64 12)
  %14 = mul nuw nsw <4 x i64> %vec.ind, splat (i64 15360)
  %15 = getelementptr i8, ptr %12, <4 x i64> %14
  %wide.masked.gather = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %15, <4 x i1> %13, <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %16 = add <4 x i32> %wide.masked.gather, %vec.phi
  %17 = getelementptr i8, <4 x ptr> %15, i64 4
  %wide.masked.gather5 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %17, <4 x i1> %13, <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %18 = add <4 x i32> %wide.masked.gather5, %16
  %19 = getelementptr i8, <4 x ptr> %15, i64 8
  %wide.masked.gather6 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %19, <4 x i1> %13, <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %20 = add <4 x i32> %wide.masked.gather6, %18
  %21 = getelementptr i8, <4 x ptr> %15, i64 12
  %wide.masked.gather7 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %21, <4 x i1> %13, <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %22 = add <4 x i32> %wide.masked.gather7, %20
  %23 = getelementptr i8, <4 x ptr> %15, i64 16
  %wide.masked.gather8 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %23, <4 x i1> %13, <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %24 = add <4 x i32> %wide.masked.gather8, %22
  %25 = getelementptr i8, <4 x ptr> %15, i64 20
  %wide.masked.gather9 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %25, <4 x i1> %13, <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %26 = add <4 x i32> %wide.masked.gather9, %24
  %27 = getelementptr i8, <4 x ptr> %15, i64 24
  %wide.masked.gather10 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %27, <4 x i1> %13, <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %28 = add <4 x i32> %wide.masked.gather10, %26
  %29 = getelementptr i8, <4 x ptr> %15, i64 28
  %wide.masked.gather11 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %29, <4 x i1> %13, <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %30 = add <4 x i32> %wide.masked.gather11, %28
  %31 = getelementptr i8, <4 x ptr> %15, i64 32
  %wide.masked.gather12 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %31, <4 x i1> %13, <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %32 = add <4 x i32> %wide.masked.gather12, %30
  %33 = getelementptr i8, <4 x ptr> %15, i64 36
  %wide.masked.gather13 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %33, <4 x i1> %13, <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %34 = add <4 x i32> %wide.masked.gather13, %32
  %35 = getelementptr i8, <4 x ptr> %15, i64 40
  %wide.masked.gather14 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %35, <4 x i1> %13, <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %36 = add <4 x i32> %wide.masked.gather14, %34
  %37 = getelementptr i8, <4 x ptr> %15, i64 44
  %wide.masked.gather15 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %37, <4 x i1> %13, <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %38 = add <4 x i32> %wide.masked.gather15, %36
  %39 = getelementptr i8, <4 x ptr> %15, i64 48
  %wide.masked.gather16 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %39, <4 x i1> %13, <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %40 = add <4 x i32> %wide.masked.gather16, %38
  %41 = getelementptr i8, <4 x ptr> %15, i64 52
  %wide.masked.gather17 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %41, <4 x i1> %13, <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %42 = add <4 x i32> %wide.masked.gather17, %40
  %43 = getelementptr i8, <4 x ptr> %15, i64 56
  %wide.masked.gather18 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %43, <4 x i1> %13, <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %44 = add <4 x i32> %wide.masked.gather18, %42
  %45 = getelementptr i8, <4 x ptr> %15, i64 60
  %wide.masked.gather19 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %45, <4 x i1> %13, <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %46 = add <4 x i32> %wide.masked.gather19, %44
  %47 = getelementptr i8, <4 x ptr> %15, i64 64
  %wide.masked.gather20 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %47, <4 x i1> %13, <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %48 = add <4 x i32> %wide.masked.gather20, %46
  %49 = getelementptr i8, <4 x ptr> %15, i64 68
  %wide.masked.gather21 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %49, <4 x i1> %13, <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %50 = add <4 x i32> %wide.masked.gather21, %48
  %51 = getelementptr i8, <4 x ptr> %15, i64 72
  %wide.masked.gather22 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %51, <4 x i1> %13, <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %52 = add <4 x i32> %wide.masked.gather22, %50
  %53 = getelementptr i8, <4 x ptr> %15, i64 76
  %wide.masked.gather23 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %53, <4 x i1> %13, <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %54 = add <4 x i32> %wide.masked.gather23, %52
  %55 = getelementptr i8, <4 x ptr> %15, i64 80
  %wide.masked.gather24 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %55, <4 x i1> %13, <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %56 = add <4 x i32> %wide.masked.gather24, %54
  %57 = getelementptr i8, <4 x ptr> %15, i64 84
  %wide.masked.gather25 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %57, <4 x i1> %13, <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %58 = add <4 x i32> %wide.masked.gather25, %56
  %59 = getelementptr i8, <4 x ptr> %15, i64 88
  %wide.masked.gather26 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %59, <4 x i1> %13, <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %60 = add <4 x i32> %wide.masked.gather26, %58
  %61 = getelementptr i8, <4 x ptr> %15, i64 92
  %wide.masked.gather27 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %61, <4 x i1> %13, <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %62 = add <4 x i32> %wide.masked.gather27, %60
  %63 = getelementptr i8, <4 x ptr> %15, i64 96
  %wide.masked.gather28 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %63, <4 x i1> %13, <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %64 = add <4 x i32> %wide.masked.gather28, %62
  %65 = getelementptr i8, <4 x ptr> %15, i64 100
  %wide.masked.gather29 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %65, <4 x i1> %13, <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %66 = add <4 x i32> %wide.masked.gather29, %64
  %67 = getelementptr i8, <4 x ptr> %15, i64 104
  %wide.masked.gather30 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %67, <4 x i1> %13, <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %68 = add <4 x i32> %wide.masked.gather30, %66
  %69 = getelementptr i8, <4 x ptr> %15, i64 108
  %wide.masked.gather31 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %69, <4 x i1> %13, <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %70 = add <4 x i32> %wide.masked.gather31, %68
  %71 = getelementptr i8, <4 x ptr> %15, i64 112
  %wide.masked.gather32 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %71, <4 x i1> %13, <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %72 = add <4 x i32> %wide.masked.gather32, %70
  %73 = getelementptr i8, <4 x ptr> %15, i64 116
  %wide.masked.gather33 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %73, <4 x i1> %13, <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %74 = add <4 x i32> %wide.masked.gather33, %72
  %75 = getelementptr i8, <4 x ptr> %15, i64 120
  %wide.masked.gather34 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %75, <4 x i1> %13, <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %76 = add <4 x i32> %wide.masked.gather34, %74
  %77 = getelementptr i8, <4 x ptr> %15, i64 124
  %wide.masked.gather35 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %77, <4 x i1> %13, <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %78 = add <4 x i32> %wide.masked.gather35, %76
  %index.next = add nuw i64 %index, 4
  %vec.ind.next = add <4 x i64> %vec.ind, splat (i64 4)
  %79 = icmp eq i64 %index.next, 12
  br i1 %79, label %middle.block, label %vector.body, !llvm.loop !16

middle.block:                                     ; preds = %vector.body
  %80 = select <4 x i1> %13, <4 x i32> %78, <4 x i32> %vec.phi
  %81 = tail call i32 @llvm.vector.reduce.add.v4i32(<4 x i32> %80)
  %82 = getelementptr inbounds nuw i32, ptr %8, i64 %11
  store i32 %81, ptr %82, align 4, !alias.scope !12, !noalias !20
  %83 = add nuw nsw i64 %11, 1
  %exitcond4.not = icmp eq i64 %83, 120
  br i1 %exitcond4.not, label %wrapped_reduce-window_wrapped.exit, label %.preheader2, !llvm.loop !21

wrapped_reduce-window_wrapped.exit:               ; preds = %middle.block
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr>, <4 x i1>, <4 x i32>) #2

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.vector.reduce.add.v4i32(<4 x i32>) #3

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #3 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 3}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 184320}
!5 = !{i64 4}
!6 = !{i64 480}
!7 = !{!8}
!8 = distinct !{!8, !9, !"wrapped_reduce-window_wrapped: argument 0"}
!9 = distinct !{!9, !"wrapped_reduce-window_wrapped"}
!10 = !{!11}
!11 = distinct !{!11, !9, !"wrapped_reduce-window_wrapped: argument 1"}
!12 = !{!13}
!13 = distinct !{!13, !9, !"wrapped_reduce-window_wrapped: argument 2"}
!14 = !{!8, !13}
!15 = !{!11, !13}
!16 = distinct !{!16, !17, !18, !19}
!17 = !{!"llvm.loop.unroll.disable"}
!18 = !{!"llvm.loop.isvectorized", i32 1}
!19 = !{!"llvm.loop.unroll.runtime.disable"}
!20 = !{!8, !11}
!21 = distinct !{!21, !17}
