; ModuleID = '__compute_module_convert_reduce_fusion_kernel_module'
source_filename = "__compute_module_convert_reduce_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @convert_reduce_fusion(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !4
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !4
  %9 = getelementptr inbounds nuw i8, ptr %3, i64 64
  %10 = load ptr, ptr %9, align 8, !invariant.load !3, !dereferenceable !4
  %11 = getelementptr inbounds nuw i8, ptr %3, i64 80
  %12 = load ptr, ptr %11, align 8, !invariant.load !3, !dereferenceable !5
  %13 = getelementptr inbounds nuw i8, ptr %3, i64 96
  %14 = load ptr, ptr %13, align 8, !invariant.load !3, !dereferenceable !5
  %15 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %16 = load ptr, ptr %15, align 8
  %17 = load i64, ptr %16, align 4, !invariant.load !3
  tail call void @llvm.experimental.noalias.scope.decl(metadata !6)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !11)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !13)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !15)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !17)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !19)
  %18 = icmp ult i64 %17, 12
  br i1 %18, label %.preheader, label %convert_reduce_fusion_wrapped.exit

.preheader:                                       ; preds = %1
  %19 = getelementptr inbounds nuw i8, ptr %3, i64 48
  %20 = load ptr, ptr %19, align 8, !invariant.load !3, !dereferenceable !21
  %.idx = mul nuw nsw i64 %17, 15360
  %21 = getelementptr i8, ptr %20, i64 %.idx
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %.preheader
  %index = phi i64 [ 0, %.preheader ], [ %index.next.1, %vector.body ]
  %vec.phi = phi <8 x i32> [ zeroinitializer, %.preheader ], [ %84, %vector.body ]
  %vec.phi5 = phi <8 x i32> [ zeroinitializer, %.preheader ], [ %85, %vector.body ]
  %vec.phi6 = phi <8 x i32> [ zeroinitializer, %.preheader ], [ %82, %vector.body ]
  %vec.phi7 = phi <8 x i32> [ zeroinitializer, %.preheader ], [ %83, %vector.body ]
  %22 = getelementptr float, ptr %21, i64 %index
  %23 = getelementptr i8, ptr %22, i64 32
  %wide.load = load <8 x float>, ptr %22, align 4, !invariant.load !3, !alias.scope !13, !noalias !22
  %wide.load8 = load <8 x float>, ptr %23, align 4, !invariant.load !3, !alias.scope !13, !noalias !22
  %24 = getelementptr inbounds nuw float, ptr %10, i64 %index
  %25 = getelementptr inbounds nuw i8, ptr %24, i64 32
  %wide.load9 = load <8 x float>, ptr %24, align 4, !invariant.load !3, !alias.scope !15, !noalias !23
  %wide.load10 = load <8 x float>, ptr %25, align 4, !invariant.load !3, !alias.scope !15, !noalias !23
  %26 = fmul <8 x float> %wide.load, %wide.load9
  %27 = fmul <8 x float> %wide.load8, %wide.load10
  %28 = getelementptr inbounds nuw float, ptr %8, i64 %index
  %29 = getelementptr inbounds nuw i8, ptr %28, i64 32
  %wide.load11 = load <8 x float>, ptr %28, align 4, !invariant.load !3, !alias.scope !11, !noalias !24
  %wide.load12 = load <8 x float>, ptr %29, align 4, !invariant.load !3, !alias.scope !11, !noalias !24
  %30 = fadd <8 x float> %26, %wide.load11
  %31 = fadd <8 x float> %27, %wide.load12
  %32 = fcmp ogt <8 x float> %30, zeroinitializer
  %33 = fcmp ogt <8 x float> %31, zeroinitializer
  %34 = zext <8 x i1> %32 to <8 x i32>
  %35 = zext <8 x i1> %33 to <8 x i32>
  %36 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %30, <8 x float> zeroinitializer)
  %37 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %31, <8 x float> zeroinitializer)
  %38 = getelementptr inbounds nuw float, ptr %6, i64 %index
  %39 = getelementptr inbounds nuw i8, ptr %38, i64 32
  %wide.load13 = load <8 x float>, ptr %38, align 4, !invariant.load !3, !alias.scope !9, !noalias !25
  %wide.load14 = load <8 x float>, ptr %39, align 4, !invariant.load !3, !alias.scope !9, !noalias !25
  %40 = fmul <8 x float> %wide.load13, %36
  %41 = fmul <8 x float> %wide.load14, %37
  %42 = getelementptr inbounds nuw float, ptr %4, i64 %index
  %43 = getelementptr inbounds nuw i8, ptr %42, i64 32
  %wide.load15 = load <8 x float>, ptr %42, align 4, !invariant.load !3, !alias.scope !6, !noalias !26
  %wide.load16 = load <8 x float>, ptr %43, align 4, !invariant.load !3, !alias.scope !6, !noalias !26
  %44 = fadd <8 x float> %wide.load15, %40
  %45 = fadd <8 x float> %wide.load16, %41
  %46 = fcmp ogt <8 x float> %44, zeroinitializer
  %47 = fcmp ogt <8 x float> %45, zeroinitializer
  %48 = zext <8 x i1> %46 to <8 x i32>
  %49 = zext <8 x i1> %47 to <8 x i32>
  %50 = add <8 x i32> %vec.phi6, %34
  %51 = add <8 x i32> %vec.phi7, %35
  %52 = add <8 x i32> %vec.phi, %48
  %53 = add <8 x i32> %vec.phi5, %49
  %index.next = or disjoint i64 %index, 16
  %54 = getelementptr float, ptr %21, i64 %index.next
  %55 = getelementptr i8, ptr %54, i64 32
  %wide.load.1 = load <8 x float>, ptr %54, align 4, !invariant.load !3, !alias.scope !13, !noalias !22
  %wide.load8.1 = load <8 x float>, ptr %55, align 4, !invariant.load !3, !alias.scope !13, !noalias !22
  %56 = getelementptr inbounds nuw float, ptr %10, i64 %index.next
  %57 = getelementptr inbounds nuw i8, ptr %56, i64 32
  %wide.load9.1 = load <8 x float>, ptr %56, align 4, !invariant.load !3, !alias.scope !15, !noalias !23
  %wide.load10.1 = load <8 x float>, ptr %57, align 4, !invariant.load !3, !alias.scope !15, !noalias !23
  %58 = fmul <8 x float> %wide.load.1, %wide.load9.1
  %59 = fmul <8 x float> %wide.load8.1, %wide.load10.1
  %60 = getelementptr inbounds nuw float, ptr %8, i64 %index.next
  %61 = getelementptr inbounds nuw i8, ptr %60, i64 32
  %wide.load11.1 = load <8 x float>, ptr %60, align 4, !invariant.load !3, !alias.scope !11, !noalias !24
  %wide.load12.1 = load <8 x float>, ptr %61, align 4, !invariant.load !3, !alias.scope !11, !noalias !24
  %62 = fadd <8 x float> %58, %wide.load11.1
  %63 = fadd <8 x float> %59, %wide.load12.1
  %64 = fcmp ogt <8 x float> %62, zeroinitializer
  %65 = fcmp ogt <8 x float> %63, zeroinitializer
  %66 = zext <8 x i1> %64 to <8 x i32>
  %67 = zext <8 x i1> %65 to <8 x i32>
  %68 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %62, <8 x float> zeroinitializer)
  %69 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %63, <8 x float> zeroinitializer)
  %70 = getelementptr inbounds nuw float, ptr %6, i64 %index.next
  %71 = getelementptr inbounds nuw i8, ptr %70, i64 32
  %wide.load13.1 = load <8 x float>, ptr %70, align 4, !invariant.load !3, !alias.scope !9, !noalias !25
  %wide.load14.1 = load <8 x float>, ptr %71, align 4, !invariant.load !3, !alias.scope !9, !noalias !25
  %72 = fmul <8 x float> %wide.load13.1, %68
  %73 = fmul <8 x float> %wide.load14.1, %69
  %74 = getelementptr inbounds nuw float, ptr %4, i64 %index.next
  %75 = getelementptr inbounds nuw i8, ptr %74, i64 32
  %wide.load15.1 = load <8 x float>, ptr %74, align 4, !invariant.load !3, !alias.scope !6, !noalias !26
  %wide.load16.1 = load <8 x float>, ptr %75, align 4, !invariant.load !3, !alias.scope !6, !noalias !26
  %76 = fadd <8 x float> %wide.load15.1, %72
  %77 = fadd <8 x float> %wide.load16.1, %73
  %78 = fcmp ogt <8 x float> %76, zeroinitializer
  %79 = fcmp ogt <8 x float> %77, zeroinitializer
  %80 = zext <8 x i1> %78 to <8 x i32>
  %81 = zext <8 x i1> %79 to <8 x i32>
  %82 = add <8 x i32> %50, %66
  %83 = add <8 x i32> %51, %67
  %84 = add <8 x i32> %52, %80
  %85 = add <8 x i32> %53, %81
  %index.next.1 = add nuw nsw i64 %index, 32
  %86 = icmp eq i64 %index.next.1, 3840
  br i1 %86, label %middle.block, label %vector.body, !llvm.loop !27

middle.block:                                     ; preds = %vector.body
  %bin.rdx17 = add <8 x i32> %83, %82
  %87 = tail call i32 @llvm.vector.reduce.add.v8i32(<8 x i32> %bin.rdx17)
  %bin.rdx = add <8 x i32> %85, %84
  %88 = tail call i32 @llvm.vector.reduce.add.v8i32(<8 x i32> %bin.rdx)
  %89 = getelementptr inbounds nuw i32, ptr %12, i64 %17
  store i32 %87, ptr %89, align 4, !alias.scope !17, !noalias !30
  %90 = getelementptr inbounds nuw i32, ptr %14, i64 %17
  store i32 %88, ptr %90, align 4, !alias.scope !19, !noalias !31
  br label %convert_reduce_fusion_wrapped.exit

convert_reduce_fusion_wrapped.exit:               ; preds = %1, %middle.block
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.maximum.v8f32(<8 x float>, <8 x float>) #2

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.vector.reduce.add.v8i32(<8 x i32>) #3

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #3 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 0}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 15360}
!5 = !{i64 48}
!6 = !{!7}
!7 = distinct !{!7, !8, !"convert_reduce_fusion_wrapped: argument 0"}
!8 = distinct !{!8, !"convert_reduce_fusion_wrapped"}
!9 = !{!10}
!10 = distinct !{!10, !8, !"convert_reduce_fusion_wrapped: argument 1"}
!11 = !{!12}
!12 = distinct !{!12, !8, !"convert_reduce_fusion_wrapped: argument 2"}
!13 = !{!14}
!14 = distinct !{!14, !8, !"convert_reduce_fusion_wrapped: argument 3"}
!15 = !{!16}
!16 = distinct !{!16, !8, !"convert_reduce_fusion_wrapped: argument 4"}
!17 = !{!18}
!18 = distinct !{!18, !8, !"convert_reduce_fusion_wrapped: argument 5"}
!19 = !{!20}
!20 = distinct !{!20, !8, !"convert_reduce_fusion_wrapped: argument 6"}
!21 = !{i64 184320}
!22 = !{!7, !10, !12, !16, !18, !20}
!23 = !{!7, !10, !12, !14, !18, !20}
!24 = !{!7, !10, !14, !16, !18, !20}
!25 = !{!7, !12, !14, !16, !18, !20}
!26 = !{!10, !12, !14, !16, !18, !20}
!27 = distinct !{!27, !28, !29}
!28 = !{!"llvm.loop.isvectorized", i32 1}
!29 = !{!"llvm.loop.unroll.runtime.disable"}
!30 = !{!7, !10, !12, !14, !16, !20}
!31 = !{!7, !10, !12, !14, !16, !18}
