; ModuleID = '__compute_module_wrapped_reduce-window_kernel_module'
source_filename = "__compute_module_wrapped_reduce-window_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @wrapped_reduce-window(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !5
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !6
  tail call void @llvm.experimental.noalias.scope.decl(metadata !7)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !10)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !12)
  %9 = load i32, ptr %6, align 4, !invariant.load !3, !alias.scope !10, !noalias !14
  %broadcast.splatinsert = insertelement <8 x i32> poison, i32 %9, i64 0
  %broadcast.splat = shufflevector <8 x i32> %broadcast.splatinsert, <8 x i32> poison, <8 x i32> zeroinitializer
  br label %.preheader3

.preheader3:                                      ; preds = %1, %middle.block
  %10 = phi i64 [ 0, %1 ], [ %80, %middle.block ]
  %.idx1 = mul nuw nsw i64 %10, 15360
  %11 = getelementptr i8, ptr %4, i64 %.idx1
  %.idx = mul nuw nsw i64 %10, 480
  %12 = getelementptr i8, ptr %8, i64 %.idx
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %.preheader3
  %index = phi i64 [ 0, %.preheader3 ], [ %index.next, %vector.body ]
  %vec.ind = phi <8 x i64> [ <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>, %.preheader3 ], [ %vec.ind.next, %vector.body ]
  %13 = shl <8 x i64> %vec.ind, splat (i64 7)
  %14 = getelementptr i8, ptr %11, <8 x i64> %13
  %wide.masked.gather = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %14, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %15 = add <8 x i32> %wide.masked.gather, %broadcast.splat
  %16 = getelementptr i8, <8 x ptr> %14, i64 4
  %wide.masked.gather5 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %16, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %17 = add <8 x i32> %wide.masked.gather5, %15
  %18 = getelementptr i8, <8 x ptr> %14, i64 8
  %wide.masked.gather6 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %18, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %19 = add <8 x i32> %wide.masked.gather6, %17
  %20 = getelementptr i8, <8 x ptr> %14, i64 12
  %wide.masked.gather7 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %20, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %21 = add <8 x i32> %wide.masked.gather7, %19
  %22 = getelementptr i8, <8 x ptr> %14, i64 16
  %wide.masked.gather8 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %22, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %23 = add <8 x i32> %wide.masked.gather8, %21
  %24 = getelementptr i8, <8 x ptr> %14, i64 20
  %wide.masked.gather9 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %24, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %25 = add <8 x i32> %wide.masked.gather9, %23
  %26 = getelementptr i8, <8 x ptr> %14, i64 24
  %wide.masked.gather10 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %26, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %27 = add <8 x i32> %wide.masked.gather10, %25
  %28 = getelementptr i8, <8 x ptr> %14, i64 28
  %wide.masked.gather11 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %28, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %29 = add <8 x i32> %wide.masked.gather11, %27
  %30 = getelementptr i8, <8 x ptr> %14, i64 32
  %wide.masked.gather12 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %30, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %31 = add <8 x i32> %wide.masked.gather12, %29
  %32 = getelementptr i8, <8 x ptr> %14, i64 36
  %wide.masked.gather13 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %32, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %33 = add <8 x i32> %wide.masked.gather13, %31
  %34 = getelementptr i8, <8 x ptr> %14, i64 40
  %wide.masked.gather14 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %34, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %35 = add <8 x i32> %wide.masked.gather14, %33
  %36 = getelementptr i8, <8 x ptr> %14, i64 44
  %wide.masked.gather15 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %36, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %37 = add <8 x i32> %wide.masked.gather15, %35
  %38 = getelementptr i8, <8 x ptr> %14, i64 48
  %wide.masked.gather16 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %38, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %39 = add <8 x i32> %wide.masked.gather16, %37
  %40 = getelementptr i8, <8 x ptr> %14, i64 52
  %wide.masked.gather17 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %40, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %41 = add <8 x i32> %wide.masked.gather17, %39
  %42 = getelementptr i8, <8 x ptr> %14, i64 56
  %wide.masked.gather18 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %42, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %43 = add <8 x i32> %wide.masked.gather18, %41
  %44 = getelementptr i8, <8 x ptr> %14, i64 60
  %wide.masked.gather19 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %44, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %45 = add <8 x i32> %wide.masked.gather19, %43
  %46 = getelementptr i8, <8 x ptr> %14, i64 64
  %wide.masked.gather20 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %46, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %47 = add <8 x i32> %wide.masked.gather20, %45
  %48 = getelementptr i8, <8 x ptr> %14, i64 68
  %wide.masked.gather21 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %48, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %49 = add <8 x i32> %wide.masked.gather21, %47
  %50 = getelementptr i8, <8 x ptr> %14, i64 72
  %wide.masked.gather22 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %50, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %51 = add <8 x i32> %wide.masked.gather22, %49
  %52 = getelementptr i8, <8 x ptr> %14, i64 76
  %wide.masked.gather23 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %52, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %53 = add <8 x i32> %wide.masked.gather23, %51
  %54 = getelementptr i8, <8 x ptr> %14, i64 80
  %wide.masked.gather24 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %54, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %55 = add <8 x i32> %wide.masked.gather24, %53
  %56 = getelementptr i8, <8 x ptr> %14, i64 84
  %wide.masked.gather25 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %56, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %57 = add <8 x i32> %wide.masked.gather25, %55
  %58 = getelementptr i8, <8 x ptr> %14, i64 88
  %wide.masked.gather26 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %58, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %59 = add <8 x i32> %wide.masked.gather26, %57
  %60 = getelementptr i8, <8 x ptr> %14, i64 92
  %wide.masked.gather27 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %60, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %61 = add <8 x i32> %wide.masked.gather27, %59
  %62 = getelementptr i8, <8 x ptr> %14, i64 96
  %wide.masked.gather28 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %62, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %63 = add <8 x i32> %wide.masked.gather28, %61
  %64 = getelementptr i8, <8 x ptr> %14, i64 100
  %wide.masked.gather29 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %64, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %65 = add <8 x i32> %wide.masked.gather29, %63
  %66 = getelementptr i8, <8 x ptr> %14, i64 104
  %wide.masked.gather30 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %66, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %67 = add <8 x i32> %wide.masked.gather30, %65
  %68 = getelementptr i8, <8 x ptr> %14, i64 108
  %wide.masked.gather31 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %68, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %69 = add <8 x i32> %wide.masked.gather31, %67
  %70 = getelementptr i8, <8 x ptr> %14, i64 112
  %wide.masked.gather32 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %70, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %71 = add <8 x i32> %wide.masked.gather32, %69
  %72 = getelementptr i8, <8 x ptr> %14, i64 116
  %wide.masked.gather33 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %72, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %73 = add <8 x i32> %wide.masked.gather33, %71
  %74 = getelementptr i8, <8 x ptr> %14, i64 120
  %wide.masked.gather34 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %74, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %75 = add <8 x i32> %wide.masked.gather34, %73
  %76 = getelementptr i8, <8 x ptr> %14, i64 124
  %wide.masked.gather35 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %76, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %77 = add <8 x i32> %wide.masked.gather35, %75
  %78 = getelementptr i32, ptr %12, i64 %index
  store <8 x i32> %77, ptr %78, align 4, !alias.scope !12, !noalias !16
  %index.next = add nuw i64 %index, 8
  %vec.ind.next = add nuw nsw <8 x i64> %vec.ind, splat (i64 8)
  %79 = icmp eq i64 %index.next, 120
  br i1 %79, label %middle.block, label %vector.body, !llvm.loop !17

middle.block:                                     ; preds = %vector.body
  %80 = add nuw nsw i64 %10, 1
  %exitcond4.not = icmp eq i64 %80, 12
  br i1 %exitcond4.not, label %wrapped_reduce-window_wrapped.exit, label %.preheader3, !llvm.loop !21

wrapped_reduce-window_wrapped.exit:               ; preds = %middle.block
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr>, <8 x i1>, <8 x i32>) #2

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(read) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 3}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 184320}
!5 = !{i64 4}
!6 = !{i64 5760}
!7 = !{!8}
!8 = distinct !{!8, !9, !"wrapped_reduce-window_wrapped: argument 0"}
!9 = distinct !{!9, !"wrapped_reduce-window_wrapped"}
!10 = !{!11}
!11 = distinct !{!11, !9, !"wrapped_reduce-window_wrapped: argument 1"}
!12 = !{!13}
!13 = distinct !{!13, !9, !"wrapped_reduce-window_wrapped: argument 2"}
!14 = !{!8, !13}
!15 = !{!11, !13}
!16 = !{!8, !11}
!17 = distinct !{!17, !18, !19, !20}
!18 = !{!"llvm.loop.unroll.disable"}
!19 = !{!"llvm.loop.isvectorized", i32 1}
!20 = !{!"llvm.loop.unroll.runtime.disable"}
!21 = distinct !{!21, !18}
