; ModuleID = '__compute_module_wrapped_reduce-window.1_kernel_module'
source_filename = "__compute_module_wrapped_reduce-window.1_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @wrapped_reduce-window.1(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !5
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !6
  tail call void @llvm.experimental.noalias.scope.decl(metadata !7)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !10)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !12)
  %9 = load i32, ptr %6, align 4, !invariant.load !3, !alias.scope !10, !noalias !14
  %broadcast.splatinsert = insertelement <4 x i32> poison, i32 %9, i64 0
  %broadcast.splat = shufflevector <4 x i32> %broadcast.splatinsert, <4 x i32> poison, <4 x i32> <i32 poison, i32 0, i32 0, i32 0>
  %invariant.gep = getelementptr i32, ptr %4, <4 x i64> <i64 0, i64 32, i64 64, i64 96>
  br label %.preheader

.preheader:                                       ; preds = %1, %.preheader
  %10 = phi i64 [ 0, %1 ], [ %75, %.preheader ]
  %.idx1 = mul nuw nsw i64 %10, 480
  %.idx = shl i64 %10, 4
  %11 = getelementptr i8, ptr %8, i64 %.idx
  %gep = getelementptr i8, <4 x ptr> %invariant.gep, i64 %.idx1
  %12 = getelementptr i8, <4 x ptr> %gep, i64 -16
  %wide.masked.gather = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %12, <4 x i1> <i1 false, i1 true, i1 true, i1 true>, <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %13 = add <4 x i32> %wide.masked.gather, %broadcast.splat
  %14 = getelementptr i8, <4 x ptr> %gep, i64 -12
  %wide.masked.gather32 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %14, <4 x i1> <i1 false, i1 true, i1 true, i1 true>, <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %15 = add <4 x i32> %wide.masked.gather32, %13
  %16 = getelementptr i8, <4 x ptr> %gep, i64 -8
  %wide.masked.gather34 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %16, <4 x i1> <i1 false, i1 true, i1 true, i1 true>, <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %17 = add <4 x i32> %wide.masked.gather34, %15
  %18 = getelementptr i8, <4 x ptr> %gep, i64 -4
  %wide.masked.gather36 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %18, <4 x i1> <i1 false, i1 true, i1 true, i1 true>, <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %19 = add <4 x i32> %wide.masked.gather36, %17
  %predphi37 = insertelement <4 x i32> %19, i32 %9, i64 0
  %wide.masked.gather38 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %gep, <4 x i1> splat (i1 true), <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %20 = add <4 x i32> %wide.masked.gather38, %predphi37
  %21 = getelementptr i8, <4 x ptr> %gep, i64 4
  %wide.masked.gather39 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %21, <4 x i1> splat (i1 true), <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %22 = add <4 x i32> %wide.masked.gather39, %20
  %23 = getelementptr i8, <4 x ptr> %gep, i64 8
  %wide.masked.gather40 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %23, <4 x i1> splat (i1 true), <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %24 = add <4 x i32> %wide.masked.gather40, %22
  %25 = getelementptr i8, <4 x ptr> %gep, i64 12
  %wide.masked.gather41 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %25, <4 x i1> splat (i1 true), <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %26 = add <4 x i32> %wide.masked.gather41, %24
  %27 = getelementptr i8, <4 x ptr> %gep, i64 16
  %wide.masked.gather42 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %27, <4 x i1> splat (i1 true), <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %28 = add <4 x i32> %wide.masked.gather42, %26
  %29 = getelementptr i8, <4 x ptr> %gep, i64 20
  %wide.masked.gather43 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %29, <4 x i1> splat (i1 true), <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %30 = add <4 x i32> %wide.masked.gather43, %28
  %31 = getelementptr i8, <4 x ptr> %gep, i64 24
  %wide.masked.gather44 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %31, <4 x i1> splat (i1 true), <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %32 = add <4 x i32> %wide.masked.gather44, %30
  %33 = getelementptr i8, <4 x ptr> %gep, i64 28
  %wide.masked.gather45 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %33, <4 x i1> splat (i1 true), <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %34 = add <4 x i32> %wide.masked.gather45, %32
  %35 = getelementptr i8, <4 x ptr> %gep, i64 32
  %wide.masked.gather46 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %35, <4 x i1> splat (i1 true), <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %36 = add <4 x i32> %wide.masked.gather46, %34
  %37 = getelementptr i8, <4 x ptr> %gep, i64 36
  %wide.masked.gather47 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %37, <4 x i1> splat (i1 true), <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %38 = add <4 x i32> %wide.masked.gather47, %36
  %39 = getelementptr i8, <4 x ptr> %gep, i64 40
  %wide.masked.gather48 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %39, <4 x i1> splat (i1 true), <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %40 = add <4 x i32> %wide.masked.gather48, %38
  %41 = getelementptr i8, <4 x ptr> %gep, i64 44
  %wide.masked.gather49 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %41, <4 x i1> splat (i1 true), <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %42 = add <4 x i32> %wide.masked.gather49, %40
  %43 = getelementptr i8, <4 x ptr> %gep, i64 48
  %wide.masked.gather50 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %43, <4 x i1> splat (i1 true), <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %44 = add <4 x i32> %wide.masked.gather50, %42
  %45 = getelementptr i8, <4 x ptr> %gep, i64 52
  %wide.masked.gather51 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %45, <4 x i1> splat (i1 true), <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %46 = add <4 x i32> %wide.masked.gather51, %44
  %47 = getelementptr i8, <4 x ptr> %gep, i64 56
  %wide.masked.gather52 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %47, <4 x i1> splat (i1 true), <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %48 = add <4 x i32> %wide.masked.gather52, %46
  %49 = getelementptr i8, <4 x ptr> %gep, i64 60
  %wide.masked.gather53 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %49, <4 x i1> splat (i1 true), <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %50 = add <4 x i32> %wide.masked.gather53, %48
  %51 = getelementptr i8, <4 x ptr> %gep, i64 64
  %wide.masked.gather54 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %51, <4 x i1> splat (i1 true), <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %52 = add <4 x i32> %wide.masked.gather54, %50
  %53 = getelementptr i8, <4 x ptr> %gep, i64 68
  %wide.masked.gather55 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %53, <4 x i1> splat (i1 true), <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %54 = add <4 x i32> %wide.masked.gather55, %52
  %55 = getelementptr i8, <4 x ptr> %gep, i64 72
  %wide.masked.gather56 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %55, <4 x i1> splat (i1 true), <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %56 = add <4 x i32> %wide.masked.gather56, %54
  %57 = getelementptr i8, <4 x ptr> %gep, i64 76
  %wide.masked.gather57 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %57, <4 x i1> splat (i1 true), <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %58 = add <4 x i32> %wide.masked.gather57, %56
  %59 = getelementptr i8, <4 x ptr> %gep, i64 80
  %wide.masked.gather58 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %59, <4 x i1> splat (i1 true), <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %60 = add <4 x i32> %wide.masked.gather58, %58
  %61 = getelementptr i8, <4 x ptr> %gep, i64 84
  %wide.masked.gather59 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %61, <4 x i1> splat (i1 true), <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %62 = add <4 x i32> %wide.masked.gather59, %60
  %63 = getelementptr i8, <4 x ptr> %gep, i64 88
  %wide.masked.gather60 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %63, <4 x i1> splat (i1 true), <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %64 = add <4 x i32> %wide.masked.gather60, %62
  %65 = getelementptr i8, <4 x ptr> %gep, i64 92
  %wide.masked.gather61 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %65, <4 x i1> splat (i1 true), <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %66 = add <4 x i32> %wide.masked.gather61, %64
  %67 = getelementptr i8, <4 x ptr> %gep, i64 96
  %wide.masked.gather62 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %67, <4 x i1> <i1 true, i1 true, i1 true, i1 false>, <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %68 = add <4 x i32> %wide.masked.gather62, %66
  %69 = getelementptr i8, <4 x ptr> %gep, i64 100
  %wide.masked.gather63 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %69, <4 x i1> <i1 true, i1 true, i1 true, i1 false>, <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %70 = add <4 x i32> %wide.masked.gather63, %68
  %71 = getelementptr i8, <4 x ptr> %gep, i64 104
  %wide.masked.gather64 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %71, <4 x i1> <i1 true, i1 true, i1 true, i1 false>, <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %72 = add <4 x i32> %wide.masked.gather64, %70
  %73 = getelementptr i8, <4 x ptr> %gep, i64 108
  %wide.masked.gather65 = tail call <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr> align 4 %73, <4 x i1> <i1 true, i1 true, i1 true, i1 false>, <4 x i32> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %74 = add <4 x i32> %wide.masked.gather65, %72
  %predphi66 = shufflevector <4 x i32> %74, <4 x i32> %66, <4 x i32> <i32 0, i32 1, i32 2, i32 7>
  store <4 x i32> %predphi66, ptr %11, align 4, !alias.scope !12, !noalias !16
  %75 = add nuw nsw i64 %10, 1
  %exitcond5.not = icmp eq i64 %75, 12
  br i1 %exitcond5.not, label %wrapped_reduce-window.1_wrapped.exit, label %.preheader, !llvm.loop !17

wrapped_reduce-window.1_wrapped.exit:             ; preds = %.preheader
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <4 x i32> @llvm.masked.gather.v4i32.v4p0(<4 x ptr>, <4 x i1>, <4 x i32>) #2

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(read) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 4}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 5760}
!5 = !{i64 4}
!6 = !{i64 192}
!7 = !{!8}
!8 = distinct !{!8, !9, !"wrapped_reduce-window.1_wrapped: argument 0"}
!9 = distinct !{!9, !"wrapped_reduce-window.1_wrapped"}
!10 = !{!11}
!11 = distinct !{!11, !9, !"wrapped_reduce-window.1_wrapped: argument 1"}
!12 = !{!13}
!13 = distinct !{!13, !9, !"wrapped_reduce-window.1_wrapped: argument 2"}
!14 = !{!8, !13}
!15 = !{!11, !13}
!16 = !{!8, !11}
!17 = distinct !{!17, !18}
!18 = !{!"llvm.loop.unroll.disable"}
