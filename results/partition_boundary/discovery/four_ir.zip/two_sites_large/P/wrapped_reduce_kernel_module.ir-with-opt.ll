; ModuleID = '__compute_module_wrapped_reduce_kernel_module'
source_filename = "__compute_module_wrapped_reduce_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @wrapped_reduce(ptr readonly captures(none) %0) local_unnamed_addr #0 {
vector.ph:
  %1 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %2 = load ptr, ptr %1, align 8, !invariant.load !3
  %3 = load ptr, ptr %2, align 8, !invariant.load !3, !dereferenceable !4
  %4 = getelementptr inbounds nuw i8, ptr %2, i64 32
  %5 = load ptr, ptr %4, align 8, !invariant.load !3, !dereferenceable !5
  tail call void @llvm.experimental.noalias.scope.decl(metadata !6)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !11)
  %6 = getelementptr inbounds nuw i8, ptr %2, i64 16
  %7 = load ptr, ptr %6, align 8, !invariant.load !3, !dereferenceable !13
  %8 = load i32, ptr %7, align 4, !invariant.load !3, !alias.scope !9, !noalias !14
  %broadcast.splatinsert = insertelement <8 x i32> poison, i32 %8, i64 0
  %broadcast.splat = shufflevector <8 x i32> %broadcast.splatinsert, <8 x i32> poison, <8 x i32> zeroinitializer
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %vector.ph
  %index = phi i64 [ 0, %vector.ph ], [ %index.next, %vector.body ]
  %vec.ind = phi <8 x i64> [ <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>, %vector.ph ], [ %vec.ind.next, %vector.body ]
  %9 = mul nuw nsw <8 x i64> %vec.ind, splat (i64 20)
  %10 = getelementptr i8, ptr %3, <8 x i64> %9
  %wide.masked.gather = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %10, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %11 = add <8 x i32> %wide.masked.gather, %broadcast.splat
  %12 = getelementptr i8, <8 x ptr> %10, i64 4
  %wide.masked.gather1 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %12, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %13 = add <8 x i32> %wide.masked.gather1, %11
  %14 = getelementptr i8, <8 x ptr> %10, i64 8
  %wide.masked.gather2 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %14, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %15 = add <8 x i32> %wide.masked.gather2, %13
  %16 = getelementptr i8, <8 x ptr> %10, i64 12
  %wide.masked.gather3 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %16, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %17 = add <8 x i32> %wide.masked.gather3, %15
  %18 = getelementptr i8, <8 x ptr> %10, i64 16
  %wide.masked.gather4 = tail call <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr> align 4 %18, <8 x i1> splat (i1 true), <8 x i32> poison), !invariant.load !3, !alias.scope !6, !noalias !15
  %19 = add <8 x i32> %wide.masked.gather4, %17
  %20 = getelementptr inbounds nuw i32, ptr %5, i64 %index
  store <8 x i32> %19, ptr %20, align 4, !alias.scope !11, !noalias !16
  %index.next = add nuw i64 %index, 8
  %vec.ind.next = add nuw nsw <8 x i64> %vec.ind, splat (i64 8)
  %21 = icmp eq i64 %index.next, 288
  br i1 %21, label %wrapped_reduce_wrapped.exit, label %vector.body, !llvm.loop !17

wrapped_reduce_wrapped.exit:                      ; preds = %vector.body
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x i32> @llvm.masked.gather.v8i32.v8p0(<8 x ptr>, <8 x i1>, <8 x i32>) #2

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(read) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 3}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 5760}
!5 = !{i64 1152}
!6 = !{!7}
!7 = distinct !{!7, !8, !"wrapped_reduce_wrapped: argument 0"}
!8 = distinct !{!8, !"wrapped_reduce_wrapped"}
!9 = !{!10}
!10 = distinct !{!10, !8, !"wrapped_reduce_wrapped: argument 1"}
!11 = !{!12}
!12 = distinct !{!12, !8, !"wrapped_reduce_wrapped: argument 2"}
!13 = !{i64 4}
!14 = !{!7, !12}
!15 = !{!10, !12}
!16 = !{!7, !10}
!17 = distinct !{!17, !18, !19, !20}
!18 = !{!"llvm.loop.unroll.disable"}
!19 = !{!"llvm.loop.isvectorized", i32 1}
!20 = !{!"llvm.loop.unroll.runtime.disable"}
