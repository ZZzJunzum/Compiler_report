; ModuleID = '__compute_module_and_convert_fusion_kernel_module'
source_filename = "__compute_module_and_convert_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @and_convert_fusion(ptr readonly captures(none) %0) local_unnamed_addr #0 {
vector.ph:
  tail call void @llvm.experimental.noalias.scope.decl(metadata !3)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !6)
  %1 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %2 = load ptr, ptr %1, align 8, !invariant.load !8
  %3 = getelementptr inbounds nuw i8, ptr %2, i64 16
  %4 = load ptr, ptr %3, align 8, !invariant.load !8, !dereferenceable !9
  %5 = load ptr, ptr %2, align 8, !invariant.load !8, !dereferenceable !9
  %6 = getelementptr inbounds nuw i8, ptr %5, i64 32
  %7 = getelementptr inbounds nuw i8, ptr %5, i64 64
  %8 = getelementptr inbounds nuw i8, ptr %5, i64 96
  %wide.load = load <8 x i32>, ptr %5, align 4, !invariant.load !8, !alias.scope !3, !noalias !6
  %wide.load1 = load <8 x i32>, ptr %6, align 4, !invariant.load !8, !alias.scope !3, !noalias !6
  %wide.load2 = load <8 x i32>, ptr %7, align 4, !invariant.load !8, !alias.scope !3, !noalias !6
  %wide.load3 = load <8 x i32>, ptr %8, align 4, !invariant.load !8, !alias.scope !3, !noalias !6
  %9 = and <8 x i32> %wide.load, splat (i32 255)
  %10 = and <8 x i32> %wide.load1, splat (i32 255)
  %11 = and <8 x i32> %wide.load2, splat (i32 255)
  %12 = and <8 x i32> %wide.load3, splat (i32 255)
  %13 = getelementptr inbounds nuw i8, ptr %4, i64 32
  %14 = getelementptr inbounds nuw i8, ptr %4, i64 64
  %15 = getelementptr inbounds nuw i8, ptr %4, i64 96
  store <8 x i32> %9, ptr %4, align 4, !alias.scope !6, !noalias !3
  store <8 x i32> %10, ptr %13, align 4, !alias.scope !6, !noalias !3
  store <8 x i32> %11, ptr %14, align 4, !alias.scope !6, !noalias !3
  store <8 x i32> %12, ptr %15, align 4, !alias.scope !6, !noalias !3
  %16 = getelementptr inbounds nuw i8, ptr %5, i64 128
  %17 = getelementptr inbounds nuw i8, ptr %5, i64 160
  %18 = getelementptr inbounds nuw i8, ptr %5, i64 192
  %19 = getelementptr inbounds nuw i8, ptr %5, i64 224
  %wide.load.1 = load <8 x i32>, ptr %16, align 4, !invariant.load !8, !alias.scope !3, !noalias !6
  %wide.load1.1 = load <8 x i32>, ptr %17, align 4, !invariant.load !8, !alias.scope !3, !noalias !6
  %wide.load2.1 = load <8 x i32>, ptr %18, align 4, !invariant.load !8, !alias.scope !3, !noalias !6
  %wide.load3.1 = load <8 x i32>, ptr %19, align 4, !invariant.load !8, !alias.scope !3, !noalias !6
  %20 = and <8 x i32> %wide.load.1, splat (i32 255)
  %21 = and <8 x i32> %wide.load1.1, splat (i32 255)
  %22 = and <8 x i32> %wide.load2.1, splat (i32 255)
  %23 = and <8 x i32> %wide.load3.1, splat (i32 255)
  %24 = getelementptr inbounds nuw i8, ptr %4, i64 128
  %25 = getelementptr inbounds nuw i8, ptr %4, i64 160
  %26 = getelementptr inbounds nuw i8, ptr %4, i64 192
  %27 = getelementptr inbounds nuw i8, ptr %4, i64 224
  store <8 x i32> %20, ptr %24, align 4, !alias.scope !6, !noalias !3
  store <8 x i32> %21, ptr %25, align 4, !alias.scope !6, !noalias !3
  store <8 x i32> %22, ptr %26, align 4, !alias.scope !6, !noalias !3
  store <8 x i32> %23, ptr %27, align 4, !alias.scope !6, !noalias !3
  %28 = getelementptr inbounds nuw i8, ptr %5, i64 256
  %29 = getelementptr inbounds nuw i8, ptr %5, i64 288
  %30 = getelementptr inbounds nuw i8, ptr %5, i64 320
  %31 = getelementptr inbounds nuw i8, ptr %5, i64 352
  %wide.load.2 = load <8 x i32>, ptr %28, align 4, !invariant.load !8, !alias.scope !3, !noalias !6
  %wide.load1.2 = load <8 x i32>, ptr %29, align 4, !invariant.load !8, !alias.scope !3, !noalias !6
  %wide.load2.2 = load <8 x i32>, ptr %30, align 4, !invariant.load !8, !alias.scope !3, !noalias !6
  %wide.load3.2 = load <8 x i32>, ptr %31, align 4, !invariant.load !8, !alias.scope !3, !noalias !6
  %32 = and <8 x i32> %wide.load.2, splat (i32 255)
  %33 = and <8 x i32> %wide.load1.2, splat (i32 255)
  %34 = and <8 x i32> %wide.load2.2, splat (i32 255)
  %35 = and <8 x i32> %wide.load3.2, splat (i32 255)
  %36 = getelementptr inbounds nuw i8, ptr %4, i64 256
  %37 = getelementptr inbounds nuw i8, ptr %4, i64 288
  %38 = getelementptr inbounds nuw i8, ptr %4, i64 320
  %39 = getelementptr inbounds nuw i8, ptr %4, i64 352
  store <8 x i32> %32, ptr %36, align 4, !alias.scope !6, !noalias !3
  store <8 x i32> %33, ptr %37, align 4, !alias.scope !6, !noalias !3
  store <8 x i32> %34, ptr %38, align 4, !alias.scope !6, !noalias !3
  store <8 x i32> %35, ptr %39, align 4, !alias.scope !6, !noalias !3
  %40 = getelementptr inbounds nuw i8, ptr %5, i64 384
  %41 = getelementptr inbounds nuw i8, ptr %5, i64 416
  %42 = getelementptr inbounds nuw i8, ptr %5, i64 448
  %43 = getelementptr inbounds nuw i8, ptr %5, i64 480
  %wide.load.3 = load <8 x i32>, ptr %40, align 4, !invariant.load !8, !alias.scope !3, !noalias !6
  %wide.load1.3 = load <8 x i32>, ptr %41, align 4, !invariant.load !8, !alias.scope !3, !noalias !6
  %wide.load2.3 = load <8 x i32>, ptr %42, align 4, !invariant.load !8, !alias.scope !3, !noalias !6
  %wide.load3.3 = load <8 x i32>, ptr %43, align 4, !invariant.load !8, !alias.scope !3, !noalias !6
  %44 = and <8 x i32> %wide.load.3, splat (i32 255)
  %45 = and <8 x i32> %wide.load1.3, splat (i32 255)
  %46 = and <8 x i32> %wide.load2.3, splat (i32 255)
  %47 = and <8 x i32> %wide.load3.3, splat (i32 255)
  %48 = getelementptr inbounds nuw i8, ptr %4, i64 384
  %49 = getelementptr inbounds nuw i8, ptr %4, i64 416
  %50 = getelementptr inbounds nuw i8, ptr %4, i64 448
  %51 = getelementptr inbounds nuw i8, ptr %4, i64 480
  store <8 x i32> %44, ptr %48, align 4, !alias.scope !6, !noalias !3
  store <8 x i32> %45, ptr %49, align 4, !alias.scope !6, !noalias !3
  store <8 x i32> %46, ptr %50, align 4, !alias.scope !6, !noalias !3
  store <8 x i32> %47, ptr %51, align 4, !alias.scope !6, !noalias !3
  %52 = getelementptr inbounds nuw i8, ptr %5, i64 512
  %53 = getelementptr inbounds nuw i8, ptr %5, i64 544
  %54 = getelementptr inbounds nuw i8, ptr %5, i64 576
  %55 = getelementptr inbounds nuw i8, ptr %5, i64 608
  %wide.load.4 = load <8 x i32>, ptr %52, align 4, !invariant.load !8, !alias.scope !3, !noalias !6
  %wide.load1.4 = load <8 x i32>, ptr %53, align 4, !invariant.load !8, !alias.scope !3, !noalias !6
  %wide.load2.4 = load <8 x i32>, ptr %54, align 4, !invariant.load !8, !alias.scope !3, !noalias !6
  %wide.load3.4 = load <8 x i32>, ptr %55, align 4, !invariant.load !8, !alias.scope !3, !noalias !6
  %56 = and <8 x i32> %wide.load.4, splat (i32 255)
  %57 = and <8 x i32> %wide.load1.4, splat (i32 255)
  %58 = and <8 x i32> %wide.load2.4, splat (i32 255)
  %59 = and <8 x i32> %wide.load3.4, splat (i32 255)
  %60 = getelementptr inbounds nuw i8, ptr %4, i64 512
  %61 = getelementptr inbounds nuw i8, ptr %4, i64 544
  %62 = getelementptr inbounds nuw i8, ptr %4, i64 576
  %63 = getelementptr inbounds nuw i8, ptr %4, i64 608
  store <8 x i32> %56, ptr %60, align 4, !alias.scope !6, !noalias !3
  store <8 x i32> %57, ptr %61, align 4, !alias.scope !6, !noalias !3
  store <8 x i32> %58, ptr %62, align 4, !alias.scope !6, !noalias !3
  store <8 x i32> %59, ptr %63, align 4, !alias.scope !6, !noalias !3
  %64 = getelementptr inbounds nuw i8, ptr %5, i64 640
  %65 = getelementptr inbounds nuw i8, ptr %5, i64 672
  %66 = getelementptr inbounds nuw i8, ptr %5, i64 704
  %67 = getelementptr inbounds nuw i8, ptr %5, i64 736
  %wide.load.5 = load <8 x i32>, ptr %64, align 4, !invariant.load !8, !alias.scope !3, !noalias !6
  %wide.load1.5 = load <8 x i32>, ptr %65, align 4, !invariant.load !8, !alias.scope !3, !noalias !6
  %wide.load2.5 = load <8 x i32>, ptr %66, align 4, !invariant.load !8, !alias.scope !3, !noalias !6
  %wide.load3.5 = load <8 x i32>, ptr %67, align 4, !invariant.load !8, !alias.scope !3, !noalias !6
  %68 = and <8 x i32> %wide.load.5, splat (i32 255)
  %69 = and <8 x i32> %wide.load1.5, splat (i32 255)
  %70 = and <8 x i32> %wide.load2.5, splat (i32 255)
  %71 = and <8 x i32> %wide.load3.5, splat (i32 255)
  %72 = getelementptr inbounds nuw i8, ptr %4, i64 640
  %73 = getelementptr inbounds nuw i8, ptr %4, i64 672
  %74 = getelementptr inbounds nuw i8, ptr %4, i64 704
  %75 = getelementptr inbounds nuw i8, ptr %4, i64 736
  store <8 x i32> %68, ptr %72, align 4, !alias.scope !6, !noalias !3
  store <8 x i32> %69, ptr %73, align 4, !alias.scope !6, !noalias !3
  store <8 x i32> %70, ptr %74, align 4, !alias.scope !6, !noalias !3
  store <8 x i32> %71, ptr %75, align 4, !alias.scope !6, !noalias !3
  %76 = getelementptr inbounds nuw i8, ptr %5, i64 768
  %77 = getelementptr inbounds nuw i8, ptr %5, i64 800
  %78 = getelementptr inbounds nuw i8, ptr %5, i64 832
  %79 = getelementptr inbounds nuw i8, ptr %5, i64 864
  %wide.load.6 = load <8 x i32>, ptr %76, align 4, !invariant.load !8, !alias.scope !3, !noalias !6
  %wide.load1.6 = load <8 x i32>, ptr %77, align 4, !invariant.load !8, !alias.scope !3, !noalias !6
  %wide.load2.6 = load <8 x i32>, ptr %78, align 4, !invariant.load !8, !alias.scope !3, !noalias !6
  %wide.load3.6 = load <8 x i32>, ptr %79, align 4, !invariant.load !8, !alias.scope !3, !noalias !6
  %80 = and <8 x i32> %wide.load.6, splat (i32 255)
  %81 = and <8 x i32> %wide.load1.6, splat (i32 255)
  %82 = and <8 x i32> %wide.load2.6, splat (i32 255)
  %83 = and <8 x i32> %wide.load3.6, splat (i32 255)
  %84 = getelementptr inbounds nuw i8, ptr %4, i64 768
  %85 = getelementptr inbounds nuw i8, ptr %4, i64 800
  %86 = getelementptr inbounds nuw i8, ptr %4, i64 832
  %87 = getelementptr inbounds nuw i8, ptr %4, i64 864
  store <8 x i32> %80, ptr %84, align 4, !alias.scope !6, !noalias !3
  store <8 x i32> %81, ptr %85, align 4, !alias.scope !6, !noalias !3
  store <8 x i32> %82, ptr %86, align 4, !alias.scope !6, !noalias !3
  store <8 x i32> %83, ptr %87, align 4, !alias.scope !6, !noalias !3
  %88 = getelementptr inbounds nuw i8, ptr %5, i64 896
  %89 = getelementptr inbounds nuw i8, ptr %5, i64 928
  %90 = getelementptr inbounds nuw i8, ptr %5, i64 960
  %91 = getelementptr inbounds nuw i8, ptr %5, i64 992
  %wide.load.7 = load <8 x i32>, ptr %88, align 4, !invariant.load !8, !alias.scope !3, !noalias !6
  %wide.load1.7 = load <8 x i32>, ptr %89, align 4, !invariant.load !8, !alias.scope !3, !noalias !6
  %wide.load2.7 = load <8 x i32>, ptr %90, align 4, !invariant.load !8, !alias.scope !3, !noalias !6
  %wide.load3.7 = load <8 x i32>, ptr %91, align 4, !invariant.load !8, !alias.scope !3, !noalias !6
  %92 = and <8 x i32> %wide.load.7, splat (i32 255)
  %93 = and <8 x i32> %wide.load1.7, splat (i32 255)
  %94 = and <8 x i32> %wide.load2.7, splat (i32 255)
  %95 = and <8 x i32> %wide.load3.7, splat (i32 255)
  %96 = getelementptr inbounds nuw i8, ptr %4, i64 896
  %97 = getelementptr inbounds nuw i8, ptr %4, i64 928
  %98 = getelementptr inbounds nuw i8, ptr %4, i64 960
  %99 = getelementptr inbounds nuw i8, ptr %4, i64 992
  store <8 x i32> %92, ptr %96, align 4, !alias.scope !6, !noalias !3
  store <8 x i32> %93, ptr %97, align 4, !alias.scope !6, !noalias !3
  store <8 x i32> %94, ptr %98, align 4, !alias.scope !6, !noalias !3
  store <8 x i32> %95, ptr %99, align 4, !alias.scope !6, !noalias !3
  %100 = getelementptr inbounds nuw i8, ptr %5, i64 1024
  %101 = getelementptr inbounds nuw i8, ptr %5, i64 1056
  %102 = getelementptr inbounds nuw i8, ptr %5, i64 1088
  %103 = getelementptr inbounds nuw i8, ptr %5, i64 1120
  %wide.load.8 = load <8 x i32>, ptr %100, align 4, !invariant.load !8, !alias.scope !3, !noalias !6
  %wide.load1.8 = load <8 x i32>, ptr %101, align 4, !invariant.load !8, !alias.scope !3, !noalias !6
  %wide.load2.8 = load <8 x i32>, ptr %102, align 4, !invariant.load !8, !alias.scope !3, !noalias !6
  %wide.load3.8 = load <8 x i32>, ptr %103, align 4, !invariant.load !8, !alias.scope !3, !noalias !6
  %104 = and <8 x i32> %wide.load.8, splat (i32 255)
  %105 = and <8 x i32> %wide.load1.8, splat (i32 255)
  %106 = and <8 x i32> %wide.load2.8, splat (i32 255)
  %107 = and <8 x i32> %wide.load3.8, splat (i32 255)
  %108 = getelementptr inbounds nuw i8, ptr %4, i64 1024
  %109 = getelementptr inbounds nuw i8, ptr %4, i64 1056
  %110 = getelementptr inbounds nuw i8, ptr %4, i64 1088
  %111 = getelementptr inbounds nuw i8, ptr %4, i64 1120
  store <8 x i32> %104, ptr %108, align 4, !alias.scope !6, !noalias !3
  store <8 x i32> %105, ptr %109, align 4, !alias.scope !6, !noalias !3
  store <8 x i32> %106, ptr %110, align 4, !alias.scope !6, !noalias !3
  store <8 x i32> %107, ptr %111, align 4, !alias.scope !6, !noalias !3
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 0}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{!4}
!4 = distinct !{!4, !5, !"and_convert_fusion_wrapped: argument 0"}
!5 = distinct !{!5, !"and_convert_fusion_wrapped"}
!6 = !{!7}
!7 = distinct !{!7, !5, !"and_convert_fusion_wrapped: argument 1"}
!8 = !{}
!9 = !{i64 1152}
