; ModuleID = '__compute_module_compare_convert_fusion.1_kernel_module'
source_filename = "__compute_module_compare_convert_fusion.1_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @compare_convert_fusion.1(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !5
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !4
  %9 = getelementptr inbounds nuw i8, ptr %3, i64 48
  %10 = load ptr, ptr %9, align 8, !invariant.load !3, !dereferenceable !5
  tail call void @llvm.experimental.noalias.scope.decl(metadata !6)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !11)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !13)
  %11 = getelementptr inbounds nuw i8, ptr %8, i64 32
  %wide.load4 = load <8 x float>, ptr %8, align 4, !invariant.load !3, !alias.scope !11, !noalias !15
  %wide.load5 = load <8 x float>, ptr %11, align 4, !invariant.load !3, !alias.scope !11, !noalias !15
  %12 = getelementptr inbounds nuw i8, ptr %4, i64 32
  %wide.load6 = load <8 x float>, ptr %4, align 4, !invariant.load !3, !alias.scope !6, !noalias !16
  %wide.load7 = load <8 x float>, ptr %12, align 4, !invariant.load !3, !alias.scope !6, !noalias !16
  %13 = getelementptr inbounds nuw i8, ptr %8, i64 64
  %14 = getelementptr inbounds nuw i8, ptr %8, i64 96
  %wide.load4.1 = load <8 x float>, ptr %13, align 4, !invariant.load !3, !alias.scope !11, !noalias !15
  %wide.load5.1 = load <8 x float>, ptr %14, align 4, !invariant.load !3, !alias.scope !11, !noalias !15
  %15 = getelementptr inbounds nuw i8, ptr %4, i64 64
  %16 = getelementptr inbounds nuw i8, ptr %4, i64 96
  %wide.load6.1 = load <8 x float>, ptr %15, align 4, !invariant.load !3, !alias.scope !6, !noalias !16
  %wide.load7.1 = load <8 x float>, ptr %16, align 4, !invariant.load !3, !alias.scope !6, !noalias !16
  %17 = getelementptr inbounds nuw i8, ptr %8, i64 128
  %18 = getelementptr inbounds nuw i8, ptr %8, i64 160
  %wide.load4.2 = load <8 x float>, ptr %17, align 4, !invariant.load !3, !alias.scope !11, !noalias !15
  %wide.load5.2 = load <8 x float>, ptr %18, align 4, !invariant.load !3, !alias.scope !11, !noalias !15
  %19 = getelementptr inbounds nuw i8, ptr %4, i64 128
  %20 = getelementptr inbounds nuw i8, ptr %4, i64 160
  %wide.load6.2 = load <8 x float>, ptr %19, align 4, !invariant.load !3, !alias.scope !6, !noalias !16
  %wide.load7.2 = load <8 x float>, ptr %20, align 4, !invariant.load !3, !alias.scope !6, !noalias !16
  %21 = getelementptr inbounds nuw i8, ptr %8, i64 192
  %22 = getelementptr inbounds nuw i8, ptr %8, i64 224
  %wide.load4.3 = load <8 x float>, ptr %21, align 4, !invariant.load !3, !alias.scope !11, !noalias !15
  %wide.load5.3 = load <8 x float>, ptr %22, align 4, !invariant.load !3, !alias.scope !11, !noalias !15
  %23 = getelementptr inbounds nuw i8, ptr %4, i64 192
  %24 = getelementptr inbounds nuw i8, ptr %4, i64 224
  %wide.load6.3 = load <8 x float>, ptr %23, align 4, !invariant.load !3, !alias.scope !6, !noalias !16
  %wide.load7.3 = load <8 x float>, ptr %24, align 4, !invariant.load !3, !alias.scope !6, !noalias !16
  %25 = getelementptr inbounds nuw i8, ptr %8, i64 256
  %26 = getelementptr inbounds nuw i8, ptr %8, i64 288
  %wide.load4.4 = load <8 x float>, ptr %25, align 4, !invariant.load !3, !alias.scope !11, !noalias !15
  %wide.load5.4 = load <8 x float>, ptr %26, align 4, !invariant.load !3, !alias.scope !11, !noalias !15
  %27 = getelementptr inbounds nuw i8, ptr %4, i64 256
  %28 = getelementptr inbounds nuw i8, ptr %4, i64 288
  %wide.load6.4 = load <8 x float>, ptr %27, align 4, !invariant.load !3, !alias.scope !6, !noalias !16
  %wide.load7.4 = load <8 x float>, ptr %28, align 4, !invariant.load !3, !alias.scope !6, !noalias !16
  %29 = getelementptr inbounds nuw i8, ptr %8, i64 320
  %30 = getelementptr inbounds nuw i8, ptr %8, i64 352
  %wide.load4.5 = load <8 x float>, ptr %29, align 4, !invariant.load !3, !alias.scope !11, !noalias !15
  %wide.load5.5 = load <8 x float>, ptr %30, align 4, !invariant.load !3, !alias.scope !11, !noalias !15
  %31 = getelementptr inbounds nuw i8, ptr %4, i64 320
  %32 = getelementptr inbounds nuw i8, ptr %4, i64 352
  %wide.load6.5 = load <8 x float>, ptr %31, align 4, !invariant.load !3, !alias.scope !6, !noalias !16
  %wide.load7.5 = load <8 x float>, ptr %32, align 4, !invariant.load !3, !alias.scope !6, !noalias !16
  %33 = getelementptr inbounds nuw i8, ptr %8, i64 384
  %34 = getelementptr inbounds nuw i8, ptr %8, i64 416
  %wide.load4.6 = load <8 x float>, ptr %33, align 4, !invariant.load !3, !alias.scope !11, !noalias !15
  %wide.load5.6 = load <8 x float>, ptr %34, align 4, !invariant.load !3, !alias.scope !11, !noalias !15
  %35 = getelementptr inbounds nuw i8, ptr %4, i64 384
  %36 = getelementptr inbounds nuw i8, ptr %4, i64 416
  %wide.load6.6 = load <8 x float>, ptr %35, align 4, !invariant.load !3, !alias.scope !6, !noalias !16
  %wide.load7.6 = load <8 x float>, ptr %36, align 4, !invariant.load !3, !alias.scope !6, !noalias !16
  %37 = getelementptr inbounds nuw i8, ptr %8, i64 448
  %38 = getelementptr inbounds nuw i8, ptr %8, i64 480
  %wide.load4.7 = load <8 x float>, ptr %37, align 4, !invariant.load !3, !alias.scope !11, !noalias !15
  %wide.load5.7 = load <8 x float>, ptr %38, align 4, !invariant.load !3, !alias.scope !11, !noalias !15
  %39 = getelementptr inbounds nuw i8, ptr %4, i64 448
  %40 = getelementptr inbounds nuw i8, ptr %4, i64 480
  %wide.load6.7 = load <8 x float>, ptr %39, align 4, !invariant.load !3, !alias.scope !6, !noalias !16
  %wide.load7.7 = load <8 x float>, ptr %40, align 4, !invariant.load !3, !alias.scope !6, !noalias !16
  %41 = getelementptr inbounds nuw i8, ptr %8, i64 512
  %42 = getelementptr inbounds nuw i8, ptr %8, i64 544
  %wide.load4.8 = load <8 x float>, ptr %41, align 4, !invariant.load !3, !alias.scope !11, !noalias !15
  %wide.load5.8 = load <8 x float>, ptr %42, align 4, !invariant.load !3, !alias.scope !11, !noalias !15
  %43 = getelementptr inbounds nuw i8, ptr %4, i64 512
  %44 = getelementptr inbounds nuw i8, ptr %4, i64 544
  %wide.load6.8 = load <8 x float>, ptr %43, align 4, !invariant.load !3, !alias.scope !6, !noalias !16
  %wide.load7.8 = load <8 x float>, ptr %44, align 4, !invariant.load !3, !alias.scope !6, !noalias !16
  %45 = getelementptr inbounds nuw i8, ptr %8, i64 576
  %46 = getelementptr inbounds nuw i8, ptr %8, i64 608
  %wide.load4.9 = load <8 x float>, ptr %45, align 4, !invariant.load !3, !alias.scope !11, !noalias !15
  %wide.load5.9 = load <8 x float>, ptr %46, align 4, !invariant.load !3, !alias.scope !11, !noalias !15
  %47 = getelementptr inbounds nuw i8, ptr %4, i64 576
  %48 = getelementptr inbounds nuw i8, ptr %4, i64 608
  %wide.load6.9 = load <8 x float>, ptr %47, align 4, !invariant.load !3, !alias.scope !6, !noalias !16
  %wide.load7.9 = load <8 x float>, ptr %48, align 4, !invariant.load !3, !alias.scope !6, !noalias !16
  br label %vector.ph

vector.ph:                                        ; preds = %1, %vector.ph
  %49 = phi i64 [ 0, %1 ], [ %180, %vector.ph ]
  %50 = mul nuw nsw i64 %49, 160
  %51 = getelementptr inbounds nuw float, ptr %6, i64 %50
  %52 = getelementptr inbounds nuw i8, ptr %51, i64 32
  %wide.load = load <8 x float>, ptr %51, align 4, !invariant.load !3, !alias.scope !9, !noalias !17
  %wide.load3 = load <8 x float>, ptr %52, align 4, !invariant.load !3, !alias.scope !9, !noalias !17
  %53 = fmul <8 x float> %wide.load, %wide.load4
  %54 = fmul <8 x float> %wide.load3, %wide.load5
  %55 = fadd <8 x float> %53, %wide.load6
  %56 = fadd <8 x float> %54, %wide.load7
  %57 = fcmp ogt <8 x float> %55, zeroinitializer
  %58 = fcmp ogt <8 x float> %56, zeroinitializer
  %59 = zext <8 x i1> %57 to <8 x i32>
  %60 = zext <8 x i1> %58 to <8 x i32>
  %61 = getelementptr inbounds nuw i32, ptr %10, i64 %50
  %62 = getelementptr inbounds nuw i8, ptr %61, i64 32
  store <8 x i32> %59, ptr %61, align 4, !alias.scope !13, !noalias !18
  store <8 x i32> %60, ptr %62, align 4, !alias.scope !13, !noalias !18
  %63 = or disjoint i64 %50, 16
  %64 = getelementptr inbounds nuw float, ptr %6, i64 %63
  %65 = getelementptr inbounds nuw i8, ptr %64, i64 32
  %wide.load.1 = load <8 x float>, ptr %64, align 4, !invariant.load !3, !alias.scope !9, !noalias !17
  %wide.load3.1 = load <8 x float>, ptr %65, align 4, !invariant.load !3, !alias.scope !9, !noalias !17
  %66 = fmul <8 x float> %wide.load.1, %wide.load4.1
  %67 = fmul <8 x float> %wide.load3.1, %wide.load5.1
  %68 = fadd <8 x float> %66, %wide.load6.1
  %69 = fadd <8 x float> %67, %wide.load7.1
  %70 = fcmp ogt <8 x float> %68, zeroinitializer
  %71 = fcmp ogt <8 x float> %69, zeroinitializer
  %72 = zext <8 x i1> %70 to <8 x i32>
  %73 = zext <8 x i1> %71 to <8 x i32>
  %74 = getelementptr inbounds nuw i32, ptr %10, i64 %63
  %75 = getelementptr inbounds nuw i8, ptr %74, i64 32
  store <8 x i32> %72, ptr %74, align 4, !alias.scope !13, !noalias !18
  store <8 x i32> %73, ptr %75, align 4, !alias.scope !13, !noalias !18
  %76 = add nuw nsw i64 %50, 32
  %77 = getelementptr inbounds nuw float, ptr %6, i64 %76
  %78 = getelementptr inbounds nuw i8, ptr %77, i64 32
  %wide.load.2 = load <8 x float>, ptr %77, align 4, !invariant.load !3, !alias.scope !9, !noalias !17
  %wide.load3.2 = load <8 x float>, ptr %78, align 4, !invariant.load !3, !alias.scope !9, !noalias !17
  %79 = fmul <8 x float> %wide.load.2, %wide.load4.2
  %80 = fmul <8 x float> %wide.load3.2, %wide.load5.2
  %81 = fadd <8 x float> %79, %wide.load6.2
  %82 = fadd <8 x float> %80, %wide.load7.2
  %83 = fcmp ogt <8 x float> %81, zeroinitializer
  %84 = fcmp ogt <8 x float> %82, zeroinitializer
  %85 = zext <8 x i1> %83 to <8 x i32>
  %86 = zext <8 x i1> %84 to <8 x i32>
  %87 = getelementptr inbounds nuw i32, ptr %10, i64 %76
  %88 = getelementptr inbounds nuw i8, ptr %87, i64 32
  store <8 x i32> %85, ptr %87, align 4, !alias.scope !13, !noalias !18
  store <8 x i32> %86, ptr %88, align 4, !alias.scope !13, !noalias !18
  %89 = add nuw nsw i64 %50, 48
  %90 = getelementptr inbounds nuw float, ptr %6, i64 %89
  %91 = getelementptr inbounds nuw i8, ptr %90, i64 32
  %wide.load.3 = load <8 x float>, ptr %90, align 4, !invariant.load !3, !alias.scope !9, !noalias !17
  %wide.load3.3 = load <8 x float>, ptr %91, align 4, !invariant.load !3, !alias.scope !9, !noalias !17
  %92 = fmul <8 x float> %wide.load.3, %wide.load4.3
  %93 = fmul <8 x float> %wide.load3.3, %wide.load5.3
  %94 = fadd <8 x float> %92, %wide.load6.3
  %95 = fadd <8 x float> %93, %wide.load7.3
  %96 = fcmp ogt <8 x float> %94, zeroinitializer
  %97 = fcmp ogt <8 x float> %95, zeroinitializer
  %98 = zext <8 x i1> %96 to <8 x i32>
  %99 = zext <8 x i1> %97 to <8 x i32>
  %100 = getelementptr inbounds nuw i32, ptr %10, i64 %89
  %101 = getelementptr inbounds nuw i8, ptr %100, i64 32
  store <8 x i32> %98, ptr %100, align 4, !alias.scope !13, !noalias !18
  store <8 x i32> %99, ptr %101, align 4, !alias.scope !13, !noalias !18
  %102 = add nuw nsw i64 %50, 64
  %103 = getelementptr inbounds nuw float, ptr %6, i64 %102
  %104 = getelementptr inbounds nuw i8, ptr %103, i64 32
  %wide.load.4 = load <8 x float>, ptr %103, align 4, !invariant.load !3, !alias.scope !9, !noalias !17
  %wide.load3.4 = load <8 x float>, ptr %104, align 4, !invariant.load !3, !alias.scope !9, !noalias !17
  %105 = fmul <8 x float> %wide.load.4, %wide.load4.4
  %106 = fmul <8 x float> %wide.load3.4, %wide.load5.4
  %107 = fadd <8 x float> %105, %wide.load6.4
  %108 = fadd <8 x float> %106, %wide.load7.4
  %109 = fcmp ogt <8 x float> %107, zeroinitializer
  %110 = fcmp ogt <8 x float> %108, zeroinitializer
  %111 = zext <8 x i1> %109 to <8 x i32>
  %112 = zext <8 x i1> %110 to <8 x i32>
  %113 = getelementptr inbounds nuw i32, ptr %10, i64 %102
  %114 = getelementptr inbounds nuw i8, ptr %113, i64 32
  store <8 x i32> %111, ptr %113, align 4, !alias.scope !13, !noalias !18
  store <8 x i32> %112, ptr %114, align 4, !alias.scope !13, !noalias !18
  %115 = add nuw nsw i64 %50, 80
  %116 = getelementptr inbounds nuw float, ptr %6, i64 %115
  %117 = getelementptr inbounds nuw i8, ptr %116, i64 32
  %wide.load.5 = load <8 x float>, ptr %116, align 4, !invariant.load !3, !alias.scope !9, !noalias !17
  %wide.load3.5 = load <8 x float>, ptr %117, align 4, !invariant.load !3, !alias.scope !9, !noalias !17
  %118 = fmul <8 x float> %wide.load.5, %wide.load4.5
  %119 = fmul <8 x float> %wide.load3.5, %wide.load5.5
  %120 = fadd <8 x float> %118, %wide.load6.5
  %121 = fadd <8 x float> %119, %wide.load7.5
  %122 = fcmp ogt <8 x float> %120, zeroinitializer
  %123 = fcmp ogt <8 x float> %121, zeroinitializer
  %124 = zext <8 x i1> %122 to <8 x i32>
  %125 = zext <8 x i1> %123 to <8 x i32>
  %126 = getelementptr inbounds nuw i32, ptr %10, i64 %115
  %127 = getelementptr inbounds nuw i8, ptr %126, i64 32
  store <8 x i32> %124, ptr %126, align 4, !alias.scope !13, !noalias !18
  store <8 x i32> %125, ptr %127, align 4, !alias.scope !13, !noalias !18
  %128 = add nuw nsw i64 %50, 96
  %129 = getelementptr inbounds nuw float, ptr %6, i64 %128
  %130 = getelementptr inbounds nuw i8, ptr %129, i64 32
  %wide.load.6 = load <8 x float>, ptr %129, align 4, !invariant.load !3, !alias.scope !9, !noalias !17
  %wide.load3.6 = load <8 x float>, ptr %130, align 4, !invariant.load !3, !alias.scope !9, !noalias !17
  %131 = fmul <8 x float> %wide.load.6, %wide.load4.6
  %132 = fmul <8 x float> %wide.load3.6, %wide.load5.6
  %133 = fadd <8 x float> %131, %wide.load6.6
  %134 = fadd <8 x float> %132, %wide.load7.6
  %135 = fcmp ogt <8 x float> %133, zeroinitializer
  %136 = fcmp ogt <8 x float> %134, zeroinitializer
  %137 = zext <8 x i1> %135 to <8 x i32>
  %138 = zext <8 x i1> %136 to <8 x i32>
  %139 = getelementptr inbounds nuw i32, ptr %10, i64 %128
  %140 = getelementptr inbounds nuw i8, ptr %139, i64 32
  store <8 x i32> %137, ptr %139, align 4, !alias.scope !13, !noalias !18
  store <8 x i32> %138, ptr %140, align 4, !alias.scope !13, !noalias !18
  %141 = add nuw nsw i64 %50, 112
  %142 = getelementptr inbounds nuw float, ptr %6, i64 %141
  %143 = getelementptr inbounds nuw i8, ptr %142, i64 32
  %wide.load.7 = load <8 x float>, ptr %142, align 4, !invariant.load !3, !alias.scope !9, !noalias !17
  %wide.load3.7 = load <8 x float>, ptr %143, align 4, !invariant.load !3, !alias.scope !9, !noalias !17
  %144 = fmul <8 x float> %wide.load.7, %wide.load4.7
  %145 = fmul <8 x float> %wide.load3.7, %wide.load5.7
  %146 = fadd <8 x float> %144, %wide.load6.7
  %147 = fadd <8 x float> %145, %wide.load7.7
  %148 = fcmp ogt <8 x float> %146, zeroinitializer
  %149 = fcmp ogt <8 x float> %147, zeroinitializer
  %150 = zext <8 x i1> %148 to <8 x i32>
  %151 = zext <8 x i1> %149 to <8 x i32>
  %152 = getelementptr inbounds nuw i32, ptr %10, i64 %141
  %153 = getelementptr inbounds nuw i8, ptr %152, i64 32
  store <8 x i32> %150, ptr %152, align 4, !alias.scope !13, !noalias !18
  store <8 x i32> %151, ptr %153, align 4, !alias.scope !13, !noalias !18
  %154 = add nuw nsw i64 %50, 128
  %155 = getelementptr inbounds nuw float, ptr %6, i64 %154
  %156 = getelementptr inbounds nuw i8, ptr %155, i64 32
  %wide.load.8 = load <8 x float>, ptr %155, align 4, !invariant.load !3, !alias.scope !9, !noalias !17
  %wide.load3.8 = load <8 x float>, ptr %156, align 4, !invariant.load !3, !alias.scope !9, !noalias !17
  %157 = fmul <8 x float> %wide.load.8, %wide.load4.8
  %158 = fmul <8 x float> %wide.load3.8, %wide.load5.8
  %159 = fadd <8 x float> %157, %wide.load6.8
  %160 = fadd <8 x float> %158, %wide.load7.8
  %161 = fcmp ogt <8 x float> %159, zeroinitializer
  %162 = fcmp ogt <8 x float> %160, zeroinitializer
  %163 = zext <8 x i1> %161 to <8 x i32>
  %164 = zext <8 x i1> %162 to <8 x i32>
  %165 = getelementptr inbounds nuw i32, ptr %10, i64 %154
  %166 = getelementptr inbounds nuw i8, ptr %165, i64 32
  store <8 x i32> %163, ptr %165, align 4, !alias.scope !13, !noalias !18
  store <8 x i32> %164, ptr %166, align 4, !alias.scope !13, !noalias !18
  %167 = add nuw nsw i64 %50, 144
  %168 = getelementptr inbounds nuw float, ptr %6, i64 %167
  %169 = getelementptr inbounds nuw i8, ptr %168, i64 32
  %wide.load.9 = load <8 x float>, ptr %168, align 4, !invariant.load !3, !alias.scope !9, !noalias !17
  %wide.load3.9 = load <8 x float>, ptr %169, align 4, !invariant.load !3, !alias.scope !9, !noalias !17
  %170 = fmul <8 x float> %wide.load.9, %wide.load4.9
  %171 = fmul <8 x float> %wide.load3.9, %wide.load5.9
  %172 = fadd <8 x float> %170, %wide.load6.9
  %173 = fadd <8 x float> %171, %wide.load7.9
  %174 = fcmp ogt <8 x float> %172, zeroinitializer
  %175 = fcmp ogt <8 x float> %173, zeroinitializer
  %176 = zext <8 x i1> %174 to <8 x i32>
  %177 = zext <8 x i1> %175 to <8 x i32>
  %178 = getelementptr inbounds nuw i32, ptr %10, i64 %167
  %179 = getelementptr inbounds nuw i8, ptr %178, i64 32
  store <8 x i32> %176, ptr %178, align 4, !alias.scope !13, !noalias !18
  store <8 x i32> %177, ptr %179, align 4, !alias.scope !13, !noalias !18
  %180 = add nuw nsw i64 %49, 1
  %exitcond2.not = icmp eq i64 %180, 288
  br i1 %exitcond2.not, label %compare_convert_fusion.1_wrapped.exit, label %vector.ph, !llvm.loop !19

compare_convert_fusion.1_wrapped.exit:            ; preds = %vector.ph
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 1}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 640}
!5 = !{i64 184320}
!6 = !{!7}
!7 = distinct !{!7, !8, !"compare_convert_fusion.1_wrapped: argument 0"}
!8 = distinct !{!8, !"compare_convert_fusion.1_wrapped"}
!9 = !{!10}
!10 = distinct !{!10, !8, !"compare_convert_fusion.1_wrapped: argument 1"}
!11 = !{!12}
!12 = distinct !{!12, !8, !"compare_convert_fusion.1_wrapped: argument 2"}
!13 = !{!14}
!14 = distinct !{!14, !8, !"compare_convert_fusion.1_wrapped: argument 3"}
!15 = !{!7, !10, !14}
!16 = !{!10, !12, !14}
!17 = !{!7, !12, !14}
!18 = !{!7, !10, !12}
!19 = distinct !{!19, !20}
!20 = !{!"llvm.loop.unroll.disable"}
