module @jit_workload attributes {mhlo.num_partitions = 1 : i32, mhlo.num_replicas = 1 : i32} {
  func.func public @main(%arg0: tensor<512x192xf32>, %arg1: tensor<192x192xf32>, %arg2: tensor<192xf32>, %arg3: tensor<192xf32>, %arg4: tensor<192xf32>) -> (tensor<512x192xf32> {jax.result_info = "result"}) {
    %0 = stablehlo.dot_general %arg0, %arg1, contracting_dims = [1] x [0], precision = [DEFAULT, DEFAULT] : (tensor<512x192xf32>, tensor<192x192xf32>) -> tensor<512x192xf32>
    %1 = stablehlo.broadcast_in_dim %arg2, dims = [1] : (tensor<192xf32>) -> tensor<1x192xf32>
    %2 = stablehlo.broadcast_in_dim %1, dims = [0, 1] : (tensor<1x192xf32>) -> tensor<512x192xf32>
    %3 = stablehlo.add %0, %2 : tensor<512x192xf32>
    %cst = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %4 = stablehlo.broadcast_in_dim %cst, dims = [] : (tensor<f32>) -> tensor<512x192xf32>
    %5 = stablehlo.maximum %3, %4 : tensor<512x192xf32>
    %6 = chlo.square %5 : tensor<512x192xf32> -> tensor<512x192xf32>
    %cst_0 = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %7 = stablehlo.reduce(%6 init: %cst_0) applies stablehlo.add across dimensions = [1] : (tensor<512x192xf32>, tensor<f32>) -> tensor<512xf32>
    %8 = stablehlo.broadcast_in_dim %7, dims = [0] : (tensor<512xf32>) -> tensor<512x1xf32>
    %cst_1 = stablehlo.constant dense<1.920000e+02> : tensor<f32>
    %9 = stablehlo.broadcast_in_dim %cst_1, dims = [] : (tensor<f32>) -> tensor<512x1xf32>
    %10 = stablehlo.divide %8, %9 : tensor<512x1xf32>
    %cst_2 = stablehlo.constant dense<9.99999974E-5> : tensor<f32>
    %11 = stablehlo.broadcast_in_dim %cst_2, dims = [] : (tensor<f32>) -> tensor<512x1xf32>
    %12 = stablehlo.add %10, %11 : tensor<512x1xf32>
    %13 = stablehlo.rsqrt %12 : tensor<512x1xf32>
    %14 = stablehlo.broadcast_in_dim %13, dims = [0, 1] : (tensor<512x1xf32>) -> tensor<512x192xf32>
    %15 = stablehlo.multiply %5, %14 : tensor<512x192xf32>
    %16 = stablehlo.broadcast_in_dim %arg3, dims = [1] : (tensor<192xf32>) -> tensor<1x192xf32>
    %17 = stablehlo.broadcast_in_dim %16, dims = [0, 1] : (tensor<1x192xf32>) -> tensor<512x192xf32>
    %18 = stablehlo.multiply %15, %17 : tensor<512x192xf32>
    %19 = stablehlo.broadcast_in_dim %arg4, dims = [1] : (tensor<192xf32>) -> tensor<1x192xf32>
    %20 = stablehlo.broadcast_in_dim %19, dims = [0, 1] : (tensor<1x192xf32>) -> tensor<512x192xf32>
    %21 = stablehlo.add %18, %20 : tensor<512x192xf32>
    %cst_3 = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %22 = stablehlo.broadcast_in_dim %cst_3, dims = [] : (tensor<f32>) -> tensor<512x192xf32>
    %23 = stablehlo.maximum %21, %22 : tensor<512x192xf32>
    %cst_4 = stablehlo.constant dense<7.500000e-01> : tensor<f32>
    %24 = stablehlo.broadcast_in_dim %cst_4, dims = [] : (tensor<f32>) -> tensor<512x192xf32>
    %25 = stablehlo.multiply %23, %24 : tensor<512x192xf32>
    %cst_5 = stablehlo.constant dense<1.250000e-01> : tensor<f32>
    %26 = stablehlo.broadcast_in_dim %cst_5, dims = [] : (tensor<f32>) -> tensor<512x192xf32>
    %27 = stablehlo.add %25, %26 : tensor<512x192xf32>
    return %27 : tensor<512x192xf32>
  }
}
