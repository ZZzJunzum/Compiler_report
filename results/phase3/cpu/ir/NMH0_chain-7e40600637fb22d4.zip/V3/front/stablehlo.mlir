module @jit_front attributes {mhlo.num_partitions = 1 : i32, mhlo.num_replicas = 1 : i32} {
  func.func public @main(%arg0: tensor<32x320xf32>, %arg1: tensor<320xf32>, %arg2: tensor<320xf32>) -> (tensor<32x320xf32> {jax.result_info = "result[0]"}, tensor<i32> {jax.result_info = "result[1]"}) {
    %0 = chlo.square %arg0 : tensor<32x320xf32> -> tensor<32x320xf32>
    %cst = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %1 = stablehlo.reduce(%0 init: %cst) applies stablehlo.add across dimensions = [1] : (tensor<32x320xf32>, tensor<f32>) -> tensor<32xf32>
    %2 = stablehlo.broadcast_in_dim %1, dims = [0] : (tensor<32xf32>) -> tensor<32x1xf32>
    %cst_0 = stablehlo.constant dense<3.200000e+02> : tensor<f32>
    %3 = stablehlo.broadcast_in_dim %cst_0, dims = [] : (tensor<f32>) -> tensor<32x1xf32>
    %4 = stablehlo.divide %2, %3 : tensor<32x1xf32>
    %cst_1 = stablehlo.constant dense<9.99999974E-5> : tensor<f32>
    %5 = stablehlo.broadcast_in_dim %cst_1, dims = [] : (tensor<f32>) -> tensor<32x1xf32>
    %6 = stablehlo.add %4, %5 : tensor<32x1xf32>
    %7 = stablehlo.rsqrt %6 : tensor<32x1xf32>
    %8 = stablehlo.broadcast_in_dim %7, dims = [0, 1] : (tensor<32x1xf32>) -> tensor<32x320xf32>
    %9 = stablehlo.multiply %arg0, %8 : tensor<32x320xf32>
    %10 = stablehlo.broadcast_in_dim %arg1, dims = [1] : (tensor<320xf32>) -> tensor<1x320xf32>
    %11 = stablehlo.broadcast_in_dim %10, dims = [0, 1] : (tensor<1x320xf32>) -> tensor<32x320xf32>
    %12 = stablehlo.multiply %9, %11 : tensor<32x320xf32>
    %13 = stablehlo.broadcast_in_dim %arg2, dims = [1] : (tensor<320xf32>) -> tensor<1x320xf32>
    %14 = stablehlo.broadcast_in_dim %13, dims = [0, 1] : (tensor<1x320xf32>) -> tensor<32x320xf32>
    %15 = stablehlo.add %12, %14 : tensor<32x320xf32>
    %cst_2 = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %16 = stablehlo.broadcast_in_dim %cst_2, dims = [] : (tensor<f32>) -> tensor<32x320xf32>
    %17 = stablehlo.maximum %15, %16 : tensor<32x320xf32>
    %cst_3 = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %18 = stablehlo.broadcast_in_dim %cst_3, dims = [] : (tensor<f32>) -> tensor<32x320xf32>
    %19 = stablehlo.compare  GT, %17, %18,  FLOAT : (tensor<32x320xf32>, tensor<32x320xf32>) -> tensor<32x320xi1>
    %20 = stablehlo.convert %19 : (tensor<32x320xi1>) -> tensor<32x320xi32>
    %c = stablehlo.constant dense<0> : tensor<i32>
    %21 = stablehlo.reduce(%20 init: %c) applies stablehlo.add across dimensions = [0, 1] : (tensor<32x320xi32>, tensor<i32>) -> tensor<i32>
    return %17, %21 : tensor<32x320xf32>, tensor<i32>
  }
}
