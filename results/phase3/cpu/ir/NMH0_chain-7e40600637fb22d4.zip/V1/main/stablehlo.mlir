module @jit_workload attributes {mhlo.num_partitions = 1 : i32, mhlo.num_replicas = 1 : i32} {
  func.func public @main(%arg0: tensor<32x320xf32>, %arg1: tensor<320xf32>, %arg2: tensor<320xf32>, %arg3: tensor<320x320xf32>, %arg4: tensor<320xf32>) -> (tensor<32x320xf32> {jax.result_info = "result[0]"}, tensor<i32> {jax.result_info = "result[1]"}, tensor<i32> {jax.result_info = "result[2]"}) {
    %0 = chlo.square %arg0 : tensor<32x320xf32> -> tensor<32x320xf32>
    %cst = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %1 = stablehlo.reduce(%0 init: %cst) applies stablehlo.add across dimensions = [1] : (tensor<32x320xf32>, tensor<f32>) -> tensor<32xf32>
    %2 = stablehlo.broadcast_in_dim %1, dims = [0] : (tensor<32xf32>) -> tensor<32x1xf32>
    %cst_0 = stablehlo.constant dense<3.200000e+02> : tensor<f32>
    %3 = stablehlo.broadcast_in_dim %cst_0, dims = [] : (tensor<f32>) -> tensor<32x1xf32>
    %4 = stablehlo.divide %2, %3 : tensor<32x1xf32>
    %cst_1 = stablehlo.constant dense<9.99999974E-5> : tensor<f32>
    %5 = stablehlo.broadcast_in_dim %cst_1, dims = [] : (tensor<f32>) -> tensor<32x1xf32>
    %6 = stablehlo.add %4, %5 : tensor<32x1xf32>
    %7 = stablehlo.rsqrt %6 : tensor<32x1xf32>
    %8 = stablehlo.broadcast_in_dim %7, dims = [0, 1] : (tensor<32x1xf32>) -> tensor<32x320xf32>
    %9 = stablehlo.multiply %arg0, %8 : tensor<32x320xf32>
    %10 = stablehlo.broadcast_in_dim %arg1, dims = [1] : (tensor<320xf32>) -> tensor<1x320xf32>
    %11 = stablehlo.broadcast_in_dim %10, dims = [0, 1] : (tensor<1x320xf32>) -> tensor<32x320xf32>
    %12 = stablehlo.multiply %9, %11 : tensor<32x320xf32>
    %13 = stablehlo.broadcast_in_dim %arg2, dims = [1] : (tensor<320xf32>) -> tensor<1x320xf32>
    %14 = stablehlo.broadcast_in_dim %13, dims = [0, 1] : (tensor<1x320xf32>) -> tensor<32x320xf32>
    %15 = stablehlo.add %12, %14 : tensor<32x320xf32>
    %cst_2 = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %16 = stablehlo.broadcast_in_dim %cst_2, dims = [] : (tensor<f32>) -> tensor<32x320xf32>
    %17 = stablehlo.maximum %15, %16 : tensor<32x320xf32>
    %cst_3 = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %18 = stablehlo.broadcast_in_dim %cst_3, dims = [] : (tensor<f32>) -> tensor<32x320xf32>
    %19 = stablehlo.compare  GT, %17, %18,  FLOAT : (tensor<32x320xf32>, tensor<32x320xf32>) -> tensor<32x320xi1>
    %20 = stablehlo.convert %19 : (tensor<32x320xi1>) -> tensor<32x320xi32>
    %c = stablehlo.constant dense<0> : tensor<i32>
    %21 = stablehlo.reduce(%20 init: %c) applies stablehlo.add across dimensions = [0, 1] : (tensor<32x320xi32>, tensor<i32>) -> tensor<i32>
    %22 = stablehlo.dot_general %17, %arg3, contracting_dims = [1] x [0], precision = [DEFAULT, DEFAULT] : (tensor<32x320xf32>, tensor<320x320xf32>) -> tensor<32x320xf32>
    %23 = stablehlo.broadcast_in_dim %arg4, dims = [1] : (tensor<320xf32>) -> tensor<1x320xf32>
    %24 = stablehlo.broadcast_in_dim %23, dims = [0, 1] : (tensor<1x320xf32>) -> tensor<32x320xf32>
    %25 = stablehlo.add %22, %24 : tensor<32x320xf32>
    %cst_4 = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %26 = stablehlo.broadcast_in_dim %cst_4, dims = [] : (tensor<f32>) -> tensor<32x320xf32>
    %27 = stablehlo.maximum %25, %26 : tensor<32x320xf32>
    %cst_5 = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %28 = stablehlo.broadcast_in_dim %cst_5, dims = [] : (tensor<f32>) -> tensor<32x320xf32>
    %29 = stablehlo.compare  GT, %27, %28,  FLOAT : (tensor<32x320xf32>, tensor<32x320xf32>) -> tensor<32x320xi1>
    %30 = stablehlo.convert %29 : (tensor<32x320xi1>) -> tensor<32x320xi32>
    %c_6 = stablehlo.constant dense<0> : tensor<i32>
    %31 = stablehlo.reduce(%30 init: %c_6) applies stablehlo.add across dimensions = [0, 1] : (tensor<32x320xi32>, tensor<i32>) -> tensor<i32>
    %cst_7 = stablehlo.constant dense<7.500000e-01> : tensor<f32>
    %32 = stablehlo.broadcast_in_dim %cst_7, dims = [] : (tensor<f32>) -> tensor<32x320xf32>
    %33 = stablehlo.multiply %27, %32 : tensor<32x320xf32>
    %cst_8 = stablehlo.constant dense<1.250000e-01> : tensor<f32>
    %34 = stablehlo.broadcast_in_dim %cst_8, dims = [] : (tensor<f32>) -> tensor<32x320xf32>
    %35 = stablehlo.add %33, %34 : tensor<32x320xf32>
    return %35, %21, %31 : tensor<32x320xf32>, tensor<i32>, tensor<i32>
  }
}
