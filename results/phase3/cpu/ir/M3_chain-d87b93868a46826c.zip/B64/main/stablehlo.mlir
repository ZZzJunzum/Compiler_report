module @jit_execute attributes {mhlo.num_partitions = 1 : i32, mhlo.num_replicas = 1 : i32} {
  func.func public @main(%arg0: tensor<256x256xf32>, %arg1: tensor<256x256xf32>, %arg2: tensor<256xf32>, %arg3: tensor<256x256xf32>, %arg4: tensor<256xf32>) -> (tensor<256x256xf32> {jax.result_info = "result"}) {
    %0 = stablehlo.reshape %arg0 : (tensor<256x256xf32>) -> tensor<4x64x256xf32>
    %cst = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %1 = stablehlo.broadcast_in_dim %cst, dims = [] : (tensor<f32>) -> tensor<4x64x256xf32>
    %c = stablehlo.constant dense<0> : tensor<i32>
    %2:7 = stablehlo.while(%iterArg = %0, %iterArg_0 = %arg1, %iterArg_1 = %arg2, %iterArg_2 = %arg3, %iterArg_3 = %arg4, %iterArg_4 = %c, %iterArg_5 = %1) : tensor<4x64x256xf32>, tensor<256x256xf32>, tensor<256xf32>, tensor<256x256xf32>, tensor<256xf32>, tensor<i32>, tensor<4x64x256xf32>
    cond {
      %c_6 = stablehlo.constant dense<4> : tensor<i32>
      %4 = stablehlo.compare  LT, %iterArg_4, %c_6,  SIGNED : (tensor<i32>, tensor<i32>) -> tensor<i1>
      stablehlo.return %4 : tensor<i1>
    } do {
      %c_6 = stablehlo.constant dense<0> : tensor<i32>
      %c_7 = stablehlo.constant dense<0> : tensor<i32>
      %4 = stablehlo.dynamic_slice %iterArg, %iterArg_4, %c_6, %c_7, sizes = [1, 64, 256] : (tensor<4x64x256xf32>, tensor<i32>, tensor<i32>, tensor<i32>) -> tensor<1x64x256xf32>
      %5 = stablehlo.reshape %4 : (tensor<1x64x256xf32>) -> tensor<64x256xf32>
      %6 = func.call @closed_call(%iterArg_0, %iterArg_1, %iterArg_2, %iterArg_3, %5) : (tensor<256x256xf32>, tensor<256xf32>, tensor<256x256xf32>, tensor<256xf32>, tensor<64x256xf32>) -> tensor<64x256xf32>
      %7 = stablehlo.broadcast_in_dim %6, dims = [1, 2] : (tensor<64x256xf32>) -> tensor<1x64x256xf32>
      %c_8 = stablehlo.constant dense<0> : tensor<i32>
      %c_9 = stablehlo.constant dense<0> : tensor<i32>
      %8 = stablehlo.dynamic_update_slice %iterArg_5, %7, %iterArg_4, %c_8, %c_9 : (tensor<4x64x256xf32>, tensor<1x64x256xf32>, tensor<i32>, tensor<i32>, tensor<i32>) -> tensor<4x64x256xf32>
      %c_10 = stablehlo.constant dense<1> : tensor<i32>
      %9 = stablehlo.add %iterArg_4, %c_10 : tensor<i32>
      stablehlo.return %iterArg, %iterArg_0, %iterArg_1, %iterArg_2, %iterArg_3, %9, %8 : tensor<4x64x256xf32>, tensor<256x256xf32>, tensor<256xf32>, tensor<256x256xf32>, tensor<256xf32>, tensor<i32>, tensor<4x64x256xf32>
    }
    %3 = stablehlo.reshape %2#6 : (tensor<4x64x256xf32>) -> tensor<256x256xf32>
    return %3 : tensor<256x256xf32>
  }
  func.func private @closed_call(%arg0: tensor<256x256xf32>, %arg1: tensor<256xf32>, %arg2: tensor<256x256xf32>, %arg3: tensor<256xf32>, %arg4: tensor<64x256xf32>) -> tensor<64x256xf32> {
    %0 = stablehlo.dot_general %arg4, %arg0, contracting_dims = [1] x [0], precision = [DEFAULT, DEFAULT] : (tensor<64x256xf32>, tensor<256x256xf32>) -> tensor<64x256xf32>
    %1 = stablehlo.broadcast_in_dim %arg1, dims = [1] : (tensor<256xf32>) -> tensor<1x256xf32>
    %2 = stablehlo.broadcast_in_dim %1, dims = [0, 1] : (tensor<1x256xf32>) -> tensor<64x256xf32>
    %3 = stablehlo.add %0, %2 : tensor<64x256xf32>
    %cst = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %4 = stablehlo.broadcast_in_dim %cst, dims = [] : (tensor<f32>) -> tensor<64x256xf32>
    %5 = stablehlo.maximum %3, %4 : tensor<64x256xf32>
    %6 = stablehlo.dot_general %5, %arg2, contracting_dims = [1] x [0], precision = [DEFAULT, DEFAULT] : (tensor<64x256xf32>, tensor<256x256xf32>) -> tensor<64x256xf32>
    %7 = stablehlo.broadcast_in_dim %arg3, dims = [1] : (tensor<256xf32>) -> tensor<1x256xf32>
    %8 = stablehlo.broadcast_in_dim %7, dims = [0, 1] : (tensor<1x256xf32>) -> tensor<64x256xf32>
    %9 = stablehlo.add %6, %8 : tensor<64x256xf32>
    %cst_0 = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %10 = stablehlo.broadcast_in_dim %cst_0, dims = [] : (tensor<f32>) -> tensor<64x256xf32>
    %11 = stablehlo.maximum %9, %10 : tensor<64x256xf32>
    %cst_1 = stablehlo.constant dense<7.500000e-01> : tensor<f32>
    %12 = stablehlo.broadcast_in_dim %cst_1, dims = [] : (tensor<f32>) -> tensor<64x256xf32>
    %13 = stablehlo.multiply %11, %12 : tensor<64x256xf32>
    %cst_2 = stablehlo.constant dense<1.250000e-01> : tensor<f32>
    %14 = stablehlo.broadcast_in_dim %cst_2, dims = [] : (tensor<f32>) -> tensor<64x256xf32>
    %15 = stablehlo.add %13, %14 : tensor<64x256xf32>
    return %15 : tensor<64x256xf32>
  }
}
