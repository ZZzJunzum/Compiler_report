module @jit_workload attributes {mhlo.num_partitions = 1 : i32, mhlo.num_replicas = 1 : i32} {
  func.func public @main(%arg0: tensor<512x192xf32>, %arg1: tensor<192x192xf32>, %arg2: tensor<192xf32>, %arg3: tensor<192xf32>, %arg4: tensor<192xf32>) -> (tensor<512x192xf32> {jax.result_info = "result[0]"}, tensor<i32> {jax.result_info = "result[1]"}, tensor<i32> {jax.result_info = "result[2]"}) {
    %0 = stablehlo.dot_general %arg0, %arg1, contracting_dims = [1] x [0], precision = [DEFAULT, DEFAULT] : (tensor<512x192xf32>, tensor<192x192xf32>) -> tensor<512x192xf32>
    %1 = stablehlo.broadcast_in_dim %arg2, dims = [1] : (tensor<192xf32>) -> tensor<1x192xf32>
    %2 = stablehlo.broadcast_in_dim %1, dims = [0, 1] : (tensor<1x192xf32>) -> tensor<512x192xf32>
    %3 = stablehlo.add %0, %2 : tensor<512x192xf32>
    %cst = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %4 = stablehlo.broadcast_in_dim %cst, dims = [] : (tensor<f32>) -> tensor<512x192xf32>
    %5 = stablehlo.maximum %3, %4 : tensor<512x192xf32>
    %cst_0 = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %6 = stablehlo.broadcast_in_dim %cst_0, dims = [] : (tensor<f32>) -> tensor<512x192xf32>
    %7 = stablehlo.compare  GT, %5, %6,  FLOAT : (tensor<512x192xf32>, tensor<512x192xf32>) -> tensor<512x192xi1>
    %8 = stablehlo.convert %7 : (tensor<512x192xi1>) -> tensor<512x192xi32>
    %c = stablehlo.constant dense<0> : tensor<i32>
    %9 = stablehlo.reduce(%8 init: %c) applies stablehlo.add across dimensions = [0, 1] : (tensor<512x192xi32>, tensor<i32>) -> tensor<i32>
    %10 = chlo.square %5 : tensor<512x192xf32> -> tensor<512x192xf32>
    %cst_1 = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %11 = stablehlo.reduce(%10 init: %cst_1) applies stablehlo.add across dimensions = [1] : (tensor<512x192xf32>, tensor<f32>) -> tensor<512xf32>
    %12 = stablehlo.broadcast_in_dim %11, dims = [0] : (tensor<512xf32>) -> tensor<512x1xf32>
    %cst_2 = stablehlo.constant dense<1.920000e+02> : tensor<f32>
    %13 = stablehlo.broadcast_in_dim %cst_2, dims = [] : (tensor<f32>) -> tensor<512x1xf32>
    %14 = stablehlo.divide %12, %13 : tensor<512x1xf32>
    %cst_3 = stablehlo.constant dense<9.99999974E-5> : tensor<f32>
    %15 = stablehlo.broadcast_in_dim %cst_3, dims = [] : (tensor<f32>) -> tensor<512x1xf32>
    %16 = stablehlo.add %14, %15 : tensor<512x1xf32>
    %17 = stablehlo.rsqrt %16 : tensor<512x1xf32>
    %18 = stablehlo.broadcast_in_dim %17, dims = [0, 1] : (tensor<512x1xf32>) -> tensor<512x192xf32>
    %19 = stablehlo.multiply %5, %18 : tensor<512x192xf32>
    %20 = stablehlo.broadcast_in_dim %arg3, dims = [1] : (tensor<192xf32>) -> tensor<1x192xf32>
    %21 = stablehlo.broadcast_in_dim %20, dims = [0, 1] : (tensor<1x192xf32>) -> tensor<512x192xf32>
    %22 = stablehlo.multiply %19, %21 : tensor<512x192xf32>
    %23 = stablehlo.broadcast_in_dim %arg4, dims = [1] : (tensor<192xf32>) -> tensor<1x192xf32>
    %24 = stablehlo.broadcast_in_dim %23, dims = [0, 1] : (tensor<1x192xf32>) -> tensor<512x192xf32>
    %25 = stablehlo.add %22, %24 : tensor<512x192xf32>
    %cst_4 = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %26 = stablehlo.broadcast_in_dim %cst_4, dims = [] : (tensor<f32>) -> tensor<512x192xf32>
    %27 = stablehlo.maximum %25, %26 : tensor<512x192xf32>
    %cst_5 = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %28 = stablehlo.broadcast_in_dim %cst_5, dims = [] : (tensor<f32>) -> tensor<512x192xf32>
    %29 = stablehlo.compare  GT, %27, %28,  FLOAT : (tensor<512x192xf32>, tensor<512x192xf32>) -> tensor<512x192xi1>
    %30 = stablehlo.convert %29 : (tensor<512x192xi1>) -> tensor<512x192xi32>
    %c_6 = stablehlo.constant dense<0> : tensor<i32>
    %31 = stablehlo.reduce(%30 init: %c_6) applies stablehlo.add across dimensions = [0, 1] : (tensor<512x192xi32>, tensor<i32>) -> tensor<i32>
    %cst_7 = stablehlo.constant dense<7.500000e-01> : tensor<f32>
    %32 = stablehlo.broadcast_in_dim %cst_7, dims = [] : (tensor<f32>) -> tensor<512x192xf32>
    %33 = stablehlo.multiply %27, %32 : tensor<512x192xf32>
    %cst_8 = stablehlo.constant dense<1.250000e-01> : tensor<f32>
    %34 = stablehlo.broadcast_in_dim %cst_8, dims = [] : (tensor<f32>) -> tensor<512x192xf32>
    %35 = stablehlo.add %33, %34 : tensor<512x192xf32>
    return %35, %9, %31 : tensor<512x192xf32>, tensor<i32>, tensor<i32>
  }
}
