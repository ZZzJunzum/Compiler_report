module @jit_back attributes {mhlo.num_partitions = 1 : i32, mhlo.num_replicas = 1 : i32} {
  sdy.mesh @empty_mesh = <[]>
  func.func public @main(%arg0: tensor<512x192xf32> {sdy.sharding = #sdy.sharding<@empty_mesh, [{}, {}]>}, %arg1: tensor<192xf32>, %arg2: tensor<192xf32>) -> (tensor<512x192xf32> {jax.result_info = "result[0]"}, tensor<i32> {jax.result_info = "result[1]"}) {
    %0 = chlo.square %arg0 : tensor<512x192xf32> -> tensor<512x192xf32>
    %cst = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %1 = stablehlo.reduce(%0 init: %cst) applies stablehlo.add across dimensions = [1] : (tensor<512x192xf32>, tensor<f32>) -> tensor<512xf32>
    %2 = stablehlo.broadcast_in_dim %1, dims = [0] : (tensor<512xf32>) -> tensor<512x1xf32>
    %cst_0 = stablehlo.constant dense<1.920000e+02> : tensor<f32>
    %3 = stablehlo.broadcast_in_dim %cst_0, dims = [] : (tensor<f32>) -> tensor<512x1xf32>
    %4 = stablehlo.divide %2, %3 : tensor<512x1xf32>
    %cst_1 = stablehlo.constant dense<9.99999974E-5> : tensor<f32>
    %5 = stablehlo.broadcast_in_dim %cst_1, dims = [] : (tensor<f32>) -> tensor<512x1xf32>
    %6 = stablehlo.add %4, %5 : tensor<512x1xf32>
    %7 = stablehlo.rsqrt %6 : tensor<512x1xf32>
    %8 = stablehlo.broadcast_in_dim %7, dims = [0, 1] : (tensor<512x1xf32>) -> tensor<512x192xf32>
    %9 = stablehlo.multiply %arg0, %8 : tensor<512x192xf32>
    %10 = stablehlo.broadcast_in_dim %arg1, dims = [1] : (tensor<192xf32>) -> tensor<1x192xf32>
    %11 = stablehlo.broadcast_in_dim %10, dims = [0, 1] : (tensor<1x192xf32>) -> tensor<512x192xf32>
    %12 = stablehlo.multiply %9, %11 : tensor<512x192xf32>
    %13 = stablehlo.broadcast_in_dim %arg2, dims = [1] : (tensor<192xf32>) -> tensor<1x192xf32>
    %14 = stablehlo.broadcast_in_dim %13, dims = [0, 1] : (tensor<1x192xf32>) -> tensor<512x192xf32>
    %15 = stablehlo.add %12, %14 : tensor<512x192xf32>
    %cst_2 = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %16 = stablehlo.broadcast_in_dim %cst_2, dims = [] : (tensor<f32>) -> tensor<512x192xf32>
    %17 = stablehlo.maximum %15, %16 : tensor<512x192xf32>
    %cst_3 = stablehlo.constant dense<7.500000e-01> : tensor<f32>
    %18 = stablehlo.broadcast_in_dim %cst_3, dims = [] : (tensor<f32>) -> tensor<512x192xf32>
    %19 = stablehlo.multiply %17, %18 : tensor<512x192xf32>
    %cst_4 = stablehlo.constant dense<1.250000e-01> : tensor<f32>
    %20 = stablehlo.broadcast_in_dim %cst_4, dims = [] : (tensor<f32>) -> tensor<512x192xf32>
    %21 = stablehlo.add %19, %20 : tensor<512x192xf32>
    %cst_5 = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %22 = stablehlo.broadcast_in_dim %cst_5, dims = [] : (tensor<f32>) -> tensor<512x192xf32>
    %23 = stablehlo.compare  GT, %17, %22,  FLOAT : (tensor<512x192xf32>, tensor<512x192xf32>) -> tensor<512x192xi1>
    %24 = stablehlo.convert %23 : (tensor<512x192xi1>) -> tensor<512x192xi32>
    %c = stablehlo.constant dense<0> : tensor<i32>
    %25 = stablehlo.reduce(%24 init: %c) applies stablehlo.add across dimensions = [0, 1] : (tensor<512x192xi32>, tensor<i32>) -> tensor<i32>
    return %21, %25 : tensor<512x192xf32>, tensor<i32>
  }
}
