module @jit_execute attributes {mhlo.num_partitions = 1 : i32, mhlo.num_replicas = 1 : i32} {
  func.func public @main(%arg0: tensor<1024x256xf32>, %arg1: tensor<256xf32>, %arg2: tensor<256xf32>, %arg3: tensor<256xf32>, %arg4: tensor<256xf32>) -> (tensor<1024x256xf32> {jax.result_info = "result[0]"}, tensor<i32> {jax.result_info = "result[1]"}, tensor<i32> {jax.result_info = "result[2]"}) {
    %0 = stablehlo.reshape %arg0 : (tensor<1024x256xf32>) -> tensor<256x4x256xf32>
    %cst = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %1 = stablehlo.broadcast_in_dim %cst, dims = [] : (tensor<f32>) -> tensor<256x4x256xf32>
    %c = stablehlo.constant dense<0> : tensor<i32>
    %2 = stablehlo.broadcast_in_dim %c, dims = [] : (tensor<i32>) -> tensor<256xi32>
    %c_0 = stablehlo.constant dense<0> : tensor<i32>
    %3 = stablehlo.broadcast_in_dim %c_0, dims = [] : (tensor<i32>) -> tensor<256xi32>
    %c_1 = stablehlo.constant dense<0> : tensor<i32>
    %4:9 = stablehlo.while(%iterArg = %0, %iterArg_4 = %arg1, %iterArg_5 = %arg2, %iterArg_6 = %arg3, %iterArg_7 = %arg4, %iterArg_8 = %c_1, %iterArg_9 = %1, %iterArg_10 = %2, %iterArg_11 = %3) : tensor<256x4x256xf32>, tensor<256xf32>, tensor<256xf32>, tensor<256xf32>, tensor<256xf32>, tensor<i32>, tensor<256x4x256xf32>, tensor<256xi32>, tensor<256xi32>
    cond {
      %c_12 = stablehlo.constant dense<256> : tensor<i32>
      %8 = stablehlo.compare  LT, %iterArg_8, %c_12,  SIGNED : (tensor<i32>, tensor<i32>) -> tensor<i1>
      stablehlo.return %8 : tensor<i1>
    } do {
      %c_12 = stablehlo.constant dense<0> : tensor<i32>
      %c_13 = stablehlo.constant dense<0> : tensor<i32>
      %8 = stablehlo.dynamic_slice %iterArg, %iterArg_8, %c_12, %c_13, sizes = [1, 4, 256] : (tensor<256x4x256xf32>, tensor<i32>, tensor<i32>, tensor<i32>) -> tensor<1x4x256xf32>
      %9 = stablehlo.reshape %8 : (tensor<1x4x256xf32>) -> tensor<4x256xf32>
      %10:3 = func.call @closed_call(%iterArg_4, %iterArg_5, %iterArg_6, %iterArg_7, %9) : (tensor<256xf32>, tensor<256xf32>, tensor<256xf32>, tensor<256xf32>, tensor<4x256xf32>) -> (tensor<4x256xf32>, tensor<i32>, tensor<i32>)
      %11 = stablehlo.broadcast_in_dim %10#0, dims = [1, 2] : (tensor<4x256xf32>) -> tensor<1x4x256xf32>
      %c_14 = stablehlo.constant dense<0> : tensor<i32>
      %c_15 = stablehlo.constant dense<0> : tensor<i32>
      %12 = stablehlo.dynamic_update_slice %iterArg_9, %11, %iterArg_8, %c_14, %c_15 : (tensor<256x4x256xf32>, tensor<1x4x256xf32>, tensor<i32>, tensor<i32>, tensor<i32>) -> tensor<256x4x256xf32>
      %13 = stablehlo.broadcast_in_dim %10#1, dims = [] : (tensor<i32>) -> tensor<1xi32>
      %14 = stablehlo.dynamic_update_slice %iterArg_10, %13, %iterArg_8 : (tensor<256xi32>, tensor<1xi32>, tensor<i32>) -> tensor<256xi32>
      %15 = stablehlo.broadcast_in_dim %10#2, dims = [] : (tensor<i32>) -> tensor<1xi32>
      %16 = stablehlo.dynamic_update_slice %iterArg_11, %15, %iterArg_8 : (tensor<256xi32>, tensor<1xi32>, tensor<i32>) -> tensor<256xi32>
      %c_16 = stablehlo.constant dense<1> : tensor<i32>
      %17 = stablehlo.add %iterArg_8, %c_16 : tensor<i32>
      stablehlo.return %iterArg, %iterArg_4, %iterArg_5, %iterArg_6, %iterArg_7, %17, %12, %14, %16 : tensor<256x4x256xf32>, tensor<256xf32>, tensor<256xf32>, tensor<256xf32>, tensor<256xf32>, tensor<i32>, tensor<256x4x256xf32>, tensor<256xi32>, tensor<256xi32>
    }
    %5 = stablehlo.reshape %4#6 : (tensor<256x4x256xf32>) -> tensor<1024x256xf32>
    %c_2 = stablehlo.constant dense<0> : tensor<i32>
    %6 = stablehlo.reduce(%4#7 init: %c_2) applies stablehlo.add across dimensions = [0] : (tensor<256xi32>, tensor<i32>) -> tensor<i32>
    %c_3 = stablehlo.constant dense<0> : tensor<i32>
    %7 = stablehlo.reduce(%4#8 init: %c_3) applies stablehlo.add across dimensions = [0] : (tensor<256xi32>, tensor<i32>) -> tensor<i32>
    return %5, %6, %7 : tensor<1024x256xf32>, tensor<i32>, tensor<i32>
  }
  func.func private @closed_call(%arg0: tensor<256xf32>, %arg1: tensor<256xf32>, %arg2: tensor<256xf32>, %arg3: tensor<256xf32>, %arg4: tensor<4x256xf32>) -> (tensor<4x256xf32>, tensor<i32>, tensor<i32>) {
    %0 = chlo.square %arg4 : tensor<4x256xf32> -> tensor<4x256xf32>
    %cst = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %1 = stablehlo.reduce(%0 init: %cst) applies stablehlo.add across dimensions = [1] : (tensor<4x256xf32>, tensor<f32>) -> tensor<4xf32>
    %2 = stablehlo.broadcast_in_dim %1, dims = [0] : (tensor<4xf32>) -> tensor<4x1xf32>
    %cst_0 = stablehlo.constant dense<2.560000e+02> : tensor<f32>
    %3 = stablehlo.broadcast_in_dim %cst_0, dims = [] : (tensor<f32>) -> tensor<4x1xf32>
    %4 = stablehlo.divide %2, %3 : tensor<4x1xf32>
    %cst_1 = stablehlo.constant dense<9.99999974E-5> : tensor<f32>
    %5 = stablehlo.broadcast_in_dim %cst_1, dims = [] : (tensor<f32>) -> tensor<4x1xf32>
    %6 = stablehlo.add %4, %5 : tensor<4x1xf32>
    %7 = stablehlo.rsqrt %6 : tensor<4x1xf32>
    %8 = stablehlo.broadcast_in_dim %7, dims = [0, 1] : (tensor<4x1xf32>) -> tensor<4x256xf32>
    %9 = stablehlo.multiply %arg4, %8 : tensor<4x256xf32>
    %10 = stablehlo.broadcast_in_dim %arg0, dims = [1] : (tensor<256xf32>) -> tensor<1x256xf32>
    %11 = stablehlo.broadcast_in_dim %10, dims = [0, 1] : (tensor<1x256xf32>) -> tensor<4x256xf32>
    %12 = stablehlo.multiply %9, %11 : tensor<4x256xf32>
    %13 = stablehlo.broadcast_in_dim %arg1, dims = [1] : (tensor<256xf32>) -> tensor<1x256xf32>
    %14 = stablehlo.broadcast_in_dim %13, dims = [0, 1] : (tensor<1x256xf32>) -> tensor<4x256xf32>
    %15 = stablehlo.add %12, %14 : tensor<4x256xf32>
    %cst_2 = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %16 = stablehlo.broadcast_in_dim %cst_2, dims = [] : (tensor<f32>) -> tensor<4x256xf32>
    %17 = stablehlo.maximum %15, %16 : tensor<4x256xf32>
    %18 = chlo.square %17 : tensor<4x256xf32> -> tensor<4x256xf32>
    %cst_3 = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %19 = stablehlo.reduce(%18 init: %cst_3) applies stablehlo.add across dimensions = [1] : (tensor<4x256xf32>, tensor<f32>) -> tensor<4xf32>
    %20 = stablehlo.broadcast_in_dim %19, dims = [0] : (tensor<4xf32>) -> tensor<4x1xf32>
    %cst_4 = stablehlo.constant dense<2.560000e+02> : tensor<f32>
    %21 = stablehlo.broadcast_in_dim %cst_4, dims = [] : (tensor<f32>) -> tensor<4x1xf32>
    %22 = stablehlo.divide %20, %21 : tensor<4x1xf32>
    %cst_5 = stablehlo.constant dense<9.99999974E-5> : tensor<f32>
    %23 = stablehlo.broadcast_in_dim %cst_5, dims = [] : (tensor<f32>) -> tensor<4x1xf32>
    %24 = stablehlo.add %22, %23 : tensor<4x1xf32>
    %25 = stablehlo.rsqrt %24 : tensor<4x1xf32>
    %26 = stablehlo.broadcast_in_dim %25, dims = [0, 1] : (tensor<4x1xf32>) -> tensor<4x256xf32>
    %27 = stablehlo.multiply %17, %26 : tensor<4x256xf32>
    %28 = stablehlo.broadcast_in_dim %arg2, dims = [1] : (tensor<256xf32>) -> tensor<1x256xf32>
    %29 = stablehlo.broadcast_in_dim %28, dims = [0, 1] : (tensor<1x256xf32>) -> tensor<4x256xf32>
    %30 = stablehlo.multiply %27, %29 : tensor<4x256xf32>
    %31 = stablehlo.broadcast_in_dim %arg3, dims = [1] : (tensor<256xf32>) -> tensor<1x256xf32>
    %32 = stablehlo.broadcast_in_dim %31, dims = [0, 1] : (tensor<1x256xf32>) -> tensor<4x256xf32>
    %33 = stablehlo.add %30, %32 : tensor<4x256xf32>
    %cst_6 = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %34 = stablehlo.broadcast_in_dim %cst_6, dims = [] : (tensor<f32>) -> tensor<4x256xf32>
    %35 = stablehlo.maximum %33, %34 : tensor<4x256xf32>
    %cst_7 = stablehlo.constant dense<7.500000e-01> : tensor<f32>
    %36 = stablehlo.broadcast_in_dim %cst_7, dims = [] : (tensor<f32>) -> tensor<4x256xf32>
    %37 = stablehlo.multiply %35, %36 : tensor<4x256xf32>
    %cst_8 = stablehlo.constant dense<1.250000e-01> : tensor<f32>
    %38 = stablehlo.broadcast_in_dim %cst_8, dims = [] : (tensor<f32>) -> tensor<4x256xf32>
    %39 = stablehlo.add %37, %38 : tensor<4x256xf32>
    %cst_9 = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %40 = stablehlo.broadcast_in_dim %cst_9, dims = [] : (tensor<f32>) -> tensor<4x256xf32>
    %41 = stablehlo.compare  GT, %17, %40,  FLOAT : (tensor<4x256xf32>, tensor<4x256xf32>) -> tensor<4x256xi1>
    %42 = stablehlo.convert %41 : (tensor<4x256xi1>) -> tensor<4x256xi32>
    %cst_10 = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %43 = stablehlo.broadcast_in_dim %cst_10, dims = [] : (tensor<f32>) -> tensor<4x256xf32>
    %44 = stablehlo.compare  GT, %35, %43,  FLOAT : (tensor<4x256xf32>, tensor<4x256xf32>) -> tensor<4x256xi1>
    %45 = stablehlo.convert %44 : (tensor<4x256xi1>) -> tensor<4x256xi32>
    %c = stablehlo.constant dense<0> : tensor<i32>
    %c_11 = stablehlo.constant dense<0> : tensor<i32>
    %46:2 = stablehlo.reduce(%42 init: %c), (%45 init: %c_11) across dimensions = [0, 1] : (tensor<4x256xi32>, tensor<4x256xi32>, tensor<i32>, tensor<i32>) -> (tensor<i32>, tensor<i32>)
     reducer(%arg5: tensor<i32>, %arg7: tensor<i32>) (%arg6: tensor<i32>, %arg8: tensor<i32>)  {
      %47 = stablehlo.add %arg5, %arg7 : tensor<i32>
      %48 = stablehlo.add %arg6, %arg8 : tensor<i32>
      stablehlo.return %47, %48 : tensor<i32>, tensor<i32>
    }
    return %39, %46#0, %46#1 : tensor<4x256xf32>, tensor<i32>, tensor<i32>
  }
}
