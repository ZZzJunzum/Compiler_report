module @jit_workload attributes {mhlo.num_partitions = 1 : i32, mhlo.num_replicas = 1 : i32} {
  func.func public @main(%arg0: tensor<32x320xf32>, %arg1: tensor<320x320xf32>, %arg2: tensor<320xf32>, %arg3: tensor<320xf32>, %arg4: tensor<320xf32>) -> (tensor<32x320xf32> {jax.result_info = "result[0]"}, tensor<i32> {jax.result_info = "result[1]"}, tensor<i32> {jax.result_info = "result[2]"}) {
    %0 = stablehlo.dot_general %arg0, %arg1, contracting_dims = [1] x [0], precision = [DEFAULT, DEFAULT] : (tensor<32x320xf32>, tensor<320x320xf32>) -> tensor<32x320xf32>
    %1 = stablehlo.broadcast_in_dim %arg2, dims = [1] : (tensor<320xf32>) -> tensor<1x320xf32>
    %2 = stablehlo.broadcast_in_dim %1, dims = [0, 1] : (tensor<1x320xf32>) -> tensor<32x320xf32>
    %3 = stablehlo.add %0, %2 : tensor<32x320xf32>
    %cst = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %4 = stablehlo.broadcast_in_dim %cst, dims = [] : (tensor<f32>) -> tensor<32x320xf32>
    %5 = stablehlo.maximum %3, %4 : tensor<32x320xf32>
    %6 = chlo.square %5 : tensor<32x320xf32> -> tensor<32x320xf32>
    %cst_0 = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %7 = stablehlo.reduce(%6 init: %cst_0) applies stablehlo.add across dimensions = [1] : (tensor<32x320xf32>, tensor<f32>) -> tensor<32xf32>
    %8 = stablehlo.broadcast_in_dim %7, dims = [0] : (tensor<32xf32>) -> tensor<32x1xf32>
    %cst_1 = stablehlo.constant dense<3.200000e+02> : tensor<f32>
    %9 = stablehlo.broadcast_in_dim %cst_1, dims = [] : (tensor<f32>) -> tensor<32x1xf32>
    %10 = stablehlo.divide %8, %9 : tensor<32x1xf32>
    %cst_2 = stablehlo.constant dense<9.99999974E-5> : tensor<f32>
    %11 = stablehlo.broadcast_in_dim %cst_2, dims = [] : (tensor<f32>) -> tensor<32x1xf32>
    %12 = stablehlo.add %10, %11 : tensor<32x1xf32>
    %13 = stablehlo.rsqrt %12 : tensor<32x1xf32>
    %14 = stablehlo.broadcast_in_dim %13, dims = [0, 1] : (tensor<32x1xf32>) -> tensor<32x320xf32>
    %15 = stablehlo.multiply %5, %14 : tensor<32x320xf32>
    %16 = stablehlo.broadcast_in_dim %arg3, dims = [1] : (tensor<320xf32>) -> tensor<1x320xf32>
    %17 = stablehlo.broadcast_in_dim %16, dims = [0, 1] : (tensor<1x320xf32>) -> tensor<32x320xf32>
    %18 = stablehlo.multiply %15, %17 : tensor<32x320xf32>
    %19 = stablehlo.broadcast_in_dim %arg4, dims = [1] : (tensor<320xf32>) -> tensor<1x320xf32>
    %20 = stablehlo.broadcast_in_dim %19, dims = [0, 1] : (tensor<1x320xf32>) -> tensor<32x320xf32>
    %21 = stablehlo.add %18, %20 : tensor<32x320xf32>
    %cst_3 = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %22 = stablehlo.broadcast_in_dim %cst_3, dims = [] : (tensor<f32>) -> tensor<32x320xf32>
    %23 = stablehlo.maximum %21, %22 : tensor<32x320xf32>
    %cst_4 = stablehlo.constant dense<7.500000e-01> : tensor<f32>
    %24 = stablehlo.broadcast_in_dim %cst_4, dims = [] : (tensor<f32>) -> tensor<32x320xf32>
    %25 = stablehlo.multiply %23, %24 : tensor<32x320xf32>
    %cst_5 = stablehlo.constant dense<1.250000e-01> : tensor<f32>
    %26 = stablehlo.broadcast_in_dim %cst_5, dims = [] : (tensor<f32>) -> tensor<32x320xf32>
    %27 = stablehlo.add %25, %26 : tensor<32x320xf32>
    %cst_6 = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %28 = stablehlo.broadcast_in_dim %cst_6, dims = [] : (tensor<f32>) -> tensor<32x320xf32>
    %29 = stablehlo.compare  GT, %5, %28,  FLOAT : (tensor<32x320xf32>, tensor<32x320xf32>) -> tensor<32x320xi1>
    %30 = stablehlo.convert %29 : (tensor<32x320xi1>) -> tensor<32x320xi32>
    %cst_7 = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %31 = stablehlo.broadcast_in_dim %cst_7, dims = [] : (tensor<f32>) -> tensor<32x320xf32>
    %32 = stablehlo.compare  GT, %23, %31,  FLOAT : (tensor<32x320xf32>, tensor<32x320xf32>) -> tensor<32x320xi1>
    %33 = stablehlo.convert %32 : (tensor<32x320xi1>) -> tensor<32x320xi32>
    %c = stablehlo.constant dense<0> : tensor<i32>
    %c_8 = stablehlo.constant dense<0> : tensor<i32>
    %34:2 = stablehlo.reduce(%30 init: %c), (%33 init: %c_8) across dimensions = [0, 1] : (tensor<32x320xi32>, tensor<32x320xi32>, tensor<i32>, tensor<i32>) -> (tensor<i32>, tensor<i32>)
     reducer(%arg5: tensor<i32>, %arg7: tensor<i32>) (%arg6: tensor<i32>, %arg8: tensor<i32>)  {
      %35 = stablehlo.add %arg5, %arg7 : tensor<i32>
      %36 = stablehlo.add %arg6, %arg8 : tensor<i32>
      stablehlo.return %35, %36 : tensor<i32>, tensor<i32>
    }
    return %27, %34#0, %34#1 : tensor<32x320xf32>, tensor<i32>, tensor<i32>
  }
}
