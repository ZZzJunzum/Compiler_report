module @jit_execute attributes {mhlo.num_partitions = 1 : i32, mhlo.num_replicas = 1 : i32} {
  func.func public @main(%arg0: tensor<256x256xf32>, %arg1: tensor<256x256xf32>, %arg2: tensor<256xf32>, %arg3: tensor<256x256xf32>, %arg4: tensor<256xf32>) -> (tensor<256x256xf32> {jax.result_info = "result[0]"}, tensor<i32> {jax.result_info = "result[1]"}, tensor<i32> {jax.result_info = "result[2]"}) {
    %0 = stablehlo.reshape %arg0 : (tensor<256x256xf32>) -> tensor<64x4x256xf32>
    %cst = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %1 = stablehlo.broadcast_in_dim %cst, dims = [] : (tensor<f32>) -> tensor<64x4x256xf32>
    %c = stablehlo.constant dense<0> : tensor<i32>
    %2 = stablehlo.broadcast_in_dim %c, dims = [] : (tensor<i32>) -> tensor<64xi32>
    %c_0 = stablehlo.constant dense<0> : tensor<i32>
    %3 = stablehlo.broadcast_in_dim %c_0, dims = [] : (tensor<i32>) -> tensor<64xi32>
    %c_1 = stablehlo.constant dense<0> : tensor<i32>
    %4:9 = stablehlo.while(%iterArg = %0, %iterArg_4 = %arg1, %iterArg_5 = %arg2, %iterArg_6 = %arg3, %iterArg_7 = %arg4, %iterArg_8 = %c_1, %iterArg_9 = %1, %iterArg_10 = %2, %iterArg_11 = %3) : tensor<64x4x256xf32>, tensor<256x256xf32>, tensor<256xf32>, tensor<256x256xf32>, tensor<256xf32>, tensor<i32>, tensor<64x4x256xf32>, tensor<64xi32>, tensor<64xi32>
    cond {
      %c_12 = stablehlo.constant dense<64> : tensor<i32>
      %8 = stablehlo.compare  LT, %iterArg_8, %c_12,  SIGNED : (tensor<i32>, tensor<i32>) -> tensor<i1>
      stablehlo.return %8 : tensor<i1>
    } do {
      %c_12 = stablehlo.constant dense<0> : tensor<i32>
      %c_13 = stablehlo.constant dense<0> : tensor<i32>
      %8 = stablehlo.dynamic_slice %iterArg, %iterArg_8, %c_12, %c_13, sizes = [1, 4, 256] : (tensor<64x4x256xf32>, tensor<i32>, tensor<i32>, tensor<i32>) -> tensor<1x4x256xf32>
      %9 = stablehlo.reshape %8 : (tensor<1x4x256xf32>) -> tensor<4x256xf32>
      %10:3 = func.call @closed_call(%iterArg_4, %iterArg_5, %iterArg_6, %iterArg_7, %9) : (tensor<256x256xf32>, tensor<256xf32>, tensor<256x256xf32>, tensor<256xf32>, tensor<4x256xf32>) -> (tensor<4x256xf32>, tensor<i32>, tensor<i32>)
      %11 = stablehlo.broadcast_in_dim %10#0, dims = [1, 2] : (tensor<4x256xf32>) -> tensor<1x4x256xf32>
      %c_14 = stablehlo.constant dense<0> : tensor<i32>
      %c_15 = stablehlo.constant dense<0> : tensor<i32>
      %12 = stablehlo.dynamic_update_slice %iterArg_9, %11, %iterArg_8, %c_14, %c_15 : (tensor<64x4x256xf32>, tensor<1x4x256xf32>, tensor<i32>, tensor<i32>, tensor<i32>) -> tensor<64x4x256xf32>
      %13 = stablehlo.broadcast_in_dim %10#1, dims = [] : (tensor<i32>) -> tensor<1xi32>
      %14 = stablehlo.dynamic_update_slice %iterArg_10, %13, %iterArg_8 : (tensor<64xi32>, tensor<1xi32>, tensor<i32>) -> tensor<64xi32>
      %15 = stablehlo.broadcast_in_dim %10#2, dims = [] : (tensor<i32>) -> tensor<1xi32>
      %16 = stablehlo.dynamic_update_slice %iterArg_11, %15, %iterArg_8 : (tensor<64xi32>, tensor<1xi32>, tensor<i32>) -> tensor<64xi32>
      %c_16 = stablehlo.constant dense<1> : tensor<i32>
      %17 = stablehlo.add %iterArg_8, %c_16 : tensor<i32>
      stablehlo.return %iterArg, %iterArg_4, %iterArg_5, %iterArg_6, %iterArg_7, %17, %12, %14, %16 : tensor<64x4x256xf32>, tensor<256x256xf32>, tensor<256xf32>, tensor<256x256xf32>, tensor<256xf32>, tensor<i32>, tensor<64x4x256xf32>, tensor<64xi32>, tensor<64xi32>
    }
    %5 = stablehlo.reshape %4#6 : (tensor<64x4x256xf32>) -> tensor<256x256xf32>
    %c_2 = stablehlo.constant dense<0> : tensor<i32>
    %6 = stablehlo.reduce(%4#7 init: %c_2) applies stablehlo.add across dimensions = [0] : (tensor<64xi32>, tensor<i32>) -> tensor<i32>
    %c_3 = stablehlo.constant dense<0> : tensor<i32>
    %7 = stablehlo.reduce(%4#8 init: %c_3) applies stablehlo.add across dimensions = [0] : (tensor<64xi32>, tensor<i32>) -> tensor<i32>
    return %5, %6, %7 : tensor<256x256xf32>, tensor<i32>, tensor<i32>
  }
  func.func private @closed_call(%arg0: tensor<256x256xf32>, %arg1: tensor<256xf32>, %arg2: tensor<256x256xf32>, %arg3: tensor<256xf32>, %arg4: tensor<4x256xf32>) -> (tensor<4x256xf32>, tensor<i32>, tensor<i32>) {
    %0 = stablehlo.dot_general %arg4, %arg0, contracting_dims = [1] x [0], precision = [DEFAULT, DEFAULT] : (tensor<4x256xf32>, tensor<256x256xf32>) -> tensor<4x256xf32>
    %1 = stablehlo.broadcast_in_dim %arg1, dims = [1] : (tensor<256xf32>) -> tensor<1x256xf32>
    %2 = stablehlo.broadcast_in_dim %1, dims = [0, 1] : (tensor<1x256xf32>) -> tensor<4x256xf32>
    %3 = stablehlo.add %0, %2 : tensor<4x256xf32>
    %cst = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %4 = stablehlo.broadcast_in_dim %cst, dims = [] : (tensor<f32>) -> tensor<4x256xf32>
    %5 = stablehlo.maximum %3, %4 : tensor<4x256xf32>
    %cst_0 = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %6 = stablehlo.broadcast_in_dim %cst_0, dims = [] : (tensor<f32>) -> tensor<4x256xf32>
    %7 = stablehlo.compare  GT, %5, %6,  FLOAT : (tensor<4x256xf32>, tensor<4x256xf32>) -> tensor<4x256xi1>
    %8 = stablehlo.convert %7 : (tensor<4x256xi1>) -> tensor<4x256xi32>
    %c = stablehlo.constant dense<0> : tensor<i32>
    %9 = stablehlo.reduce(%8 init: %c) applies stablehlo.add across dimensions = [0, 1] : (tensor<4x256xi32>, tensor<i32>) -> tensor<i32>
    %10 = stablehlo.dot_general %5, %arg2, contracting_dims = [1] x [0], precision = [DEFAULT, DEFAULT] : (tensor<4x256xf32>, tensor<256x256xf32>) -> tensor<4x256xf32>
    %11 = stablehlo.broadcast_in_dim %arg3, dims = [1] : (tensor<256xf32>) -> tensor<1x256xf32>
    %12 = stablehlo.broadcast_in_dim %11, dims = [0, 1] : (tensor<1x256xf32>) -> tensor<4x256xf32>
    %13 = stablehlo.add %10, %12 : tensor<4x256xf32>
    %cst_1 = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %14 = stablehlo.broadcast_in_dim %cst_1, dims = [] : (tensor<f32>) -> tensor<4x256xf32>
    %15 = stablehlo.maximum %13, %14 : tensor<4x256xf32>
    %cst_2 = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %16 = stablehlo.broadcast_in_dim %cst_2, dims = [] : (tensor<f32>) -> tensor<4x256xf32>
    %17 = stablehlo.compare  GT, %15, %16,  FLOAT : (tensor<4x256xf32>, tensor<4x256xf32>) -> tensor<4x256xi1>
    %18 = stablehlo.convert %17 : (tensor<4x256xi1>) -> tensor<4x256xi32>
    %c_3 = stablehlo.constant dense<0> : tensor<i32>
    %19 = stablehlo.reduce(%18 init: %c_3) applies stablehlo.add across dimensions = [0, 1] : (tensor<4x256xi32>, tensor<i32>) -> tensor<i32>
    %cst_4 = stablehlo.constant dense<7.500000e-01> : tensor<f32>
    %20 = stablehlo.broadcast_in_dim %cst_4, dims = [] : (tensor<f32>) -> tensor<4x256xf32>
    %21 = stablehlo.multiply %15, %20 : tensor<4x256xf32>
    %cst_5 = stablehlo.constant dense<1.250000e-01> : tensor<f32>
    %22 = stablehlo.broadcast_in_dim %cst_5, dims = [] : (tensor<f32>) -> tensor<4x256xf32>
    %23 = stablehlo.add %21, %22 : tensor<4x256xf32>
    return %23, %9, %19 : tensor<4x256xf32>, tensor<i32>, tensor<i32>
  }
}
