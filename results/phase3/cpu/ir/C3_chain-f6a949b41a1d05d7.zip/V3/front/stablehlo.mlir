module @jit_front attributes {mhlo.num_partitions = 1 : i32, mhlo.num_replicas = 1 : i32} {
  func.func public @main(%arg0: tensor<16x32x32x16xf32>, %arg1: tensor<3x3x16x16xf32>, %arg2: tensor<16xf32>) -> (tensor<16x32x32x16xf32> {jax.result_info = "result[0]"}, tensor<i32> {jax.result_info = "result[1]"}) {
    %0 = stablehlo.convolution(%arg0, %arg1) dim_numbers = [b, 0, 1, f]x[0, 1, i, o]->[b, 0, 1, f], window = {stride = [1, 1], pad = [[1, 1], [1, 1]], lhs_dilate = [1, 1], rhs_dilate = [1, 1], reverse = [false, false]} {batch_group_count = 1 : i64, feature_group_count = 1 : i64, precision_config = [#stablehlo<precision DEFAULT>, #stablehlo<precision DEFAULT>]} : (tensor<16x32x32x16xf32>, tensor<3x3x16x16xf32>) -> tensor<16x32x32x16xf32>
    %1 = stablehlo.broadcast_in_dim %arg2, dims = [3] : (tensor<16xf32>) -> tensor<1x1x1x16xf32>
    %2 = stablehlo.broadcast_in_dim %1, dims = [0, 1, 2, 3] : (tensor<1x1x1x16xf32>) -> tensor<16x32x32x16xf32>
    %3 = stablehlo.add %0, %2 : tensor<16x32x32x16xf32>
    %cst = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %4 = stablehlo.broadcast_in_dim %cst, dims = [] : (tensor<f32>) -> tensor<16x32x32x16xf32>
    %5 = stablehlo.maximum %3, %4 : tensor<16x32x32x16xf32>
    %cst_0 = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %6 = stablehlo.broadcast_in_dim %cst_0, dims = [] : (tensor<f32>) -> tensor<16x32x32x16xf32>
    %7 = stablehlo.compare  GT, %5, %6,  FLOAT : (tensor<16x32x32x16xf32>, tensor<16x32x32x16xf32>) -> tensor<16x32x32x16xi1>
    %8 = stablehlo.convert %7 : (tensor<16x32x32x16xi1>) -> tensor<16x32x32x16xi32>
    %c = stablehlo.constant dense<0> : tensor<i32>
    %9 = stablehlo.reduce(%8 init: %c) applies stablehlo.add across dimensions = [0, 1, 2, 3] : (tensor<16x32x32x16xi32>, tensor<i32>) -> tensor<i32>
    return %5, %9 : tensor<16x32x32x16xf32>, tensor<i32>
  }
}
