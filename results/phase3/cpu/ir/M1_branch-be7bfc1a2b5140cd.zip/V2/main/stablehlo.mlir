module @jit_workload attributes {mhlo.num_partitions = 1 : i32, mhlo.num_replicas = 1 : i32} {
  func.func public @main(%arg0: tensor<16x256xf32>, %arg1: tensor<256x256xf32>, %arg2: tensor<256xf32>, %arg3: tensor<256x256xf32>, %arg4: tensor<256xf32>) -> (tensor<16x256xf32> {jax.result_info = "result[0]"}, tensor<i32> {jax.result_info = "result[1]"}, tensor<i32> {jax.result_info = "result[2]"}) {
    %0 = stablehlo.dot_general %arg0, %arg1, contracting_dims = [1] x [0], precision = [DEFAULT, DEFAULT] : (tensor<16x256xf32>, tensor<256x256xf32>) -> tensor<16x256xf32>
    %1 = stablehlo.broadcast_in_dim %arg2, dims = [1] : (tensor<256xf32>) -> tensor<1x256xf32>
    %2 = stablehlo.broadcast_in_dim %1, dims = [0, 1] : (tensor<1x256xf32>) -> tensor<16x256xf32>
    %3 = stablehlo.add %0, %2 : tensor<16x256xf32>
    %cst = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %4 = stablehlo.broadcast_in_dim %cst, dims = [] : (tensor<f32>) -> tensor<16x256xf32>
    %5 = stablehlo.maximum %3, %4 : tensor<16x256xf32>
    %6 = stablehlo.dot_general %5, %arg3, contracting_dims = [1] x [0], precision = [DEFAULT, DEFAULT] : (tensor<16x256xf32>, tensor<256x256xf32>) -> tensor<16x256xf32>
    %7 = stablehlo.broadcast_in_dim %arg4, dims = [1] : (tensor<256xf32>) -> tensor<1x256xf32>
    %8 = stablehlo.broadcast_in_dim %7, dims = [0, 1] : (tensor<1x256xf32>) -> tensor<16x256xf32>
    %9 = stablehlo.add %6, %8 : tensor<16x256xf32>
    %cst_0 = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %10 = stablehlo.broadcast_in_dim %cst_0, dims = [] : (tensor<f32>) -> tensor<16x256xf32>
    %11 = stablehlo.maximum %9, %10 : tensor<16x256xf32>
    %cst_1 = stablehlo.constant dense<7.500000e-01> : tensor<f32>
    %12 = stablehlo.broadcast_in_dim %cst_1, dims = [] : (tensor<f32>) -> tensor<16x256xf32>
    %13 = stablehlo.multiply %11, %12 : tensor<16x256xf32>
    %cst_2 = stablehlo.constant dense<1.250000e-01> : tensor<f32>
    %14 = stablehlo.broadcast_in_dim %cst_2, dims = [] : (tensor<f32>) -> tensor<16x256xf32>
    %15 = stablehlo.add %13, %14 : tensor<16x256xf32>
    %cst_3 = stablehlo.constant dense<2.500000e-01> : tensor<f32>
    %16 = stablehlo.broadcast_in_dim %cst_3, dims = [] : (tensor<f32>) -> tensor<16x256xf32>
    %17 = stablehlo.multiply %5, %16 : tensor<16x256xf32>
    %18 = stablehlo.add %15, %17 : tensor<16x256xf32>
    %cst_4 = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %19 = stablehlo.broadcast_in_dim %cst_4, dims = [] : (tensor<f32>) -> tensor<16x256xf32>
    %20 = stablehlo.compare  GT, %5, %19,  FLOAT : (tensor<16x256xf32>, tensor<16x256xf32>) -> tensor<16x256xi1>
    %21 = stablehlo.convert %20 : (tensor<16x256xi1>) -> tensor<16x256xi32>
    %cst_5 = stablehlo.constant dense<0.000000e+00> : tensor<f32>
    %22 = stablehlo.broadcast_in_dim %cst_5, dims = [] : (tensor<f32>) -> tensor<16x256xf32>
    %23 = stablehlo.compare  GT, %11, %22,  FLOAT : (tensor<16x256xf32>, tensor<16x256xf32>) -> tensor<16x256xi1>
    %24 = stablehlo.convert %23 : (tensor<16x256xi1>) -> tensor<16x256xi32>
    %c = stablehlo.constant dense<0> : tensor<i32>
    %c_6 = stablehlo.constant dense<0> : tensor<i32>
    %25:2 = stablehlo.reduce(%21 init: %c), (%24 init: %c_6) across dimensions = [0, 1] : (tensor<16x256xi32>, tensor<16x256xi32>, tensor<i32>, tensor<i32>) -> (tensor<i32>, tensor<i32>)
     reducer(%arg5: tensor<i32>, %arg7: tensor<i32>) (%arg6: tensor<i32>, %arg8: tensor<i32>)  {
      %26 = stablehlo.add %arg5, %arg7 : tensor<i32>
      %27 = stablehlo.add %arg6, %arg8 : tensor<i32>
      stablehlo.return %26, %27 : tensor<i32>, tensor<i32>
    }
    return %18, %25#0, %25#1 : tensor<16x256xf32>, tensor<i32>, tensor<i32>
  }
}
