; ModuleID = '__compute_module_wrapped_reduce-window_kernel_module'
source_filename = "__compute_module_wrapped_reduce-window_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

%XLA_CPU_KernelCallFrame = type { ptr, ptr, i64, ptr }
%XLA_CPU_KernelArg = type { ptr, i64 }
%kernel_dim3 = type { i64, i64, i64 }

; Function Attrs: uwtable
define ptr @wrapped_reduce-window(ptr %0) #0 {
  %2 = getelementptr inbounds %XLA_CPU_KernelCallFrame, ptr %0, i32 0, i32 3
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 0, i32 0
  %5 = load ptr, ptr %4, align 8, !invariant.load !3, !dereferenceable !4
  %6 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 1, i32 0
  %7 = load ptr, ptr %6, align 8, !invariant.load !3, !dereferenceable !5
  %8 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 2, i32 0
  %9 = load ptr, ptr %8, align 8, !invariant.load !3, !dereferenceable !6
  %10 = getelementptr inbounds %XLA_CPU_KernelCallFrame, ptr %0, i32 0, i32 1
  %11 = load ptr, ptr %10, align 8
  %12 = getelementptr inbounds %kernel_dim3, ptr %11, i32 0, i32 0
  %13 = load i64, ptr %12, align 4, !invariant.load !3
  %14 = getelementptr inbounds %kernel_dim3, ptr %11, i32 0, i32 1
  %15 = load i64, ptr %14, align 4, !invariant.load !3
  %16 = getelementptr inbounds %kernel_dim3, ptr %11, i32 0, i32 2
  %17 = load i64, ptr %16, align 4, !invariant.load !3
  call void @wrapped_reduce-window_wrapped(ptr %5, ptr %7, ptr %9, i64 %13, i64 %15, i64 %17)
  ret ptr null
}

; Function Attrs: alwaysinline
define internal void @wrapped_reduce-window_wrapped(ptr noalias align 64 dereferenceable(204800) %0, ptr noalias align 64 dereferenceable(4) %1, ptr noalias align 64 dereferenceable(200) %2, i64 %3, i64 %4, i64 %5) #1 {
  %7 = getelementptr inbounds [1 x i32], ptr %1, i32 0, i32 0
  %8 = load i32, ptr %7, align 4, !invariant.load !3
  br label %9

9:                                                ; preds = %44, %6
  %10 = phi i64 [ %45, %44 ], [ 0, %6 ]
  %11 = icmp slt i64 %10, 10
  br i1 %11, label %12, label %46

12:                                               ; preds = %9
  %13 = mul nsw i64 %10, 5120
  %14 = mul nsw i64 %10, 5
  br label %15

15:                                               ; preds = %40, %12
  %16 = phi i64 [ %43, %40 ], [ 0, %12 ]
  %17 = icmp slt i64 %16, 5
  br i1 %17, label %18, label %44

18:                                               ; preds = %15
  %19 = mul nsw i64 %16, 32
  %20 = add nsw i64 %13, %19
  br label %21

21:                                               ; preds = %38, %18
  %22 = phi i64 [ %39, %38 ], [ 0, %18 ]
  %23 = phi i32 [ %30, %38 ], [ %8, %18 ]
  %24 = icmp slt i64 %22, 32
  br i1 %24, label %25, label %40

25:                                               ; preds = %21
  %26 = mul nsw i64 %22, 160
  %27 = add nsw i64 %20, %26
  br label %28

28:                                               ; preds = %32, %25
  %29 = phi i64 [ %37, %32 ], [ 0, %25 ]
  %30 = phi i32 [ %36, %32 ], [ %23, %25 ]
  %31 = icmp slt i64 %29, 32
  br i1 %31, label %32, label %38

32:                                               ; preds = %28
  %33 = add nsw i64 %27, %29
  %34 = getelementptr inbounds [51200 x i32], ptr %0, i32 0, i64 %33
  %35 = load i32, ptr %34, align 4, !invariant.load !3
  %36 = add i32 %30, %35
  %37 = add i64 %29, 1
  br label %28

38:                                               ; preds = %28
  %39 = add i64 %22, 1
  br label %21, !llvm.loop !7

40:                                               ; preds = %21
  %41 = add nsw i64 %14, %16
  %42 = getelementptr inbounds [50 x i32], ptr %2, i32 0, i64 %41
  store i32 %23, ptr %42, align 4
  %43 = add i64 %16, 1
  br label %15, !llvm.loop !7

44:                                               ; preds = %15
  %45 = add i64 %10, 1
  br label %9, !llvm.loop !7

46:                                               ; preds = %9
  ret void
}

attributes #0 = { uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { alwaysinline }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 4}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 204800}
!5 = !{i64 4}
!6 = !{i64 200}
!7 = distinct !{!7, !8}
!8 = !{!"llvm.loop.unroll.disable"}
