; ModuleID = '__compute_module_multiply_add_fusion_kernel_module'
source_filename = "__compute_module_multiply_add_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

%XLA_CPU_KernelCallFrame = type { ptr, ptr, i64, ptr }
%XLA_CPU_KernelArg = type { ptr, i64 }
%kernel_dim3 = type { i64, i64, i64 }

; Function Attrs: uwtable
define ptr @multiply_add_fusion(ptr %0) #0 {
  %2 = getelementptr inbounds %XLA_CPU_KernelCallFrame, ptr %0, i32 0, i32 3
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 0, i32 0
  %5 = load ptr, ptr %4, align 8, !invariant.load !3, !dereferenceable !4
  %6 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 1, i32 0
  %7 = load ptr, ptr %6, align 8, !invariant.load !3, !dereferenceable !4
  %8 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 2, i32 0
  %9 = load ptr, ptr %8, align 8, !invariant.load !3, !dereferenceable !4
  %10 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 3, i32 0
  %11 = load ptr, ptr %10, align 8, !invariant.load !3, !dereferenceable !4
  %12 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 4, i32 0
  %13 = load ptr, ptr %12, align 8, !invariant.load !3, !dereferenceable !4
  %14 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 5, i32 0
  %15 = load ptr, ptr %14, align 8, !invariant.load !3, !dereferenceable !5
  %16 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 6, i32 0
  %17 = load ptr, ptr %16, align 8, !invariant.load !3, !dereferenceable !4
  %18 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 7, i32 0
  %19 = load ptr, ptr %18, align 8, !invariant.load !3, !dereferenceable !5
  %20 = getelementptr inbounds %XLA_CPU_KernelCallFrame, ptr %0, i32 0, i32 1
  %21 = load ptr, ptr %20, align 8
  %22 = getelementptr inbounds %kernel_dim3, ptr %21, i32 0, i32 0
  %23 = load i64, ptr %22, align 4, !invariant.load !3
  %24 = getelementptr inbounds %kernel_dim3, ptr %21, i32 0, i32 1
  %25 = load i64, ptr %24, align 4, !invariant.load !3
  %26 = getelementptr inbounds %kernel_dim3, ptr %21, i32 0, i32 2
  %27 = load i64, ptr %26, align 4, !invariant.load !3
  call void @multiply_add_fusion_wrapped(ptr %5, ptr %7, ptr %9, ptr %11, ptr %13, ptr %15, ptr %17, ptr %19, i64 %23, i64 %25, i64 %27)
  ret ptr null
}

; Function Attrs: alwaysinline
define internal void @multiply_add_fusion_wrapped(ptr noalias align 64 dereferenceable(640) %0, ptr noalias align 64 dereferenceable(640) %1, ptr noalias align 64 dereferenceable(640) %2, ptr noalias align 64 dereferenceable(640) %3, ptr noalias align 64 dereferenceable(640) %4, ptr noalias align 64 dereferenceable(204800) %5, ptr noalias align 64 dereferenceable(640) %6, ptr noalias align 64 dereferenceable(204800) %7, i64 %8, i64 %9, i64 %10) #1 {
  %12 = icmp sle i64 %8, 10
  br i1 %12, label %13, label %61

13:                                               ; preds = %11
  %14 = icmp sge i64 %8, 0
  br i1 %14, label %15, label %60

15:                                               ; preds = %13
  %16 = mul nsw i64 %8, 4320
  br label %17

17:                                               ; preds = %57, %15
  %18 = phi i64 [ %58, %57 ], [ 0, %15 ]
  %19 = icmp slt i64 %18, 27
  br i1 %19, label %20, label %59

20:                                               ; preds = %17
  %21 = mul nsw i64 %18, 160
  %22 = add nsw i64 %16, %21
  br label %23

23:                                               ; preds = %26, %20
  %24 = phi i64 [ %56, %26 ], [ 0, %20 ]
  %25 = icmp slt i64 %24, 160
  br i1 %25, label %26, label %57

26:                                               ; preds = %23
  %27 = getelementptr inbounds [160 x float], ptr %3, i32 0, i64 %24
  %28 = load float, ptr %27, align 4, !invariant.load !3
  %29 = add nsw i64 %22, %24
  %30 = getelementptr inbounds [51200 x float], ptr %5, i32 0, i64 %29
  %31 = load float, ptr %30, align 4, !invariant.load !3
  %32 = getelementptr inbounds [160 x float], ptr %6, i32 0, i64 %24
  %33 = load float, ptr %32, align 4, !invariant.load !3
  %34 = fmul float %31, %33
  %35 = getelementptr inbounds [160 x float], ptr %4, i32 0, i64 %24
  %36 = load float, ptr %35, align 4, !invariant.load !3
  %37 = fadd float %34, %36
  %38 = call float @llvm.maximum.f32(float %37, float 0.000000e+00)
  %39 = fmul float %38, %28
  %40 = getelementptr inbounds [160 x float], ptr %2, i32 0, i64 %24
  %41 = load float, ptr %40, align 4, !invariant.load !3
  %42 = fadd float %39, %41
  %43 = call float @llvm.maximum.f32(float %42, float 0.000000e+00)
  %44 = getelementptr inbounds [160 x float], ptr %1, i32 0, i64 %24
  %45 = load float, ptr %44, align 4, !invariant.load !3
  %46 = fmul float %43, %45
  %47 = getelementptr inbounds [160 x float], ptr %0, i32 0, i64 %24
  %48 = load float, ptr %47, align 4, !invariant.load !3
  %49 = fadd float %46, %48
  %50 = call float @llvm.maximum.f32(float %49, float 0.000000e+00)
  %51 = fmul float %50, 7.500000e-01
  %52 = fadd float %51, 1.250000e-01
  %53 = fmul float %38, 2.500000e-01
  %54 = fadd float %52, %53
  %55 = getelementptr inbounds [51200 x float], ptr %7, i32 0, i64 %29
  store float %54, ptr %55, align 4
  %56 = add i64 %24, 1
  br label %23

57:                                               ; preds = %23
  %58 = add i64 %18, 1
  br label %17, !llvm.loop !6

59:                                               ; preds = %17, %64
  br label %60

60:                                               ; preds = %59, %13, %61
  br label %106

61:                                               ; preds = %11
  %62 = icmp eq i64 %8, 11
  br i1 %62, label %63, label %60

63:                                               ; preds = %61
  br label %64

64:                                               ; preds = %104, %63
  %65 = phi i64 [ %105, %104 ], [ 0, %63 ]
  %66 = icmp slt i64 %65, 23
  br i1 %66, label %67, label %59

67:                                               ; preds = %64
  %68 = mul nsw i64 %65, 160
  br label %69

69:                                               ; preds = %72, %67
  %70 = phi i64 [ %103, %72 ], [ 0, %67 ]
  %71 = icmp slt i64 %70, 160
  br i1 %71, label %72, label %104

72:                                               ; preds = %69
  %73 = getelementptr inbounds [160 x float], ptr %3, i32 0, i64 %70
  %74 = load float, ptr %73, align 4, !invariant.load !3
  %75 = add nsw i64 %68, %70
  %76 = add nsw i64 %75, 47520
  %77 = getelementptr inbounds [51200 x float], ptr %5, i32 0, i64 %76
  %78 = load float, ptr %77, align 4, !invariant.load !3
  %79 = getelementptr inbounds [160 x float], ptr %6, i32 0, i64 %70
  %80 = load float, ptr %79, align 4, !invariant.load !3
  %81 = fmul float %78, %80
  %82 = getelementptr inbounds [160 x float], ptr %4, i32 0, i64 %70
  %83 = load float, ptr %82, align 4, !invariant.load !3
  %84 = fadd float %81, %83
  %85 = call float @llvm.maximum.f32(float %84, float 0.000000e+00)
  %86 = fmul float %85, %74
  %87 = getelementptr inbounds [160 x float], ptr %2, i32 0, i64 %70
  %88 = load float, ptr %87, align 4, !invariant.load !3
  %89 = fadd float %86, %88
  %90 = call float @llvm.maximum.f32(float %89, float 0.000000e+00)
  %91 = getelementptr inbounds [160 x float], ptr %1, i32 0, i64 %70
  %92 = load float, ptr %91, align 4, !invariant.load !3
  %93 = fmul float %90, %92
  %94 = getelementptr inbounds [160 x float], ptr %0, i32 0, i64 %70
  %95 = load float, ptr %94, align 4, !invariant.load !3
  %96 = fadd float %93, %95
  %97 = call float @llvm.maximum.f32(float %96, float 0.000000e+00)
  %98 = fmul float %97, 7.500000e-01
  %99 = fadd float %98, 1.250000e-01
  %100 = fmul float %85, 2.500000e-01
  %101 = fadd float %99, %100
  %102 = getelementptr inbounds [51200 x float], ptr %7, i32 0, i64 %76
  store float %101, ptr %102, align 4
  %103 = add i64 %70, 1
  br label %69

104:                                              ; preds = %69
  %105 = add i64 %65, 1
  br label %64, !llvm.loop !6

106:                                              ; preds = %60
  ret void
}

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.maximum.f32(float, float) #2

attributes #0 = { uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { alwaysinline }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 2}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 640}
!5 = !{i64 204800}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.unroll.disable"}
