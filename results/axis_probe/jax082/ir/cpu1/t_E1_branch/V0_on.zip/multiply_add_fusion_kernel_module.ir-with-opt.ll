; ModuleID = '__compute_module_multiply_add_fusion_kernel_module'
source_filename = "__compute_module_multiply_add_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @multiply_add_fusion(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !4
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !4
  %9 = getelementptr inbounds nuw i8, ptr %3, i64 48
  %10 = load ptr, ptr %9, align 8, !invariant.load !3, !dereferenceable !4
  %11 = getelementptr inbounds nuw i8, ptr %3, i64 64
  %12 = load ptr, ptr %11, align 8, !invariant.load !3, !dereferenceable !4
  %13 = getelementptr inbounds nuw i8, ptr %3, i64 80
  %14 = load ptr, ptr %13, align 8, !invariant.load !3, !dereferenceable !5
  %15 = getelementptr inbounds nuw i8, ptr %3, i64 96
  %16 = load ptr, ptr %15, align 8, !invariant.load !3, !dereferenceable !4
  %17 = getelementptr inbounds nuw i8, ptr %3, i64 112
  %18 = load ptr, ptr %17, align 8, !invariant.load !3, !dereferenceable !5
  %19 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %20 = load ptr, ptr %19, align 8
  %21 = load i64, ptr %20, align 4, !invariant.load !3
  tail call void @llvm.experimental.noalias.scope.decl(metadata !6)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !11)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !13)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !15)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !17)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !19)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !21)
  %22 = icmp slt i64 %21, 11
  br i1 %22, label %23, label %76

23:                                               ; preds = %1
  %24 = icmp sgt i64 %21, -1
  br i1 %24, label %25, label %multiply_add_fusion_wrapped.exit

25:                                               ; preds = %23
  %26 = mul nuw nsw i64 %21, 4320
  br label %vector.ph20

vector.ph20:                                      ; preds = %25, %middle.block31
  %27 = phi i64 [ 0, %25 ], [ %75, %middle.block31 ]
  %28 = mul nuw nsw i64 %27, 160
  %29 = add nuw nsw i64 %28, %26
  br label %vector.body21

vector.body21:                                    ; preds = %vector.body21, %vector.ph20
  %index22 = phi i64 [ 0, %vector.ph20 ], [ %index.next30.1, %vector.body21 ]
  %30 = getelementptr inbounds nuw float, ptr %10, i64 %index22
  %wide.load23 = load <8 x float>, ptr %30, align 4, !invariant.load !3, !alias.scope !13, !noalias !23
  %31 = add nuw nsw i64 %29, %index22
  %32 = getelementptr inbounds nuw float, ptr %14, i64 %31
  %wide.load24 = load <8 x float>, ptr %32, align 4, !invariant.load !3, !alias.scope !17, !noalias !24
  %33 = getelementptr inbounds nuw float, ptr %16, i64 %index22
  %wide.load25 = load <8 x float>, ptr %33, align 4, !invariant.load !3, !alias.scope !19, !noalias !25
  %34 = fmul <8 x float> %wide.load24, %wide.load25
  %35 = getelementptr inbounds nuw float, ptr %12, i64 %index22
  %wide.load26 = load <8 x float>, ptr %35, align 4, !invariant.load !3, !alias.scope !15, !noalias !26
  %36 = fadd <8 x float> %34, %wide.load26
  %37 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %36, <8 x float> zeroinitializer)
  %38 = fmul <8 x float> %wide.load23, %37
  %39 = getelementptr inbounds nuw float, ptr %8, i64 %index22
  %wide.load27 = load <8 x float>, ptr %39, align 4, !invariant.load !3, !alias.scope !11, !noalias !27
  %40 = fadd <8 x float> %wide.load27, %38
  %41 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %40, <8 x float> zeroinitializer)
  %42 = getelementptr inbounds nuw float, ptr %6, i64 %index22
  %wide.load28 = load <8 x float>, ptr %42, align 4, !invariant.load !3, !alias.scope !9, !noalias !28
  %43 = fmul <8 x float> %wide.load28, %41
  %44 = getelementptr inbounds nuw float, ptr %4, i64 %index22
  %wide.load29 = load <8 x float>, ptr %44, align 4, !invariant.load !3, !alias.scope !6, !noalias !29
  %45 = fadd <8 x float> %wide.load29, %43
  %46 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %45, <8 x float> zeroinitializer)
  %47 = fmul <8 x float> %46, splat (float 7.500000e-01)
  %48 = fadd <8 x float> %47, splat (float 1.250000e-01)
  %49 = fmul <8 x float> %37, splat (float 2.500000e-01)
  %50 = fadd <8 x float> %49, %48
  %51 = getelementptr inbounds nuw float, ptr %18, i64 %31
  store <8 x float> %50, ptr %51, align 4, !alias.scope !21, !noalias !30
  %index.next30 = or disjoint i64 %index22, 8
  %52 = getelementptr inbounds nuw float, ptr %10, i64 %index.next30
  %wide.load23.1 = load <8 x float>, ptr %52, align 4, !invariant.load !3, !alias.scope !13, !noalias !23
  %53 = add nuw nsw i64 %29, %index.next30
  %54 = getelementptr inbounds nuw float, ptr %14, i64 %53
  %wide.load24.1 = load <8 x float>, ptr %54, align 4, !invariant.load !3, !alias.scope !17, !noalias !24
  %55 = getelementptr inbounds nuw float, ptr %16, i64 %index.next30
  %wide.load25.1 = load <8 x float>, ptr %55, align 4, !invariant.load !3, !alias.scope !19, !noalias !25
  %56 = fmul <8 x float> %wide.load24.1, %wide.load25.1
  %57 = getelementptr inbounds nuw float, ptr %12, i64 %index.next30
  %wide.load26.1 = load <8 x float>, ptr %57, align 4, !invariant.load !3, !alias.scope !15, !noalias !26
  %58 = fadd <8 x float> %56, %wide.load26.1
  %59 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %58, <8 x float> zeroinitializer)
  %60 = fmul <8 x float> %wide.load23.1, %59
  %61 = getelementptr inbounds nuw float, ptr %8, i64 %index.next30
  %wide.load27.1 = load <8 x float>, ptr %61, align 4, !invariant.load !3, !alias.scope !11, !noalias !27
  %62 = fadd <8 x float> %wide.load27.1, %60
  %63 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %62, <8 x float> zeroinitializer)
  %64 = getelementptr inbounds nuw float, ptr %6, i64 %index.next30
  %wide.load28.1 = load <8 x float>, ptr %64, align 4, !invariant.load !3, !alias.scope !9, !noalias !28
  %65 = fmul <8 x float> %wide.load28.1, %63
  %66 = getelementptr inbounds nuw float, ptr %4, i64 %index.next30
  %wide.load29.1 = load <8 x float>, ptr %66, align 4, !invariant.load !3, !alias.scope !6, !noalias !29
  %67 = fadd <8 x float> %wide.load29.1, %65
  %68 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %67, <8 x float> zeroinitializer)
  %69 = fmul <8 x float> %68, splat (float 7.500000e-01)
  %70 = fadd <8 x float> %69, splat (float 1.250000e-01)
  %71 = fmul <8 x float> %59, splat (float 2.500000e-01)
  %72 = fadd <8 x float> %71, %70
  %73 = getelementptr inbounds nuw float, ptr %18, i64 %53
  store <8 x float> %72, ptr %73, align 4, !alias.scope !21, !noalias !30
  %index.next30.1 = add nuw nsw i64 %index22, 16
  %74 = icmp eq i64 %index.next30.1, 160
  br i1 %74, label %middle.block31, label %vector.body21, !llvm.loop !31

middle.block31:                                   ; preds = %vector.body21
  %75 = add nuw nsw i64 %27, 1
  %exitcond9.not = icmp eq i64 %75, 27
  br i1 %exitcond9.not, label %multiply_add_fusion_wrapped.exit, label %vector.ph20, !llvm.loop !34

76:                                               ; preds = %1
  %77 = icmp eq i64 %21, 11
  br i1 %77, label %.preheader, label %multiply_add_fusion_wrapped.exit

.preheader:                                       ; preds = %76, %middle.block
  %78 = phi i64 [ %126, %middle.block ], [ 0, %76 ]
  %79 = mul nuw nsw i64 %78, 160
  %80 = add nuw nsw i64 %79, 47520
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %.preheader
  %index = phi i64 [ 0, %.preheader ], [ %index.next.1, %vector.body ]
  %81 = getelementptr inbounds nuw float, ptr %10, i64 %index
  %wide.load = load <8 x float>, ptr %81, align 4, !invariant.load !3, !alias.scope !13, !noalias !23
  %82 = add nuw nsw i64 %80, %index
  %83 = getelementptr inbounds nuw float, ptr %14, i64 %82
  %wide.load14 = load <8 x float>, ptr %83, align 4, !invariant.load !3, !alias.scope !17, !noalias !24
  %84 = getelementptr inbounds nuw float, ptr %16, i64 %index
  %wide.load15 = load <8 x float>, ptr %84, align 4, !invariant.load !3, !alias.scope !19, !noalias !25
  %85 = fmul <8 x float> %wide.load14, %wide.load15
  %86 = getelementptr inbounds nuw float, ptr %12, i64 %index
  %wide.load16 = load <8 x float>, ptr %86, align 4, !invariant.load !3, !alias.scope !15, !noalias !26
  %87 = fadd <8 x float> %85, %wide.load16
  %88 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %87, <8 x float> zeroinitializer)
  %89 = fmul <8 x float> %wide.load, %88
  %90 = getelementptr inbounds nuw float, ptr %8, i64 %index
  %wide.load17 = load <8 x float>, ptr %90, align 4, !invariant.load !3, !alias.scope !11, !noalias !27
  %91 = fadd <8 x float> %wide.load17, %89
  %92 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %91, <8 x float> zeroinitializer)
  %93 = getelementptr inbounds nuw float, ptr %6, i64 %index
  %wide.load18 = load <8 x float>, ptr %93, align 4, !invariant.load !3, !alias.scope !9, !noalias !28
  %94 = fmul <8 x float> %wide.load18, %92
  %95 = getelementptr inbounds nuw float, ptr %4, i64 %index
  %wide.load19 = load <8 x float>, ptr %95, align 4, !invariant.load !3, !alias.scope !6, !noalias !29
  %96 = fadd <8 x float> %wide.load19, %94
  %97 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %96, <8 x float> zeroinitializer)
  %98 = fmul <8 x float> %97, splat (float 7.500000e-01)
  %99 = fadd <8 x float> %98, splat (float 1.250000e-01)
  %100 = fmul <8 x float> %88, splat (float 2.500000e-01)
  %101 = fadd <8 x float> %100, %99
  %102 = getelementptr inbounds nuw float, ptr %18, i64 %82
  store <8 x float> %101, ptr %102, align 4, !alias.scope !21, !noalias !30
  %index.next = or disjoint i64 %index, 8
  %103 = getelementptr inbounds nuw float, ptr %10, i64 %index.next
  %wide.load.1 = load <8 x float>, ptr %103, align 4, !invariant.load !3, !alias.scope !13, !noalias !23
  %104 = add nuw nsw i64 %80, %index.next
  %105 = getelementptr inbounds nuw float, ptr %14, i64 %104
  %wide.load14.1 = load <8 x float>, ptr %105, align 4, !invariant.load !3, !alias.scope !17, !noalias !24
  %106 = getelementptr inbounds nuw float, ptr %16, i64 %index.next
  %wide.load15.1 = load <8 x float>, ptr %106, align 4, !invariant.load !3, !alias.scope !19, !noalias !25
  %107 = fmul <8 x float> %wide.load14.1, %wide.load15.1
  %108 = getelementptr inbounds nuw float, ptr %12, i64 %index.next
  %wide.load16.1 = load <8 x float>, ptr %108, align 4, !invariant.load !3, !alias.scope !15, !noalias !26
  %109 = fadd <8 x float> %107, %wide.load16.1
  %110 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %109, <8 x float> zeroinitializer)
  %111 = fmul <8 x float> %wide.load.1, %110
  %112 = getelementptr inbounds nuw float, ptr %8, i64 %index.next
  %wide.load17.1 = load <8 x float>, ptr %112, align 4, !invariant.load !3, !alias.scope !11, !noalias !27
  %113 = fadd <8 x float> %wide.load17.1, %111
  %114 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %113, <8 x float> zeroinitializer)
  %115 = getelementptr inbounds nuw float, ptr %6, i64 %index.next
  %wide.load18.1 = load <8 x float>, ptr %115, align 4, !invariant.load !3, !alias.scope !9, !noalias !28
  %116 = fmul <8 x float> %wide.load18.1, %114
  %117 = getelementptr inbounds nuw float, ptr %4, i64 %index.next
  %wide.load19.1 = load <8 x float>, ptr %117, align 4, !invariant.load !3, !alias.scope !6, !noalias !29
  %118 = fadd <8 x float> %wide.load19.1, %116
  %119 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %118, <8 x float> zeroinitializer)
  %120 = fmul <8 x float> %119, splat (float 7.500000e-01)
  %121 = fadd <8 x float> %120, splat (float 1.250000e-01)
  %122 = fmul <8 x float> %110, splat (float 2.500000e-01)
  %123 = fadd <8 x float> %122, %121
  %124 = getelementptr inbounds nuw float, ptr %18, i64 %104
  store <8 x float> %123, ptr %124, align 4, !alias.scope !21, !noalias !30
  %index.next.1 = add nuw nsw i64 %index, 16
  %125 = icmp eq i64 %index.next.1, 160
  br i1 %125, label %middle.block, label %vector.body, !llvm.loop !36

middle.block:                                     ; preds = %vector.body
  %126 = add nuw nsw i64 %78, 1
  %exitcond7.not = icmp eq i64 %126, 23
  br i1 %exitcond7.not, label %multiply_add_fusion_wrapped.exit, label %.preheader, !llvm.loop !34

multiply_add_fusion_wrapped.exit:                 ; preds = %middle.block, %middle.block31, %23, %76
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.maximum.v8f32(<8 x float>, <8 x float>) #2

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 0}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 640}
!5 = !{i64 204800}
!6 = !{!7}
!7 = distinct !{!7, !8, !"multiply_add_fusion_wrapped: argument 0"}
!8 = distinct !{!8, !"multiply_add_fusion_wrapped"}
!9 = !{!10}
!10 = distinct !{!10, !8, !"multiply_add_fusion_wrapped: argument 1"}
!11 = !{!12}
!12 = distinct !{!12, !8, !"multiply_add_fusion_wrapped: argument 2"}
!13 = !{!14}
!14 = distinct !{!14, !8, !"multiply_add_fusion_wrapped: argument 3"}
!15 = !{!16}
!16 = distinct !{!16, !8, !"multiply_add_fusion_wrapped: argument 4"}
!17 = !{!18}
!18 = distinct !{!18, !8, !"multiply_add_fusion_wrapped: argument 5"}
!19 = !{!20}
!20 = distinct !{!20, !8, !"multiply_add_fusion_wrapped: argument 6"}
!21 = !{!22}
!22 = distinct !{!22, !8, !"multiply_add_fusion_wrapped: argument 7"}
!23 = !{!7, !10, !12, !16, !18, !20, !22}
!24 = !{!7, !10, !12, !14, !16, !20, !22}
!25 = !{!7, !10, !12, !14, !16, !18, !22}
!26 = !{!7, !10, !12, !14, !18, !20, !22}
!27 = !{!7, !10, !14, !16, !18, !20, !22}
!28 = !{!7, !12, !14, !16, !18, !20, !22}
!29 = !{!10, !12, !14, !16, !18, !20, !22}
!30 = !{!7, !10, !12, !14, !16, !18, !20}
!31 = distinct !{!31, !32, !33}
!32 = !{!"llvm.loop.isvectorized", i32 1}
!33 = !{!"llvm.loop.unroll.runtime.disable"}
!34 = distinct !{!34, !35}
!35 = !{!"llvm.loop.unroll.disable"}
!36 = distinct !{!36, !32, !33}
