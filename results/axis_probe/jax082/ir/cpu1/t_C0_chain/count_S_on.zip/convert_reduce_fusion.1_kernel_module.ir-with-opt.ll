; ModuleID = '__compute_module_convert_reduce_fusion.1_kernel_module'
source_filename = "__compute_module_convert_reduce_fusion.1_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @convert_reduce_fusion.1(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !5
  tail call void @llvm.experimental.noalias.scope.decl(metadata !6)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !11)
  %7 = load <4 x float>, ptr %6, align 4
  %.phi.trans.insert.phi.trans.insert.phi.trans.insert = getelementptr inbounds nuw i8, ptr %6, i64 4
  %8 = load <4 x float>, ptr %.phi.trans.insert.phi.trans.insert.phi.trans.insert, align 4
  %.phi.trans.insert11.phi.trans.insert.phi.trans.insert = getelementptr inbounds nuw i8, ptr %6, i64 8
  %9 = load <4 x float>, ptr %.phi.trans.insert11.phi.trans.insert.phi.trans.insert, align 4
  %.phi.trans.insert13.phi.trans.insert.phi.trans.insert = getelementptr inbounds nuw i8, ptr %6, i64 12
  %10 = load <4 x float>, ptr %.phi.trans.insert13.phi.trans.insert.phi.trans.insert, align 4
  %.phi.trans.insert15.phi.trans.insert.phi.trans.insert = getelementptr inbounds nuw i8, ptr %6, i64 16
  %11 = load <4 x float>, ptr %.phi.trans.insert15.phi.trans.insert.phi.trans.insert, align 4
  %.phi.trans.insert17.phi.trans.insert.phi.trans.insert = getelementptr inbounds nuw i8, ptr %6, i64 20
  %12 = load <4 x float>, ptr %.phi.trans.insert17.phi.trans.insert.phi.trans.insert, align 4
  %.phi.trans.insert19.phi.trans.insert.phi.trans.insert = getelementptr inbounds nuw i8, ptr %6, i64 24
  %13 = load <4 x float>, ptr %.phi.trans.insert19.phi.trans.insert.phi.trans.insert, align 4
  %.phi.trans.insert21.phi.trans.insert.phi.trans.insert = getelementptr inbounds nuw i8, ptr %6, i64 28
  %14 = load <4 x float>, ptr %.phi.trans.insert21.phi.trans.insert.phi.trans.insert, align 4
  %.phi.trans.insert23.phi.trans.insert.phi.trans.insert = getelementptr inbounds nuw i8, ptr %6, i64 32
  %15 = load <4 x float>, ptr %.phi.trans.insert23.phi.trans.insert.phi.trans.insert, align 4
  %.phi.trans.insert25.phi.trans.insert.phi.trans.insert = getelementptr inbounds nuw i8, ptr %6, i64 36
  %.pre26.pre.pre = load float, ptr %.phi.trans.insert25.phi.trans.insert.phi.trans.insert, align 4, !invariant.load !3, !alias.scope !9, !noalias !13
  %.phi.trans.insert27.phi.trans.insert.phi.trans.insert = getelementptr inbounds nuw i8, ptr %6, i64 40
  %.pre28.pre.pre = load float, ptr %.phi.trans.insert27.phi.trans.insert.phi.trans.insert, align 4, !invariant.load !3, !alias.scope !9, !noalias !13
  %.phi.trans.insert29.phi.trans.insert.phi.trans.insert = getelementptr inbounds nuw i8, ptr %6, i64 44
  %.pre30.pre.pre = load float, ptr %.phi.trans.insert29.phi.trans.insert.phi.trans.insert, align 4, !invariant.load !3, !alias.scope !9, !noalias !13
  %broadcast.splat = shufflevector <4 x float> %7, <4 x float> poison, <4 x i32> zeroinitializer
  %broadcast.splat33 = shufflevector <4 x float> %8, <4 x float> poison, <4 x i32> zeroinitializer
  %broadcast.splat35 = shufflevector <4 x float> %9, <4 x float> poison, <4 x i32> zeroinitializer
  %broadcast.splat37 = shufflevector <4 x float> %10, <4 x float> poison, <4 x i32> zeroinitializer
  %broadcast.splat39 = shufflevector <4 x float> %11, <4 x float> poison, <4 x i32> zeroinitializer
  %broadcast.splat41 = shufflevector <4 x float> %12, <4 x float> poison, <4 x i32> zeroinitializer
  %broadcast.splat43 = shufflevector <4 x float> %13, <4 x float> poison, <4 x i32> zeroinitializer
  %broadcast.splat45 = shufflevector <4 x float> %14, <4 x float> poison, <4 x i32> zeroinitializer
  %broadcast.splat47 = shufflevector <4 x float> %15, <4 x float> poison, <4 x i32> zeroinitializer
  %broadcast.splatinsert48 = insertelement <4 x float> poison, float %.pre26.pre.pre, i64 0
  %broadcast.splat49 = shufflevector <4 x float> %broadcast.splatinsert48, <4 x float> poison, <4 x i32> zeroinitializer
  %broadcast.splatinsert50 = insertelement <4 x float> poison, float %.pre28.pre.pre, i64 0
  %broadcast.splat51 = shufflevector <4 x float> %broadcast.splatinsert50, <4 x float> poison, <4 x i32> zeroinitializer
  %broadcast.splatinsert52 = insertelement <4 x float> poison, float %.pre30.pre.pre, i64 0
  %broadcast.splat53 = shufflevector <4 x float> %broadcast.splatinsert52, <4 x float> poison, <4 x i32> zeroinitializer
  br label %.preheader4

.preheader4:                                      ; preds = %1, %87
  %16 = phi i32 [ 0, %1 ], [ %85, %87 ]
  %17 = phi i64 [ 0, %1 ], [ %88, %87 ]
  %.idx = mul nuw nsw i64 %17, 19200
  %18 = getelementptr i8, ptr %4, i64 %.idx
  br label %.preheader3

.preheader3:                                      ; preds = %.preheader4, %middle.block
  %19 = phi i32 [ %16, %.preheader4 ], [ %85, %middle.block ]
  %20 = phi i64 [ 0, %.preheader4 ], [ %86, %middle.block ]
  %.idx1 = mul nuw nsw i64 %20, 960
  %21 = getelementptr i8, ptr %18, i64 %.idx1
  %22 = insertelement <4 x i32> <i32 poison, i32 0, i32 0, i32 0>, i32 %19, i64 0
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %.preheader3
  %index = phi i64 [ 0, %.preheader3 ], [ %index.next, %vector.body ]
  %vec.phi = phi <4 x i32> [ %22, %.preheader3 ], [ %83, %vector.body ]
  %vec.ind = phi <4 x i64> [ <i64 0, i64 1, i64 2, i64 3>, %.preheader3 ], [ %vec.ind.next, %vector.body ]
  %23 = mul nuw nsw <4 x i64> %vec.ind, splat (i64 48)
  %24 = getelementptr i8, ptr %21, <4 x i64> %23
  %wide.masked.gather = tail call <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr> align 4 %24, <4 x i1> splat (i1 true), <4 x float> poison), !invariant.load !3, !alias.scope !6, !noalias !14
  %25 = fadd <4 x float> %wide.masked.gather, %broadcast.splat
  %26 = fcmp ogt <4 x float> %25, zeroinitializer
  %27 = zext <4 x i1> %26 to <4 x i32>
  %28 = add <4 x i32> %vec.phi, %27
  %29 = getelementptr i8, <4 x ptr> %24, i64 4
  %wide.masked.gather54 = tail call <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr> align 4 %29, <4 x i1> splat (i1 true), <4 x float> poison), !invariant.load !3, !alias.scope !6, !noalias !14
  %30 = fadd <4 x float> %wide.masked.gather54, %broadcast.splat33
  %31 = fcmp ogt <4 x float> %30, zeroinitializer
  %32 = zext <4 x i1> %31 to <4 x i32>
  %33 = add <4 x i32> %28, %32
  %34 = getelementptr i8, <4 x ptr> %24, i64 8
  %wide.masked.gather55 = tail call <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr> align 4 %34, <4 x i1> splat (i1 true), <4 x float> poison), !invariant.load !3, !alias.scope !6, !noalias !14
  %35 = fadd <4 x float> %wide.masked.gather55, %broadcast.splat35
  %36 = fcmp ogt <4 x float> %35, zeroinitializer
  %37 = zext <4 x i1> %36 to <4 x i32>
  %38 = add <4 x i32> %33, %37
  %39 = getelementptr i8, <4 x ptr> %24, i64 12
  %wide.masked.gather56 = tail call <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr> align 4 %39, <4 x i1> splat (i1 true), <4 x float> poison), !invariant.load !3, !alias.scope !6, !noalias !14
  %40 = fadd <4 x float> %wide.masked.gather56, %broadcast.splat37
  %41 = fcmp ogt <4 x float> %40, zeroinitializer
  %42 = zext <4 x i1> %41 to <4 x i32>
  %43 = add <4 x i32> %38, %42
  %44 = getelementptr i8, <4 x ptr> %24, i64 16
  %wide.masked.gather57 = tail call <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr> align 4 %44, <4 x i1> splat (i1 true), <4 x float> poison), !invariant.load !3, !alias.scope !6, !noalias !14
  %45 = fadd <4 x float> %wide.masked.gather57, %broadcast.splat39
  %46 = fcmp ogt <4 x float> %45, zeroinitializer
  %47 = zext <4 x i1> %46 to <4 x i32>
  %48 = add <4 x i32> %43, %47
  %49 = getelementptr i8, <4 x ptr> %24, i64 20
  %wide.masked.gather58 = tail call <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr> align 4 %49, <4 x i1> splat (i1 true), <4 x float> poison), !invariant.load !3, !alias.scope !6, !noalias !14
  %50 = fadd <4 x float> %wide.masked.gather58, %broadcast.splat41
  %51 = fcmp ogt <4 x float> %50, zeroinitializer
  %52 = zext <4 x i1> %51 to <4 x i32>
  %53 = add <4 x i32> %48, %52
  %54 = getelementptr i8, <4 x ptr> %24, i64 24
  %wide.masked.gather59 = tail call <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr> align 4 %54, <4 x i1> splat (i1 true), <4 x float> poison), !invariant.load !3, !alias.scope !6, !noalias !14
  %55 = fadd <4 x float> %wide.masked.gather59, %broadcast.splat43
  %56 = fcmp ogt <4 x float> %55, zeroinitializer
  %57 = zext <4 x i1> %56 to <4 x i32>
  %58 = add <4 x i32> %53, %57
  %59 = getelementptr i8, <4 x ptr> %24, i64 28
  %wide.masked.gather60 = tail call <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr> align 4 %59, <4 x i1> splat (i1 true), <4 x float> poison), !invariant.load !3, !alias.scope !6, !noalias !14
  %60 = fadd <4 x float> %wide.masked.gather60, %broadcast.splat45
  %61 = fcmp ogt <4 x float> %60, zeroinitializer
  %62 = zext <4 x i1> %61 to <4 x i32>
  %63 = add <4 x i32> %58, %62
  %64 = getelementptr i8, <4 x ptr> %24, i64 32
  %wide.masked.gather61 = tail call <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr> align 4 %64, <4 x i1> splat (i1 true), <4 x float> poison), !invariant.load !3, !alias.scope !6, !noalias !14
  %65 = fadd <4 x float> %wide.masked.gather61, %broadcast.splat47
  %66 = fcmp ogt <4 x float> %65, zeroinitializer
  %67 = zext <4 x i1> %66 to <4 x i32>
  %68 = add <4 x i32> %63, %67
  %69 = getelementptr i8, <4 x ptr> %24, i64 36
  %wide.masked.gather62 = tail call <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr> align 4 %69, <4 x i1> splat (i1 true), <4 x float> poison), !invariant.load !3, !alias.scope !6, !noalias !14
  %70 = fadd <4 x float> %wide.masked.gather62, %broadcast.splat49
  %71 = fcmp ogt <4 x float> %70, zeroinitializer
  %72 = zext <4 x i1> %71 to <4 x i32>
  %73 = add <4 x i32> %68, %72
  %74 = getelementptr i8, <4 x ptr> %24, i64 40
  %wide.masked.gather63 = tail call <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr> align 4 %74, <4 x i1> splat (i1 true), <4 x float> poison), !invariant.load !3, !alias.scope !6, !noalias !14
  %75 = fadd <4 x float> %wide.masked.gather63, %broadcast.splat51
  %76 = fcmp ogt <4 x float> %75, zeroinitializer
  %77 = zext <4 x i1> %76 to <4 x i32>
  %78 = add <4 x i32> %73, %77
  %79 = getelementptr i8, <4 x ptr> %24, i64 44
  %wide.masked.gather64 = tail call <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr> align 4 %79, <4 x i1> splat (i1 true), <4 x float> poison), !invariant.load !3, !alias.scope !6, !noalias !14
  %80 = fadd <4 x float> %wide.masked.gather64, %broadcast.splat53
  %81 = fcmp ogt <4 x float> %80, zeroinitializer
  %82 = zext <4 x i1> %81 to <4 x i32>
  %83 = add <4 x i32> %78, %82
  %index.next = add nuw i64 %index, 4
  %vec.ind.next = add nuw nsw <4 x i64> %vec.ind, splat (i64 4)
  %84 = icmp eq i64 %index.next, 20
  br i1 %84, label %middle.block, label %vector.body, !llvm.loop !15

middle.block:                                     ; preds = %vector.body
  %85 = tail call i32 @llvm.vector.reduce.add.v4i32(<4 x i32> %83)
  %86 = add nuw nsw i64 %20, 1
  %exitcond8.not = icmp eq i64 %86, 20
  br i1 %exitcond8.not, label %87, label %.preheader3, !llvm.loop !19

87:                                               ; preds = %middle.block
  %88 = add nuw nsw i64 %17, 1
  %exitcond9.not = icmp eq i64 %88, 3
  br i1 %exitcond9.not, label %convert_reduce_fusion.1_wrapped.exit, label %.preheader4, !llvm.loop !19

convert_reduce_fusion.1_wrapped.exit:             ; preds = %87
  %89 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %90 = load ptr, ptr %89, align 8, !invariant.load !3, !dereferenceable !20
  store i32 %85, ptr %90, align 4, !alias.scope !11, !noalias !21
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr>, <4 x i1>, <4 x float>) #2

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.vector.reduce.add.v4i32(<4 x i32>) #3

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #3 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 2}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 57600}
!5 = !{i64 48}
!6 = !{!7}
!7 = distinct !{!7, !8, !"convert_reduce_fusion.1_wrapped: argument 0"}
!8 = distinct !{!8, !"convert_reduce_fusion.1_wrapped"}
!9 = !{!10}
!10 = distinct !{!10, !8, !"convert_reduce_fusion.1_wrapped: argument 1"}
!11 = !{!12}
!12 = distinct !{!12, !8, !"convert_reduce_fusion.1_wrapped: argument 2"}
!13 = !{!7, !12}
!14 = !{!10, !12}
!15 = distinct !{!15, !16, !17, !18}
!16 = !{!"llvm.loop.unroll.disable"}
!17 = !{!"llvm.loop.isvectorized", i32 1}
!18 = !{!"llvm.loop.unroll.runtime.disable"}
!19 = distinct !{!19, !16}
!20 = !{i64 4}
!21 = !{!7, !10}
