; ModuleID = '__compute_module_convert_reduce_fusion.1_kernel_module'
source_filename = "__compute_module_convert_reduce_fusion.1_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

%XLA_CPU_KernelCallFrame = type { ptr, ptr, i64, ptr }
%XLA_CPU_KernelArg = type { ptr, i64 }
%kernel_dim3 = type { i64, i64, i64 }

; Function Attrs: uwtable
define ptr @convert_reduce_fusion.1(ptr %0) #0 {
  %2 = getelementptr inbounds %XLA_CPU_KernelCallFrame, ptr %0, i32 0, i32 3
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 0, i32 0
  %5 = load ptr, ptr %4, align 8, !invariant.load !3, !dereferenceable !4
  %6 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 1, i32 0
  %7 = load ptr, ptr %6, align 8, !invariant.load !3, !dereferenceable !5
  %8 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 2, i32 0
  %9 = load ptr, ptr %8, align 8, !invariant.load !3, !dereferenceable !6
  %10 = getelementptr inbounds %XLA_CPU_KernelCallFrame, ptr %0, i32 0, i32 1
  %11 = load ptr, ptr %10, align 8
  %12 = getelementptr inbounds %kernel_dim3, ptr %11, i32 0, i32 0
  %13 = load i64, ptr %12, align 4, !invariant.load !3
  %14 = getelementptr inbounds %kernel_dim3, ptr %11, i32 0, i32 1
  %15 = load i64, ptr %14, align 4, !invariant.load !3
  %16 = getelementptr inbounds %kernel_dim3, ptr %11, i32 0, i32 2
  %17 = load i64, ptr %16, align 4, !invariant.load !3
  call void @convert_reduce_fusion.1_wrapped(ptr %5, ptr %7, ptr %9, i64 %13, i64 %15, i64 %17)
  ret ptr null
}

; Function Attrs: alwaysinline
define internal void @convert_reduce_fusion.1_wrapped(ptr noalias align 64 dereferenceable(57600) %0, ptr noalias align 64 dereferenceable(48) %1, ptr noalias align 64 dereferenceable(4) %2, i64 %3, i64 %4, i64 %5) #1 {
  br label %7

7:                                                ; preds = %46, %6
  %8 = phi i64 [ %47, %46 ], [ 0, %6 ]
  %9 = phi i32 [ %15, %46 ], [ 0, %6 ]
  %10 = icmp slt i64 %8, 3
  br i1 %10, label %11, label %48

11:                                               ; preds = %7
  %12 = mul nsw i64 %8, 4800
  br label %13

13:                                               ; preds = %44, %11
  %14 = phi i64 [ %45, %44 ], [ 0, %11 ]
  %15 = phi i32 [ %22, %44 ], [ %9, %11 ]
  %16 = icmp slt i64 %14, 20
  br i1 %16, label %17, label %46

17:                                               ; preds = %13
  %18 = mul nsw i64 %14, 240
  %19 = add nsw i64 %12, %18
  br label %20

20:                                               ; preds = %42, %17
  %21 = phi i64 [ %43, %42 ], [ 0, %17 ]
  %22 = phi i32 [ %29, %42 ], [ %15, %17 ]
  %23 = icmp slt i64 %21, 20
  br i1 %23, label %24, label %44

24:                                               ; preds = %20
  %25 = mul nsw i64 %21, 12
  %26 = add nsw i64 %19, %25
  br label %27

27:                                               ; preds = %31, %24
  %28 = phi i64 [ %41, %31 ], [ 0, %24 ]
  %29 = phi i32 [ %40, %31 ], [ %22, %24 ]
  %30 = icmp slt i64 %28, 12
  br i1 %30, label %31, label %42

31:                                               ; preds = %27
  %32 = add nsw i64 %26, %28
  %33 = getelementptr inbounds [14400 x float], ptr %0, i32 0, i64 %32
  %34 = load float, ptr %33, align 4, !invariant.load !3
  %35 = getelementptr inbounds [12 x float], ptr %1, i32 0, i64 %28
  %36 = load float, ptr %35, align 4, !invariant.load !3
  %37 = fadd float %34, %36
  %38 = fcmp ogt float %37, 0.000000e+00
  %39 = zext i1 %38 to i32
  %40 = add i32 %29, %39
  %41 = add i64 %28, 1
  br label %27

42:                                               ; preds = %27
  %43 = add i64 %21, 1
  br label %20, !llvm.loop !7

44:                                               ; preds = %20
  %45 = add i64 %14, 1
  br label %13, !llvm.loop !7

46:                                               ; preds = %13
  %47 = add i64 %8, 1
  br label %7, !llvm.loop !7

48:                                               ; preds = %7
  %49 = getelementptr inbounds [1 x i32], ptr %2, i32 0, i32 0
  store i32 %9, ptr %49, align 4
  ret void
}

attributes #0 = { uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { alwaysinline }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 2}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 57600}
!5 = !{i64 48}
!6 = !{i64 4}
!7 = distinct !{!7, !8}
!8 = !{!"llvm.loop.unroll.disable"}
