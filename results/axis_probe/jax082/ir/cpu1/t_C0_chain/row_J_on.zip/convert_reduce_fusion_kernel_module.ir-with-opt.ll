; ModuleID = '__compute_module_convert_reduce_fusion_kernel_module'
source_filename = "__compute_module_convert_reduce_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @convert_reduce_fusion(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !5
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !4
  %9 = getelementptr inbounds nuw i8, ptr %3, i64 48
  %10 = load ptr, ptr %9, align 8, !invariant.load !3, !dereferenceable !5
  %11 = getelementptr inbounds nuw i8, ptr %3, i64 64
  %12 = load ptr, ptr %11, align 8, !invariant.load !3, !dereferenceable !6
  %13 = getelementptr inbounds nuw i8, ptr %3, i64 80
  %14 = load ptr, ptr %13, align 8, !invariant.load !3, !dereferenceable !6
  tail call void @llvm.experimental.noalias.scope.decl(metadata !7)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !10)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !12)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !14)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !16)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !18)
  %15 = load <4 x float>, ptr %10, align 4
  %16 = load <4 x float>, ptr %6, align 4
  %17 = getelementptr inbounds nuw i8, ptr %10, i64 4
  %18 = load <4 x float>, ptr %17, align 4
  %19 = getelementptr inbounds nuw i8, ptr %6, i64 4
  %20 = load <4 x float>, ptr %19, align 4
  %21 = getelementptr inbounds nuw i8, ptr %10, i64 8
  %22 = load <4 x float>, ptr %21, align 4
  %23 = getelementptr inbounds nuw i8, ptr %6, i64 8
  %24 = load <4 x float>, ptr %23, align 4
  %25 = getelementptr inbounds nuw i8, ptr %10, i64 12
  %26 = load <4 x float>, ptr %25, align 4
  %27 = getelementptr inbounds nuw i8, ptr %6, i64 12
  %28 = load <4 x float>, ptr %27, align 4
  %29 = getelementptr inbounds nuw i8, ptr %10, i64 16
  %30 = load <4 x float>, ptr %29, align 4
  %31 = getelementptr inbounds nuw i8, ptr %6, i64 16
  %32 = load <4 x float>, ptr %31, align 4
  %33 = getelementptr inbounds nuw i8, ptr %10, i64 20
  %34 = load <4 x float>, ptr %33, align 4
  %35 = getelementptr inbounds nuw i8, ptr %6, i64 20
  %36 = load <4 x float>, ptr %35, align 4
  %37 = getelementptr inbounds nuw i8, ptr %10, i64 24
  %38 = load <4 x float>, ptr %37, align 4
  %39 = getelementptr inbounds nuw i8, ptr %6, i64 24
  %40 = load <4 x float>, ptr %39, align 4
  %41 = getelementptr inbounds nuw i8, ptr %10, i64 28
  %42 = load <4 x float>, ptr %41, align 4
  %43 = getelementptr inbounds nuw i8, ptr %6, i64 28
  %44 = load <4 x float>, ptr %43, align 4
  %45 = getelementptr inbounds nuw i8, ptr %10, i64 32
  %46 = load <4 x float>, ptr %45, align 4
  %47 = getelementptr inbounds nuw i8, ptr %6, i64 32
  %48 = load <4 x float>, ptr %47, align 4
  %49 = getelementptr inbounds nuw i8, ptr %10, i64 36
  %50 = load float, ptr %49, align 4, !invariant.load !3, !alias.scope !14, !noalias !20
  %51 = getelementptr inbounds nuw i8, ptr %6, i64 36
  %52 = load float, ptr %51, align 4, !invariant.load !3, !alias.scope !10, !noalias !21
  %53 = getelementptr inbounds nuw i8, ptr %10, i64 40
  %54 = load float, ptr %53, align 4, !invariant.load !3, !alias.scope !14, !noalias !20
  %55 = getelementptr inbounds nuw i8, ptr %6, i64 40
  %56 = load float, ptr %55, align 4, !invariant.load !3, !alias.scope !10, !noalias !21
  %57 = getelementptr inbounds nuw i8, ptr %10, i64 44
  %58 = load float, ptr %57, align 4, !invariant.load !3, !alias.scope !14, !noalias !20
  %59 = getelementptr inbounds nuw i8, ptr %6, i64 44
  %60 = load float, ptr %59, align 4, !invariant.load !3, !alias.scope !10, !noalias !21
  %broadcast.splat10 = shufflevector <4 x float> %15, <4 x float> poison, <4 x i32> zeroinitializer
  %broadcast.splat12 = shufflevector <4 x float> %16, <4 x float> poison, <4 x i32> zeroinitializer
  %broadcast.splat14 = shufflevector <4 x float> %18, <4 x float> poison, <4 x i32> zeroinitializer
  %broadcast.splat16 = shufflevector <4 x float> %20, <4 x float> poison, <4 x i32> zeroinitializer
  %broadcast.splat18 = shufflevector <4 x float> %22, <4 x float> poison, <4 x i32> zeroinitializer
  %broadcast.splat20 = shufflevector <4 x float> %24, <4 x float> poison, <4 x i32> zeroinitializer
  %broadcast.splat22 = shufflevector <4 x float> %26, <4 x float> poison, <4 x i32> zeroinitializer
  %broadcast.splat24 = shufflevector <4 x float> %28, <4 x float> poison, <4 x i32> zeroinitializer
  %broadcast.splat26 = shufflevector <4 x float> %30, <4 x float> poison, <4 x i32> zeroinitializer
  %broadcast.splat28 = shufflevector <4 x float> %32, <4 x float> poison, <4 x i32> zeroinitializer
  %broadcast.splat30 = shufflevector <4 x float> %34, <4 x float> poison, <4 x i32> zeroinitializer
  %broadcast.splat32 = shufflevector <4 x float> %36, <4 x float> poison, <4 x i32> zeroinitializer
  %broadcast.splat34 = shufflevector <4 x float> %38, <4 x float> poison, <4 x i32> zeroinitializer
  %broadcast.splat36 = shufflevector <4 x float> %40, <4 x float> poison, <4 x i32> zeroinitializer
  %broadcast.splat38 = shufflevector <4 x float> %42, <4 x float> poison, <4 x i32> zeroinitializer
  %broadcast.splat40 = shufflevector <4 x float> %44, <4 x float> poison, <4 x i32> zeroinitializer
  %broadcast.splat42 = shufflevector <4 x float> %46, <4 x float> poison, <4 x i32> zeroinitializer
  %broadcast.splat44 = shufflevector <4 x float> %48, <4 x float> poison, <4 x i32> zeroinitializer
  %broadcast.splatinsert45 = insertelement <4 x float> poison, float %50, i64 0
  %broadcast.splat46 = shufflevector <4 x float> %broadcast.splatinsert45, <4 x float> poison, <4 x i32> zeroinitializer
  %broadcast.splatinsert47 = insertelement <4 x float> poison, float %52, i64 0
  %broadcast.splat48 = shufflevector <4 x float> %broadcast.splatinsert47, <4 x float> poison, <4 x i32> zeroinitializer
  %broadcast.splatinsert49 = insertelement <4 x float> poison, float %54, i64 0
  %broadcast.splat50 = shufflevector <4 x float> %broadcast.splatinsert49, <4 x float> poison, <4 x i32> zeroinitializer
  %broadcast.splatinsert51 = insertelement <4 x float> poison, float %56, i64 0
  %broadcast.splat52 = shufflevector <4 x float> %broadcast.splatinsert51, <4 x float> poison, <4 x i32> zeroinitializer
  %broadcast.splatinsert53 = insertelement <4 x float> poison, float %58, i64 0
  %broadcast.splat54 = shufflevector <4 x float> %broadcast.splatinsert53, <4 x float> poison, <4 x i32> zeroinitializer
  %broadcast.splatinsert55 = insertelement <4 x float> poison, float %60, i64 0
  %broadcast.splat56 = shufflevector <4 x float> %broadcast.splatinsert55, <4 x float> poison, <4 x i32> zeroinitializer
  br label %61

61:                                               ; preds = %1, %206
  %62 = phi i64 [ 0, %1 ], [ %207, %206 ]
  %63 = mul nuw nsw i64 %62, 4800
  %64 = mul nuw nsw i64 %62, 400
  br label %vector.ph

vector.ph:                                        ; preds = %61, %middle.block
  %65 = phi i64 [ 0, %61 ], [ %205, %middle.block ]
  %66 = mul nuw nsw i64 %65, 20
  %67 = add nuw nsw i64 %66, %64
  %68 = mul nuw nsw i64 %65, 240
  %69 = add nuw nsw i64 %68, %63
  %broadcast.splatinsert = insertelement <4 x i64> poison, i64 %69, i64 0
  %broadcast.splat = shufflevector <4 x i64> %broadcast.splatinsert, <4 x i64> poison, <4 x i32> zeroinitializer
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %vector.ph
  %index = phi i64 [ 0, %vector.ph ], [ %index.next, %vector.body ]
  %vec.ind = phi <4 x i64> [ <i64 0, i64 1, i64 2, i64 3>, %vector.ph ], [ %vec.ind.next, %vector.body ]
  %70 = mul nuw nsw <4 x i64> %vec.ind, splat (i64 12)
  %71 = add nuw nsw <4 x i64> %broadcast.splat, %70
  %72 = getelementptr inbounds nuw float, ptr %8, <4 x i64> %71
  %wide.masked.gather = tail call <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr> align 4 %72, <4 x i1> splat (i1 true), <4 x float> poison), !invariant.load !3, !alias.scope !12, !noalias !22
  %73 = fadd <4 x float> %wide.masked.gather, %broadcast.splat10
  %74 = fcmp ogt <4 x float> %73, zeroinitializer
  %75 = zext <4 x i1> %74 to <4 x i32>
  %76 = getelementptr inbounds nuw float, ptr %4, <4 x i64> %71
  %wide.masked.gather57 = tail call <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr> align 4 %76, <4 x i1> splat (i1 true), <4 x float> poison), !invariant.load !3, !alias.scope !7, !noalias !23
  %77 = fadd <4 x float> %wide.masked.gather57, %broadcast.splat12
  %78 = fcmp ogt <4 x float> %77, zeroinitializer
  %79 = zext <4 x i1> %78 to <4 x i32>
  %80 = or disjoint <4 x i64> %71, splat (i64 1)
  %81 = getelementptr inbounds nuw float, ptr %8, <4 x i64> %80
  %wide.masked.gather58 = tail call <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr> align 4 %81, <4 x i1> splat (i1 true), <4 x float> poison), !invariant.load !3, !alias.scope !12, !noalias !22
  %82 = fadd <4 x float> %wide.masked.gather58, %broadcast.splat14
  %83 = fcmp ogt <4 x float> %82, zeroinitializer
  %84 = zext <4 x i1> %83 to <4 x i32>
  %85 = getelementptr inbounds nuw float, ptr %4, <4 x i64> %80
  %wide.masked.gather59 = tail call <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr> align 4 %85, <4 x i1> splat (i1 true), <4 x float> poison), !invariant.load !3, !alias.scope !7, !noalias !23
  %86 = fadd <4 x float> %wide.masked.gather59, %broadcast.splat16
  %87 = fcmp ogt <4 x float> %86, zeroinitializer
  %88 = zext <4 x i1> %87 to <4 x i32>
  %89 = add nuw nsw <4 x i32> %75, %84
  %90 = add nuw nsw <4 x i32> %79, %88
  %91 = or disjoint <4 x i64> %71, splat (i64 2)
  %92 = getelementptr inbounds nuw float, ptr %8, <4 x i64> %91
  %wide.masked.gather60 = tail call <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr> align 4 %92, <4 x i1> splat (i1 true), <4 x float> poison), !invariant.load !3, !alias.scope !12, !noalias !22
  %93 = fadd <4 x float> %wide.masked.gather60, %broadcast.splat18
  %94 = fcmp ogt <4 x float> %93, zeroinitializer
  %95 = zext <4 x i1> %94 to <4 x i32>
  %96 = getelementptr inbounds nuw float, ptr %4, <4 x i64> %91
  %wide.masked.gather61 = tail call <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr> align 4 %96, <4 x i1> splat (i1 true), <4 x float> poison), !invariant.load !3, !alias.scope !7, !noalias !23
  %97 = fadd <4 x float> %wide.masked.gather61, %broadcast.splat20
  %98 = fcmp ogt <4 x float> %97, zeroinitializer
  %99 = zext <4 x i1> %98 to <4 x i32>
  %100 = add nuw nsw <4 x i32> %89, %95
  %101 = add nuw nsw <4 x i32> %90, %99
  %102 = or disjoint <4 x i64> %71, splat (i64 3)
  %103 = getelementptr inbounds nuw float, ptr %8, <4 x i64> %102
  %wide.masked.gather62 = tail call <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr> align 4 %103, <4 x i1> splat (i1 true), <4 x float> poison), !invariant.load !3, !alias.scope !12, !noalias !22
  %104 = fadd <4 x float> %wide.masked.gather62, %broadcast.splat22
  %105 = fcmp ogt <4 x float> %104, zeroinitializer
  %106 = zext <4 x i1> %105 to <4 x i32>
  %107 = getelementptr inbounds nuw float, ptr %4, <4 x i64> %102
  %wide.masked.gather63 = tail call <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr> align 4 %107, <4 x i1> splat (i1 true), <4 x float> poison), !invariant.load !3, !alias.scope !7, !noalias !23
  %108 = fadd <4 x float> %wide.masked.gather63, %broadcast.splat24
  %109 = fcmp ogt <4 x float> %108, zeroinitializer
  %110 = zext <4 x i1> %109 to <4 x i32>
  %111 = add nuw nsw <4 x i32> %100, %106
  %112 = add nuw nsw <4 x i32> %101, %110
  %113 = add nuw nsw <4 x i64> %71, splat (i64 4)
  %114 = getelementptr inbounds nuw float, ptr %8, <4 x i64> %113
  %wide.masked.gather64 = tail call <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr> align 4 %114, <4 x i1> splat (i1 true), <4 x float> poison), !invariant.load !3, !alias.scope !12, !noalias !22
  %115 = fadd <4 x float> %wide.masked.gather64, %broadcast.splat26
  %116 = fcmp ogt <4 x float> %115, zeroinitializer
  %117 = zext <4 x i1> %116 to <4 x i32>
  %118 = getelementptr inbounds nuw float, ptr %4, <4 x i64> %113
  %wide.masked.gather65 = tail call <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr> align 4 %118, <4 x i1> splat (i1 true), <4 x float> poison), !invariant.load !3, !alias.scope !7, !noalias !23
  %119 = fadd <4 x float> %wide.masked.gather65, %broadcast.splat28
  %120 = fcmp ogt <4 x float> %119, zeroinitializer
  %121 = zext <4 x i1> %120 to <4 x i32>
  %122 = add nuw nsw <4 x i32> %111, %117
  %123 = add nuw nsw <4 x i32> %112, %121
  %124 = add nuw nsw <4 x i64> %71, splat (i64 5)
  %125 = getelementptr inbounds nuw float, ptr %8, <4 x i64> %124
  %wide.masked.gather66 = tail call <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr> align 4 %125, <4 x i1> splat (i1 true), <4 x float> poison), !invariant.load !3, !alias.scope !12, !noalias !22
  %126 = fadd <4 x float> %wide.masked.gather66, %broadcast.splat30
  %127 = fcmp ogt <4 x float> %126, zeroinitializer
  %128 = zext <4 x i1> %127 to <4 x i32>
  %129 = getelementptr inbounds nuw float, ptr %4, <4 x i64> %124
  %wide.masked.gather67 = tail call <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr> align 4 %129, <4 x i1> splat (i1 true), <4 x float> poison), !invariant.load !3, !alias.scope !7, !noalias !23
  %130 = fadd <4 x float> %wide.masked.gather67, %broadcast.splat32
  %131 = fcmp ogt <4 x float> %130, zeroinitializer
  %132 = zext <4 x i1> %131 to <4 x i32>
  %133 = add nuw nsw <4 x i32> %122, %128
  %134 = add nuw nsw <4 x i32> %123, %132
  %135 = add nuw nsw <4 x i64> %71, splat (i64 6)
  %136 = getelementptr inbounds nuw float, ptr %8, <4 x i64> %135
  %wide.masked.gather68 = tail call <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr> align 4 %136, <4 x i1> splat (i1 true), <4 x float> poison), !invariant.load !3, !alias.scope !12, !noalias !22
  %137 = fadd <4 x float> %wide.masked.gather68, %broadcast.splat34
  %138 = fcmp ogt <4 x float> %137, zeroinitializer
  %139 = zext <4 x i1> %138 to <4 x i32>
  %140 = getelementptr inbounds nuw float, ptr %4, <4 x i64> %135
  %wide.masked.gather69 = tail call <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr> align 4 %140, <4 x i1> splat (i1 true), <4 x float> poison), !invariant.load !3, !alias.scope !7, !noalias !23
  %141 = fadd <4 x float> %wide.masked.gather69, %broadcast.splat36
  %142 = fcmp ogt <4 x float> %141, zeroinitializer
  %143 = zext <4 x i1> %142 to <4 x i32>
  %144 = add nuw nsw <4 x i32> %133, %139
  %145 = add nuw nsw <4 x i32> %134, %143
  %146 = add nuw nsw <4 x i64> %71, splat (i64 7)
  %147 = getelementptr inbounds nuw float, ptr %8, <4 x i64> %146
  %wide.masked.gather70 = tail call <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr> align 4 %147, <4 x i1> splat (i1 true), <4 x float> poison), !invariant.load !3, !alias.scope !12, !noalias !22
  %148 = fadd <4 x float> %wide.masked.gather70, %broadcast.splat38
  %149 = fcmp ogt <4 x float> %148, zeroinitializer
  %150 = zext <4 x i1> %149 to <4 x i32>
  %151 = getelementptr inbounds nuw float, ptr %4, <4 x i64> %146
  %wide.masked.gather71 = tail call <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr> align 4 %151, <4 x i1> splat (i1 true), <4 x float> poison), !invariant.load !3, !alias.scope !7, !noalias !23
  %152 = fadd <4 x float> %wide.masked.gather71, %broadcast.splat40
  %153 = fcmp ogt <4 x float> %152, zeroinitializer
  %154 = zext <4 x i1> %153 to <4 x i32>
  %155 = add nuw nsw <4 x i32> %144, %150
  %156 = add nuw nsw <4 x i32> %145, %154
  %157 = add nuw nsw <4 x i64> %71, splat (i64 8)
  %158 = getelementptr inbounds nuw float, ptr %8, <4 x i64> %157
  %wide.masked.gather72 = tail call <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr> align 4 %158, <4 x i1> splat (i1 true), <4 x float> poison), !invariant.load !3, !alias.scope !12, !noalias !22
  %159 = fadd <4 x float> %wide.masked.gather72, %broadcast.splat42
  %160 = fcmp ogt <4 x float> %159, zeroinitializer
  %161 = zext <4 x i1> %160 to <4 x i32>
  %162 = getelementptr inbounds nuw float, ptr %4, <4 x i64> %157
  %wide.masked.gather73 = tail call <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr> align 4 %162, <4 x i1> splat (i1 true), <4 x float> poison), !invariant.load !3, !alias.scope !7, !noalias !23
  %163 = fadd <4 x float> %wide.masked.gather73, %broadcast.splat44
  %164 = fcmp ogt <4 x float> %163, zeroinitializer
  %165 = zext <4 x i1> %164 to <4 x i32>
  %166 = add nuw nsw <4 x i32> %155, %161
  %167 = add nuw nsw <4 x i32> %156, %165
  %168 = add nuw nsw <4 x i64> %71, splat (i64 9)
  %169 = getelementptr inbounds nuw float, ptr %8, <4 x i64> %168
  %wide.masked.gather74 = tail call <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr> align 4 %169, <4 x i1> splat (i1 true), <4 x float> poison), !invariant.load !3, !alias.scope !12, !noalias !22
  %170 = fadd <4 x float> %wide.masked.gather74, %broadcast.splat46
  %171 = fcmp ogt <4 x float> %170, zeroinitializer
  %172 = zext <4 x i1> %171 to <4 x i32>
  %173 = getelementptr inbounds nuw float, ptr %4, <4 x i64> %168
  %wide.masked.gather75 = tail call <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr> align 4 %173, <4 x i1> splat (i1 true), <4 x float> poison), !invariant.load !3, !alias.scope !7, !noalias !23
  %174 = fadd <4 x float> %wide.masked.gather75, %broadcast.splat48
  %175 = fcmp ogt <4 x float> %174, zeroinitializer
  %176 = zext <4 x i1> %175 to <4 x i32>
  %177 = add nuw nsw <4 x i32> %166, %172
  %178 = add nuw nsw <4 x i32> %167, %176
  %179 = add nuw nsw <4 x i64> %71, splat (i64 10)
  %180 = getelementptr inbounds nuw float, ptr %8, <4 x i64> %179
  %wide.masked.gather76 = tail call <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr> align 4 %180, <4 x i1> splat (i1 true), <4 x float> poison), !invariant.load !3, !alias.scope !12, !noalias !22
  %181 = fadd <4 x float> %wide.masked.gather76, %broadcast.splat50
  %182 = fcmp ogt <4 x float> %181, zeroinitializer
  %183 = zext <4 x i1> %182 to <4 x i32>
  %184 = getelementptr inbounds nuw float, ptr %4, <4 x i64> %179
  %wide.masked.gather77 = tail call <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr> align 4 %184, <4 x i1> splat (i1 true), <4 x float> poison), !invariant.load !3, !alias.scope !7, !noalias !23
  %185 = fadd <4 x float> %wide.masked.gather77, %broadcast.splat52
  %186 = fcmp ogt <4 x float> %185, zeroinitializer
  %187 = zext <4 x i1> %186 to <4 x i32>
  %188 = add nuw nsw <4 x i32> %177, %183
  %189 = add nuw nsw <4 x i32> %178, %187
  %190 = add nuw nsw <4 x i64> %71, splat (i64 11)
  %191 = getelementptr inbounds nuw float, ptr %8, <4 x i64> %190
  %wide.masked.gather78 = tail call <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr> align 4 %191, <4 x i1> splat (i1 true), <4 x float> poison), !invariant.load !3, !alias.scope !12, !noalias !22
  %192 = fadd <4 x float> %wide.masked.gather78, %broadcast.splat54
  %193 = fcmp ogt <4 x float> %192, zeroinitializer
  %194 = zext <4 x i1> %193 to <4 x i32>
  %195 = getelementptr inbounds nuw float, ptr %4, <4 x i64> %190
  %wide.masked.gather79 = tail call <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr> align 4 %195, <4 x i1> splat (i1 true), <4 x float> poison), !invariant.load !3, !alias.scope !7, !noalias !23
  %196 = fadd <4 x float> %wide.masked.gather79, %broadcast.splat56
  %197 = fcmp ogt <4 x float> %196, zeroinitializer
  %198 = zext <4 x i1> %197 to <4 x i32>
  %199 = add nuw nsw <4 x i32> %188, %194
  %200 = add nuw nsw <4 x i32> %189, %198
  %201 = add nuw nsw i64 %67, %index
  %202 = getelementptr inbounds nuw i32, ptr %12, i64 %201
  store <4 x i32> %199, ptr %202, align 4, !alias.scope !16, !noalias !24
  %203 = getelementptr inbounds nuw i32, ptr %14, i64 %201
  store <4 x i32> %200, ptr %203, align 4, !alias.scope !18, !noalias !25
  %index.next = add nuw i64 %index, 4
  %vec.ind.next = add nuw nsw <4 x i64> %vec.ind, splat (i64 4)
  %204 = icmp eq i64 %index.next, 20
  br i1 %204, label %middle.block, label %vector.body, !llvm.loop !26

middle.block:                                     ; preds = %vector.body
  %205 = add nuw nsw i64 %65, 1
  %exitcond6.not = icmp eq i64 %205, 20
  br i1 %exitcond6.not, label %206, label %vector.ph, !llvm.loop !30

206:                                              ; preds = %middle.block
  %207 = add nuw nsw i64 %62, 1
  %exitcond7.not = icmp eq i64 %207, 3
  br i1 %exitcond7.not, label %convert_reduce_fusion_wrapped.exit, label %61, !llvm.loop !30

convert_reduce_fusion_wrapped.exit:               ; preds = %206
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr>, <4 x i1>, <4 x float>) #2

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(read) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 2}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 57600}
!5 = !{i64 48}
!6 = !{i64 4800}
!7 = !{!8}
!8 = distinct !{!8, !9, !"convert_reduce_fusion_wrapped: argument 0"}
!9 = distinct !{!9, !"convert_reduce_fusion_wrapped"}
!10 = !{!11}
!11 = distinct !{!11, !9, !"convert_reduce_fusion_wrapped: argument 1"}
!12 = !{!13}
!13 = distinct !{!13, !9, !"convert_reduce_fusion_wrapped: argument 2"}
!14 = !{!15}
!15 = distinct !{!15, !9, !"convert_reduce_fusion_wrapped: argument 3"}
!16 = !{!17}
!17 = distinct !{!17, !9, !"convert_reduce_fusion_wrapped: argument 4"}
!18 = !{!19}
!19 = distinct !{!19, !9, !"convert_reduce_fusion_wrapped: argument 5"}
!20 = !{!8, !11, !13, !17, !19}
!21 = !{!8, !13, !15, !17, !19}
!22 = !{!8, !11, !15, !17, !19}
!23 = !{!11, !13, !15, !17, !19}
!24 = !{!8, !11, !13, !15, !19}
!25 = !{!8, !11, !13, !15, !17}
!26 = distinct !{!26, !27, !28, !29}
!27 = !{!"llvm.loop.unroll.disable"}
!28 = !{!"llvm.loop.isvectorized", i32 1}
!29 = !{!"llvm.loop.unroll.runtime.disable"}
!30 = distinct !{!30, !27}
