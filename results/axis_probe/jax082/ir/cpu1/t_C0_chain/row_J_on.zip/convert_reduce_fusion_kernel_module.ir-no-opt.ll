; ModuleID = '__compute_module_convert_reduce_fusion_kernel_module'
source_filename = "__compute_module_convert_reduce_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

%XLA_CPU_KernelCallFrame = type { ptr, ptr, i64, ptr }
%XLA_CPU_KernelArg = type { ptr, i64 }
%kernel_dim3 = type { i64, i64, i64 }

; Function Attrs: uwtable
define ptr @convert_reduce_fusion(ptr %0) #0 {
  %2 = getelementptr inbounds %XLA_CPU_KernelCallFrame, ptr %0, i32 0, i32 3
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 0, i32 0
  %5 = load ptr, ptr %4, align 8, !invariant.load !3, !dereferenceable !4
  %6 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 1, i32 0
  %7 = load ptr, ptr %6, align 8, !invariant.load !3, !dereferenceable !5
  %8 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 2, i32 0
  %9 = load ptr, ptr %8, align 8, !invariant.load !3, !dereferenceable !4
  %10 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 3, i32 0
  %11 = load ptr, ptr %10, align 8, !invariant.load !3, !dereferenceable !5
  %12 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 4, i32 0
  %13 = load ptr, ptr %12, align 8, !invariant.load !3, !dereferenceable !6
  %14 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 5, i32 0
  %15 = load ptr, ptr %14, align 8, !invariant.load !3, !dereferenceable !6
  %16 = getelementptr inbounds %XLA_CPU_KernelCallFrame, ptr %0, i32 0, i32 1
  %17 = load ptr, ptr %16, align 8
  %18 = getelementptr inbounds %kernel_dim3, ptr %17, i32 0, i32 0
  %19 = load i64, ptr %18, align 4, !invariant.load !3
  %20 = getelementptr inbounds %kernel_dim3, ptr %17, i32 0, i32 1
  %21 = load i64, ptr %20, align 4, !invariant.load !3
  %22 = getelementptr inbounds %kernel_dim3, ptr %17, i32 0, i32 2
  %23 = load i64, ptr %22, align 4, !invariant.load !3
  call void @convert_reduce_fusion_wrapped(ptr %5, ptr %7, ptr %9, ptr %11, ptr %13, ptr %15, i64 %19, i64 %21, i64 %23)
  ret ptr null
}

; Function Attrs: alwaysinline
define internal void @convert_reduce_fusion_wrapped(ptr noalias align 64 dereferenceable(57600) %0, ptr noalias align 64 dereferenceable(48) %1, ptr noalias align 64 dereferenceable(57600) %2, ptr noalias align 64 dereferenceable(48) %3, ptr noalias align 64 dereferenceable(4800) %4, ptr noalias align 64 dereferenceable(4800) %5, i64 %6, i64 %7, i64 %8) #1 {
  br label %10

10:                                               ; preds = %61, %9
  %11 = phi i64 [ %62, %61 ], [ 0, %9 ]
  %12 = icmp slt i64 %11, 3
  br i1 %12, label %13, label %63

13:                                               ; preds = %10
  %14 = mul nsw i64 %11, 4800
  %15 = mul nsw i64 %11, 400
  br label %16

16:                                               ; preds = %59, %13
  %17 = phi i64 [ %60, %59 ], [ 0, %13 ]
  %18 = icmp slt i64 %17, 20
  br i1 %18, label %19, label %61

19:                                               ; preds = %16
  %20 = mul nsw i64 %17, 240
  %21 = add nsw i64 %14, %20
  %22 = mul nsw i64 %17, 20
  %23 = add nsw i64 %15, %22
  br label %24

24:                                               ; preds = %54, %19
  %25 = phi i64 [ %58, %54 ], [ 0, %19 ]
  %26 = icmp slt i64 %25, 20
  br i1 %26, label %27, label %59

27:                                               ; preds = %24
  %28 = mul nsw i64 %25, 12
  %29 = add nsw i64 %21, %28
  br label %30

30:                                               ; preds = %35, %27
  %31 = phi i64 [ %53, %35 ], [ 0, %27 ]
  %32 = phi i32 [ %51, %35 ], [ 0, %27 ]
  %33 = phi i32 [ %52, %35 ], [ 0, %27 ]
  %34 = icmp slt i64 %31, 12
  br i1 %34, label %35, label %54

35:                                               ; preds = %30
  %36 = add nsw i64 %29, %31
  %37 = getelementptr inbounds [14400 x float], ptr %2, i32 0, i64 %36
  %38 = load float, ptr %37, align 4, !invariant.load !3
  %39 = getelementptr inbounds [12 x float], ptr %3, i32 0, i64 %31
  %40 = load float, ptr %39, align 4, !invariant.load !3
  %41 = fadd float %38, %40
  %42 = fcmp ogt float %41, 0.000000e+00
  %43 = zext i1 %42 to i32
  %44 = getelementptr inbounds [14400 x float], ptr %0, i32 0, i64 %36
  %45 = load float, ptr %44, align 4, !invariant.load !3
  %46 = getelementptr inbounds [12 x float], ptr %1, i32 0, i64 %31
  %47 = load float, ptr %46, align 4, !invariant.load !3
  %48 = fadd float %45, %47
  %49 = fcmp ogt float %48, 0.000000e+00
  %50 = zext i1 %49 to i32
  %51 = add i32 %32, %43
  %52 = add i32 %33, %50
  %53 = add i64 %31, 1
  br label %30

54:                                               ; preds = %30
  %55 = add nsw i64 %23, %25
  %56 = getelementptr inbounds [1200 x i32], ptr %4, i32 0, i64 %55
  store i32 %32, ptr %56, align 4
  %57 = getelementptr inbounds [1200 x i32], ptr %5, i32 0, i64 %55
  store i32 %33, ptr %57, align 4
  %58 = add i64 %25, 1
  br label %24, !llvm.loop !7

59:                                               ; preds = %24
  %60 = add i64 %17, 1
  br label %16, !llvm.loop !7

61:                                               ; preds = %16
  %62 = add i64 %11, 1
  br label %10, !llvm.loop !7

63:                                               ; preds = %10
  ret void
}

attributes #0 = { uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { alwaysinline }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 2}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 57600}
!5 = !{i64 48}
!6 = !{i64 4800}
!7 = distinct !{!7, !8}
!8 = !{!"llvm.loop.unroll.disable"}
