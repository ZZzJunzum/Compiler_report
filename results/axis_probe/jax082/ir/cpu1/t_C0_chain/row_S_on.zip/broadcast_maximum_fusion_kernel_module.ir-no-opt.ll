; ModuleID = '__compute_module_broadcast_maximum_fusion_kernel_module'
source_filename = "__compute_module_broadcast_maximum_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

%XLA_CPU_KernelCallFrame = type { ptr, ptr, i64, ptr }
%XLA_CPU_KernelArg = type { ptr, i64 }
%kernel_dim3 = type { i64, i64, i64 }

; Function Attrs: uwtable
define ptr @broadcast_maximum_fusion(ptr %0) #0 {
  %2 = getelementptr inbounds %XLA_CPU_KernelCallFrame, ptr %0, i32 0, i32 3
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 0, i32 0
  %5 = load ptr, ptr %4, align 8, !invariant.load !3, !dereferenceable !4
  %6 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 1, i32 0
  %7 = load ptr, ptr %6, align 8, !invariant.load !3, !dereferenceable !5
  %8 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 2, i32 0
  %9 = load ptr, ptr %8, align 8, !invariant.load !3, !dereferenceable !4
  %10 = getelementptr inbounds %XLA_CPU_KernelCallFrame, ptr %0, i32 0, i32 1
  %11 = load ptr, ptr %10, align 8
  %12 = getelementptr inbounds %kernel_dim3, ptr %11, i32 0, i32 0
  %13 = load i64, ptr %12, align 4, !invariant.load !3
  %14 = getelementptr inbounds %kernel_dim3, ptr %11, i32 0, i32 1
  %15 = load i64, ptr %14, align 4, !invariant.load !3
  %16 = getelementptr inbounds %kernel_dim3, ptr %11, i32 0, i32 2
  %17 = load i64, ptr %16, align 4, !invariant.load !3
  call void @broadcast_maximum_fusion_wrapped(ptr %5, ptr %7, ptr %9, i64 %13, i64 %15, i64 %17)
  ret ptr null
}

; Function Attrs: alwaysinline
define internal void @broadcast_maximum_fusion_wrapped(ptr noalias align 64 dereferenceable(57600) %0, ptr noalias align 64 dereferenceable(48) %1, ptr noalias align 64 dereferenceable(57600) %2, i64 %3, i64 %4, i64 %5) #1 {
  br label %7

7:                                                ; preds = %41, %6
  %8 = phi i64 [ %42, %41 ], [ 0, %6 ]
  %9 = icmp slt i64 %8, 3
  br i1 %9, label %10, label %43

10:                                               ; preds = %7
  %11 = mul nsw i64 %8, 4800
  br label %12

12:                                               ; preds = %39, %10
  %13 = phi i64 [ %40, %39 ], [ 0, %10 ]
  %14 = icmp slt i64 %13, 20
  br i1 %14, label %15, label %41

15:                                               ; preds = %12
  %16 = mul nsw i64 %13, 240
  %17 = add nsw i64 %11, %16
  br label %18

18:                                               ; preds = %37, %15
  %19 = phi i64 [ %38, %37 ], [ 0, %15 ]
  %20 = icmp slt i64 %19, 20
  br i1 %20, label %21, label %39

21:                                               ; preds = %18
  %22 = mul nsw i64 %19, 12
  %23 = add nsw i64 %17, %22
  br label %24

24:                                               ; preds = %27, %21
  %25 = phi i64 [ %36, %27 ], [ 0, %21 ]
  %26 = icmp slt i64 %25, 12
  br i1 %26, label %27, label %37

27:                                               ; preds = %24
  %28 = add nsw i64 %23, %25
  %29 = getelementptr inbounds [14400 x float], ptr %0, i32 0, i64 %28
  %30 = load float, ptr %29, align 4, !invariant.load !3
  %31 = getelementptr inbounds [12 x float], ptr %1, i32 0, i64 %25
  %32 = load float, ptr %31, align 4, !invariant.load !3
  %33 = fadd float %30, %32
  %34 = call float @llvm.maximum.f32(float %33, float 0.000000e+00)
  %35 = getelementptr inbounds [14400 x float], ptr %2, i32 0, i64 %28
  store float %34, ptr %35, align 4
  %36 = add i64 %25, 1
  br label %24

37:                                               ; preds = %24
  %38 = add i64 %19, 1
  br label %18, !llvm.loop !6

39:                                               ; preds = %18
  %40 = add i64 %13, 1
  br label %12, !llvm.loop !6

41:                                               ; preds = %12
  %42 = add i64 %8, 1
  br label %7, !llvm.loop !6

43:                                               ; preds = %7
  ret void
}

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.maximum.f32(float, float) #2

attributes #0 = { uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { alwaysinline }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 1}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 57600}
!5 = !{i64 48}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.unroll.disable"}
