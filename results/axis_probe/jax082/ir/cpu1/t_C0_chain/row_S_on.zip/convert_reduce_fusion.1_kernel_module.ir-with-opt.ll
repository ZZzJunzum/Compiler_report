; ModuleID = '__compute_module_convert_reduce_fusion.1_kernel_module'
source_filename = "__compute_module_convert_reduce_fusion.1_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @convert_reduce_fusion.1(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !5
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !6
  tail call void @llvm.experimental.noalias.scope.decl(metadata !7)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !10)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !12)
  %9 = load <4 x float>, ptr %6, align 4
  %.phi.trans.insert.phi.trans.insert.phi.trans.insert = getelementptr inbounds nuw i8, ptr %6, i64 4
  %10 = load <4 x float>, ptr %.phi.trans.insert.phi.trans.insert.phi.trans.insert, align 4
  %.phi.trans.insert10.phi.trans.insert.phi.trans.insert = getelementptr inbounds nuw i8, ptr %6, i64 8
  %11 = load <4 x float>, ptr %.phi.trans.insert10.phi.trans.insert.phi.trans.insert, align 4
  %.phi.trans.insert12.phi.trans.insert.phi.trans.insert = getelementptr inbounds nuw i8, ptr %6, i64 12
  %12 = load <4 x float>, ptr %.phi.trans.insert12.phi.trans.insert.phi.trans.insert, align 4
  %.phi.trans.insert14.phi.trans.insert.phi.trans.insert = getelementptr inbounds nuw i8, ptr %6, i64 16
  %13 = load <4 x float>, ptr %.phi.trans.insert14.phi.trans.insert.phi.trans.insert, align 4
  %.phi.trans.insert16.phi.trans.insert.phi.trans.insert = getelementptr inbounds nuw i8, ptr %6, i64 20
  %14 = load <4 x float>, ptr %.phi.trans.insert16.phi.trans.insert.phi.trans.insert, align 4
  %.phi.trans.insert18.phi.trans.insert.phi.trans.insert = getelementptr inbounds nuw i8, ptr %6, i64 24
  %15 = load <4 x float>, ptr %.phi.trans.insert18.phi.trans.insert.phi.trans.insert, align 4
  %.phi.trans.insert20.phi.trans.insert.phi.trans.insert = getelementptr inbounds nuw i8, ptr %6, i64 28
  %16 = load <4 x float>, ptr %.phi.trans.insert20.phi.trans.insert.phi.trans.insert, align 4
  %.phi.trans.insert22.phi.trans.insert.phi.trans.insert = getelementptr inbounds nuw i8, ptr %6, i64 32
  %17 = load <4 x float>, ptr %.phi.trans.insert22.phi.trans.insert.phi.trans.insert, align 4
  %.phi.trans.insert24.phi.trans.insert.phi.trans.insert = getelementptr inbounds nuw i8, ptr %6, i64 36
  %.pre25.pre.pre = load float, ptr %.phi.trans.insert24.phi.trans.insert.phi.trans.insert, align 4, !invariant.load !3, !alias.scope !10, !noalias !14
  %.phi.trans.insert26.phi.trans.insert.phi.trans.insert = getelementptr inbounds nuw i8, ptr %6, i64 40
  %.pre27.pre.pre = load float, ptr %.phi.trans.insert26.phi.trans.insert.phi.trans.insert, align 4, !invariant.load !3, !alias.scope !10, !noalias !14
  %.phi.trans.insert28.phi.trans.insert.phi.trans.insert = getelementptr inbounds nuw i8, ptr %6, i64 44
  %.pre29.pre.pre = load float, ptr %.phi.trans.insert28.phi.trans.insert.phi.trans.insert, align 4, !invariant.load !3, !alias.scope !10, !noalias !14
  %broadcast.splat = shufflevector <4 x float> %9, <4 x float> poison, <4 x i32> zeroinitializer
  %broadcast.splat32 = shufflevector <4 x float> %10, <4 x float> poison, <4 x i32> zeroinitializer
  %broadcast.splat34 = shufflevector <4 x float> %11, <4 x float> poison, <4 x i32> zeroinitializer
  %broadcast.splat36 = shufflevector <4 x float> %12, <4 x float> poison, <4 x i32> zeroinitializer
  %broadcast.splat38 = shufflevector <4 x float> %13, <4 x float> poison, <4 x i32> zeroinitializer
  %broadcast.splat40 = shufflevector <4 x float> %14, <4 x float> poison, <4 x i32> zeroinitializer
  %broadcast.splat42 = shufflevector <4 x float> %15, <4 x float> poison, <4 x i32> zeroinitializer
  %broadcast.splat44 = shufflevector <4 x float> %16, <4 x float> poison, <4 x i32> zeroinitializer
  %broadcast.splat46 = shufflevector <4 x float> %17, <4 x float> poison, <4 x i32> zeroinitializer
  %broadcast.splatinsert47 = insertelement <4 x float> poison, float %.pre25.pre.pre, i64 0
  %broadcast.splat48 = shufflevector <4 x float> %broadcast.splatinsert47, <4 x float> poison, <4 x i32> zeroinitializer
  %broadcast.splatinsert49 = insertelement <4 x float> poison, float %.pre27.pre.pre, i64 0
  %broadcast.splat50 = shufflevector <4 x float> %broadcast.splatinsert49, <4 x float> poison, <4 x i32> zeroinitializer
  %broadcast.splatinsert51 = insertelement <4 x float> poison, float %.pre29.pre.pre, i64 0
  %broadcast.splat52 = shufflevector <4 x float> %broadcast.splatinsert51, <4 x float> poison, <4 x i32> zeroinitializer
  br label %.preheader6

.preheader6:                                      ; preds = %1, %87
  %18 = phi i64 [ 0, %1 ], [ %88, %87 ]
  %.idx2 = mul nuw nsw i64 %18, 19200
  %19 = getelementptr i8, ptr %4, i64 %.idx2
  %.idx = mul nuw nsw i64 %18, 1600
  %20 = getelementptr i8, ptr %8, i64 %.idx
  br label %.preheader5

.preheader5:                                      ; preds = %.preheader6, %middle.block
  %21 = phi i64 [ 0, %.preheader6 ], [ %86, %middle.block ]
  %.idx3 = mul nuw nsw i64 %21, 960
  %22 = getelementptr i8, ptr %19, i64 %.idx3
  %.idx1 = mul nuw nsw i64 %21, 80
  %23 = getelementptr i8, ptr %20, i64 %.idx1
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %.preheader5
  %index = phi i64 [ 0, %.preheader5 ], [ %index.next, %vector.body ]
  %vec.ind = phi <4 x i64> [ <i64 0, i64 1, i64 2, i64 3>, %.preheader5 ], [ %vec.ind.next, %vector.body ]
  %24 = mul nuw nsw <4 x i64> %vec.ind, splat (i64 48)
  %25 = getelementptr i8, ptr %22, <4 x i64> %24
  %wide.masked.gather = tail call <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr> align 4 %25, <4 x i1> splat (i1 true), <4 x float> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %26 = fadd <4 x float> %wide.masked.gather, %broadcast.splat
  %27 = fcmp ogt <4 x float> %26, zeroinitializer
  %28 = zext <4 x i1> %27 to <4 x i32>
  %29 = getelementptr i8, <4 x ptr> %25, i64 4
  %wide.masked.gather53 = tail call <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr> align 4 %29, <4 x i1> splat (i1 true), <4 x float> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %30 = fadd <4 x float> %wide.masked.gather53, %broadcast.splat32
  %31 = fcmp ogt <4 x float> %30, zeroinitializer
  %32 = zext <4 x i1> %31 to <4 x i32>
  %33 = add nuw nsw <4 x i32> %28, %32
  %34 = getelementptr i8, <4 x ptr> %25, i64 8
  %wide.masked.gather54 = tail call <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr> align 4 %34, <4 x i1> splat (i1 true), <4 x float> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %35 = fadd <4 x float> %wide.masked.gather54, %broadcast.splat34
  %36 = fcmp ogt <4 x float> %35, zeroinitializer
  %37 = zext <4 x i1> %36 to <4 x i32>
  %38 = add nuw nsw <4 x i32> %33, %37
  %39 = getelementptr i8, <4 x ptr> %25, i64 12
  %wide.masked.gather55 = tail call <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr> align 4 %39, <4 x i1> splat (i1 true), <4 x float> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %40 = fadd <4 x float> %wide.masked.gather55, %broadcast.splat36
  %41 = fcmp ogt <4 x float> %40, zeroinitializer
  %42 = zext <4 x i1> %41 to <4 x i32>
  %43 = add nuw nsw <4 x i32> %38, %42
  %44 = getelementptr i8, <4 x ptr> %25, i64 16
  %wide.masked.gather56 = tail call <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr> align 4 %44, <4 x i1> splat (i1 true), <4 x float> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %45 = fadd <4 x float> %wide.masked.gather56, %broadcast.splat38
  %46 = fcmp ogt <4 x float> %45, zeroinitializer
  %47 = zext <4 x i1> %46 to <4 x i32>
  %48 = add nuw nsw <4 x i32> %43, %47
  %49 = getelementptr i8, <4 x ptr> %25, i64 20
  %wide.masked.gather57 = tail call <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr> align 4 %49, <4 x i1> splat (i1 true), <4 x float> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %50 = fadd <4 x float> %wide.masked.gather57, %broadcast.splat40
  %51 = fcmp ogt <4 x float> %50, zeroinitializer
  %52 = zext <4 x i1> %51 to <4 x i32>
  %53 = add nuw nsw <4 x i32> %48, %52
  %54 = getelementptr i8, <4 x ptr> %25, i64 24
  %wide.masked.gather58 = tail call <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr> align 4 %54, <4 x i1> splat (i1 true), <4 x float> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %55 = fadd <4 x float> %wide.masked.gather58, %broadcast.splat42
  %56 = fcmp ogt <4 x float> %55, zeroinitializer
  %57 = zext <4 x i1> %56 to <4 x i32>
  %58 = add nuw nsw <4 x i32> %53, %57
  %59 = getelementptr i8, <4 x ptr> %25, i64 28
  %wide.masked.gather59 = tail call <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr> align 4 %59, <4 x i1> splat (i1 true), <4 x float> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %60 = fadd <4 x float> %wide.masked.gather59, %broadcast.splat44
  %61 = fcmp ogt <4 x float> %60, zeroinitializer
  %62 = zext <4 x i1> %61 to <4 x i32>
  %63 = add nuw nsw <4 x i32> %58, %62
  %64 = getelementptr i8, <4 x ptr> %25, i64 32
  %wide.masked.gather60 = tail call <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr> align 4 %64, <4 x i1> splat (i1 true), <4 x float> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %65 = fadd <4 x float> %wide.masked.gather60, %broadcast.splat46
  %66 = fcmp ogt <4 x float> %65, zeroinitializer
  %67 = zext <4 x i1> %66 to <4 x i32>
  %68 = add nuw nsw <4 x i32> %63, %67
  %69 = getelementptr i8, <4 x ptr> %25, i64 36
  %wide.masked.gather61 = tail call <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr> align 4 %69, <4 x i1> splat (i1 true), <4 x float> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %70 = fadd <4 x float> %wide.masked.gather61, %broadcast.splat48
  %71 = fcmp ogt <4 x float> %70, zeroinitializer
  %72 = zext <4 x i1> %71 to <4 x i32>
  %73 = add nuw nsw <4 x i32> %68, %72
  %74 = getelementptr i8, <4 x ptr> %25, i64 40
  %wide.masked.gather62 = tail call <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr> align 4 %74, <4 x i1> splat (i1 true), <4 x float> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %75 = fadd <4 x float> %wide.masked.gather62, %broadcast.splat50
  %76 = fcmp ogt <4 x float> %75, zeroinitializer
  %77 = zext <4 x i1> %76 to <4 x i32>
  %78 = add nuw nsw <4 x i32> %73, %77
  %79 = getelementptr i8, <4 x ptr> %25, i64 44
  %wide.masked.gather63 = tail call <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr> align 4 %79, <4 x i1> splat (i1 true), <4 x float> poison), !invariant.load !3, !alias.scope !7, !noalias !15
  %80 = fadd <4 x float> %wide.masked.gather63, %broadcast.splat52
  %81 = fcmp ogt <4 x float> %80, zeroinitializer
  %82 = zext <4 x i1> %81 to <4 x i32>
  %83 = add nuw nsw <4 x i32> %78, %82
  %84 = getelementptr i32, ptr %23, i64 %index
  store <4 x i32> %83, ptr %84, align 4, !alias.scope !12, !noalias !16
  %index.next = add nuw i64 %index, 4
  %vec.ind.next = add nuw nsw <4 x i64> %vec.ind, splat (i64 4)
  %85 = icmp eq i64 %index.next, 20
  br i1 %85, label %middle.block, label %vector.body, !llvm.loop !17

middle.block:                                     ; preds = %vector.body
  %86 = add nuw nsw i64 %21, 1
  %exitcond7.not = icmp eq i64 %86, 20
  br i1 %exitcond7.not, label %87, label %.preheader5, !llvm.loop !21

87:                                               ; preds = %middle.block
  %88 = add nuw nsw i64 %18, 1
  %exitcond8.not = icmp eq i64 %88, 3
  br i1 %exitcond8.not, label %convert_reduce_fusion.1_wrapped.exit, label %.preheader6, !llvm.loop !21

convert_reduce_fusion.1_wrapped.exit:             ; preds = %87
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr>, <4 x i1>, <4 x float>) #2

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(read) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 2}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 57600}
!5 = !{i64 48}
!6 = !{i64 4800}
!7 = !{!8}
!8 = distinct !{!8, !9, !"convert_reduce_fusion.1_wrapped: argument 0"}
!9 = distinct !{!9, !"convert_reduce_fusion.1_wrapped"}
!10 = !{!11}
!11 = distinct !{!11, !9, !"convert_reduce_fusion.1_wrapped: argument 1"}
!12 = !{!13}
!13 = distinct !{!13, !9, !"convert_reduce_fusion.1_wrapped: argument 2"}
!14 = !{!8, !13}
!15 = !{!11, !13}
!16 = !{!8, !11}
!17 = distinct !{!17, !18, !19, !20}
!18 = !{!"llvm.loop.unroll.disable"}
!19 = !{!"llvm.loop.isvectorized", i32 1}
!20 = !{!"llvm.loop.unroll.runtime.disable"}
!21 = distinct !{!21, !18}
