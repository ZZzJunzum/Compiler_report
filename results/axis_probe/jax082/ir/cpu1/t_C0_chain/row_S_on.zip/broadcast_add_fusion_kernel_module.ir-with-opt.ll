; ModuleID = '__compute_module_broadcast_add_fusion_kernel_module'
source_filename = "__compute_module_broadcast_add_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @broadcast_add_fusion(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !5
  tail call void @llvm.experimental.noalias.scope.decl(metadata !6)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9)
  %.phi.trans.insert.phi.trans.insert.phi.trans.insert = getelementptr inbounds nuw i8, ptr %6, i64 4
  %.pre.pre.pre = load float, ptr %.phi.trans.insert.phi.trans.insert.phi.trans.insert, align 4, !invariant.load !3, !alias.scope !9, !noalias !6
  %.phi.trans.insert7.phi.trans.insert.phi.trans.insert = getelementptr inbounds nuw i8, ptr %6, i64 8
  %.pre8.pre.pre = load float, ptr %.phi.trans.insert7.phi.trans.insert.phi.trans.insert, align 4, !invariant.load !3, !alias.scope !9, !noalias !6
  %.phi.trans.insert9.phi.trans.insert.phi.trans.insert = getelementptr inbounds nuw i8, ptr %6, i64 12
  %.pre10.pre.pre = load float, ptr %.phi.trans.insert9.phi.trans.insert.phi.trans.insert, align 4, !invariant.load !3, !alias.scope !9, !noalias !6
  %.phi.trans.insert11.phi.trans.insert.phi.trans.insert = getelementptr inbounds nuw i8, ptr %6, i64 16
  %.pre12.pre.pre = load float, ptr %.phi.trans.insert11.phi.trans.insert.phi.trans.insert, align 4, !invariant.load !3, !alias.scope !9, !noalias !6
  %.phi.trans.insert13.phi.trans.insert.phi.trans.insert = getelementptr inbounds nuw i8, ptr %6, i64 20
  %.pre14.pre.pre = load float, ptr %.phi.trans.insert13.phi.trans.insert.phi.trans.insert, align 4, !invariant.load !3, !alias.scope !9, !noalias !6
  %.phi.trans.insert15.phi.trans.insert.phi.trans.insert = getelementptr inbounds nuw i8, ptr %6, i64 24
  %.pre16.pre.pre = load float, ptr %.phi.trans.insert15.phi.trans.insert.phi.trans.insert, align 4, !invariant.load !3, !alias.scope !9, !noalias !6
  %.phi.trans.insert17.phi.trans.insert.phi.trans.insert = getelementptr inbounds nuw i8, ptr %6, i64 28
  %.pre18.pre.pre = load float, ptr %.phi.trans.insert17.phi.trans.insert.phi.trans.insert, align 4, !invariant.load !3, !alias.scope !9, !noalias !6
  %.phi.trans.insert19.phi.trans.insert.phi.trans.insert = getelementptr inbounds nuw i8, ptr %6, i64 32
  %.pre20.pre.pre = load float, ptr %.phi.trans.insert19.phi.trans.insert.phi.trans.insert, align 4, !invariant.load !3, !alias.scope !9, !noalias !6
  %.phi.trans.insert21.phi.trans.insert.phi.trans.insert = getelementptr inbounds nuw i8, ptr %6, i64 36
  %.pre22.pre.pre = load float, ptr %.phi.trans.insert21.phi.trans.insert.phi.trans.insert, align 4, !invariant.load !3, !alias.scope !9, !noalias !6
  %.phi.trans.insert23.phi.trans.insert.phi.trans.insert = getelementptr inbounds nuw i8, ptr %6, i64 40
  %.pre24.pre.pre = load float, ptr %.phi.trans.insert23.phi.trans.insert.phi.trans.insert, align 4, !invariant.load !3, !alias.scope !9, !noalias !6
  %.phi.trans.insert25.phi.trans.insert.phi.trans.insert = getelementptr inbounds nuw i8, ptr %6, i64 44
  %.pre26.pre.pre = load float, ptr %.phi.trans.insert25.phi.trans.insert.phi.trans.insert, align 4, !invariant.load !3, !alias.scope !9, !noalias !6
  %.pre27.pre.pre = load float, ptr %6, align 4, !invariant.load !3, !alias.scope !9, !noalias !6
  %broadcast.splatinsert = insertelement <8 x float> poison, float %.pre27.pre.pre, i64 0
  %broadcast.splat = shufflevector <8 x float> %broadcast.splatinsert, <8 x float> poison, <8 x i32> zeroinitializer
  %broadcast.splatinsert29 = insertelement <8 x float> poison, float %.pre.pre.pre, i64 0
  %broadcast.splat30 = shufflevector <8 x float> %broadcast.splatinsert29, <8 x float> poison, <8 x i32> zeroinitializer
  %broadcast.splatinsert31 = insertelement <8 x float> poison, float %.pre8.pre.pre, i64 0
  %broadcast.splat32 = shufflevector <8 x float> %broadcast.splatinsert31, <8 x float> poison, <8 x i32> zeroinitializer
  %broadcast.splatinsert33 = insertelement <8 x float> poison, float %.pre10.pre.pre, i64 0
  %broadcast.splat34 = shufflevector <8 x float> %broadcast.splatinsert33, <8 x float> poison, <8 x i32> zeroinitializer
  %broadcast.splatinsert35 = insertelement <8 x float> poison, float %.pre12.pre.pre, i64 0
  %broadcast.splat36 = shufflevector <8 x float> %broadcast.splatinsert35, <8 x float> poison, <8 x i32> zeroinitializer
  %broadcast.splatinsert37 = insertelement <8 x float> poison, float %.pre14.pre.pre, i64 0
  %broadcast.splat38 = shufflevector <8 x float> %broadcast.splatinsert37, <8 x float> poison, <8 x i32> zeroinitializer
  %broadcast.splatinsert39 = insertelement <8 x float> poison, float %.pre16.pre.pre, i64 0
  %broadcast.splat40 = shufflevector <8 x float> %broadcast.splatinsert39, <8 x float> poison, <8 x i32> zeroinitializer
  %broadcast.splatinsert41 = insertelement <8 x float> poison, float %.pre18.pre.pre, i64 0
  %broadcast.splat42 = shufflevector <8 x float> %broadcast.splatinsert41, <8 x float> poison, <8 x i32> zeroinitializer
  %broadcast.splatinsert43 = insertelement <8 x float> poison, float %.pre20.pre.pre, i64 0
  %broadcast.splat44 = shufflevector <8 x float> %broadcast.splatinsert43, <8 x float> poison, <8 x i32> zeroinitializer
  %broadcast.splatinsert45 = insertelement <8 x float> poison, float %.pre22.pre.pre, i64 0
  %broadcast.splat46 = shufflevector <8 x float> %broadcast.splatinsert45, <8 x float> poison, <8 x i32> zeroinitializer
  %broadcast.splatinsert47 = insertelement <8 x float> poison, float %.pre24.pre.pre, i64 0
  %broadcast.splat48 = shufflevector <8 x float> %broadcast.splatinsert47, <8 x float> poison, <8 x i32> zeroinitializer
  %broadcast.splatinsert49 = insertelement <8 x float> poison, float %.pre26.pre.pre, i64 0
  %broadcast.splat50 = shufflevector <8 x float> %broadcast.splatinsert49, <8 x float> poison, <8 x i32> zeroinitializer
  br label %.preheader4

.preheader4:                                      ; preds = %1, %341
  %7 = phi i64 [ 0, %1 ], [ %342, %341 ]
  %.idx = mul nuw nsw i64 %7, 19200
  %8 = getelementptr i8, ptr %4, i64 %.idx
  br label %.preheader3

.preheader3:                                      ; preds = %.preheader4, %339
  %9 = phi i64 [ 0, %.preheader4 ], [ %340, %339 ]
  %.idx1 = mul nuw nsw i64 %9, 960
  %10 = getelementptr i8, ptr %8, i64 %.idx1
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %.preheader3
  %index = phi i64 [ 0, %.preheader3 ], [ %index.next, %vector.body ]
  %vec.ind = phi <8 x i64> [ <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>, %.preheader3 ], [ %vec.ind.next, %vector.body ]
  %11 = mul nuw nsw <8 x i64> %vec.ind, splat (i64 48)
  %12 = getelementptr i8, ptr %10, <8 x i64> %11
  %13 = extractelement <8 x ptr> %12, i64 0
  %14 = extractelement <8 x ptr> %12, i64 1
  %15 = extractelement <8 x ptr> %12, i64 2
  %16 = extractelement <8 x ptr> %12, i64 3
  %17 = extractelement <8 x ptr> %12, i64 4
  %18 = extractelement <8 x ptr> %12, i64 5
  %19 = extractelement <8 x ptr> %12, i64 6
  %20 = extractelement <8 x ptr> %12, i64 7
  %wide.masked.gather = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %12, <8 x i1> splat (i1 true), <8 x float> poison), !alias.scope !6, !noalias !9
  %21 = fadd <8 x float> %wide.masked.gather, %broadcast.splat
  %22 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %21, <8 x float> zeroinitializer)
  %23 = fmul <8 x float> %22, splat (float 7.500000e-01)
  %24 = fadd <8 x float> %23, splat (float 1.250000e-01)
  %25 = extractelement <8 x float> %24, i64 0
  %26 = extractelement <8 x float> %24, i64 1
  %27 = extractelement <8 x float> %24, i64 2
  %28 = extractelement <8 x float> %24, i64 3
  %29 = extractelement <8 x float> %24, i64 4
  %30 = extractelement <8 x float> %24, i64 5
  %31 = extractelement <8 x float> %24, i64 6
  %32 = extractelement <8 x float> %24, i64 7
  store float %25, ptr %13, align 4, !alias.scope !6, !noalias !9
  store float %26, ptr %14, align 4, !alias.scope !6, !noalias !9
  store float %27, ptr %15, align 4, !alias.scope !6, !noalias !9
  store float %28, ptr %16, align 4, !alias.scope !6, !noalias !9
  store float %29, ptr %17, align 4, !alias.scope !6, !noalias !9
  store float %30, ptr %18, align 4, !alias.scope !6, !noalias !9
  store float %31, ptr %19, align 4, !alias.scope !6, !noalias !9
  store float %32, ptr %20, align 4, !alias.scope !6, !noalias !9
  %33 = getelementptr i8, <8 x ptr> %12, i64 4
  %34 = extractelement <8 x ptr> %33, i64 0
  %35 = extractelement <8 x ptr> %33, i64 1
  %36 = extractelement <8 x ptr> %33, i64 2
  %37 = extractelement <8 x ptr> %33, i64 3
  %38 = extractelement <8 x ptr> %33, i64 4
  %39 = extractelement <8 x ptr> %33, i64 5
  %40 = extractelement <8 x ptr> %33, i64 6
  %41 = extractelement <8 x ptr> %33, i64 7
  %wide.masked.gather51 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %33, <8 x i1> splat (i1 true), <8 x float> poison), !alias.scope !6, !noalias !9
  %42 = fadd <8 x float> %wide.masked.gather51, %broadcast.splat30
  %43 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %42, <8 x float> zeroinitializer)
  %44 = fmul <8 x float> %43, splat (float 7.500000e-01)
  %45 = fadd <8 x float> %44, splat (float 1.250000e-01)
  %46 = extractelement <8 x float> %45, i64 0
  %47 = extractelement <8 x float> %45, i64 1
  %48 = extractelement <8 x float> %45, i64 2
  %49 = extractelement <8 x float> %45, i64 3
  %50 = extractelement <8 x float> %45, i64 4
  %51 = extractelement <8 x float> %45, i64 5
  %52 = extractelement <8 x float> %45, i64 6
  %53 = extractelement <8 x float> %45, i64 7
  store float %46, ptr %34, align 4, !alias.scope !6, !noalias !9
  store float %47, ptr %35, align 4, !alias.scope !6, !noalias !9
  store float %48, ptr %36, align 4, !alias.scope !6, !noalias !9
  store float %49, ptr %37, align 4, !alias.scope !6, !noalias !9
  store float %50, ptr %38, align 4, !alias.scope !6, !noalias !9
  store float %51, ptr %39, align 4, !alias.scope !6, !noalias !9
  store float %52, ptr %40, align 4, !alias.scope !6, !noalias !9
  store float %53, ptr %41, align 4, !alias.scope !6, !noalias !9
  %54 = getelementptr i8, <8 x ptr> %12, i64 8
  %55 = extractelement <8 x ptr> %54, i64 0
  %56 = extractelement <8 x ptr> %54, i64 1
  %57 = extractelement <8 x ptr> %54, i64 2
  %58 = extractelement <8 x ptr> %54, i64 3
  %59 = extractelement <8 x ptr> %54, i64 4
  %60 = extractelement <8 x ptr> %54, i64 5
  %61 = extractelement <8 x ptr> %54, i64 6
  %62 = extractelement <8 x ptr> %54, i64 7
  %wide.masked.gather52 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %54, <8 x i1> splat (i1 true), <8 x float> poison), !alias.scope !6, !noalias !9
  %63 = fadd <8 x float> %wide.masked.gather52, %broadcast.splat32
  %64 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %63, <8 x float> zeroinitializer)
  %65 = fmul <8 x float> %64, splat (float 7.500000e-01)
  %66 = fadd <8 x float> %65, splat (float 1.250000e-01)
  %67 = extractelement <8 x float> %66, i64 0
  %68 = extractelement <8 x float> %66, i64 1
  %69 = extractelement <8 x float> %66, i64 2
  %70 = extractelement <8 x float> %66, i64 3
  %71 = extractelement <8 x float> %66, i64 4
  %72 = extractelement <8 x float> %66, i64 5
  %73 = extractelement <8 x float> %66, i64 6
  %74 = extractelement <8 x float> %66, i64 7
  store float %67, ptr %55, align 4, !alias.scope !6, !noalias !9
  store float %68, ptr %56, align 4, !alias.scope !6, !noalias !9
  store float %69, ptr %57, align 4, !alias.scope !6, !noalias !9
  store float %70, ptr %58, align 4, !alias.scope !6, !noalias !9
  store float %71, ptr %59, align 4, !alias.scope !6, !noalias !9
  store float %72, ptr %60, align 4, !alias.scope !6, !noalias !9
  store float %73, ptr %61, align 4, !alias.scope !6, !noalias !9
  store float %74, ptr %62, align 4, !alias.scope !6, !noalias !9
  %75 = getelementptr i8, <8 x ptr> %12, i64 12
  %76 = extractelement <8 x ptr> %75, i64 0
  %77 = extractelement <8 x ptr> %75, i64 1
  %78 = extractelement <8 x ptr> %75, i64 2
  %79 = extractelement <8 x ptr> %75, i64 3
  %80 = extractelement <8 x ptr> %75, i64 4
  %81 = extractelement <8 x ptr> %75, i64 5
  %82 = extractelement <8 x ptr> %75, i64 6
  %83 = extractelement <8 x ptr> %75, i64 7
  %wide.masked.gather53 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %75, <8 x i1> splat (i1 true), <8 x float> poison), !alias.scope !6, !noalias !9
  %84 = fadd <8 x float> %wide.masked.gather53, %broadcast.splat34
  %85 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %84, <8 x float> zeroinitializer)
  %86 = fmul <8 x float> %85, splat (float 7.500000e-01)
  %87 = fadd <8 x float> %86, splat (float 1.250000e-01)
  %88 = extractelement <8 x float> %87, i64 0
  %89 = extractelement <8 x float> %87, i64 1
  %90 = extractelement <8 x float> %87, i64 2
  %91 = extractelement <8 x float> %87, i64 3
  %92 = extractelement <8 x float> %87, i64 4
  %93 = extractelement <8 x float> %87, i64 5
  %94 = extractelement <8 x float> %87, i64 6
  %95 = extractelement <8 x float> %87, i64 7
  store float %88, ptr %76, align 4, !alias.scope !6, !noalias !9
  store float %89, ptr %77, align 4, !alias.scope !6, !noalias !9
  store float %90, ptr %78, align 4, !alias.scope !6, !noalias !9
  store float %91, ptr %79, align 4, !alias.scope !6, !noalias !9
  store float %92, ptr %80, align 4, !alias.scope !6, !noalias !9
  store float %93, ptr %81, align 4, !alias.scope !6, !noalias !9
  store float %94, ptr %82, align 4, !alias.scope !6, !noalias !9
  store float %95, ptr %83, align 4, !alias.scope !6, !noalias !9
  %96 = getelementptr i8, <8 x ptr> %12, i64 16
  %97 = extractelement <8 x ptr> %96, i64 0
  %98 = extractelement <8 x ptr> %96, i64 1
  %99 = extractelement <8 x ptr> %96, i64 2
  %100 = extractelement <8 x ptr> %96, i64 3
  %101 = extractelement <8 x ptr> %96, i64 4
  %102 = extractelement <8 x ptr> %96, i64 5
  %103 = extractelement <8 x ptr> %96, i64 6
  %104 = extractelement <8 x ptr> %96, i64 7
  %wide.masked.gather54 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %96, <8 x i1> splat (i1 true), <8 x float> poison), !alias.scope !6, !noalias !9
  %105 = fadd <8 x float> %wide.masked.gather54, %broadcast.splat36
  %106 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %105, <8 x float> zeroinitializer)
  %107 = fmul <8 x float> %106, splat (float 7.500000e-01)
  %108 = fadd <8 x float> %107, splat (float 1.250000e-01)
  %109 = extractelement <8 x float> %108, i64 0
  %110 = extractelement <8 x float> %108, i64 1
  %111 = extractelement <8 x float> %108, i64 2
  %112 = extractelement <8 x float> %108, i64 3
  %113 = extractelement <8 x float> %108, i64 4
  %114 = extractelement <8 x float> %108, i64 5
  %115 = extractelement <8 x float> %108, i64 6
  %116 = extractelement <8 x float> %108, i64 7
  store float %109, ptr %97, align 4, !alias.scope !6, !noalias !9
  store float %110, ptr %98, align 4, !alias.scope !6, !noalias !9
  store float %111, ptr %99, align 4, !alias.scope !6, !noalias !9
  store float %112, ptr %100, align 4, !alias.scope !6, !noalias !9
  store float %113, ptr %101, align 4, !alias.scope !6, !noalias !9
  store float %114, ptr %102, align 4, !alias.scope !6, !noalias !9
  store float %115, ptr %103, align 4, !alias.scope !6, !noalias !9
  store float %116, ptr %104, align 4, !alias.scope !6, !noalias !9
  %117 = getelementptr i8, <8 x ptr> %12, i64 20
  %118 = extractelement <8 x ptr> %117, i64 0
  %119 = extractelement <8 x ptr> %117, i64 1
  %120 = extractelement <8 x ptr> %117, i64 2
  %121 = extractelement <8 x ptr> %117, i64 3
  %122 = extractelement <8 x ptr> %117, i64 4
  %123 = extractelement <8 x ptr> %117, i64 5
  %124 = extractelement <8 x ptr> %117, i64 6
  %125 = extractelement <8 x ptr> %117, i64 7
  %wide.masked.gather55 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %117, <8 x i1> splat (i1 true), <8 x float> poison), !alias.scope !6, !noalias !9
  %126 = fadd <8 x float> %wide.masked.gather55, %broadcast.splat38
  %127 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %126, <8 x float> zeroinitializer)
  %128 = fmul <8 x float> %127, splat (float 7.500000e-01)
  %129 = fadd <8 x float> %128, splat (float 1.250000e-01)
  %130 = extractelement <8 x float> %129, i64 0
  %131 = extractelement <8 x float> %129, i64 1
  %132 = extractelement <8 x float> %129, i64 2
  %133 = extractelement <8 x float> %129, i64 3
  %134 = extractelement <8 x float> %129, i64 4
  %135 = extractelement <8 x float> %129, i64 5
  %136 = extractelement <8 x float> %129, i64 6
  %137 = extractelement <8 x float> %129, i64 7
  store float %130, ptr %118, align 4, !alias.scope !6, !noalias !9
  store float %131, ptr %119, align 4, !alias.scope !6, !noalias !9
  store float %132, ptr %120, align 4, !alias.scope !6, !noalias !9
  store float %133, ptr %121, align 4, !alias.scope !6, !noalias !9
  store float %134, ptr %122, align 4, !alias.scope !6, !noalias !9
  store float %135, ptr %123, align 4, !alias.scope !6, !noalias !9
  store float %136, ptr %124, align 4, !alias.scope !6, !noalias !9
  store float %137, ptr %125, align 4, !alias.scope !6, !noalias !9
  %138 = getelementptr i8, <8 x ptr> %12, i64 24
  %139 = extractelement <8 x ptr> %138, i64 0
  %140 = extractelement <8 x ptr> %138, i64 1
  %141 = extractelement <8 x ptr> %138, i64 2
  %142 = extractelement <8 x ptr> %138, i64 3
  %143 = extractelement <8 x ptr> %138, i64 4
  %144 = extractelement <8 x ptr> %138, i64 5
  %145 = extractelement <8 x ptr> %138, i64 6
  %146 = extractelement <8 x ptr> %138, i64 7
  %wide.masked.gather56 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %138, <8 x i1> splat (i1 true), <8 x float> poison), !alias.scope !6, !noalias !9
  %147 = fadd <8 x float> %wide.masked.gather56, %broadcast.splat40
  %148 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %147, <8 x float> zeroinitializer)
  %149 = fmul <8 x float> %148, splat (float 7.500000e-01)
  %150 = fadd <8 x float> %149, splat (float 1.250000e-01)
  %151 = extractelement <8 x float> %150, i64 0
  %152 = extractelement <8 x float> %150, i64 1
  %153 = extractelement <8 x float> %150, i64 2
  %154 = extractelement <8 x float> %150, i64 3
  %155 = extractelement <8 x float> %150, i64 4
  %156 = extractelement <8 x float> %150, i64 5
  %157 = extractelement <8 x float> %150, i64 6
  %158 = extractelement <8 x float> %150, i64 7
  store float %151, ptr %139, align 4, !alias.scope !6, !noalias !9
  store float %152, ptr %140, align 4, !alias.scope !6, !noalias !9
  store float %153, ptr %141, align 4, !alias.scope !6, !noalias !9
  store float %154, ptr %142, align 4, !alias.scope !6, !noalias !9
  store float %155, ptr %143, align 4, !alias.scope !6, !noalias !9
  store float %156, ptr %144, align 4, !alias.scope !6, !noalias !9
  store float %157, ptr %145, align 4, !alias.scope !6, !noalias !9
  store float %158, ptr %146, align 4, !alias.scope !6, !noalias !9
  %159 = getelementptr i8, <8 x ptr> %12, i64 28
  %160 = extractelement <8 x ptr> %159, i64 0
  %161 = extractelement <8 x ptr> %159, i64 1
  %162 = extractelement <8 x ptr> %159, i64 2
  %163 = extractelement <8 x ptr> %159, i64 3
  %164 = extractelement <8 x ptr> %159, i64 4
  %165 = extractelement <8 x ptr> %159, i64 5
  %166 = extractelement <8 x ptr> %159, i64 6
  %167 = extractelement <8 x ptr> %159, i64 7
  %wide.masked.gather57 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %159, <8 x i1> splat (i1 true), <8 x float> poison), !alias.scope !6, !noalias !9
  %168 = fadd <8 x float> %wide.masked.gather57, %broadcast.splat42
  %169 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %168, <8 x float> zeroinitializer)
  %170 = fmul <8 x float> %169, splat (float 7.500000e-01)
  %171 = fadd <8 x float> %170, splat (float 1.250000e-01)
  %172 = extractelement <8 x float> %171, i64 0
  %173 = extractelement <8 x float> %171, i64 1
  %174 = extractelement <8 x float> %171, i64 2
  %175 = extractelement <8 x float> %171, i64 3
  %176 = extractelement <8 x float> %171, i64 4
  %177 = extractelement <8 x float> %171, i64 5
  %178 = extractelement <8 x float> %171, i64 6
  %179 = extractelement <8 x float> %171, i64 7
  store float %172, ptr %160, align 4, !alias.scope !6, !noalias !9
  store float %173, ptr %161, align 4, !alias.scope !6, !noalias !9
  store float %174, ptr %162, align 4, !alias.scope !6, !noalias !9
  store float %175, ptr %163, align 4, !alias.scope !6, !noalias !9
  store float %176, ptr %164, align 4, !alias.scope !6, !noalias !9
  store float %177, ptr %165, align 4, !alias.scope !6, !noalias !9
  store float %178, ptr %166, align 4, !alias.scope !6, !noalias !9
  store float %179, ptr %167, align 4, !alias.scope !6, !noalias !9
  %180 = getelementptr i8, <8 x ptr> %12, i64 32
  %181 = extractelement <8 x ptr> %180, i64 0
  %182 = extractelement <8 x ptr> %180, i64 1
  %183 = extractelement <8 x ptr> %180, i64 2
  %184 = extractelement <8 x ptr> %180, i64 3
  %185 = extractelement <8 x ptr> %180, i64 4
  %186 = extractelement <8 x ptr> %180, i64 5
  %187 = extractelement <8 x ptr> %180, i64 6
  %188 = extractelement <8 x ptr> %180, i64 7
  %wide.masked.gather58 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %180, <8 x i1> splat (i1 true), <8 x float> poison), !alias.scope !6, !noalias !9
  %189 = fadd <8 x float> %wide.masked.gather58, %broadcast.splat44
  %190 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %189, <8 x float> zeroinitializer)
  %191 = fmul <8 x float> %190, splat (float 7.500000e-01)
  %192 = fadd <8 x float> %191, splat (float 1.250000e-01)
  %193 = extractelement <8 x float> %192, i64 0
  %194 = extractelement <8 x float> %192, i64 1
  %195 = extractelement <8 x float> %192, i64 2
  %196 = extractelement <8 x float> %192, i64 3
  %197 = extractelement <8 x float> %192, i64 4
  %198 = extractelement <8 x float> %192, i64 5
  %199 = extractelement <8 x float> %192, i64 6
  %200 = extractelement <8 x float> %192, i64 7
  store float %193, ptr %181, align 4, !alias.scope !6, !noalias !9
  store float %194, ptr %182, align 4, !alias.scope !6, !noalias !9
  store float %195, ptr %183, align 4, !alias.scope !6, !noalias !9
  store float %196, ptr %184, align 4, !alias.scope !6, !noalias !9
  store float %197, ptr %185, align 4, !alias.scope !6, !noalias !9
  store float %198, ptr %186, align 4, !alias.scope !6, !noalias !9
  store float %199, ptr %187, align 4, !alias.scope !6, !noalias !9
  store float %200, ptr %188, align 4, !alias.scope !6, !noalias !9
  %201 = getelementptr i8, <8 x ptr> %12, i64 36
  %202 = extractelement <8 x ptr> %201, i64 0
  %203 = extractelement <8 x ptr> %201, i64 1
  %204 = extractelement <8 x ptr> %201, i64 2
  %205 = extractelement <8 x ptr> %201, i64 3
  %206 = extractelement <8 x ptr> %201, i64 4
  %207 = extractelement <8 x ptr> %201, i64 5
  %208 = extractelement <8 x ptr> %201, i64 6
  %209 = extractelement <8 x ptr> %201, i64 7
  %wide.masked.gather59 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %201, <8 x i1> splat (i1 true), <8 x float> poison), !alias.scope !6, !noalias !9
  %210 = fadd <8 x float> %wide.masked.gather59, %broadcast.splat46
  %211 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %210, <8 x float> zeroinitializer)
  %212 = fmul <8 x float> %211, splat (float 7.500000e-01)
  %213 = fadd <8 x float> %212, splat (float 1.250000e-01)
  %214 = extractelement <8 x float> %213, i64 0
  %215 = extractelement <8 x float> %213, i64 1
  %216 = extractelement <8 x float> %213, i64 2
  %217 = extractelement <8 x float> %213, i64 3
  %218 = extractelement <8 x float> %213, i64 4
  %219 = extractelement <8 x float> %213, i64 5
  %220 = extractelement <8 x float> %213, i64 6
  %221 = extractelement <8 x float> %213, i64 7
  store float %214, ptr %202, align 4, !alias.scope !6, !noalias !9
  store float %215, ptr %203, align 4, !alias.scope !6, !noalias !9
  store float %216, ptr %204, align 4, !alias.scope !6, !noalias !9
  store float %217, ptr %205, align 4, !alias.scope !6, !noalias !9
  store float %218, ptr %206, align 4, !alias.scope !6, !noalias !9
  store float %219, ptr %207, align 4, !alias.scope !6, !noalias !9
  store float %220, ptr %208, align 4, !alias.scope !6, !noalias !9
  store float %221, ptr %209, align 4, !alias.scope !6, !noalias !9
  %222 = getelementptr i8, <8 x ptr> %12, i64 40
  %223 = extractelement <8 x ptr> %222, i64 0
  %224 = extractelement <8 x ptr> %222, i64 1
  %225 = extractelement <8 x ptr> %222, i64 2
  %226 = extractelement <8 x ptr> %222, i64 3
  %227 = extractelement <8 x ptr> %222, i64 4
  %228 = extractelement <8 x ptr> %222, i64 5
  %229 = extractelement <8 x ptr> %222, i64 6
  %230 = extractelement <8 x ptr> %222, i64 7
  %wide.masked.gather60 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %222, <8 x i1> splat (i1 true), <8 x float> poison), !alias.scope !6, !noalias !9
  %231 = fadd <8 x float> %wide.masked.gather60, %broadcast.splat48
  %232 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %231, <8 x float> zeroinitializer)
  %233 = fmul <8 x float> %232, splat (float 7.500000e-01)
  %234 = fadd <8 x float> %233, splat (float 1.250000e-01)
  %235 = extractelement <8 x float> %234, i64 0
  %236 = extractelement <8 x float> %234, i64 1
  %237 = extractelement <8 x float> %234, i64 2
  %238 = extractelement <8 x float> %234, i64 3
  %239 = extractelement <8 x float> %234, i64 4
  %240 = extractelement <8 x float> %234, i64 5
  %241 = extractelement <8 x float> %234, i64 6
  %242 = extractelement <8 x float> %234, i64 7
  store float %235, ptr %223, align 4, !alias.scope !6, !noalias !9
  store float %236, ptr %224, align 4, !alias.scope !6, !noalias !9
  store float %237, ptr %225, align 4, !alias.scope !6, !noalias !9
  store float %238, ptr %226, align 4, !alias.scope !6, !noalias !9
  store float %239, ptr %227, align 4, !alias.scope !6, !noalias !9
  store float %240, ptr %228, align 4, !alias.scope !6, !noalias !9
  store float %241, ptr %229, align 4, !alias.scope !6, !noalias !9
  store float %242, ptr %230, align 4, !alias.scope !6, !noalias !9
  %243 = getelementptr i8, <8 x ptr> %12, i64 44
  %244 = extractelement <8 x ptr> %243, i64 0
  %245 = extractelement <8 x ptr> %243, i64 1
  %246 = extractelement <8 x ptr> %243, i64 2
  %247 = extractelement <8 x ptr> %243, i64 3
  %248 = extractelement <8 x ptr> %243, i64 4
  %249 = extractelement <8 x ptr> %243, i64 5
  %250 = extractelement <8 x ptr> %243, i64 6
  %251 = extractelement <8 x ptr> %243, i64 7
  %wide.masked.gather61 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %243, <8 x i1> splat (i1 true), <8 x float> poison), !alias.scope !6, !noalias !9
  %252 = fadd <8 x float> %wide.masked.gather61, %broadcast.splat50
  %253 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %252, <8 x float> zeroinitializer)
  %254 = fmul <8 x float> %253, splat (float 7.500000e-01)
  %255 = fadd <8 x float> %254, splat (float 1.250000e-01)
  %256 = extractelement <8 x float> %255, i64 0
  %257 = extractelement <8 x float> %255, i64 1
  %258 = extractelement <8 x float> %255, i64 2
  %259 = extractelement <8 x float> %255, i64 3
  %260 = extractelement <8 x float> %255, i64 4
  %261 = extractelement <8 x float> %255, i64 5
  %262 = extractelement <8 x float> %255, i64 6
  %263 = extractelement <8 x float> %255, i64 7
  store float %256, ptr %244, align 4, !alias.scope !6, !noalias !9
  store float %257, ptr %245, align 4, !alias.scope !6, !noalias !9
  store float %258, ptr %246, align 4, !alias.scope !6, !noalias !9
  store float %259, ptr %247, align 4, !alias.scope !6, !noalias !9
  store float %260, ptr %248, align 4, !alias.scope !6, !noalias !9
  store float %261, ptr %249, align 4, !alias.scope !6, !noalias !9
  store float %262, ptr %250, align 4, !alias.scope !6, !noalias !9
  store float %263, ptr %251, align 4, !alias.scope !6, !noalias !9
  %index.next = add nuw i64 %index, 8
  %vec.ind.next = add nuw nsw <8 x i64> %vec.ind, splat (i64 8)
  %264 = icmp eq i64 %index.next, 16
  br i1 %264, label %.preheader, label %vector.body, !llvm.loop !11

.preheader:                                       ; preds = %vector.body, %.preheader
  %265 = phi i64 [ %338, %.preheader ], [ 16, %vector.body ]
  %.idx2 = mul nuw nsw i64 %265, 48
  %266 = getelementptr i8, ptr %10, i64 %.idx2
  %267 = load float, ptr %266, align 4, !alias.scope !6, !noalias !9
  %268 = fadd float %267, %.pre27.pre.pre
  %269 = tail call float @llvm.maximum.f32(float %268, float 0.000000e+00)
  %270 = fmul float %269, 7.500000e-01
  %271 = fadd float %270, 1.250000e-01
  store float %271, ptr %266, align 4, !alias.scope !6, !noalias !9
  %272 = getelementptr i8, ptr %266, i64 4
  %273 = load float, ptr %272, align 4, !alias.scope !6, !noalias !9
  %274 = fadd float %273, %.pre.pre.pre
  %275 = tail call float @llvm.maximum.f32(float %274, float 0.000000e+00)
  %276 = fmul float %275, 7.500000e-01
  %277 = fadd float %276, 1.250000e-01
  store float %277, ptr %272, align 4, !alias.scope !6, !noalias !9
  %278 = getelementptr i8, ptr %266, i64 8
  %279 = load float, ptr %278, align 4, !alias.scope !6, !noalias !9
  %280 = fadd float %279, %.pre8.pre.pre
  %281 = tail call float @llvm.maximum.f32(float %280, float 0.000000e+00)
  %282 = fmul float %281, 7.500000e-01
  %283 = fadd float %282, 1.250000e-01
  store float %283, ptr %278, align 4, !alias.scope !6, !noalias !9
  %284 = getelementptr i8, ptr %266, i64 12
  %285 = load float, ptr %284, align 4, !alias.scope !6, !noalias !9
  %286 = fadd float %285, %.pre10.pre.pre
  %287 = tail call float @llvm.maximum.f32(float %286, float 0.000000e+00)
  %288 = fmul float %287, 7.500000e-01
  %289 = fadd float %288, 1.250000e-01
  store float %289, ptr %284, align 4, !alias.scope !6, !noalias !9
  %290 = getelementptr i8, ptr %266, i64 16
  %291 = load float, ptr %290, align 4, !alias.scope !6, !noalias !9
  %292 = fadd float %291, %.pre12.pre.pre
  %293 = tail call float @llvm.maximum.f32(float %292, float 0.000000e+00)
  %294 = fmul float %293, 7.500000e-01
  %295 = fadd float %294, 1.250000e-01
  store float %295, ptr %290, align 4, !alias.scope !6, !noalias !9
  %296 = getelementptr i8, ptr %266, i64 20
  %297 = load float, ptr %296, align 4, !alias.scope !6, !noalias !9
  %298 = fadd float %297, %.pre14.pre.pre
  %299 = tail call float @llvm.maximum.f32(float %298, float 0.000000e+00)
  %300 = fmul float %299, 7.500000e-01
  %301 = fadd float %300, 1.250000e-01
  store float %301, ptr %296, align 4, !alias.scope !6, !noalias !9
  %302 = getelementptr i8, ptr %266, i64 24
  %303 = load float, ptr %302, align 4, !alias.scope !6, !noalias !9
  %304 = fadd float %303, %.pre16.pre.pre
  %305 = tail call float @llvm.maximum.f32(float %304, float 0.000000e+00)
  %306 = fmul float %305, 7.500000e-01
  %307 = fadd float %306, 1.250000e-01
  store float %307, ptr %302, align 4, !alias.scope !6, !noalias !9
  %308 = getelementptr i8, ptr %266, i64 28
  %309 = load float, ptr %308, align 4, !alias.scope !6, !noalias !9
  %310 = fadd float %309, %.pre18.pre.pre
  %311 = tail call float @llvm.maximum.f32(float %310, float 0.000000e+00)
  %312 = fmul float %311, 7.500000e-01
  %313 = fadd float %312, 1.250000e-01
  store float %313, ptr %308, align 4, !alias.scope !6, !noalias !9
  %314 = getelementptr i8, ptr %266, i64 32
  %315 = load float, ptr %314, align 4, !alias.scope !6, !noalias !9
  %316 = fadd float %315, %.pre20.pre.pre
  %317 = tail call float @llvm.maximum.f32(float %316, float 0.000000e+00)
  %318 = fmul float %317, 7.500000e-01
  %319 = fadd float %318, 1.250000e-01
  store float %319, ptr %314, align 4, !alias.scope !6, !noalias !9
  %320 = getelementptr i8, ptr %266, i64 36
  %321 = load float, ptr %320, align 4, !alias.scope !6, !noalias !9
  %322 = fadd float %321, %.pre22.pre.pre
  %323 = tail call float @llvm.maximum.f32(float %322, float 0.000000e+00)
  %324 = fmul float %323, 7.500000e-01
  %325 = fadd float %324, 1.250000e-01
  store float %325, ptr %320, align 4, !alias.scope !6, !noalias !9
  %326 = getelementptr i8, ptr %266, i64 40
  %327 = load float, ptr %326, align 4, !alias.scope !6, !noalias !9
  %328 = fadd float %327, %.pre24.pre.pre
  %329 = tail call float @llvm.maximum.f32(float %328, float 0.000000e+00)
  %330 = fmul float %329, 7.500000e-01
  %331 = fadd float %330, 1.250000e-01
  store float %331, ptr %326, align 4, !alias.scope !6, !noalias !9
  %332 = getelementptr i8, ptr %266, i64 44
  %333 = load float, ptr %332, align 4, !alias.scope !6, !noalias !9
  %334 = fadd float %333, %.pre26.pre.pre
  %335 = tail call float @llvm.maximum.f32(float %334, float 0.000000e+00)
  %336 = fmul float %335, 7.500000e-01
  %337 = fadd float %336, 1.250000e-01
  store float %337, ptr %332, align 4, !alias.scope !6, !noalias !9
  %338 = add nuw nsw i64 %265, 1
  %exitcond.not = icmp eq i64 %338, 20
  br i1 %exitcond.not, label %339, label %.preheader, !llvm.loop !15

339:                                              ; preds = %.preheader
  %340 = add nuw nsw i64 %9, 1
  %exitcond5.not = icmp eq i64 %340, 20
  br i1 %exitcond5.not, label %341, label %.preheader3, !llvm.loop !16

341:                                              ; preds = %339
  %342 = add nuw nsw i64 %7, 1
  %exitcond6.not = icmp eq i64 %342, 3
  br i1 %exitcond6.not, label %broadcast_add_fusion_wrapped.exit, label %.preheader4, !llvm.loop !16

broadcast_add_fusion_wrapped.exit:                ; preds = %341
  ret ptr null
}

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.maximum.f32(float, float) #1

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #2

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr>, <8 x i1>, <8 x float>) #3

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.maximum.v8f32(<8 x float>, <8 x float>) #4

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #4 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 0}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 57600}
!5 = !{i64 48}
!6 = !{!7}
!7 = distinct !{!7, !8, !"broadcast_add_fusion_wrapped: argument 0"}
!8 = distinct !{!8, !"broadcast_add_fusion_wrapped"}
!9 = !{!10}
!10 = distinct !{!10, !8, !"broadcast_add_fusion_wrapped: argument 1"}
!11 = distinct !{!11, !12, !13, !14}
!12 = !{!"llvm.loop.unroll.disable"}
!13 = !{!"llvm.loop.isvectorized", i32 1}
!14 = !{!"llvm.loop.unroll.runtime.disable"}
!15 = distinct !{!15, !12, !13}
!16 = distinct !{!16, !12}
