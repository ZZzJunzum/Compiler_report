; ModuleID = '__compute_module_convert_reduce_fusion_kernel_module'
source_filename = "__compute_module_convert_reduce_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

%XLA_CPU_KernelCallFrame = type { ptr, ptr, i64, ptr }
%XLA_CPU_KernelArg = type { ptr, i64 }
%kernel_dim3 = type { i64, i64, i64 }

; Function Attrs: uwtable
define ptr @convert_reduce_fusion(ptr %0) #0 {
  %2 = getelementptr inbounds %XLA_CPU_KernelCallFrame, ptr %0, i32 0, i32 3
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 0, i32 0
  %5 = load ptr, ptr %4, align 8, !invariant.load !3, !dereferenceable !4
  %6 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 1, i32 0
  %7 = load ptr, ptr %6, align 8, !invariant.load !3, !dereferenceable !4
  %8 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 2, i32 0
  %9 = load ptr, ptr %8, align 8, !invariant.load !3, !dereferenceable !4
  %10 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 3, i32 0
  %11 = load ptr, ptr %10, align 8, !invariant.load !3, !dereferenceable !5
  %12 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 4, i32 0
  %13 = load ptr, ptr %12, align 8, !invariant.load !3, !dereferenceable !4
  %14 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 5, i32 0
  %15 = load ptr, ptr %14, align 8, !invariant.load !3, !dereferenceable !6
  %16 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 6, i32 0
  %17 = load ptr, ptr %16, align 8, !invariant.load !3, !dereferenceable !6
  %18 = getelementptr inbounds %XLA_CPU_KernelCallFrame, ptr %0, i32 0, i32 1
  %19 = load ptr, ptr %18, align 8
  %20 = getelementptr inbounds %kernel_dim3, ptr %19, i32 0, i32 0
  %21 = load i64, ptr %20, align 4, !invariant.load !3
  %22 = getelementptr inbounds %kernel_dim3, ptr %19, i32 0, i32 1
  %23 = load i64, ptr %22, align 4, !invariant.load !3
  %24 = getelementptr inbounds %kernel_dim3, ptr %19, i32 0, i32 2
  %25 = load i64, ptr %24, align 4, !invariant.load !3
  call void @convert_reduce_fusion_wrapped(ptr %5, ptr %7, ptr %9, ptr %11, ptr %13, ptr %15, ptr %17, i64 %21, i64 %23, i64 %25)
  ret ptr null
}

; Function Attrs: alwaysinline
define internal void @convert_reduce_fusion_wrapped(ptr noalias align 64 dereferenceable(640) %0, ptr noalias align 64 dereferenceable(640) %1, ptr noalias align 64 dereferenceable(640) %2, ptr noalias align 64 dereferenceable(184320) %3, ptr noalias align 64 dereferenceable(640) %4, ptr noalias align 64 dereferenceable(1152) %5, ptr noalias align 64 dereferenceable(1152) %6, i64 %7, i64 %8, i64 %9) #1 {
  %11 = icmp sge i64 %7, 0
  %12 = icmp sle i64 %7, 11
  %13 = and i1 %11, %12
  br i1 %13, label %14, label %58

14:                                               ; preds = %10
  %15 = mul nsw i64 %7, 24
  %16 = mul nsw i64 %7, 3840
  br label %17

17:                                               ; preds = %53, %14
  %18 = phi i64 [ %56, %53 ], [ 0, %14 ]
  %19 = icmp slt i64 %18, 24
  br i1 %19, label %20, label %57

20:                                               ; preds = %17
  %21 = add nsw i64 %15, %18
  %22 = mul nsw i64 %18, 160
  %23 = add nsw i64 %16, %22
  br label %24

24:                                               ; preds = %29, %20
  %25 = phi i64 [ %52, %29 ], [ 0, %20 ]
  %26 = phi i32 [ %50, %29 ], [ 0, %20 ]
  %27 = phi i32 [ %51, %29 ], [ 0, %20 ]
  %28 = icmp slt i64 %25, 160
  br i1 %28, label %29, label %53

29:                                               ; preds = %24
  %30 = add nsw i64 %23, %25
  %31 = getelementptr inbounds [46080 x float], ptr %3, i32 0, i64 %30
  %32 = load float, ptr %31, align 4, !invariant.load !3
  %33 = getelementptr inbounds [160 x float], ptr %4, i32 0, i64 %25
  %34 = load float, ptr %33, align 4, !invariant.load !3
  %35 = fmul float %32, %34
  %36 = getelementptr inbounds [160 x float], ptr %2, i32 0, i64 %25
  %37 = load float, ptr %36, align 4, !invariant.load !3
  %38 = fadd float %35, %37
  %39 = fcmp ogt float %38, 0.000000e+00
  %40 = zext i1 %39 to i32
  %41 = call float @llvm.maximum.f32(float %38, float 0.000000e+00)
  %42 = getelementptr inbounds [160 x float], ptr %1, i32 0, i64 %25
  %43 = load float, ptr %42, align 4, !invariant.load !3
  %44 = fmul float %41, %43
  %45 = getelementptr inbounds [160 x float], ptr %0, i32 0, i64 %25
  %46 = load float, ptr %45, align 4, !invariant.load !3
  %47 = fadd float %44, %46
  %48 = fcmp ogt float %47, 0.000000e+00
  %49 = zext i1 %48 to i32
  %50 = add i32 %26, %40
  %51 = add i32 %27, %49
  %52 = add i64 %25, 1
  br label %24

53:                                               ; preds = %24
  %54 = getelementptr inbounds [288 x i32], ptr %5, i32 0, i64 %21
  store i32 %26, ptr %54, align 4
  %55 = getelementptr inbounds [288 x i32], ptr %6, i32 0, i64 %21
  store i32 %27, ptr %55, align 4
  %56 = add i64 %18, 1
  br label %17, !llvm.loop !7

57:                                               ; preds = %17
  br label %58

58:                                               ; preds = %57, %10
  ret void
}

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.maximum.f32(float, float) #2

attributes #0 = { uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { alwaysinline }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 0}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 640}
!5 = !{i64 184320}
!6 = !{i64 1152}
!7 = distinct !{!7, !8}
!8 = !{!"llvm.loop.unroll.disable"}
