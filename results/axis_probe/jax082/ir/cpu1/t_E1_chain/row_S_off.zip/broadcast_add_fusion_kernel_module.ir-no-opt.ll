; ModuleID = '__compute_module_broadcast_add_fusion_kernel_module'
source_filename = "__compute_module_broadcast_add_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

%XLA_CPU_KernelCallFrame = type { ptr, ptr, i64, ptr }
%XLA_CPU_KernelArg = type { ptr, i64 }
%kernel_dim3 = type { i64, i64, i64 }

; Function Attrs: uwtable
define ptr @broadcast_add_fusion(ptr %0) #0 {
  %2 = getelementptr inbounds %XLA_CPU_KernelCallFrame, ptr %0, i32 0, i32 3
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 0, i32 0
  %5 = load ptr, ptr %4, align 8, !invariant.load !3, !dereferenceable !4
  %6 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 1, i32 0
  %7 = load ptr, ptr %6, align 8, !invariant.load !3, !dereferenceable !4
  %8 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 2, i32 0
  %9 = load ptr, ptr %8, align 8, !invariant.load !3, !dereferenceable !4
  %10 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 3, i32 0
  %11 = load ptr, ptr %10, align 8, !invariant.load !3, !dereferenceable !4
  %12 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 4, i32 0
  %13 = load ptr, ptr %12, align 8, !invariant.load !3, !dereferenceable !4
  %14 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 5, i32 0
  %15 = load ptr, ptr %14, align 8, !invariant.load !3, !dereferenceable !5
  %16 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 6, i32 0
  %17 = load ptr, ptr %16, align 8, !invariant.load !3, !dereferenceable !4
  %18 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 7, i32 0
  %19 = load ptr, ptr %18, align 8, !invariant.load !3, !dereferenceable !5
  %20 = getelementptr inbounds %XLA_CPU_KernelCallFrame, ptr %0, i32 0, i32 1
  %21 = load ptr, ptr %20, align 8
  %22 = getelementptr inbounds %kernel_dim3, ptr %21, i32 0, i32 0
  %23 = load i64, ptr %22, align 4, !invariant.load !3
  %24 = getelementptr inbounds %kernel_dim3, ptr %21, i32 0, i32 1
  %25 = load i64, ptr %24, align 4, !invariant.load !3
  %26 = getelementptr inbounds %kernel_dim3, ptr %21, i32 0, i32 2
  %27 = load i64, ptr %26, align 4, !invariant.load !3
  call void @broadcast_add_fusion_wrapped(ptr %5, ptr %7, ptr %9, ptr %11, ptr %13, ptr %15, ptr %17, ptr %19, i64 %23, i64 %25, i64 %27)
  ret ptr null
}

; Function Attrs: alwaysinline
define internal void @broadcast_add_fusion_wrapped(ptr noalias align 64 dereferenceable(640) %0, ptr noalias align 64 dereferenceable(640) %1, ptr noalias align 64 dereferenceable(640) %2, ptr noalias align 64 dereferenceable(640) %3, ptr noalias align 64 dereferenceable(640) %4, ptr noalias align 64 dereferenceable(204800) %5, ptr noalias align 64 dereferenceable(640) %6, ptr noalias align 64 dereferenceable(204800) %7, i64 %8, i64 %9, i64 %10) #1 {
  br label %12

12:                                               ; preds = %49, %11
  %13 = phi i64 [ %50, %49 ], [ 0, %11 ]
  %14 = icmp slt i64 %13, 320
  br i1 %14, label %15, label %51

15:                                               ; preds = %12
  %16 = mul nsw i64 %13, 160
  br label %17

17:                                               ; preds = %20, %15
  %18 = phi i64 [ %48, %20 ], [ 0, %15 ]
  %19 = icmp slt i64 %18, 160
  br i1 %19, label %20, label %49

20:                                               ; preds = %17
  %21 = add nsw i64 %16, %18
  %22 = getelementptr inbounds [51200 x float], ptr %5, i32 0, i64 %21
  %23 = load float, ptr %22, align 4, !invariant.load !3
  %24 = getelementptr inbounds [160 x float], ptr %6, i32 0, i64 %18
  %25 = load float, ptr %24, align 4, !invariant.load !3
  %26 = fmul float %23, %25
  %27 = getelementptr inbounds [160 x float], ptr %4, i32 0, i64 %18
  %28 = load float, ptr %27, align 4, !invariant.load !3
  %29 = fadd float %26, %28
  %30 = call float @llvm.maximum.f32(float %29, float 0.000000e+00)
  %31 = getelementptr inbounds [160 x float], ptr %3, i32 0, i64 %18
  %32 = load float, ptr %31, align 4, !invariant.load !3
  %33 = fmul float %30, %32
  %34 = getelementptr inbounds [160 x float], ptr %2, i32 0, i64 %18
  %35 = load float, ptr %34, align 4, !invariant.load !3
  %36 = fadd float %33, %35
  %37 = call float @llvm.maximum.f32(float %36, float 0.000000e+00)
  %38 = getelementptr inbounds [160 x float], ptr %1, i32 0, i64 %18
  %39 = load float, ptr %38, align 4, !invariant.load !3
  %40 = fmul float %37, %39
  %41 = getelementptr inbounds [160 x float], ptr %0, i32 0, i64 %18
  %42 = load float, ptr %41, align 4, !invariant.load !3
  %43 = fadd float %40, %42
  %44 = call float @llvm.maximum.f32(float %43, float 0.000000e+00)
  %45 = fmul float %44, 7.500000e-01
  %46 = fadd float %45, 1.250000e-01
  %47 = getelementptr inbounds [51200 x float], ptr %7, i32 0, i64 %21
  store float %46, ptr %47, align 4
  %48 = add i64 %18, 1
  br label %17

49:                                               ; preds = %17
  %50 = add i64 %13, 1
  br label %12, !llvm.loop !6

51:                                               ; preds = %12
  ret void
}

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.maximum.f32(float, float) #2

attributes #0 = { uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { alwaysinline }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 0}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 640}
!5 = !{i64 204800}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.unroll.disable"}
