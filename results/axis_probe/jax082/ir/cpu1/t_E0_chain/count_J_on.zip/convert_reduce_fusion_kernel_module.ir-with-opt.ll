; ModuleID = '__compute_module_convert_reduce_fusion_kernel_module'
source_filename = "__compute_module_convert_reduce_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @convert_reduce_fusion(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !4
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !4
  %9 = getelementptr inbounds nuw i8, ptr %3, i64 48
  %10 = load ptr, ptr %9, align 8, !invariant.load !3, !dereferenceable !5
  %11 = getelementptr inbounds nuw i8, ptr %3, i64 64
  %12 = load ptr, ptr %11, align 8, !invariant.load !3, !dereferenceable !4
  tail call void @llvm.experimental.noalias.scope.decl(metadata !6)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !11)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !13)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !15)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !17)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !19)
  %13 = getelementptr inbounds nuw i8, ptr %12, i64 32
  %wide.load12 = load <8 x float>, ptr %12, align 4, !invariant.load !3, !alias.scope !15, !noalias !21
  %wide.load13 = load <8 x float>, ptr %13, align 4, !invariant.load !3, !alias.scope !15, !noalias !21
  %14 = getelementptr inbounds nuw i8, ptr %8, i64 32
  %wide.load14 = load <8 x float>, ptr %8, align 4, !invariant.load !3, !alias.scope !11, !noalias !22
  %wide.load15 = load <8 x float>, ptr %14, align 4, !invariant.load !3, !alias.scope !11, !noalias !22
  %15 = getelementptr inbounds nuw i8, ptr %6, i64 32
  %wide.load16 = load <8 x float>, ptr %6, align 4, !invariant.load !3, !alias.scope !9, !noalias !23
  %wide.load17 = load <8 x float>, ptr %15, align 4, !invariant.load !3, !alias.scope !9, !noalias !23
  %16 = getelementptr inbounds nuw i8, ptr %4, i64 32
  %wide.load18 = load <8 x float>, ptr %4, align 4, !invariant.load !3, !alias.scope !6, !noalias !24
  %wide.load19 = load <8 x float>, ptr %16, align 4, !invariant.load !3, !alias.scope !6, !noalias !24
  %17 = getelementptr inbounds nuw i8, ptr %12, i64 64
  %18 = getelementptr inbounds nuw i8, ptr %12, i64 96
  %wide.load12.1 = load <8 x float>, ptr %17, align 4, !invariant.load !3, !alias.scope !15, !noalias !21
  %wide.load13.1 = load <8 x float>, ptr %18, align 4, !invariant.load !3, !alias.scope !15, !noalias !21
  %19 = getelementptr inbounds nuw i8, ptr %8, i64 64
  %20 = getelementptr inbounds nuw i8, ptr %8, i64 96
  %wide.load14.1 = load <8 x float>, ptr %19, align 4, !invariant.load !3, !alias.scope !11, !noalias !22
  %wide.load15.1 = load <8 x float>, ptr %20, align 4, !invariant.load !3, !alias.scope !11, !noalias !22
  %21 = getelementptr inbounds nuw i8, ptr %6, i64 64
  %22 = getelementptr inbounds nuw i8, ptr %6, i64 96
  %wide.load16.1 = load <8 x float>, ptr %21, align 4, !invariant.load !3, !alias.scope !9, !noalias !23
  %wide.load17.1 = load <8 x float>, ptr %22, align 4, !invariant.load !3, !alias.scope !9, !noalias !23
  %23 = getelementptr inbounds nuw i8, ptr %4, i64 64
  %24 = getelementptr inbounds nuw i8, ptr %4, i64 96
  %wide.load18.1 = load <8 x float>, ptr %23, align 4, !invariant.load !3, !alias.scope !6, !noalias !24
  %wide.load19.1 = load <8 x float>, ptr %24, align 4, !invariant.load !3, !alias.scope !6, !noalias !24
  %25 = getelementptr inbounds nuw i8, ptr %12, i64 128
  %26 = getelementptr inbounds nuw i8, ptr %12, i64 160
  %wide.load12.2 = load <8 x float>, ptr %25, align 4, !invariant.load !3, !alias.scope !15, !noalias !21
  %wide.load13.2 = load <8 x float>, ptr %26, align 4, !invariant.load !3, !alias.scope !15, !noalias !21
  %27 = getelementptr inbounds nuw i8, ptr %8, i64 128
  %28 = getelementptr inbounds nuw i8, ptr %8, i64 160
  %wide.load14.2 = load <8 x float>, ptr %27, align 4, !invariant.load !3, !alias.scope !11, !noalias !22
  %wide.load15.2 = load <8 x float>, ptr %28, align 4, !invariant.load !3, !alias.scope !11, !noalias !22
  %29 = getelementptr inbounds nuw i8, ptr %6, i64 128
  %30 = getelementptr inbounds nuw i8, ptr %6, i64 160
  %wide.load16.2 = load <8 x float>, ptr %29, align 4, !invariant.load !3, !alias.scope !9, !noalias !23
  %wide.load17.2 = load <8 x float>, ptr %30, align 4, !invariant.load !3, !alias.scope !9, !noalias !23
  %31 = getelementptr inbounds nuw i8, ptr %4, i64 128
  %32 = getelementptr inbounds nuw i8, ptr %4, i64 160
  %wide.load18.2 = load <8 x float>, ptr %31, align 4, !invariant.load !3, !alias.scope !6, !noalias !24
  %wide.load19.2 = load <8 x float>, ptr %32, align 4, !invariant.load !3, !alias.scope !6, !noalias !24
  %33 = getelementptr inbounds nuw i8, ptr %12, i64 192
  %34 = getelementptr inbounds nuw i8, ptr %12, i64 224
  %wide.load12.3 = load <8 x float>, ptr %33, align 4, !invariant.load !3, !alias.scope !15, !noalias !21
  %wide.load13.3 = load <8 x float>, ptr %34, align 4, !invariant.load !3, !alias.scope !15, !noalias !21
  %35 = getelementptr inbounds nuw i8, ptr %8, i64 192
  %36 = getelementptr inbounds nuw i8, ptr %8, i64 224
  %wide.load14.3 = load <8 x float>, ptr %35, align 4, !invariant.load !3, !alias.scope !11, !noalias !22
  %wide.load15.3 = load <8 x float>, ptr %36, align 4, !invariant.load !3, !alias.scope !11, !noalias !22
  %37 = getelementptr inbounds nuw i8, ptr %6, i64 192
  %38 = getelementptr inbounds nuw i8, ptr %6, i64 224
  %wide.load16.3 = load <8 x float>, ptr %37, align 4, !invariant.load !3, !alias.scope !9, !noalias !23
  %wide.load17.3 = load <8 x float>, ptr %38, align 4, !invariant.load !3, !alias.scope !9, !noalias !23
  %39 = getelementptr inbounds nuw i8, ptr %4, i64 192
  %40 = getelementptr inbounds nuw i8, ptr %4, i64 224
  %wide.load18.3 = load <8 x float>, ptr %39, align 4, !invariant.load !3, !alias.scope !6, !noalias !24
  %wide.load19.3 = load <8 x float>, ptr %40, align 4, !invariant.load !3, !alias.scope !6, !noalias !24
  %41 = getelementptr inbounds nuw i8, ptr %12, i64 256
  %42 = getelementptr inbounds nuw i8, ptr %12, i64 288
  %wide.load12.4 = load <8 x float>, ptr %41, align 4, !invariant.load !3, !alias.scope !15, !noalias !21
  %wide.load13.4 = load <8 x float>, ptr %42, align 4, !invariant.load !3, !alias.scope !15, !noalias !21
  %43 = getelementptr inbounds nuw i8, ptr %8, i64 256
  %44 = getelementptr inbounds nuw i8, ptr %8, i64 288
  %wide.load14.4 = load <8 x float>, ptr %43, align 4, !invariant.load !3, !alias.scope !11, !noalias !22
  %wide.load15.4 = load <8 x float>, ptr %44, align 4, !invariant.load !3, !alias.scope !11, !noalias !22
  %45 = getelementptr inbounds nuw i8, ptr %6, i64 256
  %46 = getelementptr inbounds nuw i8, ptr %6, i64 288
  %wide.load16.4 = load <8 x float>, ptr %45, align 4, !invariant.load !3, !alias.scope !9, !noalias !23
  %wide.load17.4 = load <8 x float>, ptr %46, align 4, !invariant.load !3, !alias.scope !9, !noalias !23
  %47 = getelementptr inbounds nuw i8, ptr %4, i64 256
  %48 = getelementptr inbounds nuw i8, ptr %4, i64 288
  %wide.load18.4 = load <8 x float>, ptr %47, align 4, !invariant.load !3, !alias.scope !6, !noalias !24
  %wide.load19.4 = load <8 x float>, ptr %48, align 4, !invariant.load !3, !alias.scope !6, !noalias !24
  br label %.preheader

.preheader:                                       ; preds = %1, %.preheader
  %49 = phi i32 [ 0, %1 ], [ %173, %.preheader ]
  %50 = phi i32 [ 0, %1 ], [ %172, %.preheader ]
  %51 = phi i64 [ 0, %1 ], [ %174, %.preheader ]
  %52 = insertelement <8 x i32> <i32 poison, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0>, i32 %50, i64 0
  %53 = insertelement <8 x i32> <i32 poison, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0>, i32 %49, i64 0
  %.idx = mul nuw nsw i64 %51, 320
  %54 = getelementptr i8, ptr %10, i64 %.idx
  %55 = getelementptr i8, ptr %54, i64 32
  %wide.load = load <8 x float>, ptr %54, align 4, !invariant.load !3, !alias.scope !13, !noalias !25
  %wide.load11 = load <8 x float>, ptr %55, align 4, !invariant.load !3, !alias.scope !13, !noalias !25
  %56 = fmul <8 x float> %wide.load, %wide.load12
  %57 = fmul <8 x float> %wide.load11, %wide.load13
  %58 = fadd <8 x float> %56, %wide.load14
  %59 = fadd <8 x float> %57, %wide.load15
  %60 = fcmp ogt <8 x float> %58, zeroinitializer
  %61 = fcmp ogt <8 x float> %59, zeroinitializer
  %62 = zext <8 x i1> %60 to <8 x i32>
  %63 = zext <8 x i1> %61 to <8 x i32>
  %64 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %58, <8 x float> zeroinitializer)
  %65 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %59, <8 x float> zeroinitializer)
  %66 = fmul <8 x float> %wide.load16, %64
  %67 = fmul <8 x float> %wide.load17, %65
  %68 = fadd <8 x float> %wide.load18, %66
  %69 = fadd <8 x float> %wide.load19, %67
  %70 = fcmp ogt <8 x float> %68, zeroinitializer
  %71 = fcmp ogt <8 x float> %69, zeroinitializer
  %72 = zext <8 x i1> %70 to <8 x i32>
  %73 = zext <8 x i1> %71 to <8 x i32>
  %74 = add <8 x i32> %52, %62
  %75 = add <8 x i32> %53, %72
  %76 = getelementptr i8, ptr %54, i64 64
  %77 = getelementptr i8, ptr %54, i64 96
  %wide.load.1 = load <8 x float>, ptr %76, align 4, !invariant.load !3, !alias.scope !13, !noalias !25
  %wide.load11.1 = load <8 x float>, ptr %77, align 4, !invariant.load !3, !alias.scope !13, !noalias !25
  %78 = fmul <8 x float> %wide.load.1, %wide.load12.1
  %79 = fmul <8 x float> %wide.load11.1, %wide.load13.1
  %80 = fadd <8 x float> %78, %wide.load14.1
  %81 = fadd <8 x float> %79, %wide.load15.1
  %82 = fcmp ogt <8 x float> %80, zeroinitializer
  %83 = fcmp ogt <8 x float> %81, zeroinitializer
  %84 = zext <8 x i1> %82 to <8 x i32>
  %85 = zext <8 x i1> %83 to <8 x i32>
  %86 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %80, <8 x float> zeroinitializer)
  %87 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %81, <8 x float> zeroinitializer)
  %88 = fmul <8 x float> %wide.load16.1, %86
  %89 = fmul <8 x float> %wide.load17.1, %87
  %90 = fadd <8 x float> %wide.load18.1, %88
  %91 = fadd <8 x float> %wide.load19.1, %89
  %92 = fcmp ogt <8 x float> %90, zeroinitializer
  %93 = fcmp ogt <8 x float> %91, zeroinitializer
  %94 = zext <8 x i1> %92 to <8 x i32>
  %95 = zext <8 x i1> %93 to <8 x i32>
  %96 = add <8 x i32> %74, %84
  %97 = add nuw nsw <8 x i32> %63, %85
  %98 = add <8 x i32> %75, %94
  %99 = add nuw nsw <8 x i32> %73, %95
  %100 = getelementptr i8, ptr %54, i64 128
  %101 = getelementptr i8, ptr %54, i64 160
  %wide.load.2 = load <8 x float>, ptr %100, align 4, !invariant.load !3, !alias.scope !13, !noalias !25
  %wide.load11.2 = load <8 x float>, ptr %101, align 4, !invariant.load !3, !alias.scope !13, !noalias !25
  %102 = fmul <8 x float> %wide.load.2, %wide.load12.2
  %103 = fmul <8 x float> %wide.load11.2, %wide.load13.2
  %104 = fadd <8 x float> %102, %wide.load14.2
  %105 = fadd <8 x float> %103, %wide.load15.2
  %106 = fcmp ogt <8 x float> %104, zeroinitializer
  %107 = fcmp ogt <8 x float> %105, zeroinitializer
  %108 = zext <8 x i1> %106 to <8 x i32>
  %109 = zext <8 x i1> %107 to <8 x i32>
  %110 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %104, <8 x float> zeroinitializer)
  %111 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %105, <8 x float> zeroinitializer)
  %112 = fmul <8 x float> %wide.load16.2, %110
  %113 = fmul <8 x float> %wide.load17.2, %111
  %114 = fadd <8 x float> %wide.load18.2, %112
  %115 = fadd <8 x float> %wide.load19.2, %113
  %116 = fcmp ogt <8 x float> %114, zeroinitializer
  %117 = fcmp ogt <8 x float> %115, zeroinitializer
  %118 = zext <8 x i1> %116 to <8 x i32>
  %119 = zext <8 x i1> %117 to <8 x i32>
  %120 = add <8 x i32> %96, %108
  %121 = add nuw nsw <8 x i32> %97, %109
  %122 = add <8 x i32> %98, %118
  %123 = add nuw nsw <8 x i32> %99, %119
  %124 = getelementptr i8, ptr %54, i64 192
  %125 = getelementptr i8, ptr %54, i64 224
  %wide.load.3 = load <8 x float>, ptr %124, align 4, !invariant.load !3, !alias.scope !13, !noalias !25
  %wide.load11.3 = load <8 x float>, ptr %125, align 4, !invariant.load !3, !alias.scope !13, !noalias !25
  %126 = fmul <8 x float> %wide.load.3, %wide.load12.3
  %127 = fmul <8 x float> %wide.load11.3, %wide.load13.3
  %128 = fadd <8 x float> %126, %wide.load14.3
  %129 = fadd <8 x float> %127, %wide.load15.3
  %130 = fcmp ogt <8 x float> %128, zeroinitializer
  %131 = fcmp ogt <8 x float> %129, zeroinitializer
  %132 = zext <8 x i1> %130 to <8 x i32>
  %133 = zext <8 x i1> %131 to <8 x i32>
  %134 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %128, <8 x float> zeroinitializer)
  %135 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %129, <8 x float> zeroinitializer)
  %136 = fmul <8 x float> %wide.load16.3, %134
  %137 = fmul <8 x float> %wide.load17.3, %135
  %138 = fadd <8 x float> %wide.load18.3, %136
  %139 = fadd <8 x float> %wide.load19.3, %137
  %140 = fcmp ogt <8 x float> %138, zeroinitializer
  %141 = fcmp ogt <8 x float> %139, zeroinitializer
  %142 = zext <8 x i1> %140 to <8 x i32>
  %143 = zext <8 x i1> %141 to <8 x i32>
  %144 = add <8 x i32> %120, %132
  %145 = add nuw nsw <8 x i32> %121, %133
  %146 = add <8 x i32> %122, %142
  %147 = add nuw nsw <8 x i32> %123, %143
  %148 = getelementptr i8, ptr %54, i64 256
  %149 = getelementptr i8, ptr %54, i64 288
  %wide.load.4 = load <8 x float>, ptr %148, align 4, !invariant.load !3, !alias.scope !13, !noalias !25
  %wide.load11.4 = load <8 x float>, ptr %149, align 4, !invariant.load !3, !alias.scope !13, !noalias !25
  %150 = fmul <8 x float> %wide.load.4, %wide.load12.4
  %151 = fmul <8 x float> %wide.load11.4, %wide.load13.4
  %152 = fadd <8 x float> %150, %wide.load14.4
  %153 = fadd <8 x float> %151, %wide.load15.4
  %154 = fcmp ogt <8 x float> %152, zeroinitializer
  %155 = fcmp ogt <8 x float> %153, zeroinitializer
  %156 = zext <8 x i1> %154 to <8 x i32>
  %157 = zext <8 x i1> %155 to <8 x i32>
  %158 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %152, <8 x float> zeroinitializer)
  %159 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %153, <8 x float> zeroinitializer)
  %160 = fmul <8 x float> %wide.load16.4, %158
  %161 = fmul <8 x float> %wide.load17.4, %159
  %162 = fadd <8 x float> %wide.load18.4, %160
  %163 = fadd <8 x float> %wide.load19.4, %161
  %164 = fcmp ogt <8 x float> %162, zeroinitializer
  %165 = fcmp ogt <8 x float> %163, zeroinitializer
  %166 = zext <8 x i1> %164 to <8 x i32>
  %167 = zext <8 x i1> %165 to <8 x i32>
  %168 = add <8 x i32> %144, %156
  %169 = add nuw nsw <8 x i32> %145, %157
  %170 = add <8 x i32> %146, %166
  %171 = add nuw nsw <8 x i32> %147, %167
  %bin.rdx20 = add <8 x i32> %169, %168
  %172 = tail call i32 @llvm.vector.reduce.add.v8i32(<8 x i32> %bin.rdx20)
  %bin.rdx = add <8 x i32> %171, %170
  %173 = tail call i32 @llvm.vector.reduce.add.v8i32(<8 x i32> %bin.rdx)
  %174 = add nuw nsw i64 %51, 1
  %exitcond5.not = icmp eq i64 %174, 48
  br i1 %exitcond5.not, label %convert_reduce_fusion_wrapped.exit, label %.preheader, !llvm.loop !26

convert_reduce_fusion_wrapped.exit:               ; preds = %.preheader
  %175 = getelementptr inbounds nuw i8, ptr %3, i64 96
  %176 = load ptr, ptr %175, align 8, !invariant.load !3, !dereferenceable !28
  %177 = getelementptr inbounds nuw i8, ptr %3, i64 80
  %178 = load ptr, ptr %177, align 8, !invariant.load !3, !dereferenceable !28
  store i32 %172, ptr %178, align 4, !alias.scope !17, !noalias !29
  store i32 %173, ptr %176, align 4, !alias.scope !19, !noalias !30
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.maximum.v8f32(<8 x float>, <8 x float>) #2

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.vector.reduce.add.v8i32(<8 x i32>) #3

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #3 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 1}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 320}
!5 = !{i64 15360}
!6 = !{!7}
!7 = distinct !{!7, !8, !"convert_reduce_fusion_wrapped: argument 0"}
!8 = distinct !{!8, !"convert_reduce_fusion_wrapped"}
!9 = !{!10}
!10 = distinct !{!10, !8, !"convert_reduce_fusion_wrapped: argument 1"}
!11 = !{!12}
!12 = distinct !{!12, !8, !"convert_reduce_fusion_wrapped: argument 2"}
!13 = !{!14}
!14 = distinct !{!14, !8, !"convert_reduce_fusion_wrapped: argument 3"}
!15 = !{!16}
!16 = distinct !{!16, !8, !"convert_reduce_fusion_wrapped: argument 4"}
!17 = !{!18}
!18 = distinct !{!18, !8, !"convert_reduce_fusion_wrapped: argument 5"}
!19 = !{!20}
!20 = distinct !{!20, !8, !"convert_reduce_fusion_wrapped: argument 6"}
!21 = !{!7, !10, !12, !14, !18, !20}
!22 = !{!7, !10, !14, !16, !18, !20}
!23 = !{!7, !12, !14, !16, !18, !20}
!24 = !{!10, !12, !14, !16, !18, !20}
!25 = !{!7, !10, !12, !16, !18, !20}
!26 = distinct !{!26, !27}
!27 = !{!"llvm.loop.unroll.disable"}
!28 = !{i64 4}
!29 = !{!7, !10, !12, !14, !16, !20}
!30 = !{!7, !10, !12, !14, !16, !18}
