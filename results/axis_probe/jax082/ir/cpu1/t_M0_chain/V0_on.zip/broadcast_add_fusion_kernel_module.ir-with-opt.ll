; ModuleID = '__compute_module_broadcast_add_fusion_kernel_module'
source_filename = "__compute_module_broadcast_add_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @broadcast_add_fusion(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !5
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !4
  tail call void @llvm.experimental.noalias.scope.decl(metadata !6)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !11)
  %9 = getelementptr inbounds nuw i8, ptr %6, i64 32
  %wide.load4 = load <8 x float>, ptr %6, align 4, !invariant.load !3, !alias.scope !9, !noalias !13
  %wide.load5 = load <8 x float>, ptr %9, align 4, !invariant.load !3, !alias.scope !9, !noalias !13
  %10 = getelementptr inbounds nuw i8, ptr %6, i64 64
  %11 = getelementptr inbounds nuw i8, ptr %6, i64 96
  %wide.load4.1 = load <8 x float>, ptr %10, align 4, !invariant.load !3, !alias.scope !9, !noalias !13
  %wide.load5.1 = load <8 x float>, ptr %11, align 4, !invariant.load !3, !alias.scope !9, !noalias !13
  %12 = getelementptr inbounds nuw i8, ptr %6, i64 128
  %13 = getelementptr inbounds nuw i8, ptr %6, i64 160
  %wide.load4.2 = load <8 x float>, ptr %12, align 4, !invariant.load !3, !alias.scope !9, !noalias !13
  %wide.load5.2 = load <8 x float>, ptr %13, align 4, !invariant.load !3, !alias.scope !9, !noalias !13
  %14 = getelementptr inbounds nuw i8, ptr %6, i64 192
  %15 = getelementptr inbounds nuw i8, ptr %6, i64 224
  %wide.load4.3 = load <8 x float>, ptr %14, align 4, !invariant.load !3, !alias.scope !9, !noalias !13
  %wide.load5.3 = load <8 x float>, ptr %15, align 4, !invariant.load !3, !alias.scope !9, !noalias !13
  %16 = getelementptr inbounds nuw i8, ptr %6, i64 256
  %17 = getelementptr inbounds nuw i8, ptr %6, i64 288
  %wide.load4.4 = load <8 x float>, ptr %16, align 4, !invariant.load !3, !alias.scope !9, !noalias !13
  %wide.load5.4 = load <8 x float>, ptr %17, align 4, !invariant.load !3, !alias.scope !9, !noalias !13
  br label %vector.ph

vector.ph:                                        ; preds = %1, %vector.ph
  %18 = phi i64 [ 0, %1 ], [ %84, %vector.ph ]
  %19 = mul nuw nsw i64 %18, 80
  %20 = getelementptr inbounds nuw float, ptr %4, i64 %19
  %21 = getelementptr inbounds nuw i8, ptr %20, i64 32
  %wide.load = load <8 x float>, ptr %20, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %wide.load3 = load <8 x float>, ptr %21, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %22 = fadd <8 x float> %wide.load, %wide.load4
  %23 = fadd <8 x float> %wide.load3, %wide.load5
  %24 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %22, <8 x float> zeroinitializer)
  %25 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %23, <8 x float> zeroinitializer)
  %26 = fmul <8 x float> %24, splat (float 7.500000e-01)
  %27 = fmul <8 x float> %25, splat (float 7.500000e-01)
  %28 = fadd <8 x float> %26, splat (float 1.250000e-01)
  %29 = fadd <8 x float> %27, splat (float 1.250000e-01)
  %30 = getelementptr inbounds nuw float, ptr %8, i64 %19
  %31 = getelementptr inbounds nuw i8, ptr %30, i64 32
  store <8 x float> %28, ptr %30, align 4, !alias.scope !11, !noalias !15
  store <8 x float> %29, ptr %31, align 4, !alias.scope !11, !noalias !15
  %32 = add nuw nsw i64 %19, 16
  %33 = getelementptr inbounds nuw float, ptr %4, i64 %32
  %34 = getelementptr inbounds nuw i8, ptr %33, i64 32
  %wide.load.1 = load <8 x float>, ptr %33, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %wide.load3.1 = load <8 x float>, ptr %34, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %35 = fadd <8 x float> %wide.load.1, %wide.load4.1
  %36 = fadd <8 x float> %wide.load3.1, %wide.load5.1
  %37 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %35, <8 x float> zeroinitializer)
  %38 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %36, <8 x float> zeroinitializer)
  %39 = fmul <8 x float> %37, splat (float 7.500000e-01)
  %40 = fmul <8 x float> %38, splat (float 7.500000e-01)
  %41 = fadd <8 x float> %39, splat (float 1.250000e-01)
  %42 = fadd <8 x float> %40, splat (float 1.250000e-01)
  %43 = getelementptr inbounds nuw float, ptr %8, i64 %32
  %44 = getelementptr inbounds nuw i8, ptr %43, i64 32
  store <8 x float> %41, ptr %43, align 4, !alias.scope !11, !noalias !15
  store <8 x float> %42, ptr %44, align 4, !alias.scope !11, !noalias !15
  %45 = add nuw nsw i64 %19, 32
  %46 = getelementptr inbounds nuw float, ptr %4, i64 %45
  %47 = getelementptr inbounds nuw i8, ptr %46, i64 32
  %wide.load.2 = load <8 x float>, ptr %46, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %wide.load3.2 = load <8 x float>, ptr %47, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %48 = fadd <8 x float> %wide.load.2, %wide.load4.2
  %49 = fadd <8 x float> %wide.load3.2, %wide.load5.2
  %50 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %48, <8 x float> zeroinitializer)
  %51 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %49, <8 x float> zeroinitializer)
  %52 = fmul <8 x float> %50, splat (float 7.500000e-01)
  %53 = fmul <8 x float> %51, splat (float 7.500000e-01)
  %54 = fadd <8 x float> %52, splat (float 1.250000e-01)
  %55 = fadd <8 x float> %53, splat (float 1.250000e-01)
  %56 = getelementptr inbounds nuw float, ptr %8, i64 %45
  %57 = getelementptr inbounds nuw i8, ptr %56, i64 32
  store <8 x float> %54, ptr %56, align 4, !alias.scope !11, !noalias !15
  store <8 x float> %55, ptr %57, align 4, !alias.scope !11, !noalias !15
  %58 = add nuw nsw i64 %19, 48
  %59 = getelementptr inbounds nuw float, ptr %4, i64 %58
  %60 = getelementptr inbounds nuw i8, ptr %59, i64 32
  %wide.load.3 = load <8 x float>, ptr %59, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %wide.load3.3 = load <8 x float>, ptr %60, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %61 = fadd <8 x float> %wide.load.3, %wide.load4.3
  %62 = fadd <8 x float> %wide.load3.3, %wide.load5.3
  %63 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %61, <8 x float> zeroinitializer)
  %64 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %62, <8 x float> zeroinitializer)
  %65 = fmul <8 x float> %63, splat (float 7.500000e-01)
  %66 = fmul <8 x float> %64, splat (float 7.500000e-01)
  %67 = fadd <8 x float> %65, splat (float 1.250000e-01)
  %68 = fadd <8 x float> %66, splat (float 1.250000e-01)
  %69 = getelementptr inbounds nuw float, ptr %8, i64 %58
  %70 = getelementptr inbounds nuw i8, ptr %69, i64 32
  store <8 x float> %67, ptr %69, align 4, !alias.scope !11, !noalias !15
  store <8 x float> %68, ptr %70, align 4, !alias.scope !11, !noalias !15
  %71 = add nuw nsw i64 %19, 64
  %72 = getelementptr inbounds nuw float, ptr %4, i64 %71
  %73 = getelementptr inbounds nuw i8, ptr %72, i64 32
  %wide.load.4 = load <8 x float>, ptr %72, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %wide.load3.4 = load <8 x float>, ptr %73, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %74 = fadd <8 x float> %wide.load.4, %wide.load4.4
  %75 = fadd <8 x float> %wide.load3.4, %wide.load5.4
  %76 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %74, <8 x float> zeroinitializer)
  %77 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %75, <8 x float> zeroinitializer)
  %78 = fmul <8 x float> %76, splat (float 7.500000e-01)
  %79 = fmul <8 x float> %77, splat (float 7.500000e-01)
  %80 = fadd <8 x float> %78, splat (float 1.250000e-01)
  %81 = fadd <8 x float> %79, splat (float 1.250000e-01)
  %82 = getelementptr inbounds nuw float, ptr %8, i64 %71
  %83 = getelementptr inbounds nuw i8, ptr %82, i64 32
  store <8 x float> %80, ptr %82, align 4, !alias.scope !11, !noalias !15
  store <8 x float> %81, ptr %83, align 4, !alias.scope !11, !noalias !15
  %84 = add nuw nsw i64 %18, 1
  %exitcond2.not = icmp eq i64 %84, 48
  br i1 %exitcond2.not, label %broadcast_add_fusion_wrapped.exit, label %vector.ph, !llvm.loop !16

broadcast_add_fusion_wrapped.exit:                ; preds = %vector.ph
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.maximum.v8f32(<8 x float>, <8 x float>) #2

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 1}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 15360}
!5 = !{i64 320}
!6 = !{!7}
!7 = distinct !{!7, !8, !"broadcast_add_fusion_wrapped: argument 0"}
!8 = distinct !{!8, !"broadcast_add_fusion_wrapped"}
!9 = !{!10}
!10 = distinct !{!10, !8, !"broadcast_add_fusion_wrapped: argument 1"}
!11 = !{!12}
!12 = distinct !{!12, !8, !"broadcast_add_fusion_wrapped: argument 2"}
!13 = !{!7, !12}
!14 = !{!10, !12}
!15 = !{!7, !10}
!16 = distinct !{!16, !17}
!17 = !{!"llvm.loop.unroll.disable"}
