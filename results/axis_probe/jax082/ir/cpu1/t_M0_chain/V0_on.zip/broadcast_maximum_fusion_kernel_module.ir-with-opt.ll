; ModuleID = '__compute_module_broadcast_maximum_fusion_kernel_module'
source_filename = "__compute_module_broadcast_maximum_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @broadcast_maximum_fusion(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !5
  tail call void @llvm.experimental.noalias.scope.decl(metadata !6)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9)
  %7 = getelementptr inbounds nuw i8, ptr %6, i64 32
  %8 = getelementptr inbounds nuw i8, ptr %6, i64 64
  %9 = getelementptr inbounds nuw i8, ptr %6, i64 96
  %wide.load5 = load <8 x float>, ptr %6, align 4, !invariant.load !3, !alias.scope !9, !noalias !6
  %wide.load6 = load <8 x float>, ptr %7, align 4, !invariant.load !3, !alias.scope !9, !noalias !6
  %wide.load7 = load <8 x float>, ptr %8, align 4, !invariant.load !3, !alias.scope !9, !noalias !6
  %wide.load8 = load <8 x float>, ptr %9, align 4, !invariant.load !3, !alias.scope !9, !noalias !6
  %10 = getelementptr inbounds nuw i8, ptr %6, i64 128
  %11 = getelementptr inbounds nuw i8, ptr %6, i64 160
  %12 = getelementptr inbounds nuw i8, ptr %6, i64 192
  %13 = getelementptr inbounds nuw i8, ptr %6, i64 224
  %wide.load5.1 = load <8 x float>, ptr %10, align 4, !invariant.load !3, !alias.scope !9, !noalias !6
  %wide.load6.1 = load <8 x float>, ptr %11, align 4, !invariant.load !3, !alias.scope !9, !noalias !6
  %wide.load7.1 = load <8 x float>, ptr %12, align 4, !invariant.load !3, !alias.scope !9, !noalias !6
  %wide.load8.1 = load <8 x float>, ptr %13, align 4, !invariant.load !3, !alias.scope !9, !noalias !6
  %14 = getelementptr inbounds nuw i8, ptr %6, i64 256
  %wide.load11 = load <8 x float>, ptr %14, align 4, !invariant.load !3, !alias.scope !9, !noalias !6
  %15 = getelementptr inbounds nuw i8, ptr %6, i64 288
  %wide.load11.1 = load <8 x float>, ptr %15, align 4, !invariant.load !3, !alias.scope !9, !noalias !6
  br label %iter.check

iter.check:                                       ; preds = %1, %iter.check
  %16 = phi i64 [ 0, %1 ], [ %47, %iter.check ]
  %.idx = mul nuw nsw i64 %16, 320
  %17 = getelementptr i8, ptr %4, i64 %.idx
  %18 = getelementptr i8, ptr %17, i64 32
  %19 = getelementptr i8, ptr %17, i64 64
  %20 = getelementptr i8, ptr %17, i64 96
  %wide.load = load <8 x float>, ptr %17, align 4, !alias.scope !6, !noalias !9
  %wide.load2 = load <8 x float>, ptr %18, align 4, !alias.scope !6, !noalias !9
  %wide.load3 = load <8 x float>, ptr %19, align 4, !alias.scope !6, !noalias !9
  %wide.load4 = load <8 x float>, ptr %20, align 4, !alias.scope !6, !noalias !9
  %21 = fadd <8 x float> %wide.load, %wide.load5
  %22 = fadd <8 x float> %wide.load2, %wide.load6
  %23 = fadd <8 x float> %wide.load3, %wide.load7
  %24 = fadd <8 x float> %wide.load4, %wide.load8
  %25 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %21, <8 x float> zeroinitializer)
  %26 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %22, <8 x float> zeroinitializer)
  %27 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %23, <8 x float> zeroinitializer)
  %28 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %24, <8 x float> zeroinitializer)
  store <8 x float> %25, ptr %17, align 4, !alias.scope !6, !noalias !9
  store <8 x float> %26, ptr %18, align 4, !alias.scope !6, !noalias !9
  store <8 x float> %27, ptr %19, align 4, !alias.scope !6, !noalias !9
  store <8 x float> %28, ptr %20, align 4, !alias.scope !6, !noalias !9
  %29 = getelementptr i8, ptr %17, i64 128
  %30 = getelementptr i8, ptr %17, i64 160
  %31 = getelementptr i8, ptr %17, i64 192
  %32 = getelementptr i8, ptr %17, i64 224
  %wide.load.1 = load <8 x float>, ptr %29, align 4, !alias.scope !6, !noalias !9
  %wide.load2.1 = load <8 x float>, ptr %30, align 4, !alias.scope !6, !noalias !9
  %wide.load3.1 = load <8 x float>, ptr %31, align 4, !alias.scope !6, !noalias !9
  %wide.load4.1 = load <8 x float>, ptr %32, align 4, !alias.scope !6, !noalias !9
  %33 = fadd <8 x float> %wide.load.1, %wide.load5.1
  %34 = fadd <8 x float> %wide.load2.1, %wide.load6.1
  %35 = fadd <8 x float> %wide.load3.1, %wide.load7.1
  %36 = fadd <8 x float> %wide.load4.1, %wide.load8.1
  %37 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %33, <8 x float> zeroinitializer)
  %38 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %34, <8 x float> zeroinitializer)
  %39 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %35, <8 x float> zeroinitializer)
  %40 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %36, <8 x float> zeroinitializer)
  store <8 x float> %37, ptr %29, align 4, !alias.scope !6, !noalias !9
  store <8 x float> %38, ptr %30, align 4, !alias.scope !6, !noalias !9
  store <8 x float> %39, ptr %31, align 4, !alias.scope !6, !noalias !9
  store <8 x float> %40, ptr %32, align 4, !alias.scope !6, !noalias !9
  %41 = getelementptr i8, ptr %17, i64 256
  %wide.load10 = load <8 x float>, ptr %41, align 4, !alias.scope !6, !noalias !9
  %42 = fadd <8 x float> %wide.load10, %wide.load11
  %43 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %42, <8 x float> zeroinitializer)
  store <8 x float> %43, ptr %41, align 4, !alias.scope !6, !noalias !9
  %44 = getelementptr i8, ptr %17, i64 288
  %wide.load10.1 = load <8 x float>, ptr %44, align 4, !alias.scope !6, !noalias !9
  %45 = fadd <8 x float> %wide.load10.1, %wide.load11.1
  %46 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %45, <8 x float> zeroinitializer)
  store <8 x float> %46, ptr %44, align 4, !alias.scope !6, !noalias !9
  %47 = add nuw nsw i64 %16, 1
  %exitcond1.not = icmp eq i64 %47, 48
  br i1 %exitcond1.not, label %broadcast_maximum_fusion_wrapped.exit, label %iter.check, !llvm.loop !11

broadcast_maximum_fusion_wrapped.exit:            ; preds = %iter.check
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.maximum.v8f32(<8 x float>, <8 x float>) #2

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 2}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 15360}
!5 = !{i64 320}
!6 = !{!7}
!7 = distinct !{!7, !8, !"broadcast_maximum_fusion_wrapped: argument 0"}
!8 = distinct !{!8, !"broadcast_maximum_fusion_wrapped"}
!9 = !{!10}
!10 = distinct !{!10, !8, !"broadcast_maximum_fusion_wrapped: argument 1"}
!11 = distinct !{!11, !12}
!12 = !{!"llvm.loop.unroll.disable"}
