; ModuleID = '__compute_module_wrapped_reduce-window_kernel_module'
source_filename = "__compute_module_wrapped_reduce-window_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

%XLA_CPU_KernelCallFrame = type { ptr, ptr, i64, ptr }
%XLA_CPU_KernelArg = type { ptr, i64 }
%kernel_dim3 = type { i64, i64, i64 }

; Function Attrs: uwtable
define ptr @wrapped_reduce-window(ptr %0) #0 {
  %2 = getelementptr inbounds %XLA_CPU_KernelCallFrame, ptr %0, i32 0, i32 3
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 0, i32 0
  %5 = load ptr, ptr %4, align 8, !invariant.load !3, !dereferenceable !4
  %6 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 1, i32 0
  %7 = load ptr, ptr %6, align 8, !invariant.load !3, !dereferenceable !5
  %8 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 2, i32 0
  %9 = load ptr, ptr %8, align 8, !invariant.load !3, !dereferenceable !6
  %10 = getelementptr inbounds %XLA_CPU_KernelCallFrame, ptr %0, i32 0, i32 1
  %11 = load ptr, ptr %10, align 8
  %12 = getelementptr inbounds %kernel_dim3, ptr %11, i32 0, i32 0
  %13 = load i64, ptr %12, align 4, !invariant.load !3
  %14 = getelementptr inbounds %kernel_dim3, ptr %11, i32 0, i32 1
  %15 = load i64, ptr %14, align 4, !invariant.load !3
  %16 = getelementptr inbounds %kernel_dim3, ptr %11, i32 0, i32 2
  %17 = load i64, ptr %16, align 4, !invariant.load !3
  call void @wrapped_reduce-window_wrapped(ptr %5, ptr %7, ptr %9, i64 %13, i64 %15, i64 %17)
  ret ptr null
}

; Function Attrs: alwaysinline
define internal void @wrapped_reduce-window_wrapped(ptr noalias align 64 dereferenceable(23040) %0, ptr noalias align 64 dereferenceable(4) %1, ptr noalias align 64 dereferenceable(800) %2, i64 %3, i64 %4, i64 %5) #1 {
  %7 = getelementptr inbounds [1 x i32], ptr %1, i32 0, i32 0
  %8 = load i32, ptr %7, align 4, !invariant.load !3
  br label %9

9:                                                ; preds = %45, %6
  %10 = phi i64 [ %46, %45 ], [ 0, %6 ]
  %11 = icmp slt i64 %10, 40
  br i1 %11, label %12, label %47

12:                                               ; preds = %9
  %13 = mul nsw i64 %10, 5
  br label %14

14:                                               ; preds = %41, %12
  %15 = phi i64 [ %44, %41 ], [ 0, %12 ]
  %16 = icmp slt i64 %15, 5
  br i1 %16, label %17, label %45

17:                                               ; preds = %14
  %18 = mul nsw i64 %15, 32
  br label %19

19:                                               ; preds = %39, %17
  %20 = phi i64 [ %40, %39 ], [ 0, %17 ]
  %21 = phi i32 [ %38, %39 ], [ %8, %17 ]
  %22 = icmp slt i64 %20, 32
  br i1 %22, label %23, label %41

23:                                               ; preds = %19
  %24 = add nsw i64 %18, %20
  %25 = icmp sge i64 %24, 8
  %26 = icmp sle i64 %24, 151
  %27 = and i1 %25, %26
  br i1 %27, label %28, label %36

28:                                               ; preds = %23
  %29 = mul nsw i64 %10, 144
  %30 = add nsw i64 %29, %18
  %31 = add nsw i64 %30, %20
  %32 = add nsw i64 %31, -8
  %33 = getelementptr inbounds [5760 x i32], ptr %0, i32 0, i64 %32
  %34 = load i32, ptr %33, align 4, !invariant.load !3
  %35 = add i32 %21, %34
  br label %37

36:                                               ; preds = %23
  br label %37

37:                                               ; preds = %28, %36
  %38 = phi i32 [ %21, %36 ], [ %35, %28 ]
  br label %39

39:                                               ; preds = %37
  %40 = add i64 %20, 1
  br label %19

41:                                               ; preds = %19
  %42 = add nsw i64 %13, %15
  %43 = getelementptr inbounds [200 x i32], ptr %2, i32 0, i64 %42
  store i32 %21, ptr %43, align 4
  %44 = add i64 %15, 1
  br label %14, !llvm.loop !7

45:                                               ; preds = %14
  %46 = add i64 %10, 1
  br label %9, !llvm.loop !7

47:                                               ; preds = %9
  ret void
}

attributes #0 = { uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { alwaysinline }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 5}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 23040}
!5 = !{i64 4}
!6 = !{i64 800}
!7 = distinct !{!7, !8}
!8 = !{!"llvm.loop.unroll.disable"}
