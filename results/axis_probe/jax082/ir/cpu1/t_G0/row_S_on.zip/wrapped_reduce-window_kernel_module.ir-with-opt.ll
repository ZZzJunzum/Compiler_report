; ModuleID = '__compute_module_wrapped_reduce-window_kernel_module'
source_filename = "__compute_module_wrapped_reduce-window_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @wrapped_reduce-window(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !5
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !6
  tail call void @llvm.experimental.noalias.scope.decl(metadata !7)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !10)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !12)
  %9 = load i32, ptr %6, align 4, !invariant.load !3, !alias.scope !10, !noalias !14
  br label %.preheader

.preheader:                                       ; preds = %1, %156
  %10 = phi i64 [ 0, %1 ], [ %157, %156 ]
  %.idx1 = mul nuw nsw i64 %10, 576
  %invariant.gep3 = getelementptr i8, ptr %4, i64 %.idx1
  %.idx = mul nuw nsw i64 %10, 20
  %11 = getelementptr i8, ptr %8, i64 %.idx
  br label %12

12:                                               ; preds = %.preheader, %152
  %13 = phi i64 [ 0, %.preheader ], [ %155, %152 ]
  %14 = shl nuw nsw i64 %13, 5
  %15 = add nsw i64 %14, -8
  %gep4 = getelementptr i32, ptr %invariant.gep3, i64 %14
  %16 = icmp ult i64 %15, 144
  br i1 %16, label %17, label %21

17:                                               ; preds = %12
  %18 = getelementptr i8, ptr %gep4, i64 -32
  %19 = load i32, ptr %18, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %20 = add i32 %19, %9
  br label %21

21:                                               ; preds = %12, %17
  %22 = phi i32 [ %20, %17 ], [ %9, %12 ]
  %23 = add nsw i64 %14, -7
  %24 = icmp ult i64 %23, 144
  br i1 %24, label %25, label %29

25:                                               ; preds = %21
  %26 = getelementptr i8, ptr %gep4, i64 -28
  %27 = load i32, ptr %26, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %28 = add i32 %27, %22
  br label %29

29:                                               ; preds = %25, %21
  %30 = phi i32 [ %28, %25 ], [ %22, %21 ]
  %31 = add nsw i64 %14, -6
  %32 = icmp ult i64 %31, 144
  br i1 %32, label %33, label %37

33:                                               ; preds = %29
  %34 = getelementptr i8, ptr %gep4, i64 -24
  %35 = load i32, ptr %34, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %36 = add i32 %35, %30
  br label %37

37:                                               ; preds = %33, %29
  %38 = phi i32 [ %36, %33 ], [ %30, %29 ]
  %39 = add nsw i64 %14, -5
  %40 = icmp ult i64 %39, 144
  br i1 %40, label %41, label %45

41:                                               ; preds = %37
  %42 = getelementptr i8, ptr %gep4, i64 -20
  %43 = load i32, ptr %42, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %44 = add i32 %43, %38
  br label %45

45:                                               ; preds = %41, %37
  %46 = phi i32 [ %44, %41 ], [ %38, %37 ]
  %47 = add nsw i64 %14, -4
  %48 = icmp ult i64 %47, 144
  br i1 %48, label %49, label %53

49:                                               ; preds = %45
  %50 = getelementptr i8, ptr %gep4, i64 -16
  %51 = load i32, ptr %50, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %52 = add i32 %51, %46
  br label %53

53:                                               ; preds = %49, %45
  %54 = phi i32 [ %52, %49 ], [ %46, %45 ]
  %55 = add nsw i64 %14, -3
  %56 = icmp ult i64 %55, 144
  br i1 %56, label %57, label %61

57:                                               ; preds = %53
  %58 = getelementptr i8, ptr %gep4, i64 -12
  %59 = load i32, ptr %58, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %60 = add i32 %59, %54
  br label %61

61:                                               ; preds = %57, %53
  %62 = phi i32 [ %60, %57 ], [ %54, %53 ]
  %63 = add nsw i64 %14, -2
  %64 = icmp ult i64 %63, 144
  br i1 %64, label %65, label %69

65:                                               ; preds = %61
  %66 = getelementptr i8, ptr %gep4, i64 -8
  %67 = load i32, ptr %66, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %68 = add i32 %67, %62
  br label %69

69:                                               ; preds = %65, %61
  %70 = phi i32 [ %68, %65 ], [ %62, %61 ]
  %71 = add nsw i64 %14, -1
  %72 = icmp ult i64 %71, 144
  br i1 %72, label %73, label %77

73:                                               ; preds = %69
  %74 = getelementptr i8, ptr %gep4, i64 -4
  %75 = load i32, ptr %74, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %76 = add i32 %75, %70
  br label %77

77:                                               ; preds = %73, %69
  %78 = phi i32 [ %76, %73 ], [ %70, %69 ]
  %79 = load i32, ptr %gep4, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %80 = add i32 %79, %78
  %81 = getelementptr i8, ptr %gep4, i64 4
  %82 = load i32, ptr %81, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %83 = add i32 %82, %80
  %84 = getelementptr i8, ptr %gep4, i64 8
  %85 = load i32, ptr %84, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %86 = add i32 %85, %83
  %87 = getelementptr i8, ptr %gep4, i64 12
  %88 = load i32, ptr %87, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %89 = add i32 %88, %86
  %90 = getelementptr i8, ptr %gep4, i64 16
  %91 = load i32, ptr %90, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %92 = add i32 %91, %89
  %93 = getelementptr i8, ptr %gep4, i64 20
  %94 = load i32, ptr %93, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %95 = add i32 %94, %92
  %96 = getelementptr i8, ptr %gep4, i64 24
  %97 = load i32, ptr %96, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %98 = add i32 %97, %95
  %99 = getelementptr i8, ptr %gep4, i64 28
  %100 = load i32, ptr %99, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %101 = add i32 %100, %98
  %102 = getelementptr i8, ptr %gep4, i64 32
  %103 = load i32, ptr %102, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %104 = add i32 %103, %101
  %105 = getelementptr i8, ptr %gep4, i64 36
  %106 = load i32, ptr %105, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %107 = add i32 %106, %104
  %108 = getelementptr i8, ptr %gep4, i64 40
  %109 = load i32, ptr %108, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %110 = add i32 %109, %107
  %111 = getelementptr i8, ptr %gep4, i64 44
  %112 = load i32, ptr %111, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %113 = add i32 %112, %110
  %114 = getelementptr i8, ptr %gep4, i64 48
  %115 = load i32, ptr %114, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %116 = add i32 %115, %113
  %117 = getelementptr i8, ptr %gep4, i64 52
  %118 = load i32, ptr %117, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %119 = add i32 %118, %116
  %120 = getelementptr i8, ptr %gep4, i64 56
  %121 = load i32, ptr %120, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %122 = add i32 %121, %119
  %123 = getelementptr i8, ptr %gep4, i64 60
  %124 = load i32, ptr %123, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %125 = add i32 %124, %122
  %126 = icmp samesign ult i64 %13, 4
  br i1 %126, label %127, label %152

127:                                              ; preds = %77
  %128 = getelementptr i8, ptr %gep4, i64 64
  %129 = load i32, ptr %128, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %130 = add i32 %129, %125
  %131 = getelementptr i8, ptr %gep4, i64 68
  %132 = load i32, ptr %131, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %133 = add i32 %132, %130
  %134 = getelementptr i8, ptr %gep4, i64 72
  %135 = load i32, ptr %134, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %136 = add i32 %135, %133
  %137 = getelementptr i8, ptr %gep4, i64 76
  %138 = load i32, ptr %137, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %139 = add i32 %138, %136
  %140 = getelementptr i8, ptr %gep4, i64 80
  %141 = load i32, ptr %140, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %142 = add i32 %141, %139
  %143 = getelementptr i8, ptr %gep4, i64 84
  %144 = load i32, ptr %143, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %145 = add i32 %144, %142
  %146 = getelementptr i8, ptr %gep4, i64 88
  %147 = load i32, ptr %146, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %148 = add i32 %147, %145
  %149 = getelementptr i8, ptr %gep4, i64 92
  %150 = load i32, ptr %149, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %151 = add i32 %150, %148
  br label %152

152:                                              ; preds = %77, %127
  %153 = phi i32 [ %151, %127 ], [ %125, %77 ]
  %154 = getelementptr i32, ptr %11, i64 %13
  store i32 %153, ptr %154, align 4, !alias.scope !12, !noalias !16
  %155 = add nuw nsw i64 %13, 1
  %exitcond.not = icmp eq i64 %155, 5
  br i1 %exitcond.not, label %156, label %12, !llvm.loop !17

156:                                              ; preds = %152
  %157 = add nuw nsw i64 %10, 1
  %exitcond5.not = icmp eq i64 %157, 40
  br i1 %exitcond5.not, label %wrapped_reduce-window_wrapped.exit, label %.preheader, !llvm.loop !17

wrapped_reduce-window_wrapped.exit:               ; preds = %156
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 5}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 23040}
!5 = !{i64 4}
!6 = !{i64 800}
!7 = !{!8}
!8 = distinct !{!8, !9, !"wrapped_reduce-window_wrapped: argument 0"}
!9 = distinct !{!9, !"wrapped_reduce-window_wrapped"}
!10 = !{!11}
!11 = distinct !{!11, !9, !"wrapped_reduce-window_wrapped: argument 1"}
!12 = !{!13}
!13 = distinct !{!13, !9, !"wrapped_reduce-window_wrapped: argument 2"}
!14 = !{!8, !13}
!15 = !{!11, !13}
!16 = !{!8, !11}
!17 = distinct !{!17, !18}
!18 = !{!"llvm.loop.unroll.disable"}
