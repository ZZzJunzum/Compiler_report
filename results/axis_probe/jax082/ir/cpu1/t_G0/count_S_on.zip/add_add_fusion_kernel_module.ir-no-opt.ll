; ModuleID = '__compute_module_add_add_fusion_kernel_module'
source_filename = "__compute_module_add_add_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

%XLA_CPU_KernelCallFrame = type { ptr, ptr, i64, ptr }
%XLA_CPU_KernelArg = type { ptr, i64 }
%kernel_dim3 = type { i64, i64, i64 }

; Function Attrs: uwtable
define ptr @add_add_fusion(ptr %0) #0 {
  %2 = getelementptr inbounds %XLA_CPU_KernelCallFrame, ptr %0, i32 0, i32 3
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 0, i32 0
  %5 = load ptr, ptr %4, align 8, !invariant.load !3, !dereferenceable !4
  %6 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 1, i32 0
  %7 = load ptr, ptr %6, align 8, !invariant.load !3, !dereferenceable !4
  %8 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 2, i32 0
  %9 = load ptr, ptr %8, align 8, !invariant.load !3, !dereferenceable !5
  %10 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 3, i32 0
  %11 = load ptr, ptr %10, align 8, !invariant.load !3, !dereferenceable !4
  %12 = getelementptr inbounds %XLA_CPU_KernelCallFrame, ptr %0, i32 0, i32 1
  %13 = load ptr, ptr %12, align 8
  %14 = getelementptr inbounds %kernel_dim3, ptr %13, i32 0, i32 0
  %15 = load i64, ptr %14, align 4, !invariant.load !3
  %16 = getelementptr inbounds %kernel_dim3, ptr %13, i32 0, i32 1
  %17 = load i64, ptr %16, align 4, !invariant.load !3
  %18 = getelementptr inbounds %kernel_dim3, ptr %13, i32 0, i32 2
  %19 = load i64, ptr %18, align 4, !invariant.load !3
  call void @add_add_fusion_wrapped(ptr %5, ptr %7, ptr %9, ptr %11, i64 %15, i64 %17, i64 %19)
  ret ptr null
}

; Function Attrs: alwaysinline
define internal void @add_add_fusion_wrapped(ptr noalias align 64 dereferenceable(11520) %0, ptr noalias align 64 dereferenceable(11520) %1, ptr noalias align 64 dereferenceable(288) %2, ptr noalias align 64 dereferenceable(11520) %3, i64 %4, i64 %5, i64 %6) #1 {
  br label %8

8:                                                ; preds = %27, %7
  %9 = phi i64 [ %28, %27 ], [ 0, %7 ]
  %10 = icmp slt i64 %9, 40
  br i1 %10, label %11, label %29

11:                                               ; preds = %8
  %12 = mul nsw i64 %9, 72
  br label %13

13:                                               ; preds = %16, %11
  %14 = phi i64 [ %26, %16 ], [ 0, %11 ]
  %15 = icmp slt i64 %14, 72
  br i1 %15, label %16, label %27

16:                                               ; preds = %13
  %17 = add nsw i64 %12, %14
  %18 = getelementptr inbounds [2880 x float], ptr %1, i32 0, i64 %17
  %19 = load float, ptr %18, align 4
  %20 = getelementptr inbounds [72 x float], ptr %2, i32 0, i64 %14
  %21 = load float, ptr %20, align 4, !invariant.load !3
  %22 = getelementptr inbounds [2880 x float], ptr %0, i32 0, i64 %17
  %23 = load float, ptr %22, align 4, !invariant.load !3
  %24 = fadd float %19, %21
  %25 = fadd float %23, %24
  store float %25, ptr %18, align 4
  %26 = add i64 %14, 1
  br label %13

27:                                               ; preds = %13
  %28 = add i64 %9, 1
  br label %8, !llvm.loop !6

29:                                               ; preds = %8
  ret void
}

attributes #0 = { uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { alwaysinline }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 0}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 11520}
!5 = !{i64 288}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.unroll.disable"}
