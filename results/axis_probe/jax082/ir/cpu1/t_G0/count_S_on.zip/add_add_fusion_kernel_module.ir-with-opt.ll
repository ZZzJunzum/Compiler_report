; ModuleID = '__compute_module_add_add_fusion_kernel_module'
source_filename = "__compute_module_add_add_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @add_add_fusion(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !4
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !5
  tail call void @llvm.experimental.noalias.scope.decl(metadata !6)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !11)
  %9 = getelementptr inbounds nuw i8, ptr %8, i64 32
  %wide.load4 = load <8 x float>, ptr %8, align 4, !invariant.load !3, !alias.scope !11, !noalias !13
  %wide.load5 = load <8 x float>, ptr %9, align 4, !invariant.load !3, !alias.scope !11, !noalias !13
  %10 = getelementptr inbounds nuw i8, ptr %8, i64 64
  %11 = getelementptr inbounds nuw i8, ptr %8, i64 96
  %wide.load4.1 = load <8 x float>, ptr %10, align 4, !invariant.load !3, !alias.scope !11, !noalias !13
  %wide.load5.1 = load <8 x float>, ptr %11, align 4, !invariant.load !3, !alias.scope !11, !noalias !13
  %12 = getelementptr inbounds nuw i8, ptr %8, i64 128
  %13 = getelementptr inbounds nuw i8, ptr %8, i64 160
  %wide.load4.2 = load <8 x float>, ptr %12, align 4, !invariant.load !3, !alias.scope !11, !noalias !13
  %wide.load5.2 = load <8 x float>, ptr %13, align 4, !invariant.load !3, !alias.scope !11, !noalias !13
  %14 = getelementptr inbounds nuw i8, ptr %8, i64 192
  %15 = getelementptr inbounds nuw i8, ptr %8, i64 224
  %wide.load4.3 = load <8 x float>, ptr %14, align 4, !invariant.load !3, !alias.scope !11, !noalias !13
  %wide.load5.3 = load <8 x float>, ptr %15, align 4, !invariant.load !3, !alias.scope !11, !noalias !13
  %16 = getelementptr inbounds nuw i8, ptr %8, i64 256
  %wide.load10 = load <8 x float>, ptr %16, align 4, !invariant.load !3, !alias.scope !11, !noalias !13
  br label %iter.check

iter.check:                                       ; preds = %1, %iter.check
  %17 = phi i64 [ 0, %1 ], [ %59, %iter.check ]
  %18 = mul nuw nsw i64 %17, 72
  %19 = getelementptr inbounds nuw float, ptr %6, i64 %18
  %20 = getelementptr inbounds nuw i8, ptr %19, i64 32
  %wide.load = load <8 x float>, ptr %19, align 4, !alias.scope !9, !noalias !14
  %wide.load3 = load <8 x float>, ptr %20, align 4, !alias.scope !9, !noalias !14
  %21 = getelementptr inbounds nuw float, ptr %4, i64 %18
  %22 = getelementptr inbounds nuw i8, ptr %21, i64 32
  %wide.load6 = load <8 x float>, ptr %21, align 4, !invariant.load !3, !alias.scope !6, !noalias !15
  %wide.load7 = load <8 x float>, ptr %22, align 4, !invariant.load !3, !alias.scope !6, !noalias !15
  %23 = fadd <8 x float> %wide.load, %wide.load4
  %24 = fadd <8 x float> %wide.load3, %wide.load5
  %25 = fadd <8 x float> %wide.load6, %23
  %26 = fadd <8 x float> %wide.load7, %24
  store <8 x float> %25, ptr %19, align 4, !alias.scope !9, !noalias !14
  store <8 x float> %26, ptr %20, align 4, !alias.scope !9, !noalias !14
  %27 = add nuw nsw i64 %18, 16
  %28 = getelementptr inbounds nuw float, ptr %6, i64 %27
  %29 = getelementptr inbounds nuw i8, ptr %28, i64 32
  %wide.load.1 = load <8 x float>, ptr %28, align 4, !alias.scope !9, !noalias !14
  %wide.load3.1 = load <8 x float>, ptr %29, align 4, !alias.scope !9, !noalias !14
  %30 = getelementptr inbounds nuw float, ptr %4, i64 %27
  %31 = getelementptr inbounds nuw i8, ptr %30, i64 32
  %wide.load6.1 = load <8 x float>, ptr %30, align 4, !invariant.load !3, !alias.scope !6, !noalias !15
  %wide.load7.1 = load <8 x float>, ptr %31, align 4, !invariant.load !3, !alias.scope !6, !noalias !15
  %32 = fadd <8 x float> %wide.load.1, %wide.load4.1
  %33 = fadd <8 x float> %wide.load3.1, %wide.load5.1
  %34 = fadd <8 x float> %wide.load6.1, %32
  %35 = fadd <8 x float> %wide.load7.1, %33
  store <8 x float> %34, ptr %28, align 4, !alias.scope !9, !noalias !14
  store <8 x float> %35, ptr %29, align 4, !alias.scope !9, !noalias !14
  %36 = add nuw nsw i64 %18, 32
  %37 = getelementptr inbounds nuw float, ptr %6, i64 %36
  %38 = getelementptr inbounds nuw i8, ptr %37, i64 32
  %wide.load.2 = load <8 x float>, ptr %37, align 4, !alias.scope !9, !noalias !14
  %wide.load3.2 = load <8 x float>, ptr %38, align 4, !alias.scope !9, !noalias !14
  %39 = getelementptr inbounds nuw float, ptr %4, i64 %36
  %40 = getelementptr inbounds nuw i8, ptr %39, i64 32
  %wide.load6.2 = load <8 x float>, ptr %39, align 4, !invariant.load !3, !alias.scope !6, !noalias !15
  %wide.load7.2 = load <8 x float>, ptr %40, align 4, !invariant.load !3, !alias.scope !6, !noalias !15
  %41 = fadd <8 x float> %wide.load.2, %wide.load4.2
  %42 = fadd <8 x float> %wide.load3.2, %wide.load5.2
  %43 = fadd <8 x float> %wide.load6.2, %41
  %44 = fadd <8 x float> %wide.load7.2, %42
  store <8 x float> %43, ptr %37, align 4, !alias.scope !9, !noalias !14
  store <8 x float> %44, ptr %38, align 4, !alias.scope !9, !noalias !14
  %45 = add nuw nsw i64 %18, 48
  %46 = getelementptr inbounds nuw float, ptr %6, i64 %45
  %47 = getelementptr inbounds nuw i8, ptr %46, i64 32
  %wide.load.3 = load <8 x float>, ptr %46, align 4, !alias.scope !9, !noalias !14
  %wide.load3.3 = load <8 x float>, ptr %47, align 4, !alias.scope !9, !noalias !14
  %48 = getelementptr inbounds nuw float, ptr %4, i64 %45
  %49 = getelementptr inbounds nuw i8, ptr %48, i64 32
  %wide.load6.3 = load <8 x float>, ptr %48, align 4, !invariant.load !3, !alias.scope !6, !noalias !15
  %wide.load7.3 = load <8 x float>, ptr %49, align 4, !invariant.load !3, !alias.scope !6, !noalias !15
  %50 = fadd <8 x float> %wide.load.3, %wide.load4.3
  %51 = fadd <8 x float> %wide.load3.3, %wide.load5.3
  %52 = fadd <8 x float> %wide.load6.3, %50
  %53 = fadd <8 x float> %wide.load7.3, %51
  store <8 x float> %52, ptr %46, align 4, !alias.scope !9, !noalias !14
  store <8 x float> %53, ptr %47, align 4, !alias.scope !9, !noalias !14
  %54 = add nuw nsw i64 %18, 64
  %55 = getelementptr inbounds nuw float, ptr %6, i64 %54
  %wide.load9 = load <8 x float>, ptr %55, align 4, !alias.scope !9, !noalias !14
  %56 = getelementptr inbounds nuw float, ptr %4, i64 %54
  %wide.load11 = load <8 x float>, ptr %56, align 4, !invariant.load !3, !alias.scope !6, !noalias !15
  %57 = fadd <8 x float> %wide.load9, %wide.load10
  %58 = fadd <8 x float> %wide.load11, %57
  store <8 x float> %58, ptr %55, align 4, !alias.scope !9, !noalias !14
  %59 = add nuw nsw i64 %17, 1
  %exitcond2.not = icmp eq i64 %59, 40
  br i1 %exitcond2.not, label %add_add_fusion_wrapped.exit, label %iter.check, !llvm.loop !16

add_add_fusion_wrapped.exit:                      ; preds = %iter.check
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 0}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 11520}
!5 = !{i64 288}
!6 = !{!7}
!7 = distinct !{!7, !8, !"add_add_fusion_wrapped: argument 0"}
!8 = distinct !{!8, !"add_add_fusion_wrapped"}
!9 = !{!10}
!10 = distinct !{!10, !8, !"add_add_fusion_wrapped: argument 1"}
!11 = !{!12}
!12 = distinct !{!12, !8, !"add_add_fusion_wrapped: argument 2"}
!13 = !{!7, !10}
!14 = !{!7, !12}
!15 = !{!10, !12}
!16 = distinct !{!16, !17}
!17 = !{!"llvm.loop.unroll.disable"}
