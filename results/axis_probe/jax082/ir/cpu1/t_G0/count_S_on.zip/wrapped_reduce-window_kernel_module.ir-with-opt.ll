; ModuleID = '__compute_module_wrapped_reduce-window_kernel_module'
source_filename = "__compute_module_wrapped_reduce-window_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @wrapped_reduce-window(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !5
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !6
  tail call void @llvm.experimental.noalias.scope.decl(metadata !7)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !10)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !12)
  %9 = load i32, ptr %6, align 4, !invariant.load !3, !alias.scope !10, !noalias !14
  br label %10

10:                                               ; preds = %1, %159
  %11 = phi i1 [ true, %1 ], [ false, %159 ]
  %12 = phi i64 [ 0, %1 ], [ 1, %159 ]
  %13 = shl nuw nsw i64 %12, 5
  %14 = add nsw i64 %13, -12
  %.idx1 = mul nuw nsw i64 %12, 18432
  %invariant.gep9 = getelementptr i8, ptr %4, i64 %.idx1
  %.idx = mul nuw nsw i64 %12, 20
  %15 = getelementptr i8, ptr %8, i64 %.idx
  br label %16

16:                                               ; preds = %10, %156
  %17 = phi i64 [ 0, %10 ], [ %158, %156 ]
  %18 = shl nuw nsw i64 %17, 5
  %19 = add nsw i64 %18, -8
  %gep10 = getelementptr i32, ptr %invariant.gep9, i64 %18
  %20 = icmp ult i64 %19, 144
  %21 = add nsw i64 %18, -7
  %22 = icmp ult i64 %21, 144
  %23 = add nsw i64 %18, -6
  %24 = icmp ult i64 %23, 144
  %25 = add nsw i64 %18, -5
  %26 = icmp ult i64 %25, 144
  %27 = add nsw i64 %18, -4
  %28 = icmp ult i64 %27, 144
  %29 = add nsw i64 %18, -3
  %30 = icmp ult i64 %29, 144
  %31 = add nsw i64 %18, -2
  %32 = icmp ult i64 %31, 144
  %33 = add nsw i64 %18, -1
  %34 = icmp ult i64 %33, 144
  %35 = icmp samesign ult i64 %17, 4
  br label %36

36:                                               ; preds = %16, %.split8.us
  %37 = phi i32 [ %9, %16 ], [ %.us-phi, %.split8.us ]
  %38 = phi i64 [ 0, %16 ], [ %155, %.split8.us ]
  %39 = add nsw i64 %14, %38
  %40 = icmp ult i64 %39, 40
  %.idx2 = mul nuw nsw i64 %38, 576
  %41 = getelementptr i8, ptr %gep10, i64 %.idx2
  br i1 %40, label %.split.preheader, label %.split8.us

.split.preheader:                                 ; preds = %36
  br i1 %20, label %42, label %.split.1

42:                                               ; preds = %.split.preheader
  %43 = getelementptr i8, ptr %41, i64 -6944
  %44 = load i32, ptr %43, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %45 = add i32 %44, %37
  br label %.split.1

.split.1:                                         ; preds = %.split.preheader, %42
  %46 = phi i32 [ %45, %42 ], [ %37, %.split.preheader ]
  br i1 %22, label %47, label %.split.2

47:                                               ; preds = %.split.1
  %48 = getelementptr i8, ptr %41, i64 -6940
  %49 = load i32, ptr %48, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %50 = add i32 %49, %46
  br label %.split.2

.split.2:                                         ; preds = %47, %.split.1
  %51 = phi i32 [ %50, %47 ], [ %46, %.split.1 ]
  br i1 %24, label %52, label %.split.3

52:                                               ; preds = %.split.2
  %53 = getelementptr i8, ptr %41, i64 -6936
  %54 = load i32, ptr %53, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %55 = add i32 %54, %51
  br label %.split.3

.split.3:                                         ; preds = %52, %.split.2
  %56 = phi i32 [ %55, %52 ], [ %51, %.split.2 ]
  br i1 %26, label %57, label %.split.4

57:                                               ; preds = %.split.3
  %58 = getelementptr i8, ptr %41, i64 -6932
  %59 = load i32, ptr %58, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %60 = add i32 %59, %56
  br label %.split.4

.split.4:                                         ; preds = %57, %.split.3
  %61 = phi i32 [ %60, %57 ], [ %56, %.split.3 ]
  br i1 %28, label %62, label %.split.5

62:                                               ; preds = %.split.4
  %63 = getelementptr i8, ptr %41, i64 -6928
  %64 = load i32, ptr %63, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %65 = add i32 %64, %61
  br label %.split.5

.split.5:                                         ; preds = %62, %.split.4
  %66 = phi i32 [ %65, %62 ], [ %61, %.split.4 ]
  br i1 %30, label %67, label %.split.6

67:                                               ; preds = %.split.5
  %68 = getelementptr i8, ptr %41, i64 -6924
  %69 = load i32, ptr %68, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %70 = add i32 %69, %66
  br label %.split.6

.split.6:                                         ; preds = %67, %.split.5
  %71 = phi i32 [ %70, %67 ], [ %66, %.split.5 ]
  br i1 %32, label %72, label %.split.7

72:                                               ; preds = %.split.6
  %73 = getelementptr i8, ptr %41, i64 -6920
  %74 = load i32, ptr %73, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %75 = add i32 %74, %71
  br label %.split.7

.split.7:                                         ; preds = %72, %.split.6
  %76 = phi i32 [ %75, %72 ], [ %71, %.split.6 ]
  br i1 %34, label %77, label %.split.24

77:                                               ; preds = %.split.7
  %78 = getelementptr i8, ptr %41, i64 -6916
  %79 = load i32, ptr %78, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %80 = add i32 %79, %76
  br label %.split.24

.split.24:                                        ; preds = %77, %.split.7
  %81 = phi i32 [ %80, %77 ], [ %76, %.split.7 ]
  %82 = getelementptr i8, ptr %41, i64 -6912
  %83 = load i32, ptr %82, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %84 = add i32 %83, %81
  %85 = getelementptr i8, ptr %41, i64 -6908
  %86 = load i32, ptr %85, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %87 = add i32 %86, %84
  %88 = getelementptr i8, ptr %41, i64 -6904
  %89 = load i32, ptr %88, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %90 = add i32 %89, %87
  %91 = getelementptr i8, ptr %41, i64 -6900
  %92 = load i32, ptr %91, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %93 = add i32 %92, %90
  %94 = getelementptr i8, ptr %41, i64 -6896
  %95 = load i32, ptr %94, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %96 = add i32 %95, %93
  %97 = getelementptr i8, ptr %41, i64 -6892
  %98 = load i32, ptr %97, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %99 = add i32 %98, %96
  %100 = getelementptr i8, ptr %41, i64 -6888
  %101 = load i32, ptr %100, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %102 = add i32 %101, %99
  %103 = getelementptr i8, ptr %41, i64 -6884
  %104 = load i32, ptr %103, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %105 = add i32 %104, %102
  %106 = getelementptr i8, ptr %41, i64 -6880
  %107 = load i32, ptr %106, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %108 = add i32 %107, %105
  %109 = getelementptr i8, ptr %41, i64 -6876
  %110 = load i32, ptr %109, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %111 = add i32 %110, %108
  %112 = getelementptr i8, ptr %41, i64 -6872
  %113 = load i32, ptr %112, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %114 = add i32 %113, %111
  %115 = getelementptr i8, ptr %41, i64 -6868
  %116 = load i32, ptr %115, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %117 = add i32 %116, %114
  %118 = getelementptr i8, ptr %41, i64 -6864
  %119 = load i32, ptr %118, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %120 = add i32 %119, %117
  %121 = getelementptr i8, ptr %41, i64 -6860
  %122 = load i32, ptr %121, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %123 = add i32 %122, %120
  %124 = getelementptr i8, ptr %41, i64 -6856
  %125 = load i32, ptr %124, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %126 = add i32 %125, %123
  %127 = getelementptr i8, ptr %41, i64 -6852
  %128 = load i32, ptr %127, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %129 = add i32 %128, %126
  br i1 %35, label %130, label %.split8.us

130:                                              ; preds = %.split.24
  %131 = getelementptr i8, ptr %41, i64 -6848
  %132 = load i32, ptr %131, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %133 = add i32 %132, %129
  %134 = getelementptr i8, ptr %41, i64 -6844
  %135 = load i32, ptr %134, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %136 = add i32 %135, %133
  %137 = getelementptr i8, ptr %41, i64 -6840
  %138 = load i32, ptr %137, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %139 = add i32 %138, %136
  %140 = getelementptr i8, ptr %41, i64 -6836
  %141 = load i32, ptr %140, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %142 = add i32 %141, %139
  %143 = getelementptr i8, ptr %41, i64 -6832
  %144 = load i32, ptr %143, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %145 = add i32 %144, %142
  %146 = getelementptr i8, ptr %41, i64 -6828
  %147 = load i32, ptr %146, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %148 = add i32 %147, %145
  %149 = getelementptr i8, ptr %41, i64 -6824
  %150 = load i32, ptr %149, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %151 = add i32 %150, %148
  %152 = getelementptr i8, ptr %41, i64 -6820
  %153 = load i32, ptr %152, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %154 = add i32 %153, %151
  br label %.split8.us

.split8.us:                                       ; preds = %130, %.split.24, %36
  %.us-phi = phi i32 [ %37, %36 ], [ %154, %130 ], [ %129, %.split.24 ]
  %155 = add nuw nsw i64 %38, 1
  %exitcond.not = icmp eq i64 %155, 32
  br i1 %exitcond.not, label %156, label %36, !llvm.loop !16

156:                                              ; preds = %.split8.us
  %157 = getelementptr i32, ptr %15, i64 %17
  store i32 %.us-phi, ptr %157, align 4, !alias.scope !12, !noalias !18
  %158 = add nuw nsw i64 %17, 1
  %exitcond14.not = icmp eq i64 %158, 5
  br i1 %exitcond14.not, label %159, label %16, !llvm.loop !16

159:                                              ; preds = %156
  br i1 %11, label %10, label %wrapped_reduce-window_wrapped.exit, !llvm.loop !16

wrapped_reduce-window_wrapped.exit:               ; preds = %159
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 5}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 23040}
!5 = !{i64 4}
!6 = !{i64 40}
!7 = !{!8}
!8 = distinct !{!8, !9, !"wrapped_reduce-window_wrapped: argument 0"}
!9 = distinct !{!9, !"wrapped_reduce-window_wrapped"}
!10 = !{!11}
!11 = distinct !{!11, !9, !"wrapped_reduce-window_wrapped: argument 1"}
!12 = !{!13}
!13 = distinct !{!13, !9, !"wrapped_reduce-window_wrapped: argument 2"}
!14 = !{!8, !13}
!15 = !{!11, !13}
!16 = distinct !{!16, !17}
!17 = !{!"llvm.loop.unroll.disable"}
!18 = !{!8, !11}
