; ModuleID = '__compute_module_add_multiply_fusion_kernel_module'
source_filename = "__compute_module_add_multiply_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @add_multiply_fusion(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !5
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !4
  %9 = getelementptr inbounds nuw i8, ptr %3, i64 48
  %10 = load ptr, ptr %9, align 8, !invariant.load !3, !dereferenceable !5
  tail call void @llvm.experimental.noalias.scope.decl(metadata !6)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !11)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !13)
  br label %vector.ph

vector.ph:                                        ; preds = %1, %middle.block
  %11 = phi i64 [ 0, %1 ], [ %41, %middle.block ]
  %12 = mul nuw nsw i64 %11, 144
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %vector.ph
  %index = phi i64 [ 0, %vector.ph ], [ %index.next, %vector.body ]
  %13 = add nuw nsw i64 %index, %12
  %14 = getelementptr inbounds nuw float, ptr %8, i64 %13
  %wide.load = load <8 x float>, ptr %14, align 4, !invariant.load !3, !alias.scope !11, !noalias !15
  %15 = getelementptr inbounds nuw float, ptr %10, i64 %index
  %wide.load3 = load <8 x float>, ptr %15, align 4, !invariant.load !3, !alias.scope !13, !noalias !16
  %16 = fadd <8 x float> %wide.load, %wide.load3
  %17 = fneg <8 x float> %16
  %18 = fcmp uge <8 x float> %17, splat (float 0xC055F33340000000)
  %19 = select <8 x i1> %18, <8 x float> %17, <8 x float> splat (float 0xC055F33340000000)
  %20 = fcmp ule <8 x float> %19, splat (float 0x4056333340000000)
  %21 = select <8 x i1> %20, <8 x float> %19, <8 x float> splat (float 0x4056333340000000)
  %exp_f32.i = fmul <8 x float> %21, splat (float 0x3FF7154760000000)
  %exp_f321.i = fadd <8 x float> splat (float 5.000000e-01), %exp_f32.i
  %22 = call <8 x float> @llvm.floor.v8f32(<8 x float> %exp_f321.i)
  %23 = fcmp uge <8 x float> %22, splat (float -1.270000e+02)
  %24 = select <8 x i1> %23, <8 x float> %22, <8 x float> splat (float -1.270000e+02)
  %25 = fcmp ule <8 x float> %24, splat (float 1.270000e+02)
  %26 = select <8 x i1> %25, <8 x float> %24, <8 x float> splat (float 1.270000e+02)
  %exp_f322.i = fmul <8 x float> splat (float 0x3FE6300000000000), %26
  %27 = fsub <8 x float> %21, %exp_f322.i
  %exp_f323.i = fmul <8 x float> splat (float 0xBF2BD01060000000), %26
  %28 = fsub <8 x float> %27, %exp_f323.i
  %exp_f324.i = fmul <8 x float> %28, splat (float 0x3F2A0D2CE0000000)
  %exp_f325.i = fadd <8 x float> splat (float 0x3F56E879C0000000), %exp_f324.i
  %exp_f326.i = fmul <8 x float> %exp_f325.i, %28
  %exp_f327.i = fadd <8 x float> splat (float 0x3F81112100000000), %exp_f326.i
  %exp_f328.i = fmul <8 x float> %exp_f327.i, %28
  %exp_f329.i = fadd <8 x float> splat (float 0x3FA5553820000000), %exp_f328.i
  %exp_f3210.i = fmul <8 x float> %exp_f329.i, %28
  %exp_f3211.i = fadd <8 x float> splat (float 0x3FC5555540000000), %exp_f3210.i
  %exp_f3212.i = fmul <8 x float> %exp_f3211.i, %28
  %exp_f3213.i = fadd <8 x float> splat (float 5.000000e-01), %exp_f3212.i
  %exp_f3214.i = fmul <8 x float> %28, %28
  %exp_f3215.i = fmul <8 x float> %exp_f3213.i, %exp_f3214.i
  %exp_f3216.i = fadd <8 x float> %28, %exp_f3215.i
  %exp_f3217.i = fadd <8 x float> splat (float 1.000000e+00), %exp_f3216.i
  %29 = fptosi <8 x float> %26 to <8 x i32>
  %30 = add <8 x i32> %29, splat (i32 127)
  %31 = shl <8 x i32> %30, splat (i32 23)
  %32 = bitcast <8 x i32> %31 to <8 x float>
  %exp_f3218.i = fmul <8 x float> %exp_f3217.i, %32
  %33 = fadd <8 x float> %exp_f3218.i, splat (float 1.000000e+00)
  %34 = fdiv <8 x float> splat (float 1.000000e+00), %33
  %35 = getelementptr inbounds nuw float, ptr %4, i64 %13
  %wide.load4 = load <8 x float>, ptr %35, align 4, !alias.scope !6, !noalias !17
  %36 = getelementptr inbounds nuw float, ptr %6, i64 %index
  %wide.load5 = load <8 x float>, ptr %36, align 4, !invariant.load !3, !alias.scope !9, !noalias !18
  %37 = fmul <8 x float> %16, %34
  %38 = fadd <8 x float> %wide.load4, %wide.load5
  %39 = fmul <8 x float> %38, %37
  store <8 x float> %39, ptr %35, align 4, !alias.scope !6, !noalias !17
  %index.next = add nuw i64 %index, 8
  %40 = icmp eq i64 %index.next, 144
  br i1 %40, label %middle.block, label %vector.body, !llvm.loop !19

middle.block:                                     ; preds = %vector.body
  %41 = add nuw nsw i64 %11, 1
  %exitcond2.not = icmp eq i64 %41, 40
  br i1 %exitcond2.not, label %add_multiply_fusion_wrapped.exit, label %vector.ph, !llvm.loop !22

add_multiply_fusion_wrapped.exit:                 ; preds = %middle.block
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <4 x float> @llvm.floor.v4f32(<4 x float>) #2

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.floor.v8f32(<8 x float>) #2

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <16 x float> @llvm.floor.v16f32(<16 x float>) #2

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 1}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 23040}
!5 = !{i64 576}
!6 = !{!7}
!7 = distinct !{!7, !8, !"add_multiply_fusion_wrapped: argument 0"}
!8 = distinct !{!8, !"add_multiply_fusion_wrapped"}
!9 = !{!10}
!10 = distinct !{!10, !8, !"add_multiply_fusion_wrapped: argument 1"}
!11 = !{!12}
!12 = distinct !{!12, !8, !"add_multiply_fusion_wrapped: argument 2"}
!13 = !{!14}
!14 = distinct !{!14, !8, !"add_multiply_fusion_wrapped: argument 3"}
!15 = !{!7, !10, !14}
!16 = !{!7, !10, !12}
!17 = !{!10, !12, !14}
!18 = !{!7, !12, !14}
!19 = distinct !{!19, !20, !21}
!20 = !{!"llvm.loop.isvectorized", i32 1}
!21 = !{!"llvm.loop.unroll.runtime.disable"}
!22 = distinct !{!22, !23}
!23 = !{!"llvm.loop.unroll.disable"}
