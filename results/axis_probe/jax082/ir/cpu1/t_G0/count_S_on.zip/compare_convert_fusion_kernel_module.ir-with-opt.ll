; ModuleID = '__compute_module_compare_convert_fusion_kernel_module'
source_filename = "__compute_module_compare_convert_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @compare_convert_fusion(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !4
  tail call void @llvm.experimental.noalias.scope.decl(metadata !5)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !8)
  br label %iter.check

iter.check:                                       ; preds = %1, %iter.check
  %7 = phi i64 [ 0, %1 ], [ %86, %iter.check ]
  %8 = mul nuw nsw i64 %7, 144
  %9 = getelementptr inbounds nuw float, ptr %4, i64 %8
  %10 = getelementptr inbounds nuw i8, ptr %9, i64 32
  %11 = getelementptr inbounds nuw i8, ptr %9, i64 64
  %12 = getelementptr inbounds nuw i8, ptr %9, i64 96
  %wide.load = load <8 x float>, ptr %9, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %wide.load3 = load <8 x float>, ptr %10, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %wide.load4 = load <8 x float>, ptr %11, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %wide.load5 = load <8 x float>, ptr %12, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %13 = fcmp ogt <8 x float> %wide.load, zeroinitializer
  %14 = fcmp ogt <8 x float> %wide.load3, zeroinitializer
  %15 = fcmp ogt <8 x float> %wide.load4, zeroinitializer
  %16 = fcmp ogt <8 x float> %wide.load5, zeroinitializer
  %17 = zext <8 x i1> %13 to <8 x i32>
  %18 = zext <8 x i1> %14 to <8 x i32>
  %19 = zext <8 x i1> %15 to <8 x i32>
  %20 = zext <8 x i1> %16 to <8 x i32>
  %21 = getelementptr inbounds nuw i32, ptr %6, i64 %8
  %22 = getelementptr inbounds nuw i8, ptr %21, i64 32
  %23 = getelementptr inbounds nuw i8, ptr %21, i64 64
  %24 = getelementptr inbounds nuw i8, ptr %21, i64 96
  store <8 x i32> %17, ptr %21, align 4, !alias.scope !8, !noalias !5
  store <8 x i32> %18, ptr %22, align 4, !alias.scope !8, !noalias !5
  store <8 x i32> %19, ptr %23, align 4, !alias.scope !8, !noalias !5
  store <8 x i32> %20, ptr %24, align 4, !alias.scope !8, !noalias !5
  %25 = add nuw nsw i64 %8, 32
  %26 = getelementptr inbounds nuw float, ptr %4, i64 %25
  %27 = getelementptr inbounds nuw i8, ptr %26, i64 32
  %28 = getelementptr inbounds nuw i8, ptr %26, i64 64
  %29 = getelementptr inbounds nuw i8, ptr %26, i64 96
  %wide.load.1 = load <8 x float>, ptr %26, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %wide.load3.1 = load <8 x float>, ptr %27, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %wide.load4.1 = load <8 x float>, ptr %28, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %wide.load5.1 = load <8 x float>, ptr %29, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %30 = fcmp ogt <8 x float> %wide.load.1, zeroinitializer
  %31 = fcmp ogt <8 x float> %wide.load3.1, zeroinitializer
  %32 = fcmp ogt <8 x float> %wide.load4.1, zeroinitializer
  %33 = fcmp ogt <8 x float> %wide.load5.1, zeroinitializer
  %34 = zext <8 x i1> %30 to <8 x i32>
  %35 = zext <8 x i1> %31 to <8 x i32>
  %36 = zext <8 x i1> %32 to <8 x i32>
  %37 = zext <8 x i1> %33 to <8 x i32>
  %38 = getelementptr inbounds nuw i32, ptr %6, i64 %25
  %39 = getelementptr inbounds nuw i8, ptr %38, i64 32
  %40 = getelementptr inbounds nuw i8, ptr %38, i64 64
  %41 = getelementptr inbounds nuw i8, ptr %38, i64 96
  store <8 x i32> %34, ptr %38, align 4, !alias.scope !8, !noalias !5
  store <8 x i32> %35, ptr %39, align 4, !alias.scope !8, !noalias !5
  store <8 x i32> %36, ptr %40, align 4, !alias.scope !8, !noalias !5
  store <8 x i32> %37, ptr %41, align 4, !alias.scope !8, !noalias !5
  %42 = add nuw nsw i64 %8, 64
  %43 = getelementptr inbounds nuw float, ptr %4, i64 %42
  %44 = getelementptr inbounds nuw i8, ptr %43, i64 32
  %45 = getelementptr inbounds nuw i8, ptr %43, i64 64
  %46 = getelementptr inbounds nuw i8, ptr %43, i64 96
  %wide.load.2 = load <8 x float>, ptr %43, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %wide.load3.2 = load <8 x float>, ptr %44, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %wide.load4.2 = load <8 x float>, ptr %45, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %wide.load5.2 = load <8 x float>, ptr %46, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %47 = fcmp ogt <8 x float> %wide.load.2, zeroinitializer
  %48 = fcmp ogt <8 x float> %wide.load3.2, zeroinitializer
  %49 = fcmp ogt <8 x float> %wide.load4.2, zeroinitializer
  %50 = fcmp ogt <8 x float> %wide.load5.2, zeroinitializer
  %51 = zext <8 x i1> %47 to <8 x i32>
  %52 = zext <8 x i1> %48 to <8 x i32>
  %53 = zext <8 x i1> %49 to <8 x i32>
  %54 = zext <8 x i1> %50 to <8 x i32>
  %55 = getelementptr inbounds nuw i32, ptr %6, i64 %42
  %56 = getelementptr inbounds nuw i8, ptr %55, i64 32
  %57 = getelementptr inbounds nuw i8, ptr %55, i64 64
  %58 = getelementptr inbounds nuw i8, ptr %55, i64 96
  store <8 x i32> %51, ptr %55, align 4, !alias.scope !8, !noalias !5
  store <8 x i32> %52, ptr %56, align 4, !alias.scope !8, !noalias !5
  store <8 x i32> %53, ptr %57, align 4, !alias.scope !8, !noalias !5
  store <8 x i32> %54, ptr %58, align 4, !alias.scope !8, !noalias !5
  %59 = add nuw nsw i64 %8, 96
  %60 = getelementptr inbounds nuw float, ptr %4, i64 %59
  %61 = getelementptr inbounds nuw i8, ptr %60, i64 32
  %62 = getelementptr inbounds nuw i8, ptr %60, i64 64
  %63 = getelementptr inbounds nuw i8, ptr %60, i64 96
  %wide.load.3 = load <8 x float>, ptr %60, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %wide.load3.3 = load <8 x float>, ptr %61, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %wide.load4.3 = load <8 x float>, ptr %62, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %wide.load5.3 = load <8 x float>, ptr %63, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %64 = fcmp ogt <8 x float> %wide.load.3, zeroinitializer
  %65 = fcmp ogt <8 x float> %wide.load3.3, zeroinitializer
  %66 = fcmp ogt <8 x float> %wide.load4.3, zeroinitializer
  %67 = fcmp ogt <8 x float> %wide.load5.3, zeroinitializer
  %68 = zext <8 x i1> %64 to <8 x i32>
  %69 = zext <8 x i1> %65 to <8 x i32>
  %70 = zext <8 x i1> %66 to <8 x i32>
  %71 = zext <8 x i1> %67 to <8 x i32>
  %72 = getelementptr inbounds nuw i32, ptr %6, i64 %59
  %73 = getelementptr inbounds nuw i8, ptr %72, i64 32
  %74 = getelementptr inbounds nuw i8, ptr %72, i64 64
  %75 = getelementptr inbounds nuw i8, ptr %72, i64 96
  store <8 x i32> %68, ptr %72, align 4, !alias.scope !8, !noalias !5
  store <8 x i32> %69, ptr %73, align 4, !alias.scope !8, !noalias !5
  store <8 x i32> %70, ptr %74, align 4, !alias.scope !8, !noalias !5
  store <8 x i32> %71, ptr %75, align 4, !alias.scope !8, !noalias !5
  %76 = add nuw nsw i64 %8, 128
  %77 = getelementptr inbounds nuw float, ptr %4, i64 %76
  %wide.load7 = load <8 x float>, ptr %77, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %78 = fcmp ogt <8 x float> %wide.load7, zeroinitializer
  %79 = zext <8 x i1> %78 to <8 x i32>
  %80 = getelementptr inbounds nuw i32, ptr %6, i64 %76
  store <8 x i32> %79, ptr %80, align 4, !alias.scope !8, !noalias !5
  %81 = add nuw nsw i64 %8, 136
  %82 = getelementptr inbounds nuw float, ptr %4, i64 %81
  %wide.load7.1 = load <8 x float>, ptr %82, align 4, !invariant.load !3, !alias.scope !5, !noalias !8
  %83 = fcmp ogt <8 x float> %wide.load7.1, zeroinitializer
  %84 = zext <8 x i1> %83 to <8 x i32>
  %85 = getelementptr inbounds nuw i32, ptr %6, i64 %81
  store <8 x i32> %84, ptr %85, align 4, !alias.scope !8, !noalias !5
  %86 = add nuw nsw i64 %7, 1
  %exitcond2.not = icmp eq i64 %86, 40
  br i1 %exitcond2.not, label %compare_convert_fusion_wrapped.exit, label %iter.check, !llvm.loop !10

compare_convert_fusion_wrapped.exit:              ; preds = %iter.check
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 2}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 23040}
!5 = !{!6}
!6 = distinct !{!6, !7, !"compare_convert_fusion_wrapped: argument 0"}
!7 = distinct !{!7, !"compare_convert_fusion_wrapped"}
!8 = !{!9}
!9 = distinct !{!9, !7, !"compare_convert_fusion_wrapped: argument 1"}
!10 = distinct !{!10, !11}
!11 = !{!"llvm.loop.unroll.disable"}
