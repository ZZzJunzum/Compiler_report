; ModuleID = '__compute_module_wrapped_reduce_kernel_module'
source_filename = "__compute_module_wrapped_reduce_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

%XLA_CPU_KernelCallFrame = type { ptr, ptr, i64, ptr }
%XLA_CPU_KernelArg = type { ptr, i64 }
%kernel_dim3 = type { i64, i64, i64 }

; Function Attrs: uwtable
define ptr @wrapped_reduce(ptr %0) #0 {
  %2 = getelementptr inbounds %XLA_CPU_KernelCallFrame, ptr %0, i32 0, i32 3
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 0, i32 0
  %5 = load ptr, ptr %4, align 8, !invariant.load !3, !dereferenceable !4
  %6 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 1, i32 0
  %7 = load ptr, ptr %6, align 8, !invariant.load !3, !dereferenceable !5
  %8 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 2, i32 0
  %9 = load ptr, ptr %8, align 8, !invariant.load !3, !dereferenceable !5
  %10 = getelementptr inbounds %XLA_CPU_KernelCallFrame, ptr %0, i32 0, i32 1
  %11 = load ptr, ptr %10, align 8
  %12 = getelementptr inbounds %kernel_dim3, ptr %11, i32 0, i32 0
  %13 = load i64, ptr %12, align 4, !invariant.load !3
  %14 = getelementptr inbounds %kernel_dim3, ptr %11, i32 0, i32 1
  %15 = load i64, ptr %14, align 4, !invariant.load !3
  %16 = getelementptr inbounds %kernel_dim3, ptr %11, i32 0, i32 2
  %17 = load i64, ptr %16, align 4, !invariant.load !3
  call void @wrapped_reduce_wrapped(ptr %5, ptr %7, ptr %9, i64 %13, i64 %15, i64 %17)
  ret ptr null
}

; Function Attrs: alwaysinline
define internal void @wrapped_reduce_wrapped(ptr noalias align 64 dereferenceable(40) %0, ptr noalias align 64 dereferenceable(4) %1, ptr noalias align 64 dereferenceable(4) %2, i64 %3, i64 %4, i64 %5) #1 {
  %7 = getelementptr inbounds [1 x i32], ptr %1, i32 0, i32 0
  %8 = load i32, ptr %7, align 4, !invariant.load !3
  br label %9

9:                                                ; preds = %25, %6
  %10 = phi i64 [ %26, %25 ], [ 0, %6 ]
  %11 = phi i32 [ %17, %25 ], [ %8, %6 ]
  %12 = icmp slt i64 %10, 2
  br i1 %12, label %13, label %27

13:                                               ; preds = %9
  %14 = mul nsw i64 %10, 5
  br label %15

15:                                               ; preds = %19, %13
  %16 = phi i64 [ %24, %19 ], [ 0, %13 ]
  %17 = phi i32 [ %23, %19 ], [ %11, %13 ]
  %18 = icmp slt i64 %16, 5
  br i1 %18, label %19, label %25

19:                                               ; preds = %15
  %20 = add nsw i64 %14, %16
  %21 = getelementptr inbounds [10 x i32], ptr %0, i32 0, i64 %20
  %22 = load i32, ptr %21, align 4, !invariant.load !3
  %23 = add i32 %17, %22
  %24 = add i64 %16, 1
  br label %15

25:                                               ; preds = %15
  %26 = add i64 %10, 1
  br label %9, !llvm.loop !6

27:                                               ; preds = %9
  %28 = getelementptr inbounds [1 x i32], ptr %2, i32 0, i32 0
  store i32 %11, ptr %28, align 4
  ret void
}

attributes #0 = { uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { alwaysinline }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 4}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 40}
!5 = !{i64 4}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.unroll.disable"}
