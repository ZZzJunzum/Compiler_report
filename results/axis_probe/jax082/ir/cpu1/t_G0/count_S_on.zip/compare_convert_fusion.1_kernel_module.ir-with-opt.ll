; ModuleID = '__compute_module_compare_convert_fusion.1_kernel_module'
source_filename = "__compute_module_compare_convert_fusion.1_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @compare_convert_fusion.1(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !5
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !4
  tail call void @llvm.experimental.noalias.scope.decl(metadata !6)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !11)
  %9 = getelementptr inbounds nuw i8, ptr %6, i64 32
  %wide.load4 = load <8 x float>, ptr %6, align 4, !invariant.load !3, !alias.scope !9, !noalias !13
  %wide.load5 = load <8 x float>, ptr %9, align 4, !invariant.load !3, !alias.scope !9, !noalias !13
  %10 = getelementptr inbounds nuw i8, ptr %6, i64 64
  %11 = getelementptr inbounds nuw i8, ptr %6, i64 96
  %wide.load4.1 = load <8 x float>, ptr %10, align 4, !invariant.load !3, !alias.scope !9, !noalias !13
  %wide.load5.1 = load <8 x float>, ptr %11, align 4, !invariant.load !3, !alias.scope !9, !noalias !13
  %12 = getelementptr inbounds nuw i8, ptr %6, i64 128
  %13 = getelementptr inbounds nuw i8, ptr %6, i64 160
  %wide.load4.2 = load <8 x float>, ptr %12, align 4, !invariant.load !3, !alias.scope !9, !noalias !13
  %wide.load5.2 = load <8 x float>, ptr %13, align 4, !invariant.load !3, !alias.scope !9, !noalias !13
  %14 = getelementptr inbounds nuw i8, ptr %6, i64 192
  %15 = getelementptr inbounds nuw i8, ptr %6, i64 224
  %wide.load4.3 = load <8 x float>, ptr %14, align 4, !invariant.load !3, !alias.scope !9, !noalias !13
  %wide.load5.3 = load <8 x float>, ptr %15, align 4, !invariant.load !3, !alias.scope !9, !noalias !13
  %16 = getelementptr inbounds nuw i8, ptr %6, i64 256
  %17 = getelementptr inbounds nuw i8, ptr %6, i64 288
  %wide.load4.4 = load <8 x float>, ptr %16, align 4, !invariant.load !3, !alias.scope !9, !noalias !13
  %wide.load5.4 = load <8 x float>, ptr %17, align 4, !invariant.load !3, !alias.scope !9, !noalias !13
  %18 = getelementptr inbounds nuw i8, ptr %6, i64 320
  %19 = getelementptr inbounds nuw i8, ptr %6, i64 352
  %wide.load4.5 = load <8 x float>, ptr %18, align 4, !invariant.load !3, !alias.scope !9, !noalias !13
  %wide.load5.5 = load <8 x float>, ptr %19, align 4, !invariant.load !3, !alias.scope !9, !noalias !13
  %20 = getelementptr inbounds nuw i8, ptr %6, i64 384
  %21 = getelementptr inbounds nuw i8, ptr %6, i64 416
  %wide.load4.6 = load <8 x float>, ptr %20, align 4, !invariant.load !3, !alias.scope !9, !noalias !13
  %wide.load5.6 = load <8 x float>, ptr %21, align 4, !invariant.load !3, !alias.scope !9, !noalias !13
  %22 = getelementptr inbounds nuw i8, ptr %6, i64 448
  %23 = getelementptr inbounds nuw i8, ptr %6, i64 480
  %wide.load4.7 = load <8 x float>, ptr %22, align 4, !invariant.load !3, !alias.scope !9, !noalias !13
  %wide.load5.7 = load <8 x float>, ptr %23, align 4, !invariant.load !3, !alias.scope !9, !noalias !13
  %24 = getelementptr inbounds nuw i8, ptr %6, i64 512
  %25 = getelementptr inbounds nuw i8, ptr %6, i64 544
  %wide.load4.8 = load <8 x float>, ptr %24, align 4, !invariant.load !3, !alias.scope !9, !noalias !13
  %wide.load5.8 = load <8 x float>, ptr %25, align 4, !invariant.load !3, !alias.scope !9, !noalias !13
  br label %vector.ph

vector.ph:                                        ; preds = %1, %vector.ph
  %26 = phi i64 [ 0, %1 ], [ %126, %vector.ph ]
  %27 = mul nuw nsw i64 %26, 144
  %28 = getelementptr inbounds nuw float, ptr %4, i64 %27
  %29 = getelementptr inbounds nuw i8, ptr %28, i64 32
  %wide.load = load <8 x float>, ptr %28, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %wide.load3 = load <8 x float>, ptr %29, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %30 = fadd <8 x float> %wide.load, %wide.load4
  %31 = fadd <8 x float> %wide.load3, %wide.load5
  %32 = fcmp ogt <8 x float> %30, zeroinitializer
  %33 = fcmp ogt <8 x float> %31, zeroinitializer
  %34 = zext <8 x i1> %32 to <8 x i32>
  %35 = zext <8 x i1> %33 to <8 x i32>
  %36 = getelementptr inbounds nuw i32, ptr %8, i64 %27
  %37 = getelementptr inbounds nuw i8, ptr %36, i64 32
  store <8 x i32> %34, ptr %36, align 4, !alias.scope !11, !noalias !15
  store <8 x i32> %35, ptr %37, align 4, !alias.scope !11, !noalias !15
  %38 = add nuw nsw i64 %27, 16
  %39 = getelementptr inbounds nuw float, ptr %4, i64 %38
  %40 = getelementptr inbounds nuw i8, ptr %39, i64 32
  %wide.load.1 = load <8 x float>, ptr %39, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %wide.load3.1 = load <8 x float>, ptr %40, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %41 = fadd <8 x float> %wide.load.1, %wide.load4.1
  %42 = fadd <8 x float> %wide.load3.1, %wide.load5.1
  %43 = fcmp ogt <8 x float> %41, zeroinitializer
  %44 = fcmp ogt <8 x float> %42, zeroinitializer
  %45 = zext <8 x i1> %43 to <8 x i32>
  %46 = zext <8 x i1> %44 to <8 x i32>
  %47 = getelementptr inbounds nuw i32, ptr %8, i64 %38
  %48 = getelementptr inbounds nuw i8, ptr %47, i64 32
  store <8 x i32> %45, ptr %47, align 4, !alias.scope !11, !noalias !15
  store <8 x i32> %46, ptr %48, align 4, !alias.scope !11, !noalias !15
  %49 = add nuw nsw i64 %27, 32
  %50 = getelementptr inbounds nuw float, ptr %4, i64 %49
  %51 = getelementptr inbounds nuw i8, ptr %50, i64 32
  %wide.load.2 = load <8 x float>, ptr %50, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %wide.load3.2 = load <8 x float>, ptr %51, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %52 = fadd <8 x float> %wide.load.2, %wide.load4.2
  %53 = fadd <8 x float> %wide.load3.2, %wide.load5.2
  %54 = fcmp ogt <8 x float> %52, zeroinitializer
  %55 = fcmp ogt <8 x float> %53, zeroinitializer
  %56 = zext <8 x i1> %54 to <8 x i32>
  %57 = zext <8 x i1> %55 to <8 x i32>
  %58 = getelementptr inbounds nuw i32, ptr %8, i64 %49
  %59 = getelementptr inbounds nuw i8, ptr %58, i64 32
  store <8 x i32> %56, ptr %58, align 4, !alias.scope !11, !noalias !15
  store <8 x i32> %57, ptr %59, align 4, !alias.scope !11, !noalias !15
  %60 = add nuw nsw i64 %27, 48
  %61 = getelementptr inbounds nuw float, ptr %4, i64 %60
  %62 = getelementptr inbounds nuw i8, ptr %61, i64 32
  %wide.load.3 = load <8 x float>, ptr %61, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %wide.load3.3 = load <8 x float>, ptr %62, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %63 = fadd <8 x float> %wide.load.3, %wide.load4.3
  %64 = fadd <8 x float> %wide.load3.3, %wide.load5.3
  %65 = fcmp ogt <8 x float> %63, zeroinitializer
  %66 = fcmp ogt <8 x float> %64, zeroinitializer
  %67 = zext <8 x i1> %65 to <8 x i32>
  %68 = zext <8 x i1> %66 to <8 x i32>
  %69 = getelementptr inbounds nuw i32, ptr %8, i64 %60
  %70 = getelementptr inbounds nuw i8, ptr %69, i64 32
  store <8 x i32> %67, ptr %69, align 4, !alias.scope !11, !noalias !15
  store <8 x i32> %68, ptr %70, align 4, !alias.scope !11, !noalias !15
  %71 = add nuw nsw i64 %27, 64
  %72 = getelementptr inbounds nuw float, ptr %4, i64 %71
  %73 = getelementptr inbounds nuw i8, ptr %72, i64 32
  %wide.load.4 = load <8 x float>, ptr %72, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %wide.load3.4 = load <8 x float>, ptr %73, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %74 = fadd <8 x float> %wide.load.4, %wide.load4.4
  %75 = fadd <8 x float> %wide.load3.4, %wide.load5.4
  %76 = fcmp ogt <8 x float> %74, zeroinitializer
  %77 = fcmp ogt <8 x float> %75, zeroinitializer
  %78 = zext <8 x i1> %76 to <8 x i32>
  %79 = zext <8 x i1> %77 to <8 x i32>
  %80 = getelementptr inbounds nuw i32, ptr %8, i64 %71
  %81 = getelementptr inbounds nuw i8, ptr %80, i64 32
  store <8 x i32> %78, ptr %80, align 4, !alias.scope !11, !noalias !15
  store <8 x i32> %79, ptr %81, align 4, !alias.scope !11, !noalias !15
  %82 = add nuw nsw i64 %27, 80
  %83 = getelementptr inbounds nuw float, ptr %4, i64 %82
  %84 = getelementptr inbounds nuw i8, ptr %83, i64 32
  %wide.load.5 = load <8 x float>, ptr %83, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %wide.load3.5 = load <8 x float>, ptr %84, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %85 = fadd <8 x float> %wide.load.5, %wide.load4.5
  %86 = fadd <8 x float> %wide.load3.5, %wide.load5.5
  %87 = fcmp ogt <8 x float> %85, zeroinitializer
  %88 = fcmp ogt <8 x float> %86, zeroinitializer
  %89 = zext <8 x i1> %87 to <8 x i32>
  %90 = zext <8 x i1> %88 to <8 x i32>
  %91 = getelementptr inbounds nuw i32, ptr %8, i64 %82
  %92 = getelementptr inbounds nuw i8, ptr %91, i64 32
  store <8 x i32> %89, ptr %91, align 4, !alias.scope !11, !noalias !15
  store <8 x i32> %90, ptr %92, align 4, !alias.scope !11, !noalias !15
  %93 = add nuw nsw i64 %27, 96
  %94 = getelementptr inbounds nuw float, ptr %4, i64 %93
  %95 = getelementptr inbounds nuw i8, ptr %94, i64 32
  %wide.load.6 = load <8 x float>, ptr %94, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %wide.load3.6 = load <8 x float>, ptr %95, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %96 = fadd <8 x float> %wide.load.6, %wide.load4.6
  %97 = fadd <8 x float> %wide.load3.6, %wide.load5.6
  %98 = fcmp ogt <8 x float> %96, zeroinitializer
  %99 = fcmp ogt <8 x float> %97, zeroinitializer
  %100 = zext <8 x i1> %98 to <8 x i32>
  %101 = zext <8 x i1> %99 to <8 x i32>
  %102 = getelementptr inbounds nuw i32, ptr %8, i64 %93
  %103 = getelementptr inbounds nuw i8, ptr %102, i64 32
  store <8 x i32> %100, ptr %102, align 4, !alias.scope !11, !noalias !15
  store <8 x i32> %101, ptr %103, align 4, !alias.scope !11, !noalias !15
  %104 = add nuw nsw i64 %27, 112
  %105 = getelementptr inbounds nuw float, ptr %4, i64 %104
  %106 = getelementptr inbounds nuw i8, ptr %105, i64 32
  %wide.load.7 = load <8 x float>, ptr %105, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %wide.load3.7 = load <8 x float>, ptr %106, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %107 = fadd <8 x float> %wide.load.7, %wide.load4.7
  %108 = fadd <8 x float> %wide.load3.7, %wide.load5.7
  %109 = fcmp ogt <8 x float> %107, zeroinitializer
  %110 = fcmp ogt <8 x float> %108, zeroinitializer
  %111 = zext <8 x i1> %109 to <8 x i32>
  %112 = zext <8 x i1> %110 to <8 x i32>
  %113 = getelementptr inbounds nuw i32, ptr %8, i64 %104
  %114 = getelementptr inbounds nuw i8, ptr %113, i64 32
  store <8 x i32> %111, ptr %113, align 4, !alias.scope !11, !noalias !15
  store <8 x i32> %112, ptr %114, align 4, !alias.scope !11, !noalias !15
  %115 = add nuw nsw i64 %27, 128
  %116 = getelementptr inbounds nuw float, ptr %4, i64 %115
  %117 = getelementptr inbounds nuw i8, ptr %116, i64 32
  %wide.load.8 = load <8 x float>, ptr %116, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %wide.load3.8 = load <8 x float>, ptr %117, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %118 = fadd <8 x float> %wide.load.8, %wide.load4.8
  %119 = fadd <8 x float> %wide.load3.8, %wide.load5.8
  %120 = fcmp ogt <8 x float> %118, zeroinitializer
  %121 = fcmp ogt <8 x float> %119, zeroinitializer
  %122 = zext <8 x i1> %120 to <8 x i32>
  %123 = zext <8 x i1> %121 to <8 x i32>
  %124 = getelementptr inbounds nuw i32, ptr %8, i64 %115
  %125 = getelementptr inbounds nuw i8, ptr %124, i64 32
  store <8 x i32> %122, ptr %124, align 4, !alias.scope !11, !noalias !15
  store <8 x i32> %123, ptr %125, align 4, !alias.scope !11, !noalias !15
  %126 = add nuw nsw i64 %26, 1
  %exitcond2.not = icmp eq i64 %126, 40
  br i1 %exitcond2.not, label %compare_convert_fusion.1_wrapped.exit, label %vector.ph, !llvm.loop !16

compare_convert_fusion.1_wrapped.exit:            ; preds = %vector.ph
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 3}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 23040}
!5 = !{i64 576}
!6 = !{!7}
!7 = distinct !{!7, !8, !"compare_convert_fusion.1_wrapped: argument 0"}
!8 = distinct !{!8, !"compare_convert_fusion.1_wrapped"}
!9 = !{!10}
!10 = distinct !{!10, !8, !"compare_convert_fusion.1_wrapped: argument 1"}
!11 = !{!12}
!12 = distinct !{!12, !8, !"compare_convert_fusion.1_wrapped: argument 2"}
!13 = !{!7, !12}
!14 = !{!10, !12}
!15 = !{!7, !10}
!16 = distinct !{!16, !17}
!17 = !{!"llvm.loop.unroll.disable"}
