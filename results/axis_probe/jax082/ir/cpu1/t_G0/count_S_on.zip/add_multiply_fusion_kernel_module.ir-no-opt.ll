; ModuleID = '__compute_module_add_multiply_fusion_kernel_module'
source_filename = "__compute_module_add_multiply_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

%XLA_CPU_KernelCallFrame = type { ptr, ptr, i64, ptr }
%XLA_CPU_KernelArg = type { ptr, i64 }
%kernel_dim3 = type { i64, i64, i64 }

; Function Attrs: uwtable
define ptr @add_multiply_fusion(ptr %0) #0 {
  %2 = getelementptr inbounds %XLA_CPU_KernelCallFrame, ptr %0, i32 0, i32 3
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 0, i32 0
  %5 = load ptr, ptr %4, align 8, !invariant.load !3, !dereferenceable !4
  %6 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 1, i32 0
  %7 = load ptr, ptr %6, align 8, !invariant.load !3, !dereferenceable !5
  %8 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 2, i32 0
  %9 = load ptr, ptr %8, align 8, !invariant.load !3, !dereferenceable !4
  %10 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 3, i32 0
  %11 = load ptr, ptr %10, align 8, !invariant.load !3, !dereferenceable !5
  %12 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 4, i32 0
  %13 = load ptr, ptr %12, align 8, !invariant.load !3, !dereferenceable !4
  %14 = getelementptr inbounds %XLA_CPU_KernelCallFrame, ptr %0, i32 0, i32 1
  %15 = load ptr, ptr %14, align 8
  %16 = getelementptr inbounds %kernel_dim3, ptr %15, i32 0, i32 0
  %17 = load i64, ptr %16, align 4, !invariant.load !3
  %18 = getelementptr inbounds %kernel_dim3, ptr %15, i32 0, i32 1
  %19 = load i64, ptr %18, align 4, !invariant.load !3
  %20 = getelementptr inbounds %kernel_dim3, ptr %15, i32 0, i32 2
  %21 = load i64, ptr %20, align 4, !invariant.load !3
  call void @add_multiply_fusion_wrapped(ptr %5, ptr %7, ptr %9, ptr %11, ptr %13, i64 %17, i64 %19, i64 %21)
  ret ptr null
}

; Function Attrs: alwaysinline
define internal void @add_multiply_fusion_wrapped(ptr noalias align 64 dereferenceable(23040) %0, ptr noalias align 64 dereferenceable(576) %1, ptr noalias align 64 dereferenceable(23040) %2, ptr noalias align 64 dereferenceable(576) %3, ptr noalias align 64 dereferenceable(23040) %4, i64 %5, i64 %6, i64 %7) #1 {
  br label %9

9:                                                ; preds = %36, %8
  %10 = phi i64 [ %37, %36 ], [ 0, %8 ]
  %11 = icmp slt i64 %10, 40
  br i1 %11, label %12, label %38

12:                                               ; preds = %9
  %13 = mul nsw i64 %10, 144
  br label %14

14:                                               ; preds = %17, %12
  %15 = phi i64 [ %35, %17 ], [ 0, %12 ]
  %16 = icmp slt i64 %15, 144
  br i1 %16, label %17, label %36

17:                                               ; preds = %14
  %18 = add nsw i64 %13, %15
  %19 = getelementptr inbounds [5760 x float], ptr %2, i32 0, i64 %18
  %20 = load float, ptr %19, align 4, !invariant.load !3
  %21 = getelementptr inbounds [144 x float], ptr %3, i32 0, i64 %15
  %22 = load float, ptr %21, align 4, !invariant.load !3
  %23 = fadd float %20, %22
  %24 = fneg float %23
  %25 = call float @llvm.exp.f32(float %24)
  %26 = fadd float %25, 1.000000e+00
  %27 = fdiv float 1.000000e+00, %26
  %28 = getelementptr inbounds [5760 x float], ptr %0, i32 0, i64 %18
  %29 = load float, ptr %28, align 4
  %30 = getelementptr inbounds [144 x float], ptr %1, i32 0, i64 %15
  %31 = load float, ptr %30, align 4, !invariant.load !3
  %32 = fmul float %23, %27
  %33 = fadd float %29, %31
  %34 = fmul float %32, %33
  store float %34, ptr %28, align 4
  %35 = add i64 %15, 1
  br label %14

36:                                               ; preds = %14
  %37 = add i64 %10, 1
  br label %9, !llvm.loop !6

38:                                               ; preds = %9
  ret void
}

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.exp.f32(float) #2

attributes #0 = { uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { alwaysinline }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 1}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 23040}
!5 = !{i64 576}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.unroll.disable"}
