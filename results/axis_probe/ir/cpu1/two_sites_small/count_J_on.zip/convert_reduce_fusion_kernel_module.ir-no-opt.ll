; ModuleID = '__compute_module_convert_reduce_fusion_kernel_module'
source_filename = "__compute_module_convert_reduce_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

%XLA_CPU_KernelCallFrame = type { ptr, ptr, i64, ptr }
%XLA_CPU_KernelArg = type { ptr, i64 }
%kernel_dim3 = type { i64, i64, i64 }

; Function Attrs: uwtable
define ptr @convert_reduce_fusion(ptr %0) #0 {
  %2 = getelementptr inbounds %XLA_CPU_KernelCallFrame, ptr %0, i32 0, i32 3
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 0, i32 0
  %5 = load ptr, ptr %4, align 8, !invariant.load !3, !dereferenceable !4
  %6 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 1, i32 0
  %7 = load ptr, ptr %6, align 8, !invariant.load !3, !dereferenceable !4
  %8 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 2, i32 0
  %9 = load ptr, ptr %8, align 8, !invariant.load !3, !dereferenceable !4
  %10 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 3, i32 0
  %11 = load ptr, ptr %10, align 8, !invariant.load !3, !dereferenceable !5
  %12 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 4, i32 0
  %13 = load ptr, ptr %12, align 8, !invariant.load !3, !dereferenceable !4
  %14 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 5, i32 0
  %15 = load ptr, ptr %14, align 8, !invariant.load !3, !dereferenceable !6
  %16 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 6, i32 0
  %17 = load ptr, ptr %16, align 8, !invariant.load !3, !dereferenceable !6
  %18 = getelementptr inbounds %XLA_CPU_KernelCallFrame, ptr %0, i32 0, i32 1
  %19 = load ptr, ptr %18, align 8
  %20 = getelementptr inbounds %kernel_dim3, ptr %19, i32 0, i32 0
  %21 = load i64, ptr %20, align 4, !invariant.load !3
  %22 = getelementptr inbounds %kernel_dim3, ptr %19, i32 0, i32 1
  %23 = load i64, ptr %22, align 4, !invariant.load !3
  %24 = getelementptr inbounds %kernel_dim3, ptr %19, i32 0, i32 2
  %25 = load i64, ptr %24, align 4, !invariant.load !3
  call void @convert_reduce_fusion_wrapped(ptr %5, ptr %7, ptr %9, ptr %11, ptr %13, ptr %15, ptr %17, i64 %21, i64 %23, i64 %25)
  ret ptr null
}

; Function Attrs: alwaysinline
define internal void @convert_reduce_fusion_wrapped(ptr noalias align 64 dereferenceable(640) %0, ptr noalias align 64 dereferenceable(640) %1, ptr noalias align 64 dereferenceable(640) %2, ptr noalias align 64 dereferenceable(2560) %3, ptr noalias align 64 dereferenceable(640) %4, ptr noalias align 64 dereferenceable(4) %5, ptr noalias align 64 dereferenceable(4) %6, i64 %7, i64 %8, i64 %9) #1 {
  br label %11

11:                                               ; preds = %47, %10
  %12 = phi i64 [ %48, %47 ], [ 0, %10 ]
  %13 = phi i32 [ %20, %47 ], [ 0, %10 ]
  %14 = phi i32 [ %21, %47 ], [ 0, %10 ]
  %15 = icmp slt i64 %12, 4
  br i1 %15, label %16, label %49

16:                                               ; preds = %11
  %17 = mul nsw i64 %12, 160
  br label %18

18:                                               ; preds = %23, %16
  %19 = phi i64 [ %46, %23 ], [ 0, %16 ]
  %20 = phi i32 [ %44, %23 ], [ %13, %16 ]
  %21 = phi i32 [ %45, %23 ], [ %14, %16 ]
  %22 = icmp slt i64 %19, 160
  br i1 %22, label %23, label %47

23:                                               ; preds = %18
  %24 = add nsw i64 %17, %19
  %25 = getelementptr inbounds [640 x float], ptr %3, i32 0, i64 %24
  %26 = load float, ptr %25, align 4, !invariant.load !3
  %27 = getelementptr inbounds [160 x float], ptr %4, i32 0, i64 %19
  %28 = load float, ptr %27, align 4, !invariant.load !3
  %29 = fmul float %26, %28
  %30 = getelementptr inbounds [160 x float], ptr %2, i32 0, i64 %19
  %31 = load float, ptr %30, align 4, !invariant.load !3
  %32 = fadd float %29, %31
  %33 = fcmp ogt float %32, 0.000000e+00
  %34 = zext i1 %33 to i32
  %35 = call float @llvm.maximum.f32(float %32, float 0.000000e+00)
  %36 = getelementptr inbounds [160 x float], ptr %1, i32 0, i64 %19
  %37 = load float, ptr %36, align 4, !invariant.load !3
  %38 = fmul float %35, %37
  %39 = getelementptr inbounds [160 x float], ptr %0, i32 0, i64 %19
  %40 = load float, ptr %39, align 4, !invariant.load !3
  %41 = fadd float %38, %40
  %42 = fcmp ogt float %41, 0.000000e+00
  %43 = zext i1 %42 to i32
  %44 = add i32 %20, %34
  %45 = add i32 %21, %43
  %46 = add i64 %19, 1
  br label %18

47:                                               ; preds = %18
  %48 = add i64 %12, 1
  br label %11, !llvm.loop !7

49:                                               ; preds = %11
  %50 = getelementptr inbounds [1 x i32], ptr %5, i32 0, i32 0
  store i32 %13, ptr %50, align 4
  %51 = getelementptr inbounds [1 x i32], ptr %6, i32 0, i32 0
  store i32 %14, ptr %51, align 4
  ret void
}

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.maximum.f32(float, float) #2

attributes #0 = { uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { alwaysinline }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 0}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 640}
!5 = !{i64 2560}
!6 = !{i64 4}
!7 = distinct !{!7, !8}
!8 = !{!"llvm.loop.unroll.disable"}
