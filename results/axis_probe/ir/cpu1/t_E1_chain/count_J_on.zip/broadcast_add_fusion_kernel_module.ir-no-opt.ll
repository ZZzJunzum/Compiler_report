; ModuleID = '__compute_module_broadcast_add_fusion_kernel_module'
source_filename = "__compute_module_broadcast_add_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

%XLA_CPU_KernelCallFrame = type { ptr, ptr, i64, ptr }
%XLA_CPU_KernelArg = type { ptr, i64 }
%kernel_dim3 = type { i64, i64, i64 }

; Function Attrs: uwtable
define ptr @broadcast_add_fusion(ptr %0) #0 {
  %2 = getelementptr inbounds %XLA_CPU_KernelCallFrame, ptr %0, i32 0, i32 3
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 0, i32 0
  %5 = load ptr, ptr %4, align 8, !invariant.load !3, !dereferenceable !4
  %6 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 1, i32 0
  %7 = load ptr, ptr %6, align 8, !invariant.load !3, !dereferenceable !4
  %8 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 2, i32 0
  %9 = load ptr, ptr %8, align 8, !invariant.load !3, !dereferenceable !4
  %10 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 3, i32 0
  %11 = load ptr, ptr %10, align 8, !invariant.load !3, !dereferenceable !4
  %12 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 4, i32 0
  %13 = load ptr, ptr %12, align 8, !invariant.load !3, !dereferenceable !4
  %14 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 5, i32 0
  %15 = load ptr, ptr %14, align 8, !invariant.load !3, !dereferenceable !5
  %16 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 6, i32 0
  %17 = load ptr, ptr %16, align 8, !invariant.load !3, !dereferenceable !4
  %18 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 7, i32 0
  %19 = load ptr, ptr %18, align 8, !invariant.load !3, !dereferenceable !5
  %20 = getelementptr inbounds %XLA_CPU_KernelCallFrame, ptr %0, i32 0, i32 1
  %21 = load ptr, ptr %20, align 8
  %22 = getelementptr inbounds %kernel_dim3, ptr %21, i32 0, i32 0
  %23 = load i64, ptr %22, align 4, !invariant.load !3
  %24 = getelementptr inbounds %kernel_dim3, ptr %21, i32 0, i32 1
  %25 = load i64, ptr %24, align 4, !invariant.load !3
  %26 = getelementptr inbounds %kernel_dim3, ptr %21, i32 0, i32 2
  %27 = load i64, ptr %26, align 4, !invariant.load !3
  call void @broadcast_add_fusion_wrapped(ptr %5, ptr %7, ptr %9, ptr %11, ptr %13, ptr %15, ptr %17, ptr %19, i64 %23, i64 %25, i64 %27)
  ret ptr null
}

; Function Attrs: alwaysinline
define internal void @broadcast_add_fusion_wrapped(ptr noalias align 64 dereferenceable(640) %0, ptr noalias align 64 dereferenceable(640) %1, ptr noalias align 64 dereferenceable(640) %2, ptr noalias align 64 dereferenceable(640) %3, ptr noalias align 64 dereferenceable(640) %4, ptr noalias align 64 dereferenceable(204800) %5, ptr noalias align 64 dereferenceable(640) %6, ptr noalias align 64 dereferenceable(204800) %7, i64 %8, i64 %9, i64 %10) #1 {
  %12 = icmp sle i64 %8, 10
  br i1 %12, label %13, label %59

13:                                               ; preds = %11
  %14 = icmp sge i64 %8, 0
  br i1 %14, label %15, label %58

15:                                               ; preds = %13
  %16 = mul nsw i64 %8, 4320
  br label %17

17:                                               ; preds = %55, %15
  %18 = phi i64 [ %56, %55 ], [ 0, %15 ]
  %19 = icmp slt i64 %18, 27
  br i1 %19, label %20, label %57

20:                                               ; preds = %17
  %21 = mul nsw i64 %18, 160
  %22 = add nsw i64 %16, %21
  br label %23

23:                                               ; preds = %26, %20
  %24 = phi i64 [ %54, %26 ], [ 0, %20 ]
  %25 = icmp slt i64 %24, 160
  br i1 %25, label %26, label %55

26:                                               ; preds = %23
  %27 = add nsw i64 %22, %24
  %28 = getelementptr inbounds [51200 x float], ptr %5, i32 0, i64 %27
  %29 = load float, ptr %28, align 4, !invariant.load !3
  %30 = getelementptr inbounds [160 x float], ptr %6, i32 0, i64 %24
  %31 = load float, ptr %30, align 4, !invariant.load !3
  %32 = fmul float %29, %31
  %33 = getelementptr inbounds [160 x float], ptr %4, i32 0, i64 %24
  %34 = load float, ptr %33, align 4, !invariant.load !3
  %35 = fadd float %32, %34
  %36 = call float @llvm.maximum.f32(float %35, float 0.000000e+00)
  %37 = getelementptr inbounds [160 x float], ptr %3, i32 0, i64 %24
  %38 = load float, ptr %37, align 4, !invariant.load !3
  %39 = fmul float %36, %38
  %40 = getelementptr inbounds [160 x float], ptr %2, i32 0, i64 %24
  %41 = load float, ptr %40, align 4, !invariant.load !3
  %42 = fadd float %39, %41
  %43 = call float @llvm.maximum.f32(float %42, float 0.000000e+00)
  %44 = getelementptr inbounds [160 x float], ptr %1, i32 0, i64 %24
  %45 = load float, ptr %44, align 4, !invariant.load !3
  %46 = fmul float %43, %45
  %47 = getelementptr inbounds [160 x float], ptr %0, i32 0, i64 %24
  %48 = load float, ptr %47, align 4, !invariant.load !3
  %49 = fadd float %46, %48
  %50 = call float @llvm.maximum.f32(float %49, float 0.000000e+00)
  %51 = fmul float %50, 7.500000e-01
  %52 = fadd float %51, 1.250000e-01
  %53 = getelementptr inbounds [51200 x float], ptr %7, i32 0, i64 %27
  store float %52, ptr %53, align 4
  %54 = add i64 %24, 1
  br label %23

55:                                               ; preds = %23
  %56 = add i64 %18, 1
  br label %17, !llvm.loop !6

57:                                               ; preds = %17, %62
  br label %58

58:                                               ; preds = %57, %13, %59
  br label %102

59:                                               ; preds = %11
  %60 = icmp eq i64 %8, 11
  br i1 %60, label %61, label %58

61:                                               ; preds = %59
  br label %62

62:                                               ; preds = %100, %61
  %63 = phi i64 [ %101, %100 ], [ 0, %61 ]
  %64 = icmp slt i64 %63, 23
  br i1 %64, label %65, label %57

65:                                               ; preds = %62
  %66 = mul nsw i64 %63, 160
  br label %67

67:                                               ; preds = %70, %65
  %68 = phi i64 [ %99, %70 ], [ 0, %65 ]
  %69 = icmp slt i64 %68, 160
  br i1 %69, label %70, label %100

70:                                               ; preds = %67
  %71 = add nsw i64 %66, %68
  %72 = add nsw i64 %71, 47520
  %73 = getelementptr inbounds [51200 x float], ptr %5, i32 0, i64 %72
  %74 = load float, ptr %73, align 4, !invariant.load !3
  %75 = getelementptr inbounds [160 x float], ptr %6, i32 0, i64 %68
  %76 = load float, ptr %75, align 4, !invariant.load !3
  %77 = fmul float %74, %76
  %78 = getelementptr inbounds [160 x float], ptr %4, i32 0, i64 %68
  %79 = load float, ptr %78, align 4, !invariant.load !3
  %80 = fadd float %77, %79
  %81 = call float @llvm.maximum.f32(float %80, float 0.000000e+00)
  %82 = getelementptr inbounds [160 x float], ptr %3, i32 0, i64 %68
  %83 = load float, ptr %82, align 4, !invariant.load !3
  %84 = fmul float %81, %83
  %85 = getelementptr inbounds [160 x float], ptr %2, i32 0, i64 %68
  %86 = load float, ptr %85, align 4, !invariant.load !3
  %87 = fadd float %84, %86
  %88 = call float @llvm.maximum.f32(float %87, float 0.000000e+00)
  %89 = getelementptr inbounds [160 x float], ptr %1, i32 0, i64 %68
  %90 = load float, ptr %89, align 4, !invariant.load !3
  %91 = fmul float %88, %90
  %92 = getelementptr inbounds [160 x float], ptr %0, i32 0, i64 %68
  %93 = load float, ptr %92, align 4, !invariant.load !3
  %94 = fadd float %91, %93
  %95 = call float @llvm.maximum.f32(float %94, float 0.000000e+00)
  %96 = fmul float %95, 7.500000e-01
  %97 = fadd float %96, 1.250000e-01
  %98 = getelementptr inbounds [51200 x float], ptr %7, i32 0, i64 %72
  store float %97, ptr %98, align 4
  %99 = add i64 %68, 1
  br label %67

100:                                              ; preds = %67
  %101 = add i64 %63, 1
  br label %62, !llvm.loop !6

102:                                              ; preds = %58
  ret void
}

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.maximum.f32(float, float) #2

attributes #0 = { uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { alwaysinline }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 0}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 640}
!5 = !{i64 204800}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.unroll.disable"}
