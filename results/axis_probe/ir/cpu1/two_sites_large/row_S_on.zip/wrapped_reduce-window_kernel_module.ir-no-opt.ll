; ModuleID = '__compute_module_wrapped_reduce-window_kernel_module'
source_filename = "__compute_module_wrapped_reduce-window_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

%XLA_CPU_KernelCallFrame = type { ptr, ptr, i64, ptr }
%XLA_CPU_KernelArg = type { ptr, i64 }
%kernel_dim3 = type { i64, i64, i64 }

; Function Attrs: uwtable
define ptr @wrapped_reduce-window(ptr %0) #0 {
  %2 = getelementptr inbounds %XLA_CPU_KernelCallFrame, ptr %0, i32 0, i32 3
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 0, i32 0
  %5 = load ptr, ptr %4, align 8, !invariant.load !3, !dereferenceable !4
  %6 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 1, i32 0
  %7 = load ptr, ptr %6, align 8, !invariant.load !3, !dereferenceable !5
  %8 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 2, i32 0
  %9 = load ptr, ptr %8, align 8, !invariant.load !3, !dereferenceable !6
  %10 = getelementptr inbounds %XLA_CPU_KernelCallFrame, ptr %0, i32 0, i32 1
  %11 = load ptr, ptr %10, align 8
  %12 = getelementptr inbounds %kernel_dim3, ptr %11, i32 0, i32 0
  %13 = load i64, ptr %12, align 4, !invariant.load !3
  %14 = getelementptr inbounds %kernel_dim3, ptr %11, i32 0, i32 1
  %15 = load i64, ptr %14, align 4, !invariant.load !3
  %16 = getelementptr inbounds %kernel_dim3, ptr %11, i32 0, i32 2
  %17 = load i64, ptr %16, align 4, !invariant.load !3
  call void @wrapped_reduce-window_wrapped(ptr %5, ptr %7, ptr %9, i64 %13, i64 %15, i64 %17)
  ret ptr null
}

; Function Attrs: alwaysinline
define internal void @wrapped_reduce-window_wrapped(ptr noalias align 64 dereferenceable(184320) %0, ptr noalias align 64 dereferenceable(4) %1, ptr noalias align 64 dereferenceable(5760) %2, i64 %3, i64 %4, i64 %5) #1 {
  %7 = getelementptr inbounds [1 x i32], ptr %1, i32 0, i32 0
  %8 = load i32, ptr %7, align 4, !invariant.load !3
  br label %9

9:                                                ; preds = %35, %6
  %10 = phi i64 [ %36, %35 ], [ 0, %6 ]
  %11 = icmp slt i64 %10, 288
  br i1 %11, label %12, label %37

12:                                               ; preds = %9
  %13 = mul nsw i64 %10, 160
  %14 = mul nsw i64 %10, 5
  br label %15

15:                                               ; preds = %31, %12
  %16 = phi i64 [ %34, %31 ], [ 0, %12 ]
  %17 = icmp slt i64 %16, 5
  br i1 %17, label %18, label %35

18:                                               ; preds = %15
  %19 = mul nsw i64 %16, 32
  %20 = add nsw i64 %13, %19
  br label %21

21:                                               ; preds = %25, %18
  %22 = phi i64 [ %30, %25 ], [ 0, %18 ]
  %23 = phi i32 [ %29, %25 ], [ %8, %18 ]
  %24 = icmp slt i64 %22, 32
  br i1 %24, label %25, label %31

25:                                               ; preds = %21
  %26 = add nsw i64 %20, %22
  %27 = getelementptr inbounds [46080 x i32], ptr %0, i32 0, i64 %26
  %28 = load i32, ptr %27, align 4, !invariant.load !3
  %29 = add i32 %23, %28
  %30 = add i64 %22, 1
  br label %21

31:                                               ; preds = %21
  %32 = add nsw i64 %14, %16
  %33 = getelementptr inbounds [1440 x i32], ptr %2, i32 0, i64 %32
  store i32 %23, ptr %33, align 4
  %34 = add i64 %16, 1
  br label %15, !llvm.loop !7

35:                                               ; preds = %15
  %36 = add i64 %10, 1
  br label %9, !llvm.loop !7

37:                                               ; preds = %9
  ret void
}

attributes #0 = { uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { alwaysinline }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 3}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 184320}
!5 = !{i64 4}
!6 = !{i64 5760}
!7 = distinct !{!7, !8}
!8 = !{!"llvm.loop.unroll.disable"}
