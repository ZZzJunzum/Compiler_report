; ModuleID = '__compute_module_wrapped_reduce_kernel_module'
source_filename = "__compute_module_wrapped_reduce_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @wrapped_reduce(ptr readonly captures(none) %0) local_unnamed_addr #0 {
vector.ph:
  tail call void @llvm.experimental.noalias.scope.decl(metadata !3)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !6)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !8)
  %1 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %2 = load ptr, ptr %1, align 8, !invariant.load !10
  %3 = load ptr, ptr %2, align 8, !invariant.load !10, !dereferenceable !11
  %wide.vec = load <6 x i32>, ptr %3, align 4, !invariant.load !10, !alias.scope !3, !noalias !12
  %strided.vec3 = shufflevector <6 x i32> %wide.vec, <6 x i32> poison, <2 x i32> <i32 2, i32 5>
  %strided.vec2 = shufflevector <6 x i32> %wide.vec, <6 x i32> poison, <2 x i32> <i32 1, i32 4>
  %strided.vec = shufflevector <6 x i32> %wide.vec, <6 x i32> poison, <2 x i32> <i32 0, i32 3>
  %4 = getelementptr inbounds nuw i8, ptr %2, i64 16
  %5 = load ptr, ptr %4, align 8, !invariant.load !10, !dereferenceable !13
  %6 = load i32, ptr %5, align 4, !invariant.load !10, !alias.scope !6, !noalias !14
  %7 = insertelement <2 x i32> <i32 poison, i32 0>, i32 %6, i64 0
  %8 = add <2 x i32> %strided.vec, %7
  %9 = add <2 x i32> %strided.vec2, %8
  %10 = add <2 x i32> %strided.vec3, %9
  %11 = tail call i32 @llvm.vector.reduce.add.v2i32(<2 x i32> %10)
  %12 = getelementptr inbounds nuw i8, ptr %2, i64 32
  %13 = load ptr, ptr %12, align 8, !invariant.load !10, !dereferenceable !13
  store i32 %11, ptr %13, align 4, !alias.scope !8, !noalias !15
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.vector.reduce.add.v2i32(<2 x i32>) #2

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #2 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 3}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{!4}
!4 = distinct !{!4, !5, !"wrapped_reduce_wrapped: argument 0"}
!5 = distinct !{!5, !"wrapped_reduce_wrapped"}
!6 = !{!7}
!7 = distinct !{!7, !5, !"wrapped_reduce_wrapped: argument 1"}
!8 = !{!9}
!9 = distinct !{!9, !5, !"wrapped_reduce_wrapped: argument 2"}
!10 = !{}
!11 = !{i64 24}
!12 = !{!7, !9}
!13 = !{i64 4}
!14 = !{!4, !9}
!15 = !{!4, !7}
