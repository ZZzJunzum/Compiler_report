; ModuleID = '__compute_module_compare_convert_fusion.1_kernel_module'
source_filename = "__compute_module_compare_convert_fusion.1_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

%XLA_CPU_KernelCallFrame = type { ptr, ptr, i64, ptr }
%XLA_CPU_KernelArg = type { ptr, i64 }
%kernel_dim3 = type { i64, i64, i64 }

; Function Attrs: uwtable
define ptr @compare_convert_fusion.1(ptr %0) #0 {
  %2 = getelementptr inbounds %XLA_CPU_KernelCallFrame, ptr %0, i32 0, i32 3
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 0, i32 0
  %5 = load ptr, ptr %4, align 8, !invariant.load !3, !dereferenceable !4
  %6 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 1, i32 0
  %7 = load ptr, ptr %6, align 8, !invariant.load !3, !dereferenceable !5
  %8 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 2, i32 0
  %9 = load ptr, ptr %8, align 8, !invariant.load !3, !dereferenceable !4
  %10 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 3, i32 0
  %11 = load ptr, ptr %10, align 8, !invariant.load !3, !dereferenceable !5
  %12 = getelementptr inbounds %XLA_CPU_KernelCallFrame, ptr %0, i32 0, i32 1
  %13 = load ptr, ptr %12, align 8
  %14 = getelementptr inbounds %kernel_dim3, ptr %13, i32 0, i32 0
  %15 = load i64, ptr %14, align 4, !invariant.load !3
  %16 = getelementptr inbounds %kernel_dim3, ptr %13, i32 0, i32 1
  %17 = load i64, ptr %16, align 4, !invariant.load !3
  %18 = getelementptr inbounds %kernel_dim3, ptr %13, i32 0, i32 2
  %19 = load i64, ptr %18, align 4, !invariant.load !3
  call void @compare_convert_fusion.1_wrapped(ptr %5, ptr %7, ptr %9, ptr %11, i64 %15, i64 %17, i64 %19)
  ret ptr null
}

; Function Attrs: alwaysinline
define internal void @compare_convert_fusion.1_wrapped(ptr noalias align 64 dereferenceable(320) %0, ptr noalias align 64 dereferenceable(15360) %1, ptr noalias align 64 dereferenceable(320) %2, ptr noalias align 64 dereferenceable(15360) %3, i64 %4, i64 %5, i64 %6) #1 {
  br label %8

8:                                                ; preds = %30, %7
  %9 = phi i64 [ %31, %30 ], [ 0, %7 ]
  %10 = icmp slt i64 %9, 48
  br i1 %10, label %11, label %32

11:                                               ; preds = %8
  %12 = mul nsw i64 %9, 80
  br label %13

13:                                               ; preds = %16, %11
  %14 = phi i64 [ %29, %16 ], [ 0, %11 ]
  %15 = icmp slt i64 %14, 80
  br i1 %15, label %16, label %30

16:                                               ; preds = %13
  %17 = add nsw i64 %12, %14
  %18 = getelementptr inbounds [3840 x float], ptr %1, i32 0, i64 %17
  %19 = load float, ptr %18, align 4, !invariant.load !3
  %20 = getelementptr inbounds [80 x float], ptr %2, i32 0, i64 %14
  %21 = load float, ptr %20, align 4, !invariant.load !3
  %22 = fmul float %19, %21
  %23 = getelementptr inbounds [80 x float], ptr %0, i32 0, i64 %14
  %24 = load float, ptr %23, align 4, !invariant.load !3
  %25 = fadd float %22, %24
  %26 = fcmp ogt float %25, 0.000000e+00
  %27 = zext i1 %26 to i32
  %28 = getelementptr inbounds [3840 x i32], ptr %3, i32 0, i64 %17
  store i32 %27, ptr %28, align 4
  %29 = add i64 %14, 1
  br label %13

30:                                               ; preds = %13
  %31 = add i64 %9, 1
  br label %8, !llvm.loop !6

32:                                               ; preds = %8
  ret void
}

attributes #0 = { uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { alwaysinline }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 2}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 320}
!5 = !{i64 15360}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.unroll.disable"}
