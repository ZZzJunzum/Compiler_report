; ModuleID = '__compute_module_compare_convert_fusion_kernel_module'
source_filename = "__compute_module_compare_convert_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @compare_convert_fusion(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !4
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !4
  %9 = getelementptr inbounds nuw i8, ptr %3, i64 48
  %10 = load ptr, ptr %9, align 8, !invariant.load !3, !dereferenceable !5
  %11 = getelementptr inbounds nuw i8, ptr %3, i64 64
  %12 = load ptr, ptr %11, align 8, !invariant.load !3, !dereferenceable !4
  %13 = getelementptr inbounds nuw i8, ptr %3, i64 80
  %14 = load ptr, ptr %13, align 8, !invariant.load !3, !dereferenceable !5
  tail call void @llvm.experimental.noalias.scope.decl(metadata !6)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !11)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !13)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !15)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !17)
  %15 = getelementptr inbounds nuw i8, ptr %12, i64 32
  %wide.load4 = load <8 x float>, ptr %12, align 4, !invariant.load !3, !alias.scope !15, !noalias !19
  %wide.load5 = load <8 x float>, ptr %15, align 4, !invariant.load !3, !alias.scope !15, !noalias !19
  %16 = getelementptr inbounds nuw i8, ptr %8, i64 32
  %wide.load6 = load <8 x float>, ptr %8, align 4, !invariant.load !3, !alias.scope !11, !noalias !20
  %wide.load7 = load <8 x float>, ptr %16, align 4, !invariant.load !3, !alias.scope !11, !noalias !20
  %17 = getelementptr inbounds nuw i8, ptr %6, i64 32
  %wide.load8 = load <8 x float>, ptr %6, align 4, !invariant.load !3, !alias.scope !9, !noalias !21
  %wide.load9 = load <8 x float>, ptr %17, align 4, !invariant.load !3, !alias.scope !9, !noalias !21
  %18 = getelementptr inbounds nuw i8, ptr %4, i64 32
  %wide.load10 = load <8 x float>, ptr %4, align 4, !invariant.load !3, !alias.scope !6, !noalias !22
  %wide.load11 = load <8 x float>, ptr %18, align 4, !invariant.load !3, !alias.scope !6, !noalias !22
  %19 = getelementptr inbounds nuw i8, ptr %12, i64 64
  %20 = getelementptr inbounds nuw i8, ptr %12, i64 96
  %wide.load4.1 = load <8 x float>, ptr %19, align 4, !invariant.load !3, !alias.scope !15, !noalias !19
  %wide.load5.1 = load <8 x float>, ptr %20, align 4, !invariant.load !3, !alias.scope !15, !noalias !19
  %21 = getelementptr inbounds nuw i8, ptr %8, i64 64
  %22 = getelementptr inbounds nuw i8, ptr %8, i64 96
  %wide.load6.1 = load <8 x float>, ptr %21, align 4, !invariant.load !3, !alias.scope !11, !noalias !20
  %wide.load7.1 = load <8 x float>, ptr %22, align 4, !invariant.load !3, !alias.scope !11, !noalias !20
  %23 = getelementptr inbounds nuw i8, ptr %6, i64 64
  %24 = getelementptr inbounds nuw i8, ptr %6, i64 96
  %wide.load8.1 = load <8 x float>, ptr %23, align 4, !invariant.load !3, !alias.scope !9, !noalias !21
  %wide.load9.1 = load <8 x float>, ptr %24, align 4, !invariant.load !3, !alias.scope !9, !noalias !21
  %25 = getelementptr inbounds nuw i8, ptr %4, i64 64
  %26 = getelementptr inbounds nuw i8, ptr %4, i64 96
  %wide.load10.1 = load <8 x float>, ptr %25, align 4, !invariant.load !3, !alias.scope !6, !noalias !22
  %wide.load11.1 = load <8 x float>, ptr %26, align 4, !invariant.load !3, !alias.scope !6, !noalias !22
  %27 = getelementptr inbounds nuw i8, ptr %12, i64 128
  %28 = getelementptr inbounds nuw i8, ptr %12, i64 160
  %wide.load4.2 = load <8 x float>, ptr %27, align 4, !invariant.load !3, !alias.scope !15, !noalias !19
  %wide.load5.2 = load <8 x float>, ptr %28, align 4, !invariant.load !3, !alias.scope !15, !noalias !19
  %29 = getelementptr inbounds nuw i8, ptr %8, i64 128
  %30 = getelementptr inbounds nuw i8, ptr %8, i64 160
  %wide.load6.2 = load <8 x float>, ptr %29, align 4, !invariant.load !3, !alias.scope !11, !noalias !20
  %wide.load7.2 = load <8 x float>, ptr %30, align 4, !invariant.load !3, !alias.scope !11, !noalias !20
  %31 = getelementptr inbounds nuw i8, ptr %6, i64 128
  %32 = getelementptr inbounds nuw i8, ptr %6, i64 160
  %wide.load8.2 = load <8 x float>, ptr %31, align 4, !invariant.load !3, !alias.scope !9, !noalias !21
  %wide.load9.2 = load <8 x float>, ptr %32, align 4, !invariant.load !3, !alias.scope !9, !noalias !21
  %33 = getelementptr inbounds nuw i8, ptr %4, i64 128
  %34 = getelementptr inbounds nuw i8, ptr %4, i64 160
  %wide.load10.2 = load <8 x float>, ptr %33, align 4, !invariant.load !3, !alias.scope !6, !noalias !22
  %wide.load11.2 = load <8 x float>, ptr %34, align 4, !invariant.load !3, !alias.scope !6, !noalias !22
  %35 = getelementptr inbounds nuw i8, ptr %12, i64 192
  %36 = getelementptr inbounds nuw i8, ptr %12, i64 224
  %wide.load4.3 = load <8 x float>, ptr %35, align 4, !invariant.load !3, !alias.scope !15, !noalias !19
  %wide.load5.3 = load <8 x float>, ptr %36, align 4, !invariant.load !3, !alias.scope !15, !noalias !19
  %37 = getelementptr inbounds nuw i8, ptr %8, i64 192
  %38 = getelementptr inbounds nuw i8, ptr %8, i64 224
  %wide.load6.3 = load <8 x float>, ptr %37, align 4, !invariant.load !3, !alias.scope !11, !noalias !20
  %wide.load7.3 = load <8 x float>, ptr %38, align 4, !invariant.load !3, !alias.scope !11, !noalias !20
  %39 = getelementptr inbounds nuw i8, ptr %6, i64 192
  %40 = getelementptr inbounds nuw i8, ptr %6, i64 224
  %wide.load8.3 = load <8 x float>, ptr %39, align 4, !invariant.load !3, !alias.scope !9, !noalias !21
  %wide.load9.3 = load <8 x float>, ptr %40, align 4, !invariant.load !3, !alias.scope !9, !noalias !21
  %41 = getelementptr inbounds nuw i8, ptr %4, i64 192
  %42 = getelementptr inbounds nuw i8, ptr %4, i64 224
  %wide.load10.3 = load <8 x float>, ptr %41, align 4, !invariant.load !3, !alias.scope !6, !noalias !22
  %wide.load11.3 = load <8 x float>, ptr %42, align 4, !invariant.load !3, !alias.scope !6, !noalias !22
  %43 = getelementptr inbounds nuw i8, ptr %12, i64 256
  %44 = getelementptr inbounds nuw i8, ptr %12, i64 288
  %wide.load4.4 = load <8 x float>, ptr %43, align 4, !invariant.load !3, !alias.scope !15, !noalias !19
  %wide.load5.4 = load <8 x float>, ptr %44, align 4, !invariant.load !3, !alias.scope !15, !noalias !19
  %45 = getelementptr inbounds nuw i8, ptr %8, i64 256
  %46 = getelementptr inbounds nuw i8, ptr %8, i64 288
  %wide.load6.4 = load <8 x float>, ptr %45, align 4, !invariant.load !3, !alias.scope !11, !noalias !20
  %wide.load7.4 = load <8 x float>, ptr %46, align 4, !invariant.load !3, !alias.scope !11, !noalias !20
  %47 = getelementptr inbounds nuw i8, ptr %6, i64 256
  %48 = getelementptr inbounds nuw i8, ptr %6, i64 288
  %wide.load8.4 = load <8 x float>, ptr %47, align 4, !invariant.load !3, !alias.scope !9, !noalias !21
  %wide.load9.4 = load <8 x float>, ptr %48, align 4, !invariant.load !3, !alias.scope !9, !noalias !21
  %49 = getelementptr inbounds nuw i8, ptr %4, i64 256
  %50 = getelementptr inbounds nuw i8, ptr %4, i64 288
  %wide.load10.4 = load <8 x float>, ptr %49, align 4, !invariant.load !3, !alias.scope !6, !noalias !22
  %wide.load11.4 = load <8 x float>, ptr %50, align 4, !invariant.load !3, !alias.scope !6, !noalias !22
  br label %vector.ph

vector.ph:                                        ; preds = %1, %vector.ph
  %51 = phi i64 [ 0, %1 ], [ %147, %vector.ph ]
  %52 = mul nuw nsw i64 %51, 80
  %53 = getelementptr inbounds nuw float, ptr %10, i64 %52
  %54 = getelementptr inbounds nuw i8, ptr %53, i64 32
  %wide.load = load <8 x float>, ptr %53, align 4, !invariant.load !3, !alias.scope !13, !noalias !23
  %wide.load3 = load <8 x float>, ptr %54, align 4, !invariant.load !3, !alias.scope !13, !noalias !23
  %55 = fmul <8 x float> %wide.load, %wide.load4
  %56 = fmul <8 x float> %wide.load3, %wide.load5
  %57 = fadd <8 x float> %55, %wide.load6
  %58 = fadd <8 x float> %56, %wide.load7
  %59 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %57, <8 x float> zeroinitializer)
  %60 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %58, <8 x float> zeroinitializer)
  %61 = fmul <8 x float> %wide.load8, %59
  %62 = fmul <8 x float> %wide.load9, %60
  %63 = fadd <8 x float> %wide.load10, %61
  %64 = fadd <8 x float> %wide.load11, %62
  %65 = fcmp ogt <8 x float> %63, zeroinitializer
  %66 = fcmp ogt <8 x float> %64, zeroinitializer
  %67 = zext <8 x i1> %65 to <8 x i32>
  %68 = zext <8 x i1> %66 to <8 x i32>
  %69 = getelementptr inbounds nuw i32, ptr %14, i64 %52
  %70 = getelementptr inbounds nuw i8, ptr %69, i64 32
  store <8 x i32> %67, ptr %69, align 4, !alias.scope !17, !noalias !24
  store <8 x i32> %68, ptr %70, align 4, !alias.scope !17, !noalias !24
  %71 = add nuw nsw i64 %52, 16
  %72 = getelementptr inbounds nuw float, ptr %10, i64 %71
  %73 = getelementptr inbounds nuw i8, ptr %72, i64 32
  %wide.load.1 = load <8 x float>, ptr %72, align 4, !invariant.load !3, !alias.scope !13, !noalias !23
  %wide.load3.1 = load <8 x float>, ptr %73, align 4, !invariant.load !3, !alias.scope !13, !noalias !23
  %74 = fmul <8 x float> %wide.load.1, %wide.load4.1
  %75 = fmul <8 x float> %wide.load3.1, %wide.load5.1
  %76 = fadd <8 x float> %74, %wide.load6.1
  %77 = fadd <8 x float> %75, %wide.load7.1
  %78 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %76, <8 x float> zeroinitializer)
  %79 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %77, <8 x float> zeroinitializer)
  %80 = fmul <8 x float> %wide.load8.1, %78
  %81 = fmul <8 x float> %wide.load9.1, %79
  %82 = fadd <8 x float> %wide.load10.1, %80
  %83 = fadd <8 x float> %wide.load11.1, %81
  %84 = fcmp ogt <8 x float> %82, zeroinitializer
  %85 = fcmp ogt <8 x float> %83, zeroinitializer
  %86 = zext <8 x i1> %84 to <8 x i32>
  %87 = zext <8 x i1> %85 to <8 x i32>
  %88 = getelementptr inbounds nuw i32, ptr %14, i64 %71
  %89 = getelementptr inbounds nuw i8, ptr %88, i64 32
  store <8 x i32> %86, ptr %88, align 4, !alias.scope !17, !noalias !24
  store <8 x i32> %87, ptr %89, align 4, !alias.scope !17, !noalias !24
  %90 = add nuw nsw i64 %52, 32
  %91 = getelementptr inbounds nuw float, ptr %10, i64 %90
  %92 = getelementptr inbounds nuw i8, ptr %91, i64 32
  %wide.load.2 = load <8 x float>, ptr %91, align 4, !invariant.load !3, !alias.scope !13, !noalias !23
  %wide.load3.2 = load <8 x float>, ptr %92, align 4, !invariant.load !3, !alias.scope !13, !noalias !23
  %93 = fmul <8 x float> %wide.load.2, %wide.load4.2
  %94 = fmul <8 x float> %wide.load3.2, %wide.load5.2
  %95 = fadd <8 x float> %93, %wide.load6.2
  %96 = fadd <8 x float> %94, %wide.load7.2
  %97 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %95, <8 x float> zeroinitializer)
  %98 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %96, <8 x float> zeroinitializer)
  %99 = fmul <8 x float> %wide.load8.2, %97
  %100 = fmul <8 x float> %wide.load9.2, %98
  %101 = fadd <8 x float> %wide.load10.2, %99
  %102 = fadd <8 x float> %wide.load11.2, %100
  %103 = fcmp ogt <8 x float> %101, zeroinitializer
  %104 = fcmp ogt <8 x float> %102, zeroinitializer
  %105 = zext <8 x i1> %103 to <8 x i32>
  %106 = zext <8 x i1> %104 to <8 x i32>
  %107 = getelementptr inbounds nuw i32, ptr %14, i64 %90
  %108 = getelementptr inbounds nuw i8, ptr %107, i64 32
  store <8 x i32> %105, ptr %107, align 4, !alias.scope !17, !noalias !24
  store <8 x i32> %106, ptr %108, align 4, !alias.scope !17, !noalias !24
  %109 = add nuw nsw i64 %52, 48
  %110 = getelementptr inbounds nuw float, ptr %10, i64 %109
  %111 = getelementptr inbounds nuw i8, ptr %110, i64 32
  %wide.load.3 = load <8 x float>, ptr %110, align 4, !invariant.load !3, !alias.scope !13, !noalias !23
  %wide.load3.3 = load <8 x float>, ptr %111, align 4, !invariant.load !3, !alias.scope !13, !noalias !23
  %112 = fmul <8 x float> %wide.load.3, %wide.load4.3
  %113 = fmul <8 x float> %wide.load3.3, %wide.load5.3
  %114 = fadd <8 x float> %112, %wide.load6.3
  %115 = fadd <8 x float> %113, %wide.load7.3
  %116 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %114, <8 x float> zeroinitializer)
  %117 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %115, <8 x float> zeroinitializer)
  %118 = fmul <8 x float> %wide.load8.3, %116
  %119 = fmul <8 x float> %wide.load9.3, %117
  %120 = fadd <8 x float> %wide.load10.3, %118
  %121 = fadd <8 x float> %wide.load11.3, %119
  %122 = fcmp ogt <8 x float> %120, zeroinitializer
  %123 = fcmp ogt <8 x float> %121, zeroinitializer
  %124 = zext <8 x i1> %122 to <8 x i32>
  %125 = zext <8 x i1> %123 to <8 x i32>
  %126 = getelementptr inbounds nuw i32, ptr %14, i64 %109
  %127 = getelementptr inbounds nuw i8, ptr %126, i64 32
  store <8 x i32> %124, ptr %126, align 4, !alias.scope !17, !noalias !24
  store <8 x i32> %125, ptr %127, align 4, !alias.scope !17, !noalias !24
  %128 = add nuw nsw i64 %52, 64
  %129 = getelementptr inbounds nuw float, ptr %10, i64 %128
  %130 = getelementptr inbounds nuw i8, ptr %129, i64 32
  %wide.load.4 = load <8 x float>, ptr %129, align 4, !invariant.load !3, !alias.scope !13, !noalias !23
  %wide.load3.4 = load <8 x float>, ptr %130, align 4, !invariant.load !3, !alias.scope !13, !noalias !23
  %131 = fmul <8 x float> %wide.load.4, %wide.load4.4
  %132 = fmul <8 x float> %wide.load3.4, %wide.load5.4
  %133 = fadd <8 x float> %131, %wide.load6.4
  %134 = fadd <8 x float> %132, %wide.load7.4
  %135 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %133, <8 x float> zeroinitializer)
  %136 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %134, <8 x float> zeroinitializer)
  %137 = fmul <8 x float> %wide.load8.4, %135
  %138 = fmul <8 x float> %wide.load9.4, %136
  %139 = fadd <8 x float> %wide.load10.4, %137
  %140 = fadd <8 x float> %wide.load11.4, %138
  %141 = fcmp ogt <8 x float> %139, zeroinitializer
  %142 = fcmp ogt <8 x float> %140, zeroinitializer
  %143 = zext <8 x i1> %141 to <8 x i32>
  %144 = zext <8 x i1> %142 to <8 x i32>
  %145 = getelementptr inbounds nuw i32, ptr %14, i64 %128
  %146 = getelementptr inbounds nuw i8, ptr %145, i64 32
  store <8 x i32> %143, ptr %145, align 4, !alias.scope !17, !noalias !24
  store <8 x i32> %144, ptr %146, align 4, !alias.scope !17, !noalias !24
  %147 = add nuw nsw i64 %51, 1
  %exitcond2.not = icmp eq i64 %147, 48
  br i1 %exitcond2.not, label %compare_convert_fusion_wrapped.exit, label %vector.ph, !llvm.loop !25

compare_convert_fusion_wrapped.exit:              ; preds = %vector.ph
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.maximum.v8f32(<8 x float>, <8 x float>) #2

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 1}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 320}
!5 = !{i64 15360}
!6 = !{!7}
!7 = distinct !{!7, !8, !"compare_convert_fusion_wrapped: argument 0"}
!8 = distinct !{!8, !"compare_convert_fusion_wrapped"}
!9 = !{!10}
!10 = distinct !{!10, !8, !"compare_convert_fusion_wrapped: argument 1"}
!11 = !{!12}
!12 = distinct !{!12, !8, !"compare_convert_fusion_wrapped: argument 2"}
!13 = !{!14}
!14 = distinct !{!14, !8, !"compare_convert_fusion_wrapped: argument 3"}
!15 = !{!16}
!16 = distinct !{!16, !8, !"compare_convert_fusion_wrapped: argument 4"}
!17 = !{!18}
!18 = distinct !{!18, !8, !"compare_convert_fusion_wrapped: argument 5"}
!19 = !{!7, !10, !12, !14, !18}
!20 = !{!7, !10, !14, !16, !18}
!21 = !{!7, !12, !14, !16, !18}
!22 = !{!10, !12, !14, !16, !18}
!23 = !{!7, !10, !12, !16, !18}
!24 = !{!7, !10, !12, !14, !16}
!25 = distinct !{!25, !26}
!26 = !{!"llvm.loop.unroll.disable"}
