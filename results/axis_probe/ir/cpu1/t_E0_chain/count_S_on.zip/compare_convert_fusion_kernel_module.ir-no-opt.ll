; ModuleID = '__compute_module_compare_convert_fusion_kernel_module'
source_filename = "__compute_module_compare_convert_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

%XLA_CPU_KernelCallFrame = type { ptr, ptr, i64, ptr }
%XLA_CPU_KernelArg = type { ptr, i64 }
%kernel_dim3 = type { i64, i64, i64 }

; Function Attrs: uwtable
define ptr @compare_convert_fusion(ptr %0) #0 {
  %2 = getelementptr inbounds %XLA_CPU_KernelCallFrame, ptr %0, i32 0, i32 3
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 0, i32 0
  %5 = load ptr, ptr %4, align 8, !invariant.load !3, !dereferenceable !4
  %6 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 1, i32 0
  %7 = load ptr, ptr %6, align 8, !invariant.load !3, !dereferenceable !4
  %8 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 2, i32 0
  %9 = load ptr, ptr %8, align 8, !invariant.load !3, !dereferenceable !4
  %10 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 3, i32 0
  %11 = load ptr, ptr %10, align 8, !invariant.load !3, !dereferenceable !5
  %12 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 4, i32 0
  %13 = load ptr, ptr %12, align 8, !invariant.load !3, !dereferenceable !4
  %14 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 5, i32 0
  %15 = load ptr, ptr %14, align 8, !invariant.load !3, !dereferenceable !5
  %16 = getelementptr inbounds %XLA_CPU_KernelCallFrame, ptr %0, i32 0, i32 1
  %17 = load ptr, ptr %16, align 8
  %18 = getelementptr inbounds %kernel_dim3, ptr %17, i32 0, i32 0
  %19 = load i64, ptr %18, align 4, !invariant.load !3
  %20 = getelementptr inbounds %kernel_dim3, ptr %17, i32 0, i32 1
  %21 = load i64, ptr %20, align 4, !invariant.load !3
  %22 = getelementptr inbounds %kernel_dim3, ptr %17, i32 0, i32 2
  %23 = load i64, ptr %22, align 4, !invariant.load !3
  call void @compare_convert_fusion_wrapped(ptr %5, ptr %7, ptr %9, ptr %11, ptr %13, ptr %15, i64 %19, i64 %21, i64 %23)
  ret ptr null
}

; Function Attrs: alwaysinline
define internal void @compare_convert_fusion_wrapped(ptr noalias align 64 dereferenceable(320) %0, ptr noalias align 64 dereferenceable(320) %1, ptr noalias align 64 dereferenceable(320) %2, ptr noalias align 64 dereferenceable(15360) %3, ptr noalias align 64 dereferenceable(320) %4, ptr noalias align 64 dereferenceable(15360) %5, i64 %6, i64 %7, i64 %8) #1 {
  br label %10

10:                                               ; preds = %39, %9
  %11 = phi i64 [ %40, %39 ], [ 0, %9 ]
  %12 = icmp slt i64 %11, 48
  br i1 %12, label %13, label %41

13:                                               ; preds = %10
  %14 = mul nsw i64 %11, 80
  br label %15

15:                                               ; preds = %18, %13
  %16 = phi i64 [ %38, %18 ], [ 0, %13 ]
  %17 = icmp slt i64 %16, 80
  br i1 %17, label %18, label %39

18:                                               ; preds = %15
  %19 = add nsw i64 %14, %16
  %20 = getelementptr inbounds [3840 x float], ptr %3, i32 0, i64 %19
  %21 = load float, ptr %20, align 4, !invariant.load !3
  %22 = getelementptr inbounds [80 x float], ptr %4, i32 0, i64 %16
  %23 = load float, ptr %22, align 4, !invariant.load !3
  %24 = fmul float %21, %23
  %25 = getelementptr inbounds [80 x float], ptr %2, i32 0, i64 %16
  %26 = load float, ptr %25, align 4, !invariant.load !3
  %27 = fadd float %24, %26
  %28 = call float @llvm.maximum.f32(float %27, float 0.000000e+00)
  %29 = getelementptr inbounds [80 x float], ptr %1, i32 0, i64 %16
  %30 = load float, ptr %29, align 4, !invariant.load !3
  %31 = fmul float %28, %30
  %32 = getelementptr inbounds [80 x float], ptr %0, i32 0, i64 %16
  %33 = load float, ptr %32, align 4, !invariant.load !3
  %34 = fadd float %31, %33
  %35 = fcmp ogt float %34, 0.000000e+00
  %36 = zext i1 %35 to i32
  %37 = getelementptr inbounds [3840 x i32], ptr %5, i32 0, i64 %19
  store i32 %36, ptr %37, align 4
  %38 = add i64 %16, 1
  br label %15

39:                                               ; preds = %15
  %40 = add i64 %11, 1
  br label %10, !llvm.loop !6

41:                                               ; preds = %10
  ret void
}

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.maximum.f32(float, float) #2

attributes #0 = { uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { alwaysinline }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 1}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 320}
!5 = !{i64 15360}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.unroll.disable"}
