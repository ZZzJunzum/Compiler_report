; ModuleID = '__compute_module_broadcast_add_fusion_kernel_module'
source_filename = "__compute_module_broadcast_add_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @broadcast_add_fusion(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !4
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !4
  %9 = getelementptr inbounds nuw i8, ptr %3, i64 48
  %10 = load ptr, ptr %9, align 8, !invariant.load !3, !dereferenceable !4
  %11 = getelementptr inbounds nuw i8, ptr %3, i64 64
  %12 = load ptr, ptr %11, align 8, !invariant.load !3, !dereferenceable !4
  %13 = getelementptr inbounds nuw i8, ptr %3, i64 80
  %14 = load ptr, ptr %13, align 8, !invariant.load !3, !dereferenceable !5
  %15 = getelementptr inbounds nuw i8, ptr %3, i64 96
  %16 = load ptr, ptr %15, align 8, !invariant.load !3, !dereferenceable !4
  %17 = getelementptr inbounds nuw i8, ptr %3, i64 112
  %18 = load ptr, ptr %17, align 8, !invariant.load !3, !dereferenceable !5
  %19 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %20 = load ptr, ptr %19, align 8
  %21 = load i64, ptr %20, align 4, !invariant.load !3
  tail call void @llvm.experimental.noalias.scope.decl(metadata !6)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !11)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !13)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !15)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !17)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !19)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !21)
  %22 = icmp ult i64 %21, 3
  br i1 %22, label %23, label %broadcast_add_fusion_wrapped.exit

23:                                               ; preds = %1
  %24 = mul nuw nsw i64 %21, 1280
  %wide.load5 = load <8 x float>, ptr %16, align 4, !invariant.load !3, !alias.scope !19, !noalias !23
  %wide.load6 = load <8 x float>, ptr %12, align 4, !invariant.load !3, !alias.scope !15, !noalias !24
  %wide.load7 = load <8 x float>, ptr %10, align 4, !invariant.load !3, !alias.scope !13, !noalias !25
  %wide.load8 = load <8 x float>, ptr %8, align 4, !invariant.load !3, !alias.scope !11, !noalias !26
  %wide.load9 = load <8 x float>, ptr %6, align 4, !invariant.load !3, !alias.scope !9, !noalias !27
  %wide.load10 = load <8 x float>, ptr %4, align 4, !invariant.load !3, !alias.scope !6, !noalias !28
  %25 = getelementptr inbounds nuw i8, ptr %16, i64 32
  %wide.load5.1 = load <8 x float>, ptr %25, align 4, !invariant.load !3, !alias.scope !19, !noalias !23
  %26 = getelementptr inbounds nuw i8, ptr %12, i64 32
  %wide.load6.1 = load <8 x float>, ptr %26, align 4, !invariant.load !3, !alias.scope !15, !noalias !24
  %27 = getelementptr inbounds nuw i8, ptr %10, i64 32
  %wide.load7.1 = load <8 x float>, ptr %27, align 4, !invariant.load !3, !alias.scope !13, !noalias !25
  %28 = getelementptr inbounds nuw i8, ptr %8, i64 32
  %wide.load8.1 = load <8 x float>, ptr %28, align 4, !invariant.load !3, !alias.scope !11, !noalias !26
  %29 = getelementptr inbounds nuw i8, ptr %6, i64 32
  %wide.load9.1 = load <8 x float>, ptr %29, align 4, !invariant.load !3, !alias.scope !9, !noalias !27
  %30 = getelementptr inbounds nuw i8, ptr %4, i64 32
  %wide.load10.1 = load <8 x float>, ptr %30, align 4, !invariant.load !3, !alias.scope !6, !noalias !28
  %31 = getelementptr inbounds nuw i8, ptr %16, i64 64
  %wide.load5.2 = load <8 x float>, ptr %31, align 4, !invariant.load !3, !alias.scope !19, !noalias !23
  %32 = getelementptr inbounds nuw i8, ptr %12, i64 64
  %wide.load6.2 = load <8 x float>, ptr %32, align 4, !invariant.load !3, !alias.scope !15, !noalias !24
  %33 = getelementptr inbounds nuw i8, ptr %10, i64 64
  %wide.load7.2 = load <8 x float>, ptr %33, align 4, !invariant.load !3, !alias.scope !13, !noalias !25
  %34 = getelementptr inbounds nuw i8, ptr %8, i64 64
  %wide.load8.2 = load <8 x float>, ptr %34, align 4, !invariant.load !3, !alias.scope !11, !noalias !26
  %35 = getelementptr inbounds nuw i8, ptr %6, i64 64
  %wide.load9.2 = load <8 x float>, ptr %35, align 4, !invariant.load !3, !alias.scope !9, !noalias !27
  %36 = getelementptr inbounds nuw i8, ptr %4, i64 64
  %wide.load10.2 = load <8 x float>, ptr %36, align 4, !invariant.load !3, !alias.scope !6, !noalias !28
  %37 = getelementptr inbounds nuw i8, ptr %16, i64 96
  %wide.load5.3 = load <8 x float>, ptr %37, align 4, !invariant.load !3, !alias.scope !19, !noalias !23
  %38 = getelementptr inbounds nuw i8, ptr %12, i64 96
  %wide.load6.3 = load <8 x float>, ptr %38, align 4, !invariant.load !3, !alias.scope !15, !noalias !24
  %39 = getelementptr inbounds nuw i8, ptr %10, i64 96
  %wide.load7.3 = load <8 x float>, ptr %39, align 4, !invariant.load !3, !alias.scope !13, !noalias !25
  %40 = getelementptr inbounds nuw i8, ptr %8, i64 96
  %wide.load8.3 = load <8 x float>, ptr %40, align 4, !invariant.load !3, !alias.scope !11, !noalias !26
  %41 = getelementptr inbounds nuw i8, ptr %6, i64 96
  %wide.load9.3 = load <8 x float>, ptr %41, align 4, !invariant.load !3, !alias.scope !9, !noalias !27
  %42 = getelementptr inbounds nuw i8, ptr %4, i64 96
  %wide.load10.3 = load <8 x float>, ptr %42, align 4, !invariant.load !3, !alias.scope !6, !noalias !28
  %43 = getelementptr inbounds nuw i8, ptr %16, i64 128
  %wide.load5.4 = load <8 x float>, ptr %43, align 4, !invariant.load !3, !alias.scope !19, !noalias !23
  %44 = getelementptr inbounds nuw i8, ptr %12, i64 128
  %wide.load6.4 = load <8 x float>, ptr %44, align 4, !invariant.load !3, !alias.scope !15, !noalias !24
  %45 = getelementptr inbounds nuw i8, ptr %10, i64 128
  %wide.load7.4 = load <8 x float>, ptr %45, align 4, !invariant.load !3, !alias.scope !13, !noalias !25
  %46 = getelementptr inbounds nuw i8, ptr %8, i64 128
  %wide.load8.4 = load <8 x float>, ptr %46, align 4, !invariant.load !3, !alias.scope !11, !noalias !26
  %47 = getelementptr inbounds nuw i8, ptr %6, i64 128
  %wide.load9.4 = load <8 x float>, ptr %47, align 4, !invariant.load !3, !alias.scope !9, !noalias !27
  %48 = getelementptr inbounds nuw i8, ptr %4, i64 128
  %wide.load10.4 = load <8 x float>, ptr %48, align 4, !invariant.load !3, !alias.scope !6, !noalias !28
  %49 = getelementptr inbounds nuw i8, ptr %16, i64 160
  %wide.load5.5 = load <8 x float>, ptr %49, align 4, !invariant.load !3, !alias.scope !19, !noalias !23
  %50 = getelementptr inbounds nuw i8, ptr %12, i64 160
  %wide.load6.5 = load <8 x float>, ptr %50, align 4, !invariant.load !3, !alias.scope !15, !noalias !24
  %51 = getelementptr inbounds nuw i8, ptr %10, i64 160
  %wide.load7.5 = load <8 x float>, ptr %51, align 4, !invariant.load !3, !alias.scope !13, !noalias !25
  %52 = getelementptr inbounds nuw i8, ptr %8, i64 160
  %wide.load8.5 = load <8 x float>, ptr %52, align 4, !invariant.load !3, !alias.scope !11, !noalias !26
  %53 = getelementptr inbounds nuw i8, ptr %6, i64 160
  %wide.load9.5 = load <8 x float>, ptr %53, align 4, !invariant.load !3, !alias.scope !9, !noalias !27
  %54 = getelementptr inbounds nuw i8, ptr %4, i64 160
  %wide.load10.5 = load <8 x float>, ptr %54, align 4, !invariant.load !3, !alias.scope !6, !noalias !28
  %55 = getelementptr inbounds nuw i8, ptr %16, i64 192
  %wide.load5.6 = load <8 x float>, ptr %55, align 4, !invariant.load !3, !alias.scope !19, !noalias !23
  %56 = getelementptr inbounds nuw i8, ptr %12, i64 192
  %wide.load6.6 = load <8 x float>, ptr %56, align 4, !invariant.load !3, !alias.scope !15, !noalias !24
  %57 = getelementptr inbounds nuw i8, ptr %10, i64 192
  %wide.load7.6 = load <8 x float>, ptr %57, align 4, !invariant.load !3, !alias.scope !13, !noalias !25
  %58 = getelementptr inbounds nuw i8, ptr %8, i64 192
  %wide.load8.6 = load <8 x float>, ptr %58, align 4, !invariant.load !3, !alias.scope !11, !noalias !26
  %59 = getelementptr inbounds nuw i8, ptr %6, i64 192
  %wide.load9.6 = load <8 x float>, ptr %59, align 4, !invariant.load !3, !alias.scope !9, !noalias !27
  %60 = getelementptr inbounds nuw i8, ptr %4, i64 192
  %wide.load10.6 = load <8 x float>, ptr %60, align 4, !invariant.load !3, !alias.scope !6, !noalias !28
  %61 = getelementptr inbounds nuw i8, ptr %16, i64 224
  %wide.load5.7 = load <8 x float>, ptr %61, align 4, !invariant.load !3, !alias.scope !19, !noalias !23
  %62 = getelementptr inbounds nuw i8, ptr %12, i64 224
  %wide.load6.7 = load <8 x float>, ptr %62, align 4, !invariant.load !3, !alias.scope !15, !noalias !24
  %63 = getelementptr inbounds nuw i8, ptr %10, i64 224
  %wide.load7.7 = load <8 x float>, ptr %63, align 4, !invariant.load !3, !alias.scope !13, !noalias !25
  %64 = getelementptr inbounds nuw i8, ptr %8, i64 224
  %wide.load8.7 = load <8 x float>, ptr %64, align 4, !invariant.load !3, !alias.scope !11, !noalias !26
  %65 = getelementptr inbounds nuw i8, ptr %6, i64 224
  %wide.load9.7 = load <8 x float>, ptr %65, align 4, !invariant.load !3, !alias.scope !9, !noalias !27
  %66 = getelementptr inbounds nuw i8, ptr %4, i64 224
  %wide.load10.7 = load <8 x float>, ptr %66, align 4, !invariant.load !3, !alias.scope !6, !noalias !28
  %67 = getelementptr inbounds nuw i8, ptr %16, i64 256
  %wide.load5.8 = load <8 x float>, ptr %67, align 4, !invariant.load !3, !alias.scope !19, !noalias !23
  %68 = getelementptr inbounds nuw i8, ptr %12, i64 256
  %wide.load6.8 = load <8 x float>, ptr %68, align 4, !invariant.load !3, !alias.scope !15, !noalias !24
  %69 = getelementptr inbounds nuw i8, ptr %10, i64 256
  %wide.load7.8 = load <8 x float>, ptr %69, align 4, !invariant.load !3, !alias.scope !13, !noalias !25
  %70 = getelementptr inbounds nuw i8, ptr %8, i64 256
  %wide.load8.8 = load <8 x float>, ptr %70, align 4, !invariant.load !3, !alias.scope !11, !noalias !26
  %71 = getelementptr inbounds nuw i8, ptr %6, i64 256
  %wide.load9.8 = load <8 x float>, ptr %71, align 4, !invariant.load !3, !alias.scope !9, !noalias !27
  %72 = getelementptr inbounds nuw i8, ptr %4, i64 256
  %wide.load10.8 = load <8 x float>, ptr %72, align 4, !invariant.load !3, !alias.scope !6, !noalias !28
  %73 = getelementptr inbounds nuw i8, ptr %16, i64 288
  %wide.load5.9 = load <8 x float>, ptr %73, align 4, !invariant.load !3, !alias.scope !19, !noalias !23
  %74 = getelementptr inbounds nuw i8, ptr %12, i64 288
  %wide.load6.9 = load <8 x float>, ptr %74, align 4, !invariant.load !3, !alias.scope !15, !noalias !24
  %75 = getelementptr inbounds nuw i8, ptr %10, i64 288
  %wide.load7.9 = load <8 x float>, ptr %75, align 4, !invariant.load !3, !alias.scope !13, !noalias !25
  %76 = getelementptr inbounds nuw i8, ptr %8, i64 288
  %wide.load8.9 = load <8 x float>, ptr %76, align 4, !invariant.load !3, !alias.scope !11, !noalias !26
  %77 = getelementptr inbounds nuw i8, ptr %6, i64 288
  %wide.load9.9 = load <8 x float>, ptr %77, align 4, !invariant.load !3, !alias.scope !9, !noalias !27
  %78 = getelementptr inbounds nuw i8, ptr %4, i64 288
  %wide.load10.9 = load <8 x float>, ptr %78, align 4, !invariant.load !3, !alias.scope !6, !noalias !28
  br label %vector.ph

vector.ph:                                        ; preds = %23, %vector.ph
  %79 = phi i64 [ 0, %23 ], [ %221, %vector.ph ]
  %80 = mul nuw nsw i64 %79, 80
  %81 = add nuw nsw i64 %80, %24
  %82 = getelementptr inbounds nuw float, ptr %14, i64 %81
  %wide.load = load <8 x float>, ptr %82, align 4, !invariant.load !3, !alias.scope !17, !noalias !29
  %83 = fmul <8 x float> %wide.load, %wide.load5
  %84 = fadd <8 x float> %83, %wide.load6
  %85 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %84, <8 x float> zeroinitializer)
  %86 = fmul <8 x float> %wide.load7, %85
  %87 = fadd <8 x float> %wide.load8, %86
  %88 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %87, <8 x float> zeroinitializer)
  %89 = fmul <8 x float> %wide.load9, %88
  %90 = fadd <8 x float> %wide.load10, %89
  %91 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %90, <8 x float> zeroinitializer)
  %92 = fmul <8 x float> %91, splat (float 7.500000e-01)
  %93 = fadd <8 x float> %92, splat (float 1.250000e-01)
  %94 = getelementptr inbounds nuw float, ptr %18, i64 %81
  store <8 x float> %93, ptr %94, align 4, !alias.scope !21, !noalias !30
  %95 = or disjoint i64 %81, 8
  %96 = getelementptr inbounds nuw float, ptr %14, i64 %95
  %wide.load.1 = load <8 x float>, ptr %96, align 4, !invariant.load !3, !alias.scope !17, !noalias !29
  %97 = fmul <8 x float> %wide.load.1, %wide.load5.1
  %98 = fadd <8 x float> %97, %wide.load6.1
  %99 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %98, <8 x float> zeroinitializer)
  %100 = fmul <8 x float> %wide.load7.1, %99
  %101 = fadd <8 x float> %wide.load8.1, %100
  %102 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %101, <8 x float> zeroinitializer)
  %103 = fmul <8 x float> %wide.load9.1, %102
  %104 = fadd <8 x float> %wide.load10.1, %103
  %105 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %104, <8 x float> zeroinitializer)
  %106 = fmul <8 x float> %105, splat (float 7.500000e-01)
  %107 = fadd <8 x float> %106, splat (float 1.250000e-01)
  %108 = getelementptr inbounds nuw float, ptr %18, i64 %95
  store <8 x float> %107, ptr %108, align 4, !alias.scope !21, !noalias !30
  %109 = add nuw nsw i64 %81, 16
  %110 = getelementptr inbounds nuw float, ptr %14, i64 %109
  %wide.load.2 = load <8 x float>, ptr %110, align 4, !invariant.load !3, !alias.scope !17, !noalias !29
  %111 = fmul <8 x float> %wide.load.2, %wide.load5.2
  %112 = fadd <8 x float> %111, %wide.load6.2
  %113 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %112, <8 x float> zeroinitializer)
  %114 = fmul <8 x float> %wide.load7.2, %113
  %115 = fadd <8 x float> %wide.load8.2, %114
  %116 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %115, <8 x float> zeroinitializer)
  %117 = fmul <8 x float> %wide.load9.2, %116
  %118 = fadd <8 x float> %wide.load10.2, %117
  %119 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %118, <8 x float> zeroinitializer)
  %120 = fmul <8 x float> %119, splat (float 7.500000e-01)
  %121 = fadd <8 x float> %120, splat (float 1.250000e-01)
  %122 = getelementptr inbounds nuw float, ptr %18, i64 %109
  store <8 x float> %121, ptr %122, align 4, !alias.scope !21, !noalias !30
  %123 = add nuw nsw i64 %81, 24
  %124 = getelementptr inbounds nuw float, ptr %14, i64 %123
  %wide.load.3 = load <8 x float>, ptr %124, align 4, !invariant.load !3, !alias.scope !17, !noalias !29
  %125 = fmul <8 x float> %wide.load.3, %wide.load5.3
  %126 = fadd <8 x float> %125, %wide.load6.3
  %127 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %126, <8 x float> zeroinitializer)
  %128 = fmul <8 x float> %wide.load7.3, %127
  %129 = fadd <8 x float> %wide.load8.3, %128
  %130 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %129, <8 x float> zeroinitializer)
  %131 = fmul <8 x float> %wide.load9.3, %130
  %132 = fadd <8 x float> %wide.load10.3, %131
  %133 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %132, <8 x float> zeroinitializer)
  %134 = fmul <8 x float> %133, splat (float 7.500000e-01)
  %135 = fadd <8 x float> %134, splat (float 1.250000e-01)
  %136 = getelementptr inbounds nuw float, ptr %18, i64 %123
  store <8 x float> %135, ptr %136, align 4, !alias.scope !21, !noalias !30
  %137 = add nuw nsw i64 %81, 32
  %138 = getelementptr inbounds nuw float, ptr %14, i64 %137
  %wide.load.4 = load <8 x float>, ptr %138, align 4, !invariant.load !3, !alias.scope !17, !noalias !29
  %139 = fmul <8 x float> %wide.load.4, %wide.load5.4
  %140 = fadd <8 x float> %139, %wide.load6.4
  %141 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %140, <8 x float> zeroinitializer)
  %142 = fmul <8 x float> %wide.load7.4, %141
  %143 = fadd <8 x float> %wide.load8.4, %142
  %144 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %143, <8 x float> zeroinitializer)
  %145 = fmul <8 x float> %wide.load9.4, %144
  %146 = fadd <8 x float> %wide.load10.4, %145
  %147 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %146, <8 x float> zeroinitializer)
  %148 = fmul <8 x float> %147, splat (float 7.500000e-01)
  %149 = fadd <8 x float> %148, splat (float 1.250000e-01)
  %150 = getelementptr inbounds nuw float, ptr %18, i64 %137
  store <8 x float> %149, ptr %150, align 4, !alias.scope !21, !noalias !30
  %151 = add nuw nsw i64 %81, 40
  %152 = getelementptr inbounds nuw float, ptr %14, i64 %151
  %wide.load.5 = load <8 x float>, ptr %152, align 4, !invariant.load !3, !alias.scope !17, !noalias !29
  %153 = fmul <8 x float> %wide.load.5, %wide.load5.5
  %154 = fadd <8 x float> %153, %wide.load6.5
  %155 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %154, <8 x float> zeroinitializer)
  %156 = fmul <8 x float> %wide.load7.5, %155
  %157 = fadd <8 x float> %wide.load8.5, %156
  %158 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %157, <8 x float> zeroinitializer)
  %159 = fmul <8 x float> %wide.load9.5, %158
  %160 = fadd <8 x float> %wide.load10.5, %159
  %161 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %160, <8 x float> zeroinitializer)
  %162 = fmul <8 x float> %161, splat (float 7.500000e-01)
  %163 = fadd <8 x float> %162, splat (float 1.250000e-01)
  %164 = getelementptr inbounds nuw float, ptr %18, i64 %151
  store <8 x float> %163, ptr %164, align 4, !alias.scope !21, !noalias !30
  %165 = add nuw nsw i64 %81, 48
  %166 = getelementptr inbounds nuw float, ptr %14, i64 %165
  %wide.load.6 = load <8 x float>, ptr %166, align 4, !invariant.load !3, !alias.scope !17, !noalias !29
  %167 = fmul <8 x float> %wide.load.6, %wide.load5.6
  %168 = fadd <8 x float> %167, %wide.load6.6
  %169 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %168, <8 x float> zeroinitializer)
  %170 = fmul <8 x float> %wide.load7.6, %169
  %171 = fadd <8 x float> %wide.load8.6, %170
  %172 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %171, <8 x float> zeroinitializer)
  %173 = fmul <8 x float> %wide.load9.6, %172
  %174 = fadd <8 x float> %wide.load10.6, %173
  %175 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %174, <8 x float> zeroinitializer)
  %176 = fmul <8 x float> %175, splat (float 7.500000e-01)
  %177 = fadd <8 x float> %176, splat (float 1.250000e-01)
  %178 = getelementptr inbounds nuw float, ptr %18, i64 %165
  store <8 x float> %177, ptr %178, align 4, !alias.scope !21, !noalias !30
  %179 = add nuw nsw i64 %81, 56
  %180 = getelementptr inbounds nuw float, ptr %14, i64 %179
  %wide.load.7 = load <8 x float>, ptr %180, align 4, !invariant.load !3, !alias.scope !17, !noalias !29
  %181 = fmul <8 x float> %wide.load.7, %wide.load5.7
  %182 = fadd <8 x float> %181, %wide.load6.7
  %183 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %182, <8 x float> zeroinitializer)
  %184 = fmul <8 x float> %wide.load7.7, %183
  %185 = fadd <8 x float> %wide.load8.7, %184
  %186 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %185, <8 x float> zeroinitializer)
  %187 = fmul <8 x float> %wide.load9.7, %186
  %188 = fadd <8 x float> %wide.load10.7, %187
  %189 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %188, <8 x float> zeroinitializer)
  %190 = fmul <8 x float> %189, splat (float 7.500000e-01)
  %191 = fadd <8 x float> %190, splat (float 1.250000e-01)
  %192 = getelementptr inbounds nuw float, ptr %18, i64 %179
  store <8 x float> %191, ptr %192, align 4, !alias.scope !21, !noalias !30
  %193 = add nuw nsw i64 %81, 64
  %194 = getelementptr inbounds nuw float, ptr %14, i64 %193
  %wide.load.8 = load <8 x float>, ptr %194, align 4, !invariant.load !3, !alias.scope !17, !noalias !29
  %195 = fmul <8 x float> %wide.load.8, %wide.load5.8
  %196 = fadd <8 x float> %195, %wide.load6.8
  %197 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %196, <8 x float> zeroinitializer)
  %198 = fmul <8 x float> %wide.load7.8, %197
  %199 = fadd <8 x float> %wide.load8.8, %198
  %200 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %199, <8 x float> zeroinitializer)
  %201 = fmul <8 x float> %wide.load9.8, %200
  %202 = fadd <8 x float> %wide.load10.8, %201
  %203 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %202, <8 x float> zeroinitializer)
  %204 = fmul <8 x float> %203, splat (float 7.500000e-01)
  %205 = fadd <8 x float> %204, splat (float 1.250000e-01)
  %206 = getelementptr inbounds nuw float, ptr %18, i64 %193
  store <8 x float> %205, ptr %206, align 4, !alias.scope !21, !noalias !30
  %207 = add nuw nsw i64 %81, 72
  %208 = getelementptr inbounds nuw float, ptr %14, i64 %207
  %wide.load.9 = load <8 x float>, ptr %208, align 4, !invariant.load !3, !alias.scope !17, !noalias !29
  %209 = fmul <8 x float> %wide.load.9, %wide.load5.9
  %210 = fadd <8 x float> %209, %wide.load6.9
  %211 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %210, <8 x float> zeroinitializer)
  %212 = fmul <8 x float> %wide.load7.9, %211
  %213 = fadd <8 x float> %wide.load8.9, %212
  %214 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %213, <8 x float> zeroinitializer)
  %215 = fmul <8 x float> %wide.load9.9, %214
  %216 = fadd <8 x float> %wide.load10.9, %215
  %217 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %216, <8 x float> zeroinitializer)
  %218 = fmul <8 x float> %217, splat (float 7.500000e-01)
  %219 = fadd <8 x float> %218, splat (float 1.250000e-01)
  %220 = getelementptr inbounds nuw float, ptr %18, i64 %207
  store <8 x float> %219, ptr %220, align 4, !alias.scope !21, !noalias !30
  %221 = add nuw nsw i64 %79, 1
  %exitcond3.not = icmp eq i64 %221, 16
  br i1 %exitcond3.not, label %broadcast_add_fusion_wrapped.exit, label %vector.ph, !llvm.loop !31

broadcast_add_fusion_wrapped.exit:                ; preds = %vector.ph, %1
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.maximum.v8f32(<8 x float>, <8 x float>) #2

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 0}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 320}
!5 = !{i64 15360}
!6 = !{!7}
!7 = distinct !{!7, !8, !"broadcast_add_fusion_wrapped: argument 0"}
!8 = distinct !{!8, !"broadcast_add_fusion_wrapped"}
!9 = !{!10}
!10 = distinct !{!10, !8, !"broadcast_add_fusion_wrapped: argument 1"}
!11 = !{!12}
!12 = distinct !{!12, !8, !"broadcast_add_fusion_wrapped: argument 2"}
!13 = !{!14}
!14 = distinct !{!14, !8, !"broadcast_add_fusion_wrapped: argument 3"}
!15 = !{!16}
!16 = distinct !{!16, !8, !"broadcast_add_fusion_wrapped: argument 4"}
!17 = !{!18}
!18 = distinct !{!18, !8, !"broadcast_add_fusion_wrapped: argument 5"}
!19 = !{!20}
!20 = distinct !{!20, !8, !"broadcast_add_fusion_wrapped: argument 6"}
!21 = !{!22}
!22 = distinct !{!22, !8, !"broadcast_add_fusion_wrapped: argument 7"}
!23 = !{!7, !10, !12, !14, !16, !18, !22}
!24 = !{!7, !10, !12, !14, !18, !20, !22}
!25 = !{!7, !10, !12, !16, !18, !20, !22}
!26 = !{!7, !10, !14, !16, !18, !20, !22}
!27 = !{!7, !12, !14, !16, !18, !20, !22}
!28 = !{!10, !12, !14, !16, !18, !20, !22}
!29 = !{!7, !10, !12, !14, !16, !20, !22}
!30 = !{!7, !10, !12, !14, !16, !18, !20}
!31 = distinct !{!31, !32}
!32 = !{!"llvm.loop.unroll.disable"}
