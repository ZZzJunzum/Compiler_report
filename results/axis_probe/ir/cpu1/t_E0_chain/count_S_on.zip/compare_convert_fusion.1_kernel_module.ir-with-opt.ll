; ModuleID = '__compute_module_compare_convert_fusion.1_kernel_module'
source_filename = "__compute_module_compare_convert_fusion.1_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @compare_convert_fusion.1(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !5
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !4
  %9 = getelementptr inbounds nuw i8, ptr %3, i64 48
  %10 = load ptr, ptr %9, align 8, !invariant.load !3, !dereferenceable !5
  tail call void @llvm.experimental.noalias.scope.decl(metadata !6)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !11)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !13)
  %11 = getelementptr inbounds nuw i8, ptr %8, i64 32
  %wide.load4 = load <8 x float>, ptr %8, align 4, !invariant.load !3, !alias.scope !11, !noalias !15
  %wide.load5 = load <8 x float>, ptr %11, align 4, !invariant.load !3, !alias.scope !11, !noalias !15
  %12 = getelementptr inbounds nuw i8, ptr %4, i64 32
  %wide.load6 = load <8 x float>, ptr %4, align 4, !invariant.load !3, !alias.scope !6, !noalias !16
  %wide.load7 = load <8 x float>, ptr %12, align 4, !invariant.load !3, !alias.scope !6, !noalias !16
  %13 = getelementptr inbounds nuw i8, ptr %8, i64 64
  %14 = getelementptr inbounds nuw i8, ptr %8, i64 96
  %wide.load4.1 = load <8 x float>, ptr %13, align 4, !invariant.load !3, !alias.scope !11, !noalias !15
  %wide.load5.1 = load <8 x float>, ptr %14, align 4, !invariant.load !3, !alias.scope !11, !noalias !15
  %15 = getelementptr inbounds nuw i8, ptr %4, i64 64
  %16 = getelementptr inbounds nuw i8, ptr %4, i64 96
  %wide.load6.1 = load <8 x float>, ptr %15, align 4, !invariant.load !3, !alias.scope !6, !noalias !16
  %wide.load7.1 = load <8 x float>, ptr %16, align 4, !invariant.load !3, !alias.scope !6, !noalias !16
  %17 = getelementptr inbounds nuw i8, ptr %8, i64 128
  %18 = getelementptr inbounds nuw i8, ptr %8, i64 160
  %wide.load4.2 = load <8 x float>, ptr %17, align 4, !invariant.load !3, !alias.scope !11, !noalias !15
  %wide.load5.2 = load <8 x float>, ptr %18, align 4, !invariant.load !3, !alias.scope !11, !noalias !15
  %19 = getelementptr inbounds nuw i8, ptr %4, i64 128
  %20 = getelementptr inbounds nuw i8, ptr %4, i64 160
  %wide.load6.2 = load <8 x float>, ptr %19, align 4, !invariant.load !3, !alias.scope !6, !noalias !16
  %wide.load7.2 = load <8 x float>, ptr %20, align 4, !invariant.load !3, !alias.scope !6, !noalias !16
  %21 = getelementptr inbounds nuw i8, ptr %8, i64 192
  %22 = getelementptr inbounds nuw i8, ptr %8, i64 224
  %wide.load4.3 = load <8 x float>, ptr %21, align 4, !invariant.load !3, !alias.scope !11, !noalias !15
  %wide.load5.3 = load <8 x float>, ptr %22, align 4, !invariant.load !3, !alias.scope !11, !noalias !15
  %23 = getelementptr inbounds nuw i8, ptr %4, i64 192
  %24 = getelementptr inbounds nuw i8, ptr %4, i64 224
  %wide.load6.3 = load <8 x float>, ptr %23, align 4, !invariant.load !3, !alias.scope !6, !noalias !16
  %wide.load7.3 = load <8 x float>, ptr %24, align 4, !invariant.load !3, !alias.scope !6, !noalias !16
  %25 = getelementptr inbounds nuw i8, ptr %8, i64 256
  %26 = getelementptr inbounds nuw i8, ptr %8, i64 288
  %wide.load4.4 = load <8 x float>, ptr %25, align 4, !invariant.load !3, !alias.scope !11, !noalias !15
  %wide.load5.4 = load <8 x float>, ptr %26, align 4, !invariant.load !3, !alias.scope !11, !noalias !15
  %27 = getelementptr inbounds nuw i8, ptr %4, i64 256
  %28 = getelementptr inbounds nuw i8, ptr %4, i64 288
  %wide.load6.4 = load <8 x float>, ptr %27, align 4, !invariant.load !3, !alias.scope !6, !noalias !16
  %wide.load7.4 = load <8 x float>, ptr %28, align 4, !invariant.load !3, !alias.scope !6, !noalias !16
  br label %vector.ph

vector.ph:                                        ; preds = %1, %vector.ph
  %29 = phi i64 [ 0, %1 ], [ %95, %vector.ph ]
  %30 = mul nuw nsw i64 %29, 80
  %31 = getelementptr inbounds nuw float, ptr %6, i64 %30
  %32 = getelementptr inbounds nuw i8, ptr %31, i64 32
  %wide.load = load <8 x float>, ptr %31, align 4, !invariant.load !3, !alias.scope !9, !noalias !17
  %wide.load3 = load <8 x float>, ptr %32, align 4, !invariant.load !3, !alias.scope !9, !noalias !17
  %33 = fmul <8 x float> %wide.load, %wide.load4
  %34 = fmul <8 x float> %wide.load3, %wide.load5
  %35 = fadd <8 x float> %33, %wide.load6
  %36 = fadd <8 x float> %34, %wide.load7
  %37 = fcmp ogt <8 x float> %35, zeroinitializer
  %38 = fcmp ogt <8 x float> %36, zeroinitializer
  %39 = zext <8 x i1> %37 to <8 x i32>
  %40 = zext <8 x i1> %38 to <8 x i32>
  %41 = getelementptr inbounds nuw i32, ptr %10, i64 %30
  %42 = getelementptr inbounds nuw i8, ptr %41, i64 32
  store <8 x i32> %39, ptr %41, align 4, !alias.scope !13, !noalias !18
  store <8 x i32> %40, ptr %42, align 4, !alias.scope !13, !noalias !18
  %43 = add nuw nsw i64 %30, 16
  %44 = getelementptr inbounds nuw float, ptr %6, i64 %43
  %45 = getelementptr inbounds nuw i8, ptr %44, i64 32
  %wide.load.1 = load <8 x float>, ptr %44, align 4, !invariant.load !3, !alias.scope !9, !noalias !17
  %wide.load3.1 = load <8 x float>, ptr %45, align 4, !invariant.load !3, !alias.scope !9, !noalias !17
  %46 = fmul <8 x float> %wide.load.1, %wide.load4.1
  %47 = fmul <8 x float> %wide.load3.1, %wide.load5.1
  %48 = fadd <8 x float> %46, %wide.load6.1
  %49 = fadd <8 x float> %47, %wide.load7.1
  %50 = fcmp ogt <8 x float> %48, zeroinitializer
  %51 = fcmp ogt <8 x float> %49, zeroinitializer
  %52 = zext <8 x i1> %50 to <8 x i32>
  %53 = zext <8 x i1> %51 to <8 x i32>
  %54 = getelementptr inbounds nuw i32, ptr %10, i64 %43
  %55 = getelementptr inbounds nuw i8, ptr %54, i64 32
  store <8 x i32> %52, ptr %54, align 4, !alias.scope !13, !noalias !18
  store <8 x i32> %53, ptr %55, align 4, !alias.scope !13, !noalias !18
  %56 = add nuw nsw i64 %30, 32
  %57 = getelementptr inbounds nuw float, ptr %6, i64 %56
  %58 = getelementptr inbounds nuw i8, ptr %57, i64 32
  %wide.load.2 = load <8 x float>, ptr %57, align 4, !invariant.load !3, !alias.scope !9, !noalias !17
  %wide.load3.2 = load <8 x float>, ptr %58, align 4, !invariant.load !3, !alias.scope !9, !noalias !17
  %59 = fmul <8 x float> %wide.load.2, %wide.load4.2
  %60 = fmul <8 x float> %wide.load3.2, %wide.load5.2
  %61 = fadd <8 x float> %59, %wide.load6.2
  %62 = fadd <8 x float> %60, %wide.load7.2
  %63 = fcmp ogt <8 x float> %61, zeroinitializer
  %64 = fcmp ogt <8 x float> %62, zeroinitializer
  %65 = zext <8 x i1> %63 to <8 x i32>
  %66 = zext <8 x i1> %64 to <8 x i32>
  %67 = getelementptr inbounds nuw i32, ptr %10, i64 %56
  %68 = getelementptr inbounds nuw i8, ptr %67, i64 32
  store <8 x i32> %65, ptr %67, align 4, !alias.scope !13, !noalias !18
  store <8 x i32> %66, ptr %68, align 4, !alias.scope !13, !noalias !18
  %69 = add nuw nsw i64 %30, 48
  %70 = getelementptr inbounds nuw float, ptr %6, i64 %69
  %71 = getelementptr inbounds nuw i8, ptr %70, i64 32
  %wide.load.3 = load <8 x float>, ptr %70, align 4, !invariant.load !3, !alias.scope !9, !noalias !17
  %wide.load3.3 = load <8 x float>, ptr %71, align 4, !invariant.load !3, !alias.scope !9, !noalias !17
  %72 = fmul <8 x float> %wide.load.3, %wide.load4.3
  %73 = fmul <8 x float> %wide.load3.3, %wide.load5.3
  %74 = fadd <8 x float> %72, %wide.load6.3
  %75 = fadd <8 x float> %73, %wide.load7.3
  %76 = fcmp ogt <8 x float> %74, zeroinitializer
  %77 = fcmp ogt <8 x float> %75, zeroinitializer
  %78 = zext <8 x i1> %76 to <8 x i32>
  %79 = zext <8 x i1> %77 to <8 x i32>
  %80 = getelementptr inbounds nuw i32, ptr %10, i64 %69
  %81 = getelementptr inbounds nuw i8, ptr %80, i64 32
  store <8 x i32> %78, ptr %80, align 4, !alias.scope !13, !noalias !18
  store <8 x i32> %79, ptr %81, align 4, !alias.scope !13, !noalias !18
  %82 = add nuw nsw i64 %30, 64
  %83 = getelementptr inbounds nuw float, ptr %6, i64 %82
  %84 = getelementptr inbounds nuw i8, ptr %83, i64 32
  %wide.load.4 = load <8 x float>, ptr %83, align 4, !invariant.load !3, !alias.scope !9, !noalias !17
  %wide.load3.4 = load <8 x float>, ptr %84, align 4, !invariant.load !3, !alias.scope !9, !noalias !17
  %85 = fmul <8 x float> %wide.load.4, %wide.load4.4
  %86 = fmul <8 x float> %wide.load3.4, %wide.load5.4
  %87 = fadd <8 x float> %85, %wide.load6.4
  %88 = fadd <8 x float> %86, %wide.load7.4
  %89 = fcmp ogt <8 x float> %87, zeroinitializer
  %90 = fcmp ogt <8 x float> %88, zeroinitializer
  %91 = zext <8 x i1> %89 to <8 x i32>
  %92 = zext <8 x i1> %90 to <8 x i32>
  %93 = getelementptr inbounds nuw i32, ptr %10, i64 %82
  %94 = getelementptr inbounds nuw i8, ptr %93, i64 32
  store <8 x i32> %91, ptr %93, align 4, !alias.scope !13, !noalias !18
  store <8 x i32> %92, ptr %94, align 4, !alias.scope !13, !noalias !18
  %95 = add nuw nsw i64 %29, 1
  %exitcond2.not = icmp eq i64 %95, 48
  br i1 %exitcond2.not, label %compare_convert_fusion.1_wrapped.exit, label %vector.ph, !llvm.loop !19

compare_convert_fusion.1_wrapped.exit:            ; preds = %vector.ph
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 2}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 320}
!5 = !{i64 15360}
!6 = !{!7}
!7 = distinct !{!7, !8, !"compare_convert_fusion.1_wrapped: argument 0"}
!8 = distinct !{!8, !"compare_convert_fusion.1_wrapped"}
!9 = !{!10}
!10 = distinct !{!10, !8, !"compare_convert_fusion.1_wrapped: argument 1"}
!11 = !{!12}
!12 = distinct !{!12, !8, !"compare_convert_fusion.1_wrapped: argument 2"}
!13 = !{!14}
!14 = distinct !{!14, !8, !"compare_convert_fusion.1_wrapped: argument 3"}
!15 = !{!7, !10, !14}
!16 = !{!10, !12, !14}
!17 = !{!7, !12, !14}
!18 = !{!7, !10, !12}
!19 = distinct !{!19, !20}
!20 = !{!"llvm.loop.unroll.disable"}
