; ModuleID = '__compute_module_wrapped_reduce-window_kernel_module'
source_filename = "__compute_module_wrapped_reduce-window_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @wrapped_reduce-window(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !5
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !6
  tail call void @llvm.experimental.noalias.scope.decl(metadata !7)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !10)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !12)
  %9 = load i32, ptr %6, align 4, !invariant.load !3, !alias.scope !10, !noalias !14
  br label %10

10:                                               ; preds = %1, %128
  %11 = phi i1 [ true, %1 ], [ false, %128 ]
  %12 = phi i64 [ 0, %1 ], [ 1, %128 ]
  %13 = shl nuw nsw i64 %12, 5
  %14 = add nsw i64 %13, -8
  %.idx1 = mul nuw nsw i64 %12, 10240
  %invariant.gep9 = getelementptr i8, ptr %4, i64 %.idx1
  %.idx = mul nuw nsw i64 %12, 12
  %15 = getelementptr i8, ptr %8, i64 %.idx
  br label %16

16:                                               ; preds = %10, %125
  %17 = phi i64 [ 0, %10 ], [ %127, %125 ]
  %gep10.idx = shl i64 %17, 7
  %gep10 = getelementptr i8, ptr %invariant.gep9, i64 %gep10.idx
  %.not = icmp eq i64 %17, 0
  %18 = icmp samesign ult i64 %17, 2
  br label %19

19:                                               ; preds = %16, %.split8.us
  %20 = phi i32 [ %9, %16 ], [ %.us-phi, %.split8.us ]
  %21 = phi i64 [ 0, %16 ], [ %124, %.split8.us ]
  %22 = add nsw i64 %14, %21
  %23 = icmp ult i64 %22, 48
  %.idx2 = mul nuw nsw i64 %21, 320
  %24 = getelementptr i8, ptr %gep10, i64 %.idx2
  br i1 %23, label %.split.preheader, label %.split8.us

.split.preheader:                                 ; preds = %19
  br i1 %.not, label %.split.24, label %25

25:                                               ; preds = %.split.preheader
  %26 = getelementptr i8, ptr %24, i64 -2592
  %27 = load i32, ptr %26, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %28 = add i32 %27, %20
  %29 = getelementptr i8, ptr %24, i64 -2588
  %30 = load i32, ptr %29, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %31 = add i32 %30, %28
  %32 = getelementptr i8, ptr %24, i64 -2584
  %33 = load i32, ptr %32, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %34 = add i32 %33, %31
  %35 = getelementptr i8, ptr %24, i64 -2580
  %36 = load i32, ptr %35, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %37 = add i32 %36, %34
  %38 = getelementptr i8, ptr %24, i64 -2576
  %39 = load i32, ptr %38, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %40 = add i32 %39, %37
  %41 = getelementptr i8, ptr %24, i64 -2572
  %42 = load i32, ptr %41, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %43 = add i32 %42, %40
  %44 = getelementptr i8, ptr %24, i64 -2568
  %45 = load i32, ptr %44, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %46 = add i32 %45, %43
  %47 = getelementptr i8, ptr %24, i64 -2564
  %48 = load i32, ptr %47, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %49 = add i32 %48, %46
  br label %.split.24

.split.24:                                        ; preds = %.split.preheader, %25
  %50 = phi i32 [ %49, %25 ], [ %20, %.split.preheader ]
  %51 = getelementptr i8, ptr %24, i64 -2560
  %52 = load i32, ptr %51, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %53 = add i32 %52, %50
  %54 = getelementptr i8, ptr %24, i64 -2556
  %55 = load i32, ptr %54, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %56 = add i32 %55, %53
  %57 = getelementptr i8, ptr %24, i64 -2552
  %58 = load i32, ptr %57, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %59 = add i32 %58, %56
  %60 = getelementptr i8, ptr %24, i64 -2548
  %61 = load i32, ptr %60, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %62 = add i32 %61, %59
  %63 = getelementptr i8, ptr %24, i64 -2544
  %64 = load i32, ptr %63, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %65 = add i32 %64, %62
  %66 = getelementptr i8, ptr %24, i64 -2540
  %67 = load i32, ptr %66, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %68 = add i32 %67, %65
  %69 = getelementptr i8, ptr %24, i64 -2536
  %70 = load i32, ptr %69, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %71 = add i32 %70, %68
  %72 = getelementptr i8, ptr %24, i64 -2532
  %73 = load i32, ptr %72, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %74 = add i32 %73, %71
  %75 = getelementptr i8, ptr %24, i64 -2528
  %76 = load i32, ptr %75, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %77 = add i32 %76, %74
  %78 = getelementptr i8, ptr %24, i64 -2524
  %79 = load i32, ptr %78, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %80 = add i32 %79, %77
  %81 = getelementptr i8, ptr %24, i64 -2520
  %82 = load i32, ptr %81, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %83 = add i32 %82, %80
  %84 = getelementptr i8, ptr %24, i64 -2516
  %85 = load i32, ptr %84, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %86 = add i32 %85, %83
  %87 = getelementptr i8, ptr %24, i64 -2512
  %88 = load i32, ptr %87, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %89 = add i32 %88, %86
  %90 = getelementptr i8, ptr %24, i64 -2508
  %91 = load i32, ptr %90, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %92 = add i32 %91, %89
  %93 = getelementptr i8, ptr %24, i64 -2504
  %94 = load i32, ptr %93, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %95 = add i32 %94, %92
  %96 = getelementptr i8, ptr %24, i64 -2500
  %97 = load i32, ptr %96, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %98 = add i32 %97, %95
  br i1 %18, label %99, label %.split8.us

99:                                               ; preds = %.split.24
  %100 = getelementptr i8, ptr %24, i64 -2496
  %101 = load i32, ptr %100, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %102 = add i32 %101, %98
  %103 = getelementptr i8, ptr %24, i64 -2492
  %104 = load i32, ptr %103, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %105 = add i32 %104, %102
  %106 = getelementptr i8, ptr %24, i64 -2488
  %107 = load i32, ptr %106, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %108 = add i32 %107, %105
  %109 = getelementptr i8, ptr %24, i64 -2484
  %110 = load i32, ptr %109, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %111 = add i32 %110, %108
  %112 = getelementptr i8, ptr %24, i64 -2480
  %113 = load i32, ptr %112, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %114 = add i32 %113, %111
  %115 = getelementptr i8, ptr %24, i64 -2476
  %116 = load i32, ptr %115, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %117 = add i32 %116, %114
  %118 = getelementptr i8, ptr %24, i64 -2472
  %119 = load i32, ptr %118, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %120 = add i32 %119, %117
  %121 = getelementptr i8, ptr %24, i64 -2468
  %122 = load i32, ptr %121, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %123 = add i32 %122, %120
  br label %.split8.us

.split8.us:                                       ; preds = %99, %.split.24, %19
  %.us-phi = phi i32 [ %20, %19 ], [ %123, %99 ], [ %98, %.split.24 ]
  %124 = add nuw nsw i64 %21, 1
  %exitcond.not = icmp eq i64 %124, 32
  br i1 %exitcond.not, label %125, label %19, !llvm.loop !16

125:                                              ; preds = %.split8.us
  %126 = getelementptr i32, ptr %15, i64 %17
  store i32 %.us-phi, ptr %126, align 4, !alias.scope !12, !noalias !18
  %127 = add nuw nsw i64 %17, 1
  %exitcond14.not = icmp eq i64 %127, 3
  br i1 %exitcond14.not, label %128, label %16, !llvm.loop !16

128:                                              ; preds = %125
  br i1 %11, label %10, label %wrapped_reduce-window_wrapped.exit, !llvm.loop !16

wrapped_reduce-window_wrapped.exit:               ; preds = %128
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 4}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 15360}
!5 = !{i64 4}
!6 = !{i64 24}
!7 = !{!8}
!8 = distinct !{!8, !9, !"wrapped_reduce-window_wrapped: argument 0"}
!9 = distinct !{!9, !"wrapped_reduce-window_wrapped"}
!10 = !{!11}
!11 = distinct !{!11, !9, !"wrapped_reduce-window_wrapped: argument 1"}
!12 = !{!13}
!13 = distinct !{!13, !9, !"wrapped_reduce-window_wrapped: argument 2"}
!14 = !{!8, !13}
!15 = !{!11, !13}
!16 = distinct !{!16, !17}
!17 = !{!"llvm.loop.unroll.disable"}
!18 = !{!8, !11}
