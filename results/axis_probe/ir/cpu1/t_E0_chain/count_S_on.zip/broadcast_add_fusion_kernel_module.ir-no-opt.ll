; ModuleID = '__compute_module_broadcast_add_fusion_kernel_module'
source_filename = "__compute_module_broadcast_add_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

%XLA_CPU_KernelCallFrame = type { ptr, ptr, i64, ptr }
%XLA_CPU_KernelArg = type { ptr, i64 }
%kernel_dim3 = type { i64, i64, i64 }

; Function Attrs: uwtable
define ptr @broadcast_add_fusion(ptr %0) #0 {
  %2 = getelementptr inbounds %XLA_CPU_KernelCallFrame, ptr %0, i32 0, i32 3
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 0, i32 0
  %5 = load ptr, ptr %4, align 8, !invariant.load !3, !dereferenceable !4
  %6 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 1, i32 0
  %7 = load ptr, ptr %6, align 8, !invariant.load !3, !dereferenceable !4
  %8 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 2, i32 0
  %9 = load ptr, ptr %8, align 8, !invariant.load !3, !dereferenceable !4
  %10 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 3, i32 0
  %11 = load ptr, ptr %10, align 8, !invariant.load !3, !dereferenceable !4
  %12 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 4, i32 0
  %13 = load ptr, ptr %12, align 8, !invariant.load !3, !dereferenceable !4
  %14 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 5, i32 0
  %15 = load ptr, ptr %14, align 8, !invariant.load !3, !dereferenceable !5
  %16 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 6, i32 0
  %17 = load ptr, ptr %16, align 8, !invariant.load !3, !dereferenceable !4
  %18 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 7, i32 0
  %19 = load ptr, ptr %18, align 8, !invariant.load !3, !dereferenceable !5
  %20 = getelementptr inbounds %XLA_CPU_KernelCallFrame, ptr %0, i32 0, i32 1
  %21 = load ptr, ptr %20, align 8
  %22 = getelementptr inbounds %kernel_dim3, ptr %21, i32 0, i32 0
  %23 = load i64, ptr %22, align 4, !invariant.load !3
  %24 = getelementptr inbounds %kernel_dim3, ptr %21, i32 0, i32 1
  %25 = load i64, ptr %24, align 4, !invariant.load !3
  %26 = getelementptr inbounds %kernel_dim3, ptr %21, i32 0, i32 2
  %27 = load i64, ptr %26, align 4, !invariant.load !3
  call void @broadcast_add_fusion_wrapped(ptr %5, ptr %7, ptr %9, ptr %11, ptr %13, ptr %15, ptr %17, ptr %19, i64 %23, i64 %25, i64 %27)
  ret ptr null
}

; Function Attrs: alwaysinline
define internal void @broadcast_add_fusion_wrapped(ptr noalias align 64 dereferenceable(320) %0, ptr noalias align 64 dereferenceable(320) %1, ptr noalias align 64 dereferenceable(320) %2, ptr noalias align 64 dereferenceable(320) %3, ptr noalias align 64 dereferenceable(320) %4, ptr noalias align 64 dereferenceable(15360) %5, ptr noalias align 64 dereferenceable(320) %6, ptr noalias align 64 dereferenceable(15360) %7, i64 %8, i64 %9, i64 %10) #1 {
  %12 = icmp sge i64 %8, 0
  %13 = icmp sle i64 %8, 2
  %14 = and i1 %12, %13
  br i1 %14, label %15, label %58

15:                                               ; preds = %11
  %16 = mul nsw i64 %8, 1280
  br label %17

17:                                               ; preds = %55, %15
  %18 = phi i64 [ %56, %55 ], [ 0, %15 ]
  %19 = icmp slt i64 %18, 16
  br i1 %19, label %20, label %57

20:                                               ; preds = %17
  %21 = mul nsw i64 %18, 80
  %22 = add nsw i64 %16, %21
  br label %23

23:                                               ; preds = %26, %20
  %24 = phi i64 [ %54, %26 ], [ 0, %20 ]
  %25 = icmp slt i64 %24, 80
  br i1 %25, label %26, label %55

26:                                               ; preds = %23
  %27 = add nsw i64 %22, %24
  %28 = getelementptr inbounds [3840 x float], ptr %5, i32 0, i64 %27
  %29 = load float, ptr %28, align 4, !invariant.load !3
  %30 = getelementptr inbounds [80 x float], ptr %6, i32 0, i64 %24
  %31 = load float, ptr %30, align 4, !invariant.load !3
  %32 = fmul float %29, %31
  %33 = getelementptr inbounds [80 x float], ptr %4, i32 0, i64 %24
  %34 = load float, ptr %33, align 4, !invariant.load !3
  %35 = fadd float %32, %34
  %36 = call float @llvm.maximum.f32(float %35, float 0.000000e+00)
  %37 = getelementptr inbounds [80 x float], ptr %3, i32 0, i64 %24
  %38 = load float, ptr %37, align 4, !invariant.load !3
  %39 = fmul float %36, %38
  %40 = getelementptr inbounds [80 x float], ptr %2, i32 0, i64 %24
  %41 = load float, ptr %40, align 4, !invariant.load !3
  %42 = fadd float %39, %41
  %43 = call float @llvm.maximum.f32(float %42, float 0.000000e+00)
  %44 = getelementptr inbounds [80 x float], ptr %1, i32 0, i64 %24
  %45 = load float, ptr %44, align 4, !invariant.load !3
  %46 = fmul float %43, %45
  %47 = getelementptr inbounds [80 x float], ptr %0, i32 0, i64 %24
  %48 = load float, ptr %47, align 4, !invariant.load !3
  %49 = fadd float %46, %48
  %50 = call float @llvm.maximum.f32(float %49, float 0.000000e+00)
  %51 = fmul float %50, 7.500000e-01
  %52 = fadd float %51, 1.250000e-01
  %53 = getelementptr inbounds [3840 x float], ptr %7, i32 0, i64 %27
  store float %52, ptr %53, align 4
  %54 = add i64 %24, 1
  br label %23

55:                                               ; preds = %23
  %56 = add i64 %18, 1
  br label %17, !llvm.loop !6

57:                                               ; preds = %17
  br label %58

58:                                               ; preds = %57, %11
  ret void
}

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.maximum.f32(float, float) #2

attributes #0 = { uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { alwaysinline }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 0}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 320}
!5 = !{i64 15360}
!6 = distinct !{!6, !7}
!7 = !{!"llvm.loop.unroll.disable"}
