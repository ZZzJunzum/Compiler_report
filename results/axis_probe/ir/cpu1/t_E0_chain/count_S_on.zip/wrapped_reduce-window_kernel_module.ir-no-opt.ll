; ModuleID = '__compute_module_wrapped_reduce-window_kernel_module'
source_filename = "__compute_module_wrapped_reduce-window_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

%XLA_CPU_KernelCallFrame = type { ptr, ptr, i64, ptr }
%XLA_CPU_KernelArg = type { ptr, i64 }
%kernel_dim3 = type { i64, i64, i64 }

; Function Attrs: uwtable
define ptr @wrapped_reduce-window(ptr %0) #0 {
  %2 = getelementptr inbounds %XLA_CPU_KernelCallFrame, ptr %0, i32 0, i32 3
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 0, i32 0
  %5 = load ptr, ptr %4, align 8, !invariant.load !3, !dereferenceable !4
  %6 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 1, i32 0
  %7 = load ptr, ptr %6, align 8, !invariant.load !3, !dereferenceable !5
  %8 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 2, i32 0
  %9 = load ptr, ptr %8, align 8, !invariant.load !3, !dereferenceable !6
  %10 = getelementptr inbounds %XLA_CPU_KernelCallFrame, ptr %0, i32 0, i32 1
  %11 = load ptr, ptr %10, align 8
  %12 = getelementptr inbounds %kernel_dim3, ptr %11, i32 0, i32 0
  %13 = load i64, ptr %12, align 4, !invariant.load !3
  %14 = getelementptr inbounds %kernel_dim3, ptr %11, i32 0, i32 1
  %15 = load i64, ptr %14, align 4, !invariant.load !3
  %16 = getelementptr inbounds %kernel_dim3, ptr %11, i32 0, i32 2
  %17 = load i64, ptr %16, align 4, !invariant.load !3
  call void @wrapped_reduce-window_wrapped(ptr %5, ptr %7, ptr %9, i64 %13, i64 %15, i64 %17)
  ret ptr null
}

; Function Attrs: alwaysinline
define internal void @wrapped_reduce-window_wrapped(ptr noalias align 64 dereferenceable(15360) %0, ptr noalias align 64 dereferenceable(4) %1, ptr noalias align 64 dereferenceable(24) %2, i64 %3, i64 %4, i64 %5) #1 {
  %7 = getelementptr inbounds [1 x i32], ptr %1, i32 0, i32 0
  %8 = load i32, ptr %7, align 4, !invariant.load !3
  br label %9

9:                                                ; preds = %60, %6
  %10 = phi i64 [ %61, %60 ], [ 0, %6 ]
  %11 = icmp slt i64 %10, 2
  br i1 %11, label %12, label %62

12:                                               ; preds = %9
  %13 = mul nsw i64 %10, 32
  %14 = mul nsw i64 %10, 3
  br label %15

15:                                               ; preds = %56, %12
  %16 = phi i64 [ %59, %56 ], [ 0, %12 ]
  %17 = icmp slt i64 %16, 3
  br i1 %17, label %18, label %60

18:                                               ; preds = %15
  %19 = mul nsw i64 %16, 32
  br label %20

20:                                               ; preds = %54, %18
  %21 = phi i64 [ %55, %54 ], [ 0, %18 ]
  %22 = phi i32 [ %31, %54 ], [ %8, %18 ]
  %23 = icmp slt i64 %21, 32
  br i1 %23, label %24, label %56

24:                                               ; preds = %20
  %25 = add nsw i64 %13, %21
  %26 = icmp sge i64 %25, 8
  %27 = icmp sle i64 %25, 55
  %28 = and i1 %26, %27
  br label %29

29:                                               ; preds = %52, %24
  %30 = phi i64 [ %53, %52 ], [ 0, %24 ]
  %31 = phi i32 [ %51, %52 ], [ %22, %24 ]
  %32 = icmp slt i64 %30, 32
  br i1 %32, label %33, label %54

33:                                               ; preds = %29
  %34 = add nsw i64 %19, %30
  %35 = icmp sge i64 %34, 8
  %36 = icmp sle i64 %34, 87
  %37 = and i1 %35, %36
  %38 = and i1 %28, %37
  br i1 %38, label %39, label %49

39:                                               ; preds = %33
  %40 = mul nsw i64 %10, 2560
  %41 = add nsw i64 %40, %19
  %42 = mul nsw i64 %21, 80
  %43 = add nsw i64 %41, %42
  %44 = add nsw i64 %43, %30
  %45 = add nsw i64 %44, -648
  %46 = getelementptr inbounds [3840 x i32], ptr %0, i32 0, i64 %45
  %47 = load i32, ptr %46, align 4, !invariant.load !3
  %48 = add i32 %31, %47
  br label %50

49:                                               ; preds = %33
  br label %50

50:                                               ; preds = %39, %49
  %51 = phi i32 [ %31, %49 ], [ %48, %39 ]
  br label %52

52:                                               ; preds = %50
  %53 = add i64 %30, 1
  br label %29

54:                                               ; preds = %29
  %55 = add i64 %21, 1
  br label %20, !llvm.loop !7

56:                                               ; preds = %20
  %57 = add nsw i64 %14, %16
  %58 = getelementptr inbounds [6 x i32], ptr %2, i32 0, i64 %57
  store i32 %22, ptr %58, align 4
  %59 = add i64 %16, 1
  br label %15, !llvm.loop !7

60:                                               ; preds = %15
  %61 = add i64 %10, 1
  br label %9, !llvm.loop !7

62:                                               ; preds = %9
  ret void
}

attributes #0 = { uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { alwaysinline }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 4}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 15360}
!5 = !{i64 4}
!6 = !{i64 24}
!7 = distinct !{!7, !8}
!8 = !{!"llvm.loop.unroll.disable"}
