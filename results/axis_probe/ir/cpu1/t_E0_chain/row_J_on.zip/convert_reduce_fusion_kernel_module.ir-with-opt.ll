; ModuleID = '__compute_module_convert_reduce_fusion_kernel_module'
source_filename = "__compute_module_convert_reduce_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @convert_reduce_fusion(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !4
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !4
  %9 = getelementptr inbounds nuw i8, ptr %3, i64 64
  %10 = load ptr, ptr %9, align 8, !invariant.load !3, !dereferenceable !4
  %11 = getelementptr inbounds nuw i8, ptr %3, i64 80
  %12 = load ptr, ptr %11, align 8, !invariant.load !3, !dereferenceable !5
  %13 = getelementptr inbounds nuw i8, ptr %3, i64 96
  %14 = load ptr, ptr %13, align 8, !invariant.load !3, !dereferenceable !5
  %15 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %16 = load ptr, ptr %15, align 8
  %17 = load i64, ptr %16, align 4, !invariant.load !3
  tail call void @llvm.experimental.noalias.scope.decl(metadata !6)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !11)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !13)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !15)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !17)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !19)
  %18 = icmp ult i64 %17, 2
  br i1 %18, label %19, label %convert_reduce_fusion_wrapped.exit

19:                                               ; preds = %1
  %20 = getelementptr inbounds nuw i8, ptr %3, i64 48
  %21 = load ptr, ptr %20, align 8, !invariant.load !3, !dereferenceable !21
  %22 = mul nuw nsw i64 %17, 24
  %.idx = mul nuw nsw i64 %17, 7680
  %23 = getelementptr i8, ptr %21, i64 %.idx
  %24 = getelementptr inbounds nuw i8, ptr %10, i64 32
  %wide.load14 = load <8 x float>, ptr %10, align 4, !invariant.load !3, !alias.scope !15, !noalias !22
  %wide.load15 = load <8 x float>, ptr %24, align 4, !invariant.load !3, !alias.scope !15, !noalias !22
  %25 = getelementptr inbounds nuw i8, ptr %8, i64 32
  %wide.load16 = load <8 x float>, ptr %8, align 4, !invariant.load !3, !alias.scope !11, !noalias !23
  %wide.load17 = load <8 x float>, ptr %25, align 4, !invariant.load !3, !alias.scope !11, !noalias !23
  %26 = getelementptr inbounds nuw i8, ptr %6, i64 32
  %wide.load18 = load <8 x float>, ptr %6, align 4, !invariant.load !3, !alias.scope !9, !noalias !24
  %wide.load19 = load <8 x float>, ptr %26, align 4, !invariant.load !3, !alias.scope !9, !noalias !24
  %27 = getelementptr inbounds nuw i8, ptr %4, i64 32
  %wide.load20 = load <8 x float>, ptr %4, align 4, !invariant.load !3, !alias.scope !6, !noalias !25
  %wide.load21 = load <8 x float>, ptr %27, align 4, !invariant.load !3, !alias.scope !6, !noalias !25
  %28 = getelementptr inbounds nuw i8, ptr %10, i64 64
  %29 = getelementptr inbounds nuw i8, ptr %10, i64 96
  %wide.load14.1 = load <8 x float>, ptr %28, align 4, !invariant.load !3, !alias.scope !15, !noalias !22
  %wide.load15.1 = load <8 x float>, ptr %29, align 4, !invariant.load !3, !alias.scope !15, !noalias !22
  %30 = getelementptr inbounds nuw i8, ptr %8, i64 64
  %31 = getelementptr inbounds nuw i8, ptr %8, i64 96
  %wide.load16.1 = load <8 x float>, ptr %30, align 4, !invariant.load !3, !alias.scope !11, !noalias !23
  %wide.load17.1 = load <8 x float>, ptr %31, align 4, !invariant.load !3, !alias.scope !11, !noalias !23
  %32 = getelementptr inbounds nuw i8, ptr %6, i64 64
  %33 = getelementptr inbounds nuw i8, ptr %6, i64 96
  %wide.load18.1 = load <8 x float>, ptr %32, align 4, !invariant.load !3, !alias.scope !9, !noalias !24
  %wide.load19.1 = load <8 x float>, ptr %33, align 4, !invariant.load !3, !alias.scope !9, !noalias !24
  %34 = getelementptr inbounds nuw i8, ptr %4, i64 64
  %35 = getelementptr inbounds nuw i8, ptr %4, i64 96
  %wide.load20.1 = load <8 x float>, ptr %34, align 4, !invariant.load !3, !alias.scope !6, !noalias !25
  %wide.load21.1 = load <8 x float>, ptr %35, align 4, !invariant.load !3, !alias.scope !6, !noalias !25
  %36 = getelementptr inbounds nuw i8, ptr %10, i64 128
  %37 = getelementptr inbounds nuw i8, ptr %10, i64 160
  %wide.load14.2 = load <8 x float>, ptr %36, align 4, !invariant.load !3, !alias.scope !15, !noalias !22
  %wide.load15.2 = load <8 x float>, ptr %37, align 4, !invariant.load !3, !alias.scope !15, !noalias !22
  %38 = getelementptr inbounds nuw i8, ptr %8, i64 128
  %39 = getelementptr inbounds nuw i8, ptr %8, i64 160
  %wide.load16.2 = load <8 x float>, ptr %38, align 4, !invariant.load !3, !alias.scope !11, !noalias !23
  %wide.load17.2 = load <8 x float>, ptr %39, align 4, !invariant.load !3, !alias.scope !11, !noalias !23
  %40 = getelementptr inbounds nuw i8, ptr %6, i64 128
  %41 = getelementptr inbounds nuw i8, ptr %6, i64 160
  %wide.load18.2 = load <8 x float>, ptr %40, align 4, !invariant.load !3, !alias.scope !9, !noalias !24
  %wide.load19.2 = load <8 x float>, ptr %41, align 4, !invariant.load !3, !alias.scope !9, !noalias !24
  %42 = getelementptr inbounds nuw i8, ptr %4, i64 128
  %43 = getelementptr inbounds nuw i8, ptr %4, i64 160
  %wide.load20.2 = load <8 x float>, ptr %42, align 4, !invariant.load !3, !alias.scope !6, !noalias !25
  %wide.load21.2 = load <8 x float>, ptr %43, align 4, !invariant.load !3, !alias.scope !6, !noalias !25
  %44 = getelementptr inbounds nuw i8, ptr %10, i64 192
  %45 = getelementptr inbounds nuw i8, ptr %10, i64 224
  %wide.load14.3 = load <8 x float>, ptr %44, align 4, !invariant.load !3, !alias.scope !15, !noalias !22
  %wide.load15.3 = load <8 x float>, ptr %45, align 4, !invariant.load !3, !alias.scope !15, !noalias !22
  %46 = getelementptr inbounds nuw i8, ptr %8, i64 192
  %47 = getelementptr inbounds nuw i8, ptr %8, i64 224
  %wide.load16.3 = load <8 x float>, ptr %46, align 4, !invariant.load !3, !alias.scope !11, !noalias !23
  %wide.load17.3 = load <8 x float>, ptr %47, align 4, !invariant.load !3, !alias.scope !11, !noalias !23
  %48 = getelementptr inbounds nuw i8, ptr %6, i64 192
  %49 = getelementptr inbounds nuw i8, ptr %6, i64 224
  %wide.load18.3 = load <8 x float>, ptr %48, align 4, !invariant.load !3, !alias.scope !9, !noalias !24
  %wide.load19.3 = load <8 x float>, ptr %49, align 4, !invariant.load !3, !alias.scope !9, !noalias !24
  %50 = getelementptr inbounds nuw i8, ptr %4, i64 192
  %51 = getelementptr inbounds nuw i8, ptr %4, i64 224
  %wide.load20.3 = load <8 x float>, ptr %50, align 4, !invariant.load !3, !alias.scope !6, !noalias !25
  %wide.load21.3 = load <8 x float>, ptr %51, align 4, !invariant.load !3, !alias.scope !6, !noalias !25
  %52 = getelementptr inbounds nuw i8, ptr %10, i64 256
  %53 = getelementptr inbounds nuw i8, ptr %10, i64 288
  %wide.load14.4 = load <8 x float>, ptr %52, align 4, !invariant.load !3, !alias.scope !15, !noalias !22
  %wide.load15.4 = load <8 x float>, ptr %53, align 4, !invariant.load !3, !alias.scope !15, !noalias !22
  %54 = getelementptr inbounds nuw i8, ptr %8, i64 256
  %55 = getelementptr inbounds nuw i8, ptr %8, i64 288
  %wide.load16.4 = load <8 x float>, ptr %54, align 4, !invariant.load !3, !alias.scope !11, !noalias !23
  %wide.load17.4 = load <8 x float>, ptr %55, align 4, !invariant.load !3, !alias.scope !11, !noalias !23
  %56 = getelementptr inbounds nuw i8, ptr %6, i64 256
  %57 = getelementptr inbounds nuw i8, ptr %6, i64 288
  %wide.load18.4 = load <8 x float>, ptr %56, align 4, !invariant.load !3, !alias.scope !9, !noalias !24
  %wide.load19.4 = load <8 x float>, ptr %57, align 4, !invariant.load !3, !alias.scope !9, !noalias !24
  %58 = getelementptr inbounds nuw i8, ptr %4, i64 256
  %59 = getelementptr inbounds nuw i8, ptr %4, i64 288
  %wide.load20.4 = load <8 x float>, ptr %58, align 4, !invariant.load !3, !alias.scope !6, !noalias !25
  %wide.load21.4 = load <8 x float>, ptr %59, align 4, !invariant.load !3, !alias.scope !6, !noalias !25
  br label %vector.ph

vector.ph:                                        ; preds = %19, %vector.ph
  %60 = phi i64 [ 0, %19 ], [ %182, %vector.ph ]
  %.idx1 = mul nuw nsw i64 %60, 320
  %61 = getelementptr i8, ptr %23, i64 %.idx1
  %62 = getelementptr i8, ptr %61, i64 32
  %wide.load = load <8 x float>, ptr %61, align 4, !invariant.load !3, !alias.scope !13, !noalias !26
  %wide.load13 = load <8 x float>, ptr %62, align 4, !invariant.load !3, !alias.scope !13, !noalias !26
  %63 = fmul <8 x float> %wide.load, %wide.load14
  %64 = fmul <8 x float> %wide.load13, %wide.load15
  %65 = fadd <8 x float> %63, %wide.load16
  %66 = fadd <8 x float> %64, %wide.load17
  %67 = fcmp ogt <8 x float> %65, zeroinitializer
  %68 = fcmp ogt <8 x float> %66, zeroinitializer
  %69 = zext <8 x i1> %67 to <8 x i32>
  %70 = zext <8 x i1> %68 to <8 x i32>
  %71 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %65, <8 x float> zeroinitializer)
  %72 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %66, <8 x float> zeroinitializer)
  %73 = fmul <8 x float> %wide.load18, %71
  %74 = fmul <8 x float> %wide.load19, %72
  %75 = fadd <8 x float> %wide.load20, %73
  %76 = fadd <8 x float> %wide.load21, %74
  %77 = fcmp ogt <8 x float> %75, zeroinitializer
  %78 = fcmp ogt <8 x float> %76, zeroinitializer
  %79 = zext <8 x i1> %77 to <8 x i32>
  %80 = zext <8 x i1> %78 to <8 x i32>
  %81 = getelementptr i8, ptr %61, i64 64
  %82 = getelementptr i8, ptr %61, i64 96
  %wide.load.1 = load <8 x float>, ptr %81, align 4, !invariant.load !3, !alias.scope !13, !noalias !26
  %wide.load13.1 = load <8 x float>, ptr %82, align 4, !invariant.load !3, !alias.scope !13, !noalias !26
  %83 = fmul <8 x float> %wide.load.1, %wide.load14.1
  %84 = fmul <8 x float> %wide.load13.1, %wide.load15.1
  %85 = fadd <8 x float> %83, %wide.load16.1
  %86 = fadd <8 x float> %84, %wide.load17.1
  %87 = fcmp ogt <8 x float> %85, zeroinitializer
  %88 = fcmp ogt <8 x float> %86, zeroinitializer
  %89 = zext <8 x i1> %87 to <8 x i32>
  %90 = zext <8 x i1> %88 to <8 x i32>
  %91 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %85, <8 x float> zeroinitializer)
  %92 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %86, <8 x float> zeroinitializer)
  %93 = fmul <8 x float> %wide.load18.1, %91
  %94 = fmul <8 x float> %wide.load19.1, %92
  %95 = fadd <8 x float> %wide.load20.1, %93
  %96 = fadd <8 x float> %wide.load21.1, %94
  %97 = fcmp ogt <8 x float> %95, zeroinitializer
  %98 = fcmp ogt <8 x float> %96, zeroinitializer
  %99 = zext <8 x i1> %97 to <8 x i32>
  %100 = zext <8 x i1> %98 to <8 x i32>
  %101 = add nuw nsw <8 x i32> %69, %89
  %102 = add nuw nsw <8 x i32> %70, %90
  %103 = add nuw nsw <8 x i32> %79, %99
  %104 = add nuw nsw <8 x i32> %80, %100
  %105 = getelementptr i8, ptr %61, i64 128
  %106 = getelementptr i8, ptr %61, i64 160
  %wide.load.2 = load <8 x float>, ptr %105, align 4, !invariant.load !3, !alias.scope !13, !noalias !26
  %wide.load13.2 = load <8 x float>, ptr %106, align 4, !invariant.load !3, !alias.scope !13, !noalias !26
  %107 = fmul <8 x float> %wide.load.2, %wide.load14.2
  %108 = fmul <8 x float> %wide.load13.2, %wide.load15.2
  %109 = fadd <8 x float> %107, %wide.load16.2
  %110 = fadd <8 x float> %108, %wide.load17.2
  %111 = fcmp ogt <8 x float> %109, zeroinitializer
  %112 = fcmp ogt <8 x float> %110, zeroinitializer
  %113 = zext <8 x i1> %111 to <8 x i32>
  %114 = zext <8 x i1> %112 to <8 x i32>
  %115 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %109, <8 x float> zeroinitializer)
  %116 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %110, <8 x float> zeroinitializer)
  %117 = fmul <8 x float> %wide.load18.2, %115
  %118 = fmul <8 x float> %wide.load19.2, %116
  %119 = fadd <8 x float> %wide.load20.2, %117
  %120 = fadd <8 x float> %wide.load21.2, %118
  %121 = fcmp ogt <8 x float> %119, zeroinitializer
  %122 = fcmp ogt <8 x float> %120, zeroinitializer
  %123 = zext <8 x i1> %121 to <8 x i32>
  %124 = zext <8 x i1> %122 to <8 x i32>
  %125 = add nuw nsw <8 x i32> %101, %113
  %126 = add nuw nsw <8 x i32> %102, %114
  %127 = add nuw nsw <8 x i32> %103, %123
  %128 = add nuw nsw <8 x i32> %104, %124
  %129 = getelementptr i8, ptr %61, i64 192
  %130 = getelementptr i8, ptr %61, i64 224
  %wide.load.3 = load <8 x float>, ptr %129, align 4, !invariant.load !3, !alias.scope !13, !noalias !26
  %wide.load13.3 = load <8 x float>, ptr %130, align 4, !invariant.load !3, !alias.scope !13, !noalias !26
  %131 = fmul <8 x float> %wide.load.3, %wide.load14.3
  %132 = fmul <8 x float> %wide.load13.3, %wide.load15.3
  %133 = fadd <8 x float> %131, %wide.load16.3
  %134 = fadd <8 x float> %132, %wide.load17.3
  %135 = fcmp ogt <8 x float> %133, zeroinitializer
  %136 = fcmp ogt <8 x float> %134, zeroinitializer
  %137 = zext <8 x i1> %135 to <8 x i32>
  %138 = zext <8 x i1> %136 to <8 x i32>
  %139 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %133, <8 x float> zeroinitializer)
  %140 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %134, <8 x float> zeroinitializer)
  %141 = fmul <8 x float> %wide.load18.3, %139
  %142 = fmul <8 x float> %wide.load19.3, %140
  %143 = fadd <8 x float> %wide.load20.3, %141
  %144 = fadd <8 x float> %wide.load21.3, %142
  %145 = fcmp ogt <8 x float> %143, zeroinitializer
  %146 = fcmp ogt <8 x float> %144, zeroinitializer
  %147 = zext <8 x i1> %145 to <8 x i32>
  %148 = zext <8 x i1> %146 to <8 x i32>
  %149 = add nuw nsw <8 x i32> %125, %137
  %150 = add nuw nsw <8 x i32> %126, %138
  %151 = add nuw nsw <8 x i32> %127, %147
  %152 = add nuw nsw <8 x i32> %128, %148
  %153 = getelementptr i8, ptr %61, i64 256
  %154 = getelementptr i8, ptr %61, i64 288
  %wide.load.4 = load <8 x float>, ptr %153, align 4, !invariant.load !3, !alias.scope !13, !noalias !26
  %wide.load13.4 = load <8 x float>, ptr %154, align 4, !invariant.load !3, !alias.scope !13, !noalias !26
  %155 = fmul <8 x float> %wide.load.4, %wide.load14.4
  %156 = fmul <8 x float> %wide.load13.4, %wide.load15.4
  %157 = fadd <8 x float> %155, %wide.load16.4
  %158 = fadd <8 x float> %156, %wide.load17.4
  %159 = fcmp ogt <8 x float> %157, zeroinitializer
  %160 = fcmp ogt <8 x float> %158, zeroinitializer
  %161 = zext <8 x i1> %159 to <8 x i32>
  %162 = zext <8 x i1> %160 to <8 x i32>
  %163 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %157, <8 x float> zeroinitializer)
  %164 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %158, <8 x float> zeroinitializer)
  %165 = fmul <8 x float> %wide.load18.4, %163
  %166 = fmul <8 x float> %wide.load19.4, %164
  %167 = fadd <8 x float> %wide.load20.4, %165
  %168 = fadd <8 x float> %wide.load21.4, %166
  %169 = fcmp ogt <8 x float> %167, zeroinitializer
  %170 = fcmp ogt <8 x float> %168, zeroinitializer
  %171 = zext <8 x i1> %169 to <8 x i32>
  %172 = zext <8 x i1> %170 to <8 x i32>
  %173 = add nuw nsw <8 x i32> %149, %161
  %174 = add nuw nsw <8 x i32> %150, %162
  %175 = add nuw nsw <8 x i32> %151, %171
  %176 = add nuw nsw <8 x i32> %152, %172
  %bin.rdx22 = add nuw nsw <8 x i32> %174, %173
  %177 = tail call i32 @llvm.vector.reduce.add.v8i32(<8 x i32> %bin.rdx22)
  %bin.rdx = add nuw nsw <8 x i32> %176, %175
  %178 = tail call i32 @llvm.vector.reduce.add.v8i32(<8 x i32> %bin.rdx)
  %179 = add nuw nsw i64 %60, %22
  %180 = getelementptr inbounds nuw i32, ptr %12, i64 %179
  store i32 %177, ptr %180, align 4, !alias.scope !17, !noalias !27
  %181 = getelementptr inbounds nuw i32, ptr %14, i64 %179
  store i32 %178, ptr %181, align 4, !alias.scope !19, !noalias !28
  %182 = add nuw nsw i64 %60, 1
  %exitcond6.not = icmp eq i64 %182, 24
  br i1 %exitcond6.not, label %convert_reduce_fusion_wrapped.exit, label %vector.ph, !llvm.loop !29

convert_reduce_fusion_wrapped.exit:               ; preds = %vector.ph, %1
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.maximum.v8f32(<8 x float>, <8 x float>) #2

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.vector.reduce.add.v8i32(<8 x i32>) #3

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #3 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 1}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 320}
!5 = !{i64 192}
!6 = !{!7}
!7 = distinct !{!7, !8, !"convert_reduce_fusion_wrapped: argument 0"}
!8 = distinct !{!8, !"convert_reduce_fusion_wrapped"}
!9 = !{!10}
!10 = distinct !{!10, !8, !"convert_reduce_fusion_wrapped: argument 1"}
!11 = !{!12}
!12 = distinct !{!12, !8, !"convert_reduce_fusion_wrapped: argument 2"}
!13 = !{!14}
!14 = distinct !{!14, !8, !"convert_reduce_fusion_wrapped: argument 3"}
!15 = !{!16}
!16 = distinct !{!16, !8, !"convert_reduce_fusion_wrapped: argument 4"}
!17 = !{!18}
!18 = distinct !{!18, !8, !"convert_reduce_fusion_wrapped: argument 5"}
!19 = !{!20}
!20 = distinct !{!20, !8, !"convert_reduce_fusion_wrapped: argument 6"}
!21 = !{i64 15360}
!22 = !{!7, !10, !12, !14, !18, !20}
!23 = !{!7, !10, !14, !16, !18, !20}
!24 = !{!7, !12, !14, !16, !18, !20}
!25 = !{!10, !12, !14, !16, !18, !20}
!26 = !{!7, !10, !12, !16, !18, !20}
!27 = !{!7, !10, !12, !14, !16, !20}
!28 = !{!7, !10, !12, !14, !16, !18}
!29 = distinct !{!29, !30}
!30 = !{!"llvm.loop.unroll.disable"}
