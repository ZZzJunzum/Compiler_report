; ModuleID = '__compute_module_convert_reduce_fusion_kernel_module'
source_filename = "__compute_module_convert_reduce_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

%XLA_CPU_KernelCallFrame = type { ptr, ptr, i64, ptr }
%XLA_CPU_KernelArg = type { ptr, i64 }
%kernel_dim3 = type { i64, i64, i64 }

; Function Attrs: uwtable
define ptr @convert_reduce_fusion(ptr %0) #0 {
  %2 = getelementptr inbounds %XLA_CPU_KernelCallFrame, ptr %0, i32 0, i32 3
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 0, i32 0
  %5 = load ptr, ptr %4, align 8, !invariant.load !3, !dereferenceable !4
  %6 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 1, i32 0
  %7 = load ptr, ptr %6, align 8, !invariant.load !3, !dereferenceable !5
  %8 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 2, i32 0
  %9 = load ptr, ptr %8, align 8, !invariant.load !3, !dereferenceable !4
  %10 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 3, i32 0
  %11 = load ptr, ptr %10, align 8, !invariant.load !3, !dereferenceable !5
  %12 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 4, i32 0
  %13 = load ptr, ptr %12, align 8, !invariant.load !3, !dereferenceable !6
  %14 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 5, i32 0
  %15 = load ptr, ptr %14, align 8, !invariant.load !3, !dereferenceable !6
  %16 = getelementptr inbounds %XLA_CPU_KernelCallFrame, ptr %0, i32 0, i32 1
  %17 = load ptr, ptr %16, align 8
  %18 = getelementptr inbounds %kernel_dim3, ptr %17, i32 0, i32 0
  %19 = load i64, ptr %18, align 4, !invariant.load !3
  %20 = getelementptr inbounds %kernel_dim3, ptr %17, i32 0, i32 1
  %21 = load i64, ptr %20, align 4, !invariant.load !3
  %22 = getelementptr inbounds %kernel_dim3, ptr %17, i32 0, i32 2
  %23 = load i64, ptr %22, align 4, !invariant.load !3
  call void @convert_reduce_fusion_wrapped(ptr %5, ptr %7, ptr %9, ptr %11, ptr %13, ptr %15, i64 %19, i64 %21, i64 %23)
  ret ptr null
}

; Function Attrs: alwaysinline
define internal void @convert_reduce_fusion_wrapped(ptr noalias align 64 dereferenceable(57600) %0, ptr noalias align 64 dereferenceable(48) %1, ptr noalias align 64 dereferenceable(57600) %2, ptr noalias align 64 dereferenceable(48) %3, ptr noalias align 64 dereferenceable(4) %4, ptr noalias align 64 dereferenceable(4) %5, i64 %6, i64 %7, i64 %8) #1 {
  br label %10

10:                                               ; preds = %61, %9
  %11 = phi i64 [ %62, %61 ], [ 0, %9 ]
  %12 = phi i32 [ %19, %61 ], [ 0, %9 ]
  %13 = phi i32 [ %20, %61 ], [ 0, %9 ]
  %14 = icmp slt i64 %11, 3
  br i1 %14, label %15, label %63

15:                                               ; preds = %10
  %16 = mul nsw i64 %11, 4800
  br label %17

17:                                               ; preds = %59, %15
  %18 = phi i64 [ %60, %59 ], [ 0, %15 ]
  %19 = phi i32 [ %27, %59 ], [ %12, %15 ]
  %20 = phi i32 [ %28, %59 ], [ %13, %15 ]
  %21 = icmp slt i64 %18, 20
  br i1 %21, label %22, label %61

22:                                               ; preds = %17
  %23 = mul nsw i64 %18, 240
  %24 = add nsw i64 %16, %23
  br label %25

25:                                               ; preds = %57, %22
  %26 = phi i64 [ %58, %57 ], [ 0, %22 ]
  %27 = phi i32 [ %35, %57 ], [ %19, %22 ]
  %28 = phi i32 [ %36, %57 ], [ %20, %22 ]
  %29 = icmp slt i64 %26, 20
  br i1 %29, label %30, label %59

30:                                               ; preds = %25
  %31 = mul nsw i64 %26, 12
  %32 = add nsw i64 %24, %31
  br label %33

33:                                               ; preds = %38, %30
  %34 = phi i64 [ %56, %38 ], [ 0, %30 ]
  %35 = phi i32 [ %54, %38 ], [ %27, %30 ]
  %36 = phi i32 [ %55, %38 ], [ %28, %30 ]
  %37 = icmp slt i64 %34, 12
  br i1 %37, label %38, label %57

38:                                               ; preds = %33
  %39 = add nsw i64 %32, %34
  %40 = getelementptr inbounds [14400 x float], ptr %2, i32 0, i64 %39
  %41 = load float, ptr %40, align 4, !invariant.load !3
  %42 = getelementptr inbounds [12 x float], ptr %3, i32 0, i64 %34
  %43 = load float, ptr %42, align 4, !invariant.load !3
  %44 = fadd float %41, %43
  %45 = fcmp ogt float %44, 0.000000e+00
  %46 = zext i1 %45 to i32
  %47 = getelementptr inbounds [14400 x float], ptr %0, i32 0, i64 %39
  %48 = load float, ptr %47, align 4, !invariant.load !3
  %49 = getelementptr inbounds [12 x float], ptr %1, i32 0, i64 %34
  %50 = load float, ptr %49, align 4, !invariant.load !3
  %51 = fadd float %48, %50
  %52 = fcmp ogt float %51, 0.000000e+00
  %53 = zext i1 %52 to i32
  %54 = add i32 %35, %46
  %55 = add i32 %36, %53
  %56 = add i64 %34, 1
  br label %33

57:                                               ; preds = %33
  %58 = add i64 %26, 1
  br label %25, !llvm.loop !7

59:                                               ; preds = %25
  %60 = add i64 %18, 1
  br label %17, !llvm.loop !7

61:                                               ; preds = %17
  %62 = add i64 %11, 1
  br label %10, !llvm.loop !7

63:                                               ; preds = %10
  %64 = getelementptr inbounds [1 x i32], ptr %4, i32 0, i32 0
  store i32 %12, ptr %64, align 4
  %65 = getelementptr inbounds [1 x i32], ptr %5, i32 0, i32 0
  store i32 %13, ptr %65, align 4
  ret void
}

attributes #0 = { uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { alwaysinline }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 2}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 57600}
!5 = !{i64 48}
!6 = !{i64 4}
!7 = distinct !{!7, !8}
!8 = !{!"llvm.loop.unroll.disable"}
