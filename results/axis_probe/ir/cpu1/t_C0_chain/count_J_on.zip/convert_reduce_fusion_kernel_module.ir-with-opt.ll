; ModuleID = '__compute_module_convert_reduce_fusion_kernel_module'
source_filename = "__compute_module_convert_reduce_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @convert_reduce_fusion(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !5
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !4
  %9 = getelementptr inbounds nuw i8, ptr %3, i64 48
  %10 = load ptr, ptr %9, align 8, !invariant.load !3, !dereferenceable !5
  tail call void @llvm.experimental.noalias.scope.decl(metadata !6)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !11)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !13)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !15)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !17)
  %11 = load <4 x float>, ptr %10, align 4
  %12 = load <4 x float>, ptr %6, align 4
  %13 = getelementptr inbounds nuw i8, ptr %10, i64 4
  %14 = load <4 x float>, ptr %13, align 4
  %15 = getelementptr inbounds nuw i8, ptr %6, i64 4
  %16 = load <4 x float>, ptr %15, align 4
  %17 = getelementptr inbounds nuw i8, ptr %10, i64 8
  %18 = load <4 x float>, ptr %17, align 4
  %19 = getelementptr inbounds nuw i8, ptr %6, i64 8
  %20 = load <4 x float>, ptr %19, align 4
  %21 = getelementptr inbounds nuw i8, ptr %10, i64 12
  %22 = load <4 x float>, ptr %21, align 4
  %23 = getelementptr inbounds nuw i8, ptr %6, i64 12
  %24 = load <4 x float>, ptr %23, align 4
  %25 = getelementptr inbounds nuw i8, ptr %10, i64 16
  %26 = load <4 x float>, ptr %25, align 4
  %27 = getelementptr inbounds nuw i8, ptr %6, i64 16
  %28 = load <4 x float>, ptr %27, align 4
  %29 = getelementptr inbounds nuw i8, ptr %10, i64 20
  %30 = load <4 x float>, ptr %29, align 4
  %31 = getelementptr inbounds nuw i8, ptr %6, i64 20
  %32 = load <4 x float>, ptr %31, align 4
  %33 = getelementptr inbounds nuw i8, ptr %10, i64 24
  %34 = load <4 x float>, ptr %33, align 4
  %35 = getelementptr inbounds nuw i8, ptr %6, i64 24
  %36 = load <4 x float>, ptr %35, align 4
  %37 = getelementptr inbounds nuw i8, ptr %10, i64 28
  %38 = load <4 x float>, ptr %37, align 4
  %39 = getelementptr inbounds nuw i8, ptr %6, i64 28
  %40 = load <4 x float>, ptr %39, align 4
  %41 = getelementptr inbounds nuw i8, ptr %10, i64 32
  %42 = load <4 x float>, ptr %41, align 4
  %43 = getelementptr inbounds nuw i8, ptr %6, i64 32
  %44 = load <4 x float>, ptr %43, align 4
  %45 = getelementptr inbounds nuw i8, ptr %10, i64 36
  %46 = load float, ptr %45, align 4, !invariant.load !3, !alias.scope !13, !noalias !19
  %47 = getelementptr inbounds nuw i8, ptr %6, i64 36
  %48 = load float, ptr %47, align 4, !invariant.load !3, !alias.scope !9, !noalias !20
  %49 = getelementptr inbounds nuw i8, ptr %10, i64 40
  %50 = load float, ptr %49, align 4, !invariant.load !3, !alias.scope !13, !noalias !19
  %51 = getelementptr inbounds nuw i8, ptr %6, i64 40
  %52 = load float, ptr %51, align 4, !invariant.load !3, !alias.scope !9, !noalias !20
  %53 = getelementptr inbounds nuw i8, ptr %10, i64 44
  %54 = load float, ptr %53, align 4, !invariant.load !3, !alias.scope !13, !noalias !19
  %55 = getelementptr inbounds nuw i8, ptr %6, i64 44
  %56 = load float, ptr %55, align 4, !invariant.load !3, !alias.scope !9, !noalias !20
  %broadcast.splat18 = shufflevector <4 x float> %11, <4 x float> poison, <4 x i32> zeroinitializer
  %broadcast.splat20 = shufflevector <4 x float> %12, <4 x float> poison, <4 x i32> zeroinitializer
  %broadcast.splat22 = shufflevector <4 x float> %14, <4 x float> poison, <4 x i32> zeroinitializer
  %broadcast.splat24 = shufflevector <4 x float> %16, <4 x float> poison, <4 x i32> zeroinitializer
  %broadcast.splat26 = shufflevector <4 x float> %18, <4 x float> poison, <4 x i32> zeroinitializer
  %broadcast.splat28 = shufflevector <4 x float> %20, <4 x float> poison, <4 x i32> zeroinitializer
  %broadcast.splat30 = shufflevector <4 x float> %22, <4 x float> poison, <4 x i32> zeroinitializer
  %broadcast.splat32 = shufflevector <4 x float> %24, <4 x float> poison, <4 x i32> zeroinitializer
  %broadcast.splat34 = shufflevector <4 x float> %26, <4 x float> poison, <4 x i32> zeroinitializer
  %broadcast.splat36 = shufflevector <4 x float> %28, <4 x float> poison, <4 x i32> zeroinitializer
  %broadcast.splat38 = shufflevector <4 x float> %30, <4 x float> poison, <4 x i32> zeroinitializer
  %broadcast.splat40 = shufflevector <4 x float> %32, <4 x float> poison, <4 x i32> zeroinitializer
  %broadcast.splat42 = shufflevector <4 x float> %34, <4 x float> poison, <4 x i32> zeroinitializer
  %broadcast.splat44 = shufflevector <4 x float> %36, <4 x float> poison, <4 x i32> zeroinitializer
  %broadcast.splat46 = shufflevector <4 x float> %38, <4 x float> poison, <4 x i32> zeroinitializer
  %broadcast.splat48 = shufflevector <4 x float> %40, <4 x float> poison, <4 x i32> zeroinitializer
  %broadcast.splat50 = shufflevector <4 x float> %42, <4 x float> poison, <4 x i32> zeroinitializer
  %broadcast.splat52 = shufflevector <4 x float> %44, <4 x float> poison, <4 x i32> zeroinitializer
  %broadcast.splatinsert53 = insertelement <4 x float> poison, float %46, i64 0
  %broadcast.splat54 = shufflevector <4 x float> %broadcast.splatinsert53, <4 x float> poison, <4 x i32> zeroinitializer
  %broadcast.splatinsert55 = insertelement <4 x float> poison, float %48, i64 0
  %broadcast.splat56 = shufflevector <4 x float> %broadcast.splatinsert55, <4 x float> poison, <4 x i32> zeroinitializer
  %broadcast.splatinsert57 = insertelement <4 x float> poison, float %50, i64 0
  %broadcast.splat58 = shufflevector <4 x float> %broadcast.splatinsert57, <4 x float> poison, <4 x i32> zeroinitializer
  %broadcast.splatinsert59 = insertelement <4 x float> poison, float %52, i64 0
  %broadcast.splat60 = shufflevector <4 x float> %broadcast.splatinsert59, <4 x float> poison, <4 x i32> zeroinitializer
  %broadcast.splatinsert61 = insertelement <4 x float> poison, float %54, i64 0
  %broadcast.splat62 = shufflevector <4 x float> %broadcast.splatinsert61, <4 x float> poison, <4 x i32> zeroinitializer
  %broadcast.splatinsert63 = insertelement <4 x float> poison, float %56, i64 0
  %broadcast.splat64 = shufflevector <4 x float> %broadcast.splatinsert63, <4 x float> poison, <4 x i32> zeroinitializer
  br label %57

57:                                               ; preds = %1, %206
  %58 = phi i32 [ 0, %1 ], [ %204, %206 ]
  %59 = phi i32 [ 0, %1 ], [ %203, %206 ]
  %60 = phi i64 [ 0, %1 ], [ %207, %206 ]
  %61 = mul nuw nsw i64 %60, 4800
  br label %vector.ph

vector.ph:                                        ; preds = %middle.block, %57
  %62 = phi i32 [ %58, %57 ], [ %204, %middle.block ]
  %63 = phi i32 [ %59, %57 ], [ %203, %middle.block ]
  %64 = phi i64 [ 0, %57 ], [ %205, %middle.block ]
  %65 = mul nuw nsw i64 %64, 240
  %66 = add nuw nsw i64 %65, %61
  %67 = insertelement <4 x i32> <i32 poison, i32 0, i32 0, i32 0>, i32 %62, i64 0
  %68 = insertelement <4 x i32> <i32 poison, i32 0, i32 0, i32 0>, i32 %63, i64 0
  %broadcast.splatinsert = insertelement <4 x i64> poison, i64 %66, i64 0
  %broadcast.splat = shufflevector <4 x i64> %broadcast.splatinsert, <4 x i64> poison, <4 x i32> zeroinitializer
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %vector.ph
  %index = phi i64 [ 0, %vector.ph ], [ %index.next, %vector.body ]
  %vec.phi = phi <4 x i32> [ %67, %vector.ph ], [ %201, %vector.body ]
  %vec.phi65 = phi <4 x i32> [ %68, %vector.ph ], [ %200, %vector.body ]
  %vec.ind = phi <4 x i64> [ <i64 0, i64 1, i64 2, i64 3>, %vector.ph ], [ %vec.ind.next, %vector.body ]
  %69 = mul nuw nsw <4 x i64> %vec.ind, splat (i64 12)
  %70 = add nuw nsw <4 x i64> %broadcast.splat, %69
  %71 = getelementptr inbounds nuw float, ptr %8, <4 x i64> %70
  %wide.masked.gather = tail call <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr> align 4 %71, <4 x i1> splat (i1 true), <4 x float> poison), !invariant.load !3, !alias.scope !11, !noalias !21
  %72 = fadd <4 x float> %wide.masked.gather, %broadcast.splat18
  %73 = fcmp ogt <4 x float> %72, zeroinitializer
  %74 = zext <4 x i1> %73 to <4 x i32>
  %75 = getelementptr inbounds nuw float, ptr %4, <4 x i64> %70
  %wide.masked.gather66 = tail call <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr> align 4 %75, <4 x i1> splat (i1 true), <4 x float> poison), !invariant.load !3, !alias.scope !6, !noalias !22
  %76 = fadd <4 x float> %wide.masked.gather66, %broadcast.splat20
  %77 = fcmp ogt <4 x float> %76, zeroinitializer
  %78 = zext <4 x i1> %77 to <4 x i32>
  %79 = add <4 x i32> %vec.phi65, %74
  %80 = add <4 x i32> %vec.phi, %78
  %81 = or disjoint <4 x i64> %70, splat (i64 1)
  %82 = getelementptr inbounds nuw float, ptr %8, <4 x i64> %81
  %wide.masked.gather67 = tail call <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr> align 4 %82, <4 x i1> splat (i1 true), <4 x float> poison), !invariant.load !3, !alias.scope !11, !noalias !21
  %83 = fadd <4 x float> %wide.masked.gather67, %broadcast.splat22
  %84 = fcmp ogt <4 x float> %83, zeroinitializer
  %85 = zext <4 x i1> %84 to <4 x i32>
  %86 = getelementptr inbounds nuw float, ptr %4, <4 x i64> %81
  %wide.masked.gather68 = tail call <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr> align 4 %86, <4 x i1> splat (i1 true), <4 x float> poison), !invariant.load !3, !alias.scope !6, !noalias !22
  %87 = fadd <4 x float> %wide.masked.gather68, %broadcast.splat24
  %88 = fcmp ogt <4 x float> %87, zeroinitializer
  %89 = zext <4 x i1> %88 to <4 x i32>
  %90 = add <4 x i32> %79, %85
  %91 = add <4 x i32> %80, %89
  %92 = or disjoint <4 x i64> %70, splat (i64 2)
  %93 = getelementptr inbounds nuw float, ptr %8, <4 x i64> %92
  %wide.masked.gather69 = tail call <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr> align 4 %93, <4 x i1> splat (i1 true), <4 x float> poison), !invariant.load !3, !alias.scope !11, !noalias !21
  %94 = fadd <4 x float> %wide.masked.gather69, %broadcast.splat26
  %95 = fcmp ogt <4 x float> %94, zeroinitializer
  %96 = zext <4 x i1> %95 to <4 x i32>
  %97 = getelementptr inbounds nuw float, ptr %4, <4 x i64> %92
  %wide.masked.gather70 = tail call <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr> align 4 %97, <4 x i1> splat (i1 true), <4 x float> poison), !invariant.load !3, !alias.scope !6, !noalias !22
  %98 = fadd <4 x float> %wide.masked.gather70, %broadcast.splat28
  %99 = fcmp ogt <4 x float> %98, zeroinitializer
  %100 = zext <4 x i1> %99 to <4 x i32>
  %101 = add <4 x i32> %90, %96
  %102 = add <4 x i32> %91, %100
  %103 = or disjoint <4 x i64> %70, splat (i64 3)
  %104 = getelementptr inbounds nuw float, ptr %8, <4 x i64> %103
  %wide.masked.gather71 = tail call <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr> align 4 %104, <4 x i1> splat (i1 true), <4 x float> poison), !invariant.load !3, !alias.scope !11, !noalias !21
  %105 = fadd <4 x float> %wide.masked.gather71, %broadcast.splat30
  %106 = fcmp ogt <4 x float> %105, zeroinitializer
  %107 = zext <4 x i1> %106 to <4 x i32>
  %108 = getelementptr inbounds nuw float, ptr %4, <4 x i64> %103
  %wide.masked.gather72 = tail call <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr> align 4 %108, <4 x i1> splat (i1 true), <4 x float> poison), !invariant.load !3, !alias.scope !6, !noalias !22
  %109 = fadd <4 x float> %wide.masked.gather72, %broadcast.splat32
  %110 = fcmp ogt <4 x float> %109, zeroinitializer
  %111 = zext <4 x i1> %110 to <4 x i32>
  %112 = add <4 x i32> %101, %107
  %113 = add <4 x i32> %102, %111
  %114 = add nuw nsw <4 x i64> %70, splat (i64 4)
  %115 = getelementptr inbounds nuw float, ptr %8, <4 x i64> %114
  %wide.masked.gather73 = tail call <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr> align 4 %115, <4 x i1> splat (i1 true), <4 x float> poison), !invariant.load !3, !alias.scope !11, !noalias !21
  %116 = fadd <4 x float> %wide.masked.gather73, %broadcast.splat34
  %117 = fcmp ogt <4 x float> %116, zeroinitializer
  %118 = zext <4 x i1> %117 to <4 x i32>
  %119 = getelementptr inbounds nuw float, ptr %4, <4 x i64> %114
  %wide.masked.gather74 = tail call <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr> align 4 %119, <4 x i1> splat (i1 true), <4 x float> poison), !invariant.load !3, !alias.scope !6, !noalias !22
  %120 = fadd <4 x float> %wide.masked.gather74, %broadcast.splat36
  %121 = fcmp ogt <4 x float> %120, zeroinitializer
  %122 = zext <4 x i1> %121 to <4 x i32>
  %123 = add <4 x i32> %112, %118
  %124 = add <4 x i32> %113, %122
  %125 = add nuw nsw <4 x i64> %70, splat (i64 5)
  %126 = getelementptr inbounds nuw float, ptr %8, <4 x i64> %125
  %wide.masked.gather75 = tail call <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr> align 4 %126, <4 x i1> splat (i1 true), <4 x float> poison), !invariant.load !3, !alias.scope !11, !noalias !21
  %127 = fadd <4 x float> %wide.masked.gather75, %broadcast.splat38
  %128 = fcmp ogt <4 x float> %127, zeroinitializer
  %129 = zext <4 x i1> %128 to <4 x i32>
  %130 = getelementptr inbounds nuw float, ptr %4, <4 x i64> %125
  %wide.masked.gather76 = tail call <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr> align 4 %130, <4 x i1> splat (i1 true), <4 x float> poison), !invariant.load !3, !alias.scope !6, !noalias !22
  %131 = fadd <4 x float> %wide.masked.gather76, %broadcast.splat40
  %132 = fcmp ogt <4 x float> %131, zeroinitializer
  %133 = zext <4 x i1> %132 to <4 x i32>
  %134 = add <4 x i32> %123, %129
  %135 = add <4 x i32> %124, %133
  %136 = add nuw nsw <4 x i64> %70, splat (i64 6)
  %137 = getelementptr inbounds nuw float, ptr %8, <4 x i64> %136
  %wide.masked.gather77 = tail call <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr> align 4 %137, <4 x i1> splat (i1 true), <4 x float> poison), !invariant.load !3, !alias.scope !11, !noalias !21
  %138 = fadd <4 x float> %wide.masked.gather77, %broadcast.splat42
  %139 = fcmp ogt <4 x float> %138, zeroinitializer
  %140 = zext <4 x i1> %139 to <4 x i32>
  %141 = getelementptr inbounds nuw float, ptr %4, <4 x i64> %136
  %wide.masked.gather78 = tail call <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr> align 4 %141, <4 x i1> splat (i1 true), <4 x float> poison), !invariant.load !3, !alias.scope !6, !noalias !22
  %142 = fadd <4 x float> %wide.masked.gather78, %broadcast.splat44
  %143 = fcmp ogt <4 x float> %142, zeroinitializer
  %144 = zext <4 x i1> %143 to <4 x i32>
  %145 = add <4 x i32> %134, %140
  %146 = add <4 x i32> %135, %144
  %147 = add nuw nsw <4 x i64> %70, splat (i64 7)
  %148 = getelementptr inbounds nuw float, ptr %8, <4 x i64> %147
  %wide.masked.gather79 = tail call <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr> align 4 %148, <4 x i1> splat (i1 true), <4 x float> poison), !invariant.load !3, !alias.scope !11, !noalias !21
  %149 = fadd <4 x float> %wide.masked.gather79, %broadcast.splat46
  %150 = fcmp ogt <4 x float> %149, zeroinitializer
  %151 = zext <4 x i1> %150 to <4 x i32>
  %152 = getelementptr inbounds nuw float, ptr %4, <4 x i64> %147
  %wide.masked.gather80 = tail call <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr> align 4 %152, <4 x i1> splat (i1 true), <4 x float> poison), !invariant.load !3, !alias.scope !6, !noalias !22
  %153 = fadd <4 x float> %wide.masked.gather80, %broadcast.splat48
  %154 = fcmp ogt <4 x float> %153, zeroinitializer
  %155 = zext <4 x i1> %154 to <4 x i32>
  %156 = add <4 x i32> %145, %151
  %157 = add <4 x i32> %146, %155
  %158 = add nuw nsw <4 x i64> %70, splat (i64 8)
  %159 = getelementptr inbounds nuw float, ptr %8, <4 x i64> %158
  %wide.masked.gather81 = tail call <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr> align 4 %159, <4 x i1> splat (i1 true), <4 x float> poison), !invariant.load !3, !alias.scope !11, !noalias !21
  %160 = fadd <4 x float> %wide.masked.gather81, %broadcast.splat50
  %161 = fcmp ogt <4 x float> %160, zeroinitializer
  %162 = zext <4 x i1> %161 to <4 x i32>
  %163 = getelementptr inbounds nuw float, ptr %4, <4 x i64> %158
  %wide.masked.gather82 = tail call <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr> align 4 %163, <4 x i1> splat (i1 true), <4 x float> poison), !invariant.load !3, !alias.scope !6, !noalias !22
  %164 = fadd <4 x float> %wide.masked.gather82, %broadcast.splat52
  %165 = fcmp ogt <4 x float> %164, zeroinitializer
  %166 = zext <4 x i1> %165 to <4 x i32>
  %167 = add <4 x i32> %156, %162
  %168 = add <4 x i32> %157, %166
  %169 = add nuw nsw <4 x i64> %70, splat (i64 9)
  %170 = getelementptr inbounds nuw float, ptr %8, <4 x i64> %169
  %wide.masked.gather83 = tail call <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr> align 4 %170, <4 x i1> splat (i1 true), <4 x float> poison), !invariant.load !3, !alias.scope !11, !noalias !21
  %171 = fadd <4 x float> %wide.masked.gather83, %broadcast.splat54
  %172 = fcmp ogt <4 x float> %171, zeroinitializer
  %173 = zext <4 x i1> %172 to <4 x i32>
  %174 = getelementptr inbounds nuw float, ptr %4, <4 x i64> %169
  %wide.masked.gather84 = tail call <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr> align 4 %174, <4 x i1> splat (i1 true), <4 x float> poison), !invariant.load !3, !alias.scope !6, !noalias !22
  %175 = fadd <4 x float> %wide.masked.gather84, %broadcast.splat56
  %176 = fcmp ogt <4 x float> %175, zeroinitializer
  %177 = zext <4 x i1> %176 to <4 x i32>
  %178 = add <4 x i32> %167, %173
  %179 = add <4 x i32> %168, %177
  %180 = add nuw nsw <4 x i64> %70, splat (i64 10)
  %181 = getelementptr inbounds nuw float, ptr %8, <4 x i64> %180
  %wide.masked.gather85 = tail call <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr> align 4 %181, <4 x i1> splat (i1 true), <4 x float> poison), !invariant.load !3, !alias.scope !11, !noalias !21
  %182 = fadd <4 x float> %wide.masked.gather85, %broadcast.splat58
  %183 = fcmp ogt <4 x float> %182, zeroinitializer
  %184 = zext <4 x i1> %183 to <4 x i32>
  %185 = getelementptr inbounds nuw float, ptr %4, <4 x i64> %180
  %wide.masked.gather86 = tail call <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr> align 4 %185, <4 x i1> splat (i1 true), <4 x float> poison), !invariant.load !3, !alias.scope !6, !noalias !22
  %186 = fadd <4 x float> %wide.masked.gather86, %broadcast.splat60
  %187 = fcmp ogt <4 x float> %186, zeroinitializer
  %188 = zext <4 x i1> %187 to <4 x i32>
  %189 = add <4 x i32> %178, %184
  %190 = add <4 x i32> %179, %188
  %191 = add nuw nsw <4 x i64> %70, splat (i64 11)
  %192 = getelementptr inbounds nuw float, ptr %8, <4 x i64> %191
  %wide.masked.gather87 = tail call <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr> align 4 %192, <4 x i1> splat (i1 true), <4 x float> poison), !invariant.load !3, !alias.scope !11, !noalias !21
  %193 = fadd <4 x float> %wide.masked.gather87, %broadcast.splat62
  %194 = fcmp ogt <4 x float> %193, zeroinitializer
  %195 = zext <4 x i1> %194 to <4 x i32>
  %196 = getelementptr inbounds nuw float, ptr %4, <4 x i64> %191
  %wide.masked.gather88 = tail call <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr> align 4 %196, <4 x i1> splat (i1 true), <4 x float> poison), !invariant.load !3, !alias.scope !6, !noalias !22
  %197 = fadd <4 x float> %wide.masked.gather88, %broadcast.splat64
  %198 = fcmp ogt <4 x float> %197, zeroinitializer
  %199 = zext <4 x i1> %198 to <4 x i32>
  %200 = add <4 x i32> %189, %195
  %201 = add <4 x i32> %190, %199
  %index.next = add nuw i64 %index, 4
  %vec.ind.next = add nuw nsw <4 x i64> %vec.ind, splat (i64 4)
  %202 = icmp eq i64 %index.next, 20
  br i1 %202, label %middle.block, label %vector.body, !llvm.loop !23

middle.block:                                     ; preds = %vector.body
  %203 = tail call i32 @llvm.vector.reduce.add.v4i32(<4 x i32> %200)
  %204 = tail call i32 @llvm.vector.reduce.add.v4i32(<4 x i32> %201)
  %205 = add nuw nsw i64 %64, 1
  %exitcond12.not = icmp eq i64 %205, 20
  br i1 %exitcond12.not, label %206, label %vector.ph, !llvm.loop !27

206:                                              ; preds = %middle.block
  %207 = add nuw nsw i64 %60, 1
  %exitcond13.not = icmp eq i64 %207, 3
  br i1 %exitcond13.not, label %convert_reduce_fusion_wrapped.exit, label %57, !llvm.loop !27

convert_reduce_fusion_wrapped.exit:               ; preds = %206
  %208 = getelementptr inbounds nuw i8, ptr %3, i64 80
  %209 = load ptr, ptr %208, align 8, !invariant.load !3, !dereferenceable !28
  %210 = getelementptr inbounds nuw i8, ptr %3, i64 64
  %211 = load ptr, ptr %210, align 8, !invariant.load !3, !dereferenceable !28
  store i32 %203, ptr %211, align 4, !alias.scope !15, !noalias !29
  store i32 %204, ptr %209, align 4, !alias.scope !17, !noalias !30
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr>, <4 x i1>, <4 x float>) #2

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.vector.reduce.add.v4i32(<4 x i32>) #3

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #3 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 2}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 57600}
!5 = !{i64 48}
!6 = !{!7}
!7 = distinct !{!7, !8, !"convert_reduce_fusion_wrapped: argument 0"}
!8 = distinct !{!8, !"convert_reduce_fusion_wrapped"}
!9 = !{!10}
!10 = distinct !{!10, !8, !"convert_reduce_fusion_wrapped: argument 1"}
!11 = !{!12}
!12 = distinct !{!12, !8, !"convert_reduce_fusion_wrapped: argument 2"}
!13 = !{!14}
!14 = distinct !{!14, !8, !"convert_reduce_fusion_wrapped: argument 3"}
!15 = !{!16}
!16 = distinct !{!16, !8, !"convert_reduce_fusion_wrapped: argument 4"}
!17 = !{!18}
!18 = distinct !{!18, !8, !"convert_reduce_fusion_wrapped: argument 5"}
!19 = !{!7, !10, !12, !16, !18}
!20 = !{!7, !12, !14, !16, !18}
!21 = !{!7, !10, !14, !16, !18}
!22 = !{!10, !12, !14, !16, !18}
!23 = distinct !{!23, !24, !25, !26}
!24 = !{!"llvm.loop.unroll.disable"}
!25 = !{!"llvm.loop.isvectorized", i32 1}
!26 = !{!"llvm.loop.unroll.runtime.disable"}
!27 = distinct !{!27, !24}
!28 = !{i64 4}
!29 = !{!7, !10, !12, !14, !18}
!30 = !{!7, !10, !12, !14, !16}
