; ModuleID = '__compute_module_broadcast_maximum_fusion_kernel_module'
source_filename = "__compute_module_broadcast_maximum_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @broadcast_maximum_fusion(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !5
  tail call void @llvm.experimental.noalias.scope.decl(metadata !6)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9)
  %.pre.pre.pre = load float, ptr %6, align 4, !invariant.load !3, !alias.scope !9, !noalias !6
  %.phi.trans.insert.phi.trans.insert.phi.trans.insert = getelementptr inbounds nuw i8, ptr %6, i64 4
  %.pre7.pre.pre = load float, ptr %.phi.trans.insert.phi.trans.insert.phi.trans.insert, align 4, !invariant.load !3, !alias.scope !9, !noalias !6
  %.phi.trans.insert8.phi.trans.insert.phi.trans.insert = getelementptr inbounds nuw i8, ptr %6, i64 8
  %.pre9.pre.pre = load float, ptr %.phi.trans.insert8.phi.trans.insert.phi.trans.insert, align 4, !invariant.load !3, !alias.scope !9, !noalias !6
  %.phi.trans.insert10.phi.trans.insert.phi.trans.insert = getelementptr inbounds nuw i8, ptr %6, i64 12
  %.pre11.pre.pre = load float, ptr %.phi.trans.insert10.phi.trans.insert.phi.trans.insert, align 4, !invariant.load !3, !alias.scope !9, !noalias !6
  %.phi.trans.insert12.phi.trans.insert.phi.trans.insert = getelementptr inbounds nuw i8, ptr %6, i64 16
  %.pre13.pre.pre = load float, ptr %.phi.trans.insert12.phi.trans.insert.phi.trans.insert, align 4, !invariant.load !3, !alias.scope !9, !noalias !6
  %.phi.trans.insert14.phi.trans.insert.phi.trans.insert = getelementptr inbounds nuw i8, ptr %6, i64 20
  %.pre15.pre.pre = load float, ptr %.phi.trans.insert14.phi.trans.insert.phi.trans.insert, align 4, !invariant.load !3, !alias.scope !9, !noalias !6
  %.phi.trans.insert16.phi.trans.insert.phi.trans.insert = getelementptr inbounds nuw i8, ptr %6, i64 24
  %.pre17.pre.pre = load float, ptr %.phi.trans.insert16.phi.trans.insert.phi.trans.insert, align 4, !invariant.load !3, !alias.scope !9, !noalias !6
  %.phi.trans.insert18.phi.trans.insert.phi.trans.insert = getelementptr inbounds nuw i8, ptr %6, i64 28
  %.pre19.pre.pre = load float, ptr %.phi.trans.insert18.phi.trans.insert.phi.trans.insert, align 4, !invariant.load !3, !alias.scope !9, !noalias !6
  %.phi.trans.insert20.phi.trans.insert.phi.trans.insert = getelementptr inbounds nuw i8, ptr %6, i64 32
  %.pre21.pre.pre = load float, ptr %.phi.trans.insert20.phi.trans.insert.phi.trans.insert, align 4, !invariant.load !3, !alias.scope !9, !noalias !6
  %.phi.trans.insert22.phi.trans.insert.phi.trans.insert = getelementptr inbounds nuw i8, ptr %6, i64 36
  %.pre23.pre.pre = load float, ptr %.phi.trans.insert22.phi.trans.insert.phi.trans.insert, align 4, !invariant.load !3, !alias.scope !9, !noalias !6
  %.phi.trans.insert24.phi.trans.insert.phi.trans.insert = getelementptr inbounds nuw i8, ptr %6, i64 40
  %.pre25.pre.pre = load float, ptr %.phi.trans.insert24.phi.trans.insert.phi.trans.insert, align 4, !invariant.load !3, !alias.scope !9, !noalias !6
  %.phi.trans.insert26.phi.trans.insert.phi.trans.insert = getelementptr inbounds nuw i8, ptr %6, i64 44
  %.pre27.pre.pre = load float, ptr %.phi.trans.insert26.phi.trans.insert.phi.trans.insert, align 4, !invariant.load !3, !alias.scope !9, !noalias !6
  %broadcast.splatinsert = insertelement <8 x float> poison, float %.pre.pre.pre, i64 0
  %broadcast.splat = shufflevector <8 x float> %broadcast.splatinsert, <8 x float> poison, <8 x i32> zeroinitializer
  %broadcast.splatinsert29 = insertelement <8 x float> poison, float %.pre7.pre.pre, i64 0
  %broadcast.splat30 = shufflevector <8 x float> %broadcast.splatinsert29, <8 x float> poison, <8 x i32> zeroinitializer
  %broadcast.splatinsert31 = insertelement <8 x float> poison, float %.pre9.pre.pre, i64 0
  %broadcast.splat32 = shufflevector <8 x float> %broadcast.splatinsert31, <8 x float> poison, <8 x i32> zeroinitializer
  %broadcast.splatinsert33 = insertelement <8 x float> poison, float %.pre11.pre.pre, i64 0
  %broadcast.splat34 = shufflevector <8 x float> %broadcast.splatinsert33, <8 x float> poison, <8 x i32> zeroinitializer
  %broadcast.splatinsert35 = insertelement <8 x float> poison, float %.pre13.pre.pre, i64 0
  %broadcast.splat36 = shufflevector <8 x float> %broadcast.splatinsert35, <8 x float> poison, <8 x i32> zeroinitializer
  %broadcast.splatinsert37 = insertelement <8 x float> poison, float %.pre15.pre.pre, i64 0
  %broadcast.splat38 = shufflevector <8 x float> %broadcast.splatinsert37, <8 x float> poison, <8 x i32> zeroinitializer
  %broadcast.splatinsert39 = insertelement <8 x float> poison, float %.pre17.pre.pre, i64 0
  %broadcast.splat40 = shufflevector <8 x float> %broadcast.splatinsert39, <8 x float> poison, <8 x i32> zeroinitializer
  %broadcast.splatinsert41 = insertelement <8 x float> poison, float %.pre19.pre.pre, i64 0
  %broadcast.splat42 = shufflevector <8 x float> %broadcast.splatinsert41, <8 x float> poison, <8 x i32> zeroinitializer
  %broadcast.splatinsert43 = insertelement <8 x float> poison, float %.pre21.pre.pre, i64 0
  %broadcast.splat44 = shufflevector <8 x float> %broadcast.splatinsert43, <8 x float> poison, <8 x i32> zeroinitializer
  %broadcast.splatinsert45 = insertelement <8 x float> poison, float %.pre23.pre.pre, i64 0
  %broadcast.splat46 = shufflevector <8 x float> %broadcast.splatinsert45, <8 x float> poison, <8 x i32> zeroinitializer
  %broadcast.splatinsert47 = insertelement <8 x float> poison, float %.pre25.pre.pre, i64 0
  %broadcast.splat48 = shufflevector <8 x float> %broadcast.splatinsert47, <8 x float> poison, <8 x i32> zeroinitializer
  %broadcast.splatinsert49 = insertelement <8 x float> poison, float %.pre27.pre.pre, i64 0
  %broadcast.splat50 = shufflevector <8 x float> %broadcast.splatinsert49, <8 x float> poison, <8 x i32> zeroinitializer
  br label %.preheader4

.preheader4:                                      ; preds = %1, %293
  %7 = phi i64 [ 0, %1 ], [ %294, %293 ]
  %.idx = mul nuw nsw i64 %7, 19200
  %8 = getelementptr i8, ptr %4, i64 %.idx
  br label %.preheader3

.preheader3:                                      ; preds = %.preheader4, %291
  %9 = phi i64 [ 0, %.preheader4 ], [ %292, %291 ]
  %.idx1 = mul nuw nsw i64 %9, 960
  %10 = getelementptr i8, ptr %8, i64 %.idx1
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %.preheader3
  %index = phi i64 [ 0, %.preheader3 ], [ %index.next, %vector.body ]
  %vec.ind = phi <8 x i64> [ <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>, %.preheader3 ], [ %vec.ind.next, %vector.body ]
  %11 = mul nuw nsw <8 x i64> %vec.ind, splat (i64 48)
  %12 = getelementptr i8, ptr %10, <8 x i64> %11
  %13 = extractelement <8 x ptr> %12, i64 0
  %14 = extractelement <8 x ptr> %12, i64 1
  %15 = extractelement <8 x ptr> %12, i64 2
  %16 = extractelement <8 x ptr> %12, i64 3
  %17 = extractelement <8 x ptr> %12, i64 4
  %18 = extractelement <8 x ptr> %12, i64 5
  %19 = extractelement <8 x ptr> %12, i64 6
  %20 = extractelement <8 x ptr> %12, i64 7
  %wide.masked.gather = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %12, <8 x i1> splat (i1 true), <8 x float> poison), !alias.scope !6, !noalias !9
  %21 = fadd <8 x float> %wide.masked.gather, %broadcast.splat
  %22 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %21, <8 x float> zeroinitializer)
  %23 = extractelement <8 x float> %22, i64 0
  %24 = extractelement <8 x float> %22, i64 1
  %25 = extractelement <8 x float> %22, i64 2
  %26 = extractelement <8 x float> %22, i64 3
  %27 = extractelement <8 x float> %22, i64 4
  %28 = extractelement <8 x float> %22, i64 5
  %29 = extractelement <8 x float> %22, i64 6
  %30 = extractelement <8 x float> %22, i64 7
  store float %23, ptr %13, align 4, !alias.scope !6, !noalias !9
  store float %24, ptr %14, align 4, !alias.scope !6, !noalias !9
  store float %25, ptr %15, align 4, !alias.scope !6, !noalias !9
  store float %26, ptr %16, align 4, !alias.scope !6, !noalias !9
  store float %27, ptr %17, align 4, !alias.scope !6, !noalias !9
  store float %28, ptr %18, align 4, !alias.scope !6, !noalias !9
  store float %29, ptr %19, align 4, !alias.scope !6, !noalias !9
  store float %30, ptr %20, align 4, !alias.scope !6, !noalias !9
  %31 = getelementptr i8, <8 x ptr> %12, i64 4
  %32 = extractelement <8 x ptr> %31, i64 0
  %33 = extractelement <8 x ptr> %31, i64 1
  %34 = extractelement <8 x ptr> %31, i64 2
  %35 = extractelement <8 x ptr> %31, i64 3
  %36 = extractelement <8 x ptr> %31, i64 4
  %37 = extractelement <8 x ptr> %31, i64 5
  %38 = extractelement <8 x ptr> %31, i64 6
  %39 = extractelement <8 x ptr> %31, i64 7
  %wide.masked.gather51 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %31, <8 x i1> splat (i1 true), <8 x float> poison), !alias.scope !6, !noalias !9
  %40 = fadd <8 x float> %wide.masked.gather51, %broadcast.splat30
  %41 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %40, <8 x float> zeroinitializer)
  %42 = extractelement <8 x float> %41, i64 0
  %43 = extractelement <8 x float> %41, i64 1
  %44 = extractelement <8 x float> %41, i64 2
  %45 = extractelement <8 x float> %41, i64 3
  %46 = extractelement <8 x float> %41, i64 4
  %47 = extractelement <8 x float> %41, i64 5
  %48 = extractelement <8 x float> %41, i64 6
  %49 = extractelement <8 x float> %41, i64 7
  store float %42, ptr %32, align 4, !alias.scope !6, !noalias !9
  store float %43, ptr %33, align 4, !alias.scope !6, !noalias !9
  store float %44, ptr %34, align 4, !alias.scope !6, !noalias !9
  store float %45, ptr %35, align 4, !alias.scope !6, !noalias !9
  store float %46, ptr %36, align 4, !alias.scope !6, !noalias !9
  store float %47, ptr %37, align 4, !alias.scope !6, !noalias !9
  store float %48, ptr %38, align 4, !alias.scope !6, !noalias !9
  store float %49, ptr %39, align 4, !alias.scope !6, !noalias !9
  %50 = getelementptr i8, <8 x ptr> %12, i64 8
  %51 = extractelement <8 x ptr> %50, i64 0
  %52 = extractelement <8 x ptr> %50, i64 1
  %53 = extractelement <8 x ptr> %50, i64 2
  %54 = extractelement <8 x ptr> %50, i64 3
  %55 = extractelement <8 x ptr> %50, i64 4
  %56 = extractelement <8 x ptr> %50, i64 5
  %57 = extractelement <8 x ptr> %50, i64 6
  %58 = extractelement <8 x ptr> %50, i64 7
  %wide.masked.gather52 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %50, <8 x i1> splat (i1 true), <8 x float> poison), !alias.scope !6, !noalias !9
  %59 = fadd <8 x float> %wide.masked.gather52, %broadcast.splat32
  %60 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %59, <8 x float> zeroinitializer)
  %61 = extractelement <8 x float> %60, i64 0
  %62 = extractelement <8 x float> %60, i64 1
  %63 = extractelement <8 x float> %60, i64 2
  %64 = extractelement <8 x float> %60, i64 3
  %65 = extractelement <8 x float> %60, i64 4
  %66 = extractelement <8 x float> %60, i64 5
  %67 = extractelement <8 x float> %60, i64 6
  %68 = extractelement <8 x float> %60, i64 7
  store float %61, ptr %51, align 4, !alias.scope !6, !noalias !9
  store float %62, ptr %52, align 4, !alias.scope !6, !noalias !9
  store float %63, ptr %53, align 4, !alias.scope !6, !noalias !9
  store float %64, ptr %54, align 4, !alias.scope !6, !noalias !9
  store float %65, ptr %55, align 4, !alias.scope !6, !noalias !9
  store float %66, ptr %56, align 4, !alias.scope !6, !noalias !9
  store float %67, ptr %57, align 4, !alias.scope !6, !noalias !9
  store float %68, ptr %58, align 4, !alias.scope !6, !noalias !9
  %69 = getelementptr i8, <8 x ptr> %12, i64 12
  %70 = extractelement <8 x ptr> %69, i64 0
  %71 = extractelement <8 x ptr> %69, i64 1
  %72 = extractelement <8 x ptr> %69, i64 2
  %73 = extractelement <8 x ptr> %69, i64 3
  %74 = extractelement <8 x ptr> %69, i64 4
  %75 = extractelement <8 x ptr> %69, i64 5
  %76 = extractelement <8 x ptr> %69, i64 6
  %77 = extractelement <8 x ptr> %69, i64 7
  %wide.masked.gather53 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %69, <8 x i1> splat (i1 true), <8 x float> poison), !alias.scope !6, !noalias !9
  %78 = fadd <8 x float> %wide.masked.gather53, %broadcast.splat34
  %79 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %78, <8 x float> zeroinitializer)
  %80 = extractelement <8 x float> %79, i64 0
  %81 = extractelement <8 x float> %79, i64 1
  %82 = extractelement <8 x float> %79, i64 2
  %83 = extractelement <8 x float> %79, i64 3
  %84 = extractelement <8 x float> %79, i64 4
  %85 = extractelement <8 x float> %79, i64 5
  %86 = extractelement <8 x float> %79, i64 6
  %87 = extractelement <8 x float> %79, i64 7
  store float %80, ptr %70, align 4, !alias.scope !6, !noalias !9
  store float %81, ptr %71, align 4, !alias.scope !6, !noalias !9
  store float %82, ptr %72, align 4, !alias.scope !6, !noalias !9
  store float %83, ptr %73, align 4, !alias.scope !6, !noalias !9
  store float %84, ptr %74, align 4, !alias.scope !6, !noalias !9
  store float %85, ptr %75, align 4, !alias.scope !6, !noalias !9
  store float %86, ptr %76, align 4, !alias.scope !6, !noalias !9
  store float %87, ptr %77, align 4, !alias.scope !6, !noalias !9
  %88 = getelementptr i8, <8 x ptr> %12, i64 16
  %89 = extractelement <8 x ptr> %88, i64 0
  %90 = extractelement <8 x ptr> %88, i64 1
  %91 = extractelement <8 x ptr> %88, i64 2
  %92 = extractelement <8 x ptr> %88, i64 3
  %93 = extractelement <8 x ptr> %88, i64 4
  %94 = extractelement <8 x ptr> %88, i64 5
  %95 = extractelement <8 x ptr> %88, i64 6
  %96 = extractelement <8 x ptr> %88, i64 7
  %wide.masked.gather54 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %88, <8 x i1> splat (i1 true), <8 x float> poison), !alias.scope !6, !noalias !9
  %97 = fadd <8 x float> %wide.masked.gather54, %broadcast.splat36
  %98 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %97, <8 x float> zeroinitializer)
  %99 = extractelement <8 x float> %98, i64 0
  %100 = extractelement <8 x float> %98, i64 1
  %101 = extractelement <8 x float> %98, i64 2
  %102 = extractelement <8 x float> %98, i64 3
  %103 = extractelement <8 x float> %98, i64 4
  %104 = extractelement <8 x float> %98, i64 5
  %105 = extractelement <8 x float> %98, i64 6
  %106 = extractelement <8 x float> %98, i64 7
  store float %99, ptr %89, align 4, !alias.scope !6, !noalias !9
  store float %100, ptr %90, align 4, !alias.scope !6, !noalias !9
  store float %101, ptr %91, align 4, !alias.scope !6, !noalias !9
  store float %102, ptr %92, align 4, !alias.scope !6, !noalias !9
  store float %103, ptr %93, align 4, !alias.scope !6, !noalias !9
  store float %104, ptr %94, align 4, !alias.scope !6, !noalias !9
  store float %105, ptr %95, align 4, !alias.scope !6, !noalias !9
  store float %106, ptr %96, align 4, !alias.scope !6, !noalias !9
  %107 = getelementptr i8, <8 x ptr> %12, i64 20
  %108 = extractelement <8 x ptr> %107, i64 0
  %109 = extractelement <8 x ptr> %107, i64 1
  %110 = extractelement <8 x ptr> %107, i64 2
  %111 = extractelement <8 x ptr> %107, i64 3
  %112 = extractelement <8 x ptr> %107, i64 4
  %113 = extractelement <8 x ptr> %107, i64 5
  %114 = extractelement <8 x ptr> %107, i64 6
  %115 = extractelement <8 x ptr> %107, i64 7
  %wide.masked.gather55 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %107, <8 x i1> splat (i1 true), <8 x float> poison), !alias.scope !6, !noalias !9
  %116 = fadd <8 x float> %wide.masked.gather55, %broadcast.splat38
  %117 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %116, <8 x float> zeroinitializer)
  %118 = extractelement <8 x float> %117, i64 0
  %119 = extractelement <8 x float> %117, i64 1
  %120 = extractelement <8 x float> %117, i64 2
  %121 = extractelement <8 x float> %117, i64 3
  %122 = extractelement <8 x float> %117, i64 4
  %123 = extractelement <8 x float> %117, i64 5
  %124 = extractelement <8 x float> %117, i64 6
  %125 = extractelement <8 x float> %117, i64 7
  store float %118, ptr %108, align 4, !alias.scope !6, !noalias !9
  store float %119, ptr %109, align 4, !alias.scope !6, !noalias !9
  store float %120, ptr %110, align 4, !alias.scope !6, !noalias !9
  store float %121, ptr %111, align 4, !alias.scope !6, !noalias !9
  store float %122, ptr %112, align 4, !alias.scope !6, !noalias !9
  store float %123, ptr %113, align 4, !alias.scope !6, !noalias !9
  store float %124, ptr %114, align 4, !alias.scope !6, !noalias !9
  store float %125, ptr %115, align 4, !alias.scope !6, !noalias !9
  %126 = getelementptr i8, <8 x ptr> %12, i64 24
  %127 = extractelement <8 x ptr> %126, i64 0
  %128 = extractelement <8 x ptr> %126, i64 1
  %129 = extractelement <8 x ptr> %126, i64 2
  %130 = extractelement <8 x ptr> %126, i64 3
  %131 = extractelement <8 x ptr> %126, i64 4
  %132 = extractelement <8 x ptr> %126, i64 5
  %133 = extractelement <8 x ptr> %126, i64 6
  %134 = extractelement <8 x ptr> %126, i64 7
  %wide.masked.gather56 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %126, <8 x i1> splat (i1 true), <8 x float> poison), !alias.scope !6, !noalias !9
  %135 = fadd <8 x float> %wide.masked.gather56, %broadcast.splat40
  %136 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %135, <8 x float> zeroinitializer)
  %137 = extractelement <8 x float> %136, i64 0
  %138 = extractelement <8 x float> %136, i64 1
  %139 = extractelement <8 x float> %136, i64 2
  %140 = extractelement <8 x float> %136, i64 3
  %141 = extractelement <8 x float> %136, i64 4
  %142 = extractelement <8 x float> %136, i64 5
  %143 = extractelement <8 x float> %136, i64 6
  %144 = extractelement <8 x float> %136, i64 7
  store float %137, ptr %127, align 4, !alias.scope !6, !noalias !9
  store float %138, ptr %128, align 4, !alias.scope !6, !noalias !9
  store float %139, ptr %129, align 4, !alias.scope !6, !noalias !9
  store float %140, ptr %130, align 4, !alias.scope !6, !noalias !9
  store float %141, ptr %131, align 4, !alias.scope !6, !noalias !9
  store float %142, ptr %132, align 4, !alias.scope !6, !noalias !9
  store float %143, ptr %133, align 4, !alias.scope !6, !noalias !9
  store float %144, ptr %134, align 4, !alias.scope !6, !noalias !9
  %145 = getelementptr i8, <8 x ptr> %12, i64 28
  %146 = extractelement <8 x ptr> %145, i64 0
  %147 = extractelement <8 x ptr> %145, i64 1
  %148 = extractelement <8 x ptr> %145, i64 2
  %149 = extractelement <8 x ptr> %145, i64 3
  %150 = extractelement <8 x ptr> %145, i64 4
  %151 = extractelement <8 x ptr> %145, i64 5
  %152 = extractelement <8 x ptr> %145, i64 6
  %153 = extractelement <8 x ptr> %145, i64 7
  %wide.masked.gather57 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %145, <8 x i1> splat (i1 true), <8 x float> poison), !alias.scope !6, !noalias !9
  %154 = fadd <8 x float> %wide.masked.gather57, %broadcast.splat42
  %155 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %154, <8 x float> zeroinitializer)
  %156 = extractelement <8 x float> %155, i64 0
  %157 = extractelement <8 x float> %155, i64 1
  %158 = extractelement <8 x float> %155, i64 2
  %159 = extractelement <8 x float> %155, i64 3
  %160 = extractelement <8 x float> %155, i64 4
  %161 = extractelement <8 x float> %155, i64 5
  %162 = extractelement <8 x float> %155, i64 6
  %163 = extractelement <8 x float> %155, i64 7
  store float %156, ptr %146, align 4, !alias.scope !6, !noalias !9
  store float %157, ptr %147, align 4, !alias.scope !6, !noalias !9
  store float %158, ptr %148, align 4, !alias.scope !6, !noalias !9
  store float %159, ptr %149, align 4, !alias.scope !6, !noalias !9
  store float %160, ptr %150, align 4, !alias.scope !6, !noalias !9
  store float %161, ptr %151, align 4, !alias.scope !6, !noalias !9
  store float %162, ptr %152, align 4, !alias.scope !6, !noalias !9
  store float %163, ptr %153, align 4, !alias.scope !6, !noalias !9
  %164 = getelementptr i8, <8 x ptr> %12, i64 32
  %165 = extractelement <8 x ptr> %164, i64 0
  %166 = extractelement <8 x ptr> %164, i64 1
  %167 = extractelement <8 x ptr> %164, i64 2
  %168 = extractelement <8 x ptr> %164, i64 3
  %169 = extractelement <8 x ptr> %164, i64 4
  %170 = extractelement <8 x ptr> %164, i64 5
  %171 = extractelement <8 x ptr> %164, i64 6
  %172 = extractelement <8 x ptr> %164, i64 7
  %wide.masked.gather58 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %164, <8 x i1> splat (i1 true), <8 x float> poison), !alias.scope !6, !noalias !9
  %173 = fadd <8 x float> %wide.masked.gather58, %broadcast.splat44
  %174 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %173, <8 x float> zeroinitializer)
  %175 = extractelement <8 x float> %174, i64 0
  %176 = extractelement <8 x float> %174, i64 1
  %177 = extractelement <8 x float> %174, i64 2
  %178 = extractelement <8 x float> %174, i64 3
  %179 = extractelement <8 x float> %174, i64 4
  %180 = extractelement <8 x float> %174, i64 5
  %181 = extractelement <8 x float> %174, i64 6
  %182 = extractelement <8 x float> %174, i64 7
  store float %175, ptr %165, align 4, !alias.scope !6, !noalias !9
  store float %176, ptr %166, align 4, !alias.scope !6, !noalias !9
  store float %177, ptr %167, align 4, !alias.scope !6, !noalias !9
  store float %178, ptr %168, align 4, !alias.scope !6, !noalias !9
  store float %179, ptr %169, align 4, !alias.scope !6, !noalias !9
  store float %180, ptr %170, align 4, !alias.scope !6, !noalias !9
  store float %181, ptr %171, align 4, !alias.scope !6, !noalias !9
  store float %182, ptr %172, align 4, !alias.scope !6, !noalias !9
  %183 = getelementptr i8, <8 x ptr> %12, i64 36
  %184 = extractelement <8 x ptr> %183, i64 0
  %185 = extractelement <8 x ptr> %183, i64 1
  %186 = extractelement <8 x ptr> %183, i64 2
  %187 = extractelement <8 x ptr> %183, i64 3
  %188 = extractelement <8 x ptr> %183, i64 4
  %189 = extractelement <8 x ptr> %183, i64 5
  %190 = extractelement <8 x ptr> %183, i64 6
  %191 = extractelement <8 x ptr> %183, i64 7
  %wide.masked.gather59 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %183, <8 x i1> splat (i1 true), <8 x float> poison), !alias.scope !6, !noalias !9
  %192 = fadd <8 x float> %wide.masked.gather59, %broadcast.splat46
  %193 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %192, <8 x float> zeroinitializer)
  %194 = extractelement <8 x float> %193, i64 0
  %195 = extractelement <8 x float> %193, i64 1
  %196 = extractelement <8 x float> %193, i64 2
  %197 = extractelement <8 x float> %193, i64 3
  %198 = extractelement <8 x float> %193, i64 4
  %199 = extractelement <8 x float> %193, i64 5
  %200 = extractelement <8 x float> %193, i64 6
  %201 = extractelement <8 x float> %193, i64 7
  store float %194, ptr %184, align 4, !alias.scope !6, !noalias !9
  store float %195, ptr %185, align 4, !alias.scope !6, !noalias !9
  store float %196, ptr %186, align 4, !alias.scope !6, !noalias !9
  store float %197, ptr %187, align 4, !alias.scope !6, !noalias !9
  store float %198, ptr %188, align 4, !alias.scope !6, !noalias !9
  store float %199, ptr %189, align 4, !alias.scope !6, !noalias !9
  store float %200, ptr %190, align 4, !alias.scope !6, !noalias !9
  store float %201, ptr %191, align 4, !alias.scope !6, !noalias !9
  %202 = getelementptr i8, <8 x ptr> %12, i64 40
  %203 = extractelement <8 x ptr> %202, i64 0
  %204 = extractelement <8 x ptr> %202, i64 1
  %205 = extractelement <8 x ptr> %202, i64 2
  %206 = extractelement <8 x ptr> %202, i64 3
  %207 = extractelement <8 x ptr> %202, i64 4
  %208 = extractelement <8 x ptr> %202, i64 5
  %209 = extractelement <8 x ptr> %202, i64 6
  %210 = extractelement <8 x ptr> %202, i64 7
  %wide.masked.gather60 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %202, <8 x i1> splat (i1 true), <8 x float> poison), !alias.scope !6, !noalias !9
  %211 = fadd <8 x float> %wide.masked.gather60, %broadcast.splat48
  %212 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %211, <8 x float> zeroinitializer)
  %213 = extractelement <8 x float> %212, i64 0
  %214 = extractelement <8 x float> %212, i64 1
  %215 = extractelement <8 x float> %212, i64 2
  %216 = extractelement <8 x float> %212, i64 3
  %217 = extractelement <8 x float> %212, i64 4
  %218 = extractelement <8 x float> %212, i64 5
  %219 = extractelement <8 x float> %212, i64 6
  %220 = extractelement <8 x float> %212, i64 7
  store float %213, ptr %203, align 4, !alias.scope !6, !noalias !9
  store float %214, ptr %204, align 4, !alias.scope !6, !noalias !9
  store float %215, ptr %205, align 4, !alias.scope !6, !noalias !9
  store float %216, ptr %206, align 4, !alias.scope !6, !noalias !9
  store float %217, ptr %207, align 4, !alias.scope !6, !noalias !9
  store float %218, ptr %208, align 4, !alias.scope !6, !noalias !9
  store float %219, ptr %209, align 4, !alias.scope !6, !noalias !9
  store float %220, ptr %210, align 4, !alias.scope !6, !noalias !9
  %221 = getelementptr i8, <8 x ptr> %12, i64 44
  %222 = extractelement <8 x ptr> %221, i64 0
  %223 = extractelement <8 x ptr> %221, i64 1
  %224 = extractelement <8 x ptr> %221, i64 2
  %225 = extractelement <8 x ptr> %221, i64 3
  %226 = extractelement <8 x ptr> %221, i64 4
  %227 = extractelement <8 x ptr> %221, i64 5
  %228 = extractelement <8 x ptr> %221, i64 6
  %229 = extractelement <8 x ptr> %221, i64 7
  %wide.masked.gather61 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %221, <8 x i1> splat (i1 true), <8 x float> poison), !alias.scope !6, !noalias !9
  %230 = fadd <8 x float> %wide.masked.gather61, %broadcast.splat50
  %231 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %230, <8 x float> zeroinitializer)
  %232 = extractelement <8 x float> %231, i64 0
  %233 = extractelement <8 x float> %231, i64 1
  %234 = extractelement <8 x float> %231, i64 2
  %235 = extractelement <8 x float> %231, i64 3
  %236 = extractelement <8 x float> %231, i64 4
  %237 = extractelement <8 x float> %231, i64 5
  %238 = extractelement <8 x float> %231, i64 6
  %239 = extractelement <8 x float> %231, i64 7
  store float %232, ptr %222, align 4, !alias.scope !6, !noalias !9
  store float %233, ptr %223, align 4, !alias.scope !6, !noalias !9
  store float %234, ptr %224, align 4, !alias.scope !6, !noalias !9
  store float %235, ptr %225, align 4, !alias.scope !6, !noalias !9
  store float %236, ptr %226, align 4, !alias.scope !6, !noalias !9
  store float %237, ptr %227, align 4, !alias.scope !6, !noalias !9
  store float %238, ptr %228, align 4, !alias.scope !6, !noalias !9
  store float %239, ptr %229, align 4, !alias.scope !6, !noalias !9
  %index.next = add nuw i64 %index, 8
  %vec.ind.next = add nuw nsw <8 x i64> %vec.ind, splat (i64 8)
  %240 = icmp eq i64 %index.next, 16
  br i1 %240, label %.preheader, label %vector.body, !llvm.loop !11

.preheader:                                       ; preds = %vector.body, %.preheader
  %241 = phi i64 [ %290, %.preheader ], [ 16, %vector.body ]
  %.idx2 = mul nuw nsw i64 %241, 48
  %242 = getelementptr i8, ptr %10, i64 %.idx2
  %243 = load float, ptr %242, align 4, !alias.scope !6, !noalias !9
  %244 = fadd float %243, %.pre.pre.pre
  %245 = tail call float @llvm.maximum.f32(float %244, float 0.000000e+00)
  store float %245, ptr %242, align 4, !alias.scope !6, !noalias !9
  %246 = getelementptr i8, ptr %242, i64 4
  %247 = load float, ptr %246, align 4, !alias.scope !6, !noalias !9
  %248 = fadd float %247, %.pre7.pre.pre
  %249 = tail call float @llvm.maximum.f32(float %248, float 0.000000e+00)
  store float %249, ptr %246, align 4, !alias.scope !6, !noalias !9
  %250 = getelementptr i8, ptr %242, i64 8
  %251 = load float, ptr %250, align 4, !alias.scope !6, !noalias !9
  %252 = fadd float %251, %.pre9.pre.pre
  %253 = tail call float @llvm.maximum.f32(float %252, float 0.000000e+00)
  store float %253, ptr %250, align 4, !alias.scope !6, !noalias !9
  %254 = getelementptr i8, ptr %242, i64 12
  %255 = load float, ptr %254, align 4, !alias.scope !6, !noalias !9
  %256 = fadd float %255, %.pre11.pre.pre
  %257 = tail call float @llvm.maximum.f32(float %256, float 0.000000e+00)
  store float %257, ptr %254, align 4, !alias.scope !6, !noalias !9
  %258 = getelementptr i8, ptr %242, i64 16
  %259 = load float, ptr %258, align 4, !alias.scope !6, !noalias !9
  %260 = fadd float %259, %.pre13.pre.pre
  %261 = tail call float @llvm.maximum.f32(float %260, float 0.000000e+00)
  store float %261, ptr %258, align 4, !alias.scope !6, !noalias !9
  %262 = getelementptr i8, ptr %242, i64 20
  %263 = load float, ptr %262, align 4, !alias.scope !6, !noalias !9
  %264 = fadd float %263, %.pre15.pre.pre
  %265 = tail call float @llvm.maximum.f32(float %264, float 0.000000e+00)
  store float %265, ptr %262, align 4, !alias.scope !6, !noalias !9
  %266 = getelementptr i8, ptr %242, i64 24
  %267 = load float, ptr %266, align 4, !alias.scope !6, !noalias !9
  %268 = fadd float %267, %.pre17.pre.pre
  %269 = tail call float @llvm.maximum.f32(float %268, float 0.000000e+00)
  store float %269, ptr %266, align 4, !alias.scope !6, !noalias !9
  %270 = getelementptr i8, ptr %242, i64 28
  %271 = load float, ptr %270, align 4, !alias.scope !6, !noalias !9
  %272 = fadd float %271, %.pre19.pre.pre
  %273 = tail call float @llvm.maximum.f32(float %272, float 0.000000e+00)
  store float %273, ptr %270, align 4, !alias.scope !6, !noalias !9
  %274 = getelementptr i8, ptr %242, i64 32
  %275 = load float, ptr %274, align 4, !alias.scope !6, !noalias !9
  %276 = fadd float %275, %.pre21.pre.pre
  %277 = tail call float @llvm.maximum.f32(float %276, float 0.000000e+00)
  store float %277, ptr %274, align 4, !alias.scope !6, !noalias !9
  %278 = getelementptr i8, ptr %242, i64 36
  %279 = load float, ptr %278, align 4, !alias.scope !6, !noalias !9
  %280 = fadd float %279, %.pre23.pre.pre
  %281 = tail call float @llvm.maximum.f32(float %280, float 0.000000e+00)
  store float %281, ptr %278, align 4, !alias.scope !6, !noalias !9
  %282 = getelementptr i8, ptr %242, i64 40
  %283 = load float, ptr %282, align 4, !alias.scope !6, !noalias !9
  %284 = fadd float %283, %.pre25.pre.pre
  %285 = tail call float @llvm.maximum.f32(float %284, float 0.000000e+00)
  store float %285, ptr %282, align 4, !alias.scope !6, !noalias !9
  %286 = getelementptr i8, ptr %242, i64 44
  %287 = load float, ptr %286, align 4, !alias.scope !6, !noalias !9
  %288 = fadd float %287, %.pre27.pre.pre
  %289 = tail call float @llvm.maximum.f32(float %288, float 0.000000e+00)
  store float %289, ptr %286, align 4, !alias.scope !6, !noalias !9
  %290 = add nuw nsw i64 %241, 1
  %exitcond.not = icmp eq i64 %290, 20
  br i1 %exitcond.not, label %291, label %.preheader, !llvm.loop !15

291:                                              ; preds = %.preheader
  %292 = add nuw nsw i64 %9, 1
  %exitcond5.not = icmp eq i64 %292, 20
  br i1 %exitcond5.not, label %293, label %.preheader3, !llvm.loop !16

293:                                              ; preds = %291
  %294 = add nuw nsw i64 %7, 1
  %exitcond6.not = icmp eq i64 %294, 3
  br i1 %exitcond6.not, label %broadcast_maximum_fusion_wrapped.exit, label %.preheader4, !llvm.loop !16

broadcast_maximum_fusion_wrapped.exit:            ; preds = %293
  ret ptr null
}

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.maximum.f32(float, float) #1

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #2

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr>, <8 x i1>, <8 x float>) #3

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.maximum.v8f32(<8 x float>, <8 x float>) #4

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #4 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 2}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 57600}
!5 = !{i64 48}
!6 = !{!7}
!7 = distinct !{!7, !8, !"broadcast_maximum_fusion_wrapped: argument 0"}
!8 = distinct !{!8, !"broadcast_maximum_fusion_wrapped"}
!9 = !{!10}
!10 = distinct !{!10, !8, !"broadcast_maximum_fusion_wrapped: argument 1"}
!11 = distinct !{!11, !12, !13, !14}
!12 = !{!"llvm.loop.unroll.disable"}
!13 = !{!"llvm.loop.isvectorized", i32 1}
!14 = !{!"llvm.loop.unroll.runtime.disable"}
!15 = distinct !{!15, !12, !13}
!16 = distinct !{!16, !12}
