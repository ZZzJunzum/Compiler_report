; ModuleID = '__compute_module_add_maximum_fusion_kernel_module'
source_filename = "__compute_module_add_maximum_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @add_maximum_fusion(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !5
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !4
  tail call void @llvm.experimental.noalias.scope.decl(metadata !6)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !11)
  %.phi.trans.insert.phi.trans.insert.phi.trans.insert = getelementptr inbounds nuw i8, ptr %6, i64 4
  %.pre.pre.pre = load float, ptr %.phi.trans.insert.phi.trans.insert.phi.trans.insert, align 4, !invariant.load !3, !alias.scope !9, !noalias !13
  %.phi.trans.insert6.phi.trans.insert.phi.trans.insert = getelementptr inbounds nuw i8, ptr %6, i64 8
  %.pre7.pre.pre = load float, ptr %.phi.trans.insert6.phi.trans.insert.phi.trans.insert, align 4, !invariant.load !3, !alias.scope !9, !noalias !13
  %.phi.trans.insert8.phi.trans.insert.phi.trans.insert = getelementptr inbounds nuw i8, ptr %6, i64 12
  %.pre9.pre.pre = load float, ptr %.phi.trans.insert8.phi.trans.insert.phi.trans.insert, align 4, !invariant.load !3, !alias.scope !9, !noalias !13
  %.phi.trans.insert10.phi.trans.insert.phi.trans.insert = getelementptr inbounds nuw i8, ptr %6, i64 16
  %.pre11.pre.pre = load float, ptr %.phi.trans.insert10.phi.trans.insert.phi.trans.insert, align 4, !invariant.load !3, !alias.scope !9, !noalias !13
  %.phi.trans.insert12.phi.trans.insert.phi.trans.insert = getelementptr inbounds nuw i8, ptr %6, i64 20
  %.pre13.pre.pre = load float, ptr %.phi.trans.insert12.phi.trans.insert.phi.trans.insert, align 4, !invariant.load !3, !alias.scope !9, !noalias !13
  %.phi.trans.insert14.phi.trans.insert.phi.trans.insert = getelementptr inbounds nuw i8, ptr %6, i64 24
  %.pre15.pre.pre = load float, ptr %.phi.trans.insert14.phi.trans.insert.phi.trans.insert, align 4, !invariant.load !3, !alias.scope !9, !noalias !13
  %.phi.trans.insert16.phi.trans.insert.phi.trans.insert = getelementptr inbounds nuw i8, ptr %6, i64 28
  %.pre17.pre.pre = load float, ptr %.phi.trans.insert16.phi.trans.insert.phi.trans.insert, align 4, !invariant.load !3, !alias.scope !9, !noalias !13
  %.phi.trans.insert18.phi.trans.insert.phi.trans.insert = getelementptr inbounds nuw i8, ptr %6, i64 32
  %.pre19.pre.pre = load float, ptr %.phi.trans.insert18.phi.trans.insert.phi.trans.insert, align 4, !invariant.load !3, !alias.scope !9, !noalias !13
  %.phi.trans.insert20.phi.trans.insert.phi.trans.insert = getelementptr inbounds nuw i8, ptr %6, i64 36
  %.pre21.pre.pre = load float, ptr %.phi.trans.insert20.phi.trans.insert.phi.trans.insert, align 4, !invariant.load !3, !alias.scope !9, !noalias !13
  %.phi.trans.insert22.phi.trans.insert.phi.trans.insert = getelementptr inbounds nuw i8, ptr %6, i64 40
  %.pre23.pre.pre = load float, ptr %.phi.trans.insert22.phi.trans.insert.phi.trans.insert, align 4, !invariant.load !3, !alias.scope !9, !noalias !13
  %.phi.trans.insert24.phi.trans.insert.phi.trans.insert = getelementptr inbounds nuw i8, ptr %6, i64 44
  %.pre25.pre.pre = load float, ptr %.phi.trans.insert24.phi.trans.insert.phi.trans.insert, align 4, !invariant.load !3, !alias.scope !9, !noalias !13
  %.pre26.pre.pre = load float, ptr %6, align 4, !invariant.load !3, !alias.scope !9, !noalias !13
  %broadcast.splatinsert28 = insertelement <8 x float> poison, float %.pre26.pre.pre, i64 0
  %broadcast.splat29 = shufflevector <8 x float> %broadcast.splatinsert28, <8 x float> poison, <8 x i32> zeroinitializer
  %broadcast.splatinsert30 = insertelement <8 x float> poison, float %.pre.pre.pre, i64 0
  %broadcast.splat31 = shufflevector <8 x float> %broadcast.splatinsert30, <8 x float> poison, <8 x i32> zeroinitializer
  %broadcast.splatinsert32 = insertelement <8 x float> poison, float %.pre7.pre.pre, i64 0
  %broadcast.splat33 = shufflevector <8 x float> %broadcast.splatinsert32, <8 x float> poison, <8 x i32> zeroinitializer
  %broadcast.splatinsert34 = insertelement <8 x float> poison, float %.pre9.pre.pre, i64 0
  %broadcast.splat35 = shufflevector <8 x float> %broadcast.splatinsert34, <8 x float> poison, <8 x i32> zeroinitializer
  %broadcast.splatinsert36 = insertelement <8 x float> poison, float %.pre11.pre.pre, i64 0
  %broadcast.splat37 = shufflevector <8 x float> %broadcast.splatinsert36, <8 x float> poison, <8 x i32> zeroinitializer
  %broadcast.splatinsert38 = insertelement <8 x float> poison, float %.pre13.pre.pre, i64 0
  %broadcast.splat39 = shufflevector <8 x float> %broadcast.splatinsert38, <8 x float> poison, <8 x i32> zeroinitializer
  %broadcast.splatinsert40 = insertelement <8 x float> poison, float %.pre15.pre.pre, i64 0
  %broadcast.splat41 = shufflevector <8 x float> %broadcast.splatinsert40, <8 x float> poison, <8 x i32> zeroinitializer
  %broadcast.splatinsert42 = insertelement <8 x float> poison, float %.pre17.pre.pre, i64 0
  %broadcast.splat43 = shufflevector <8 x float> %broadcast.splatinsert42, <8 x float> poison, <8 x i32> zeroinitializer
  %broadcast.splatinsert44 = insertelement <8 x float> poison, float %.pre19.pre.pre, i64 0
  %broadcast.splat45 = shufflevector <8 x float> %broadcast.splatinsert44, <8 x float> poison, <8 x i32> zeroinitializer
  %broadcast.splatinsert46 = insertelement <8 x float> poison, float %.pre21.pre.pre, i64 0
  %broadcast.splat47 = shufflevector <8 x float> %broadcast.splatinsert46, <8 x float> poison, <8 x i32> zeroinitializer
  %broadcast.splatinsert48 = insertelement <8 x float> poison, float %.pre23.pre.pre, i64 0
  %broadcast.splat49 = shufflevector <8 x float> %broadcast.splatinsert48, <8 x float> poison, <8 x i32> zeroinitializer
  %broadcast.splatinsert50 = insertelement <8 x float> poison, float %.pre25.pre.pre, i64 0
  %broadcast.splat51 = shufflevector <8 x float> %broadcast.splatinsert50, <8 x float> poison, <8 x i32> zeroinitializer
  br label %9

9:                                                ; preds = %1, %430
  %10 = phi i64 [ 0, %1 ], [ %431, %430 ]
  %11 = mul nuw nsw i64 %10, 4800
  br label %vector.ph

vector.ph:                                        ; preds = %9, %428
  %12 = phi i64 [ 0, %9 ], [ %429, %428 ]
  %13 = mul nuw nsw i64 %12, 240
  %14 = add nuw nsw i64 %13, %11
  %broadcast.splatinsert = insertelement <8 x i64> poison, i64 %14, i64 0
  %broadcast.splat = shufflevector <8 x i64> %broadcast.splatinsert, <8 x i64> poison, <8 x i32> zeroinitializer
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %vector.ph
  %index = phi i64 [ 0, %vector.ph ], [ %index.next, %vector.body ]
  %vec.ind = phi <8 x i64> [ <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>, %vector.ph ], [ %vec.ind.next, %vector.body ]
  %15 = mul nuw nsw <8 x i64> %vec.ind, splat (i64 12)
  %16 = add nuw nsw <8 x i64> %broadcast.splat, %15
  %17 = extractelement <8 x i64> %16, i64 0
  %18 = extractelement <8 x i64> %16, i64 1
  %19 = extractelement <8 x i64> %16, i64 2
  %20 = extractelement <8 x i64> %16, i64 3
  %21 = extractelement <8 x i64> %16, i64 4
  %22 = extractelement <8 x i64> %16, i64 5
  %23 = extractelement <8 x i64> %16, i64 6
  %24 = extractelement <8 x i64> %16, i64 7
  %25 = getelementptr inbounds nuw float, ptr %4, <8 x i64> %16
  %wide.masked.gather = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %25, <8 x i1> splat (i1 true), <8 x float> poison), !invariant.load !3, !alias.scope !6, !noalias !14
  %26 = fadd <8 x float> %wide.masked.gather, %broadcast.splat29
  %27 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %26, <8 x float> zeroinitializer)
  %28 = extractelement <8 x float> %27, i64 0
  %29 = extractelement <8 x float> %27, i64 1
  %30 = extractelement <8 x float> %27, i64 2
  %31 = extractelement <8 x float> %27, i64 3
  %32 = extractelement <8 x float> %27, i64 4
  %33 = extractelement <8 x float> %27, i64 5
  %34 = extractelement <8 x float> %27, i64 6
  %35 = extractelement <8 x float> %27, i64 7
  %36 = getelementptr inbounds nuw float, ptr %8, i64 %17
  %37 = getelementptr inbounds nuw float, ptr %8, i64 %18
  %38 = getelementptr inbounds nuw float, ptr %8, i64 %19
  %39 = getelementptr inbounds nuw float, ptr %8, i64 %20
  %40 = getelementptr inbounds nuw float, ptr %8, i64 %21
  %41 = getelementptr inbounds nuw float, ptr %8, i64 %22
  %42 = getelementptr inbounds nuw float, ptr %8, i64 %23
  %43 = getelementptr inbounds nuw float, ptr %8, i64 %24
  store float %28, ptr %36, align 4, !alias.scope !11, !noalias !15
  store float %29, ptr %37, align 4, !alias.scope !11, !noalias !15
  store float %30, ptr %38, align 4, !alias.scope !11, !noalias !15
  store float %31, ptr %39, align 4, !alias.scope !11, !noalias !15
  store float %32, ptr %40, align 4, !alias.scope !11, !noalias !15
  store float %33, ptr %41, align 4, !alias.scope !11, !noalias !15
  store float %34, ptr %42, align 4, !alias.scope !11, !noalias !15
  store float %35, ptr %43, align 4, !alias.scope !11, !noalias !15
  %44 = or disjoint <8 x i64> %16, splat (i64 1)
  %45 = extractelement <8 x i64> %44, i64 0
  %46 = extractelement <8 x i64> %44, i64 1
  %47 = extractelement <8 x i64> %44, i64 2
  %48 = extractelement <8 x i64> %44, i64 3
  %49 = extractelement <8 x i64> %44, i64 4
  %50 = extractelement <8 x i64> %44, i64 5
  %51 = extractelement <8 x i64> %44, i64 6
  %52 = extractelement <8 x i64> %44, i64 7
  %53 = getelementptr inbounds nuw float, ptr %4, <8 x i64> %44
  %wide.masked.gather52 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %53, <8 x i1> splat (i1 true), <8 x float> poison), !invariant.load !3, !alias.scope !6, !noalias !14
  %54 = fadd <8 x float> %wide.masked.gather52, %broadcast.splat31
  %55 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %54, <8 x float> zeroinitializer)
  %56 = extractelement <8 x float> %55, i64 0
  %57 = extractelement <8 x float> %55, i64 1
  %58 = extractelement <8 x float> %55, i64 2
  %59 = extractelement <8 x float> %55, i64 3
  %60 = extractelement <8 x float> %55, i64 4
  %61 = extractelement <8 x float> %55, i64 5
  %62 = extractelement <8 x float> %55, i64 6
  %63 = extractelement <8 x float> %55, i64 7
  %64 = getelementptr inbounds nuw float, ptr %8, i64 %45
  %65 = getelementptr inbounds nuw float, ptr %8, i64 %46
  %66 = getelementptr inbounds nuw float, ptr %8, i64 %47
  %67 = getelementptr inbounds nuw float, ptr %8, i64 %48
  %68 = getelementptr inbounds nuw float, ptr %8, i64 %49
  %69 = getelementptr inbounds nuw float, ptr %8, i64 %50
  %70 = getelementptr inbounds nuw float, ptr %8, i64 %51
  %71 = getelementptr inbounds nuw float, ptr %8, i64 %52
  store float %56, ptr %64, align 4, !alias.scope !11, !noalias !15
  store float %57, ptr %65, align 4, !alias.scope !11, !noalias !15
  store float %58, ptr %66, align 4, !alias.scope !11, !noalias !15
  store float %59, ptr %67, align 4, !alias.scope !11, !noalias !15
  store float %60, ptr %68, align 4, !alias.scope !11, !noalias !15
  store float %61, ptr %69, align 4, !alias.scope !11, !noalias !15
  store float %62, ptr %70, align 4, !alias.scope !11, !noalias !15
  store float %63, ptr %71, align 4, !alias.scope !11, !noalias !15
  %72 = or disjoint <8 x i64> %16, splat (i64 2)
  %73 = extractelement <8 x i64> %72, i64 0
  %74 = extractelement <8 x i64> %72, i64 1
  %75 = extractelement <8 x i64> %72, i64 2
  %76 = extractelement <8 x i64> %72, i64 3
  %77 = extractelement <8 x i64> %72, i64 4
  %78 = extractelement <8 x i64> %72, i64 5
  %79 = extractelement <8 x i64> %72, i64 6
  %80 = extractelement <8 x i64> %72, i64 7
  %81 = getelementptr inbounds nuw float, ptr %4, <8 x i64> %72
  %wide.masked.gather53 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %81, <8 x i1> splat (i1 true), <8 x float> poison), !invariant.load !3, !alias.scope !6, !noalias !14
  %82 = fadd <8 x float> %wide.masked.gather53, %broadcast.splat33
  %83 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %82, <8 x float> zeroinitializer)
  %84 = extractelement <8 x float> %83, i64 0
  %85 = extractelement <8 x float> %83, i64 1
  %86 = extractelement <8 x float> %83, i64 2
  %87 = extractelement <8 x float> %83, i64 3
  %88 = extractelement <8 x float> %83, i64 4
  %89 = extractelement <8 x float> %83, i64 5
  %90 = extractelement <8 x float> %83, i64 6
  %91 = extractelement <8 x float> %83, i64 7
  %92 = getelementptr inbounds nuw float, ptr %8, i64 %73
  %93 = getelementptr inbounds nuw float, ptr %8, i64 %74
  %94 = getelementptr inbounds nuw float, ptr %8, i64 %75
  %95 = getelementptr inbounds nuw float, ptr %8, i64 %76
  %96 = getelementptr inbounds nuw float, ptr %8, i64 %77
  %97 = getelementptr inbounds nuw float, ptr %8, i64 %78
  %98 = getelementptr inbounds nuw float, ptr %8, i64 %79
  %99 = getelementptr inbounds nuw float, ptr %8, i64 %80
  store float %84, ptr %92, align 4, !alias.scope !11, !noalias !15
  store float %85, ptr %93, align 4, !alias.scope !11, !noalias !15
  store float %86, ptr %94, align 4, !alias.scope !11, !noalias !15
  store float %87, ptr %95, align 4, !alias.scope !11, !noalias !15
  store float %88, ptr %96, align 4, !alias.scope !11, !noalias !15
  store float %89, ptr %97, align 4, !alias.scope !11, !noalias !15
  store float %90, ptr %98, align 4, !alias.scope !11, !noalias !15
  store float %91, ptr %99, align 4, !alias.scope !11, !noalias !15
  %100 = or disjoint <8 x i64> %16, splat (i64 3)
  %101 = extractelement <8 x i64> %100, i64 0
  %102 = extractelement <8 x i64> %100, i64 1
  %103 = extractelement <8 x i64> %100, i64 2
  %104 = extractelement <8 x i64> %100, i64 3
  %105 = extractelement <8 x i64> %100, i64 4
  %106 = extractelement <8 x i64> %100, i64 5
  %107 = extractelement <8 x i64> %100, i64 6
  %108 = extractelement <8 x i64> %100, i64 7
  %109 = getelementptr inbounds nuw float, ptr %4, <8 x i64> %100
  %wide.masked.gather54 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %109, <8 x i1> splat (i1 true), <8 x float> poison), !invariant.load !3, !alias.scope !6, !noalias !14
  %110 = fadd <8 x float> %wide.masked.gather54, %broadcast.splat35
  %111 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %110, <8 x float> zeroinitializer)
  %112 = extractelement <8 x float> %111, i64 0
  %113 = extractelement <8 x float> %111, i64 1
  %114 = extractelement <8 x float> %111, i64 2
  %115 = extractelement <8 x float> %111, i64 3
  %116 = extractelement <8 x float> %111, i64 4
  %117 = extractelement <8 x float> %111, i64 5
  %118 = extractelement <8 x float> %111, i64 6
  %119 = extractelement <8 x float> %111, i64 7
  %120 = getelementptr inbounds nuw float, ptr %8, i64 %101
  %121 = getelementptr inbounds nuw float, ptr %8, i64 %102
  %122 = getelementptr inbounds nuw float, ptr %8, i64 %103
  %123 = getelementptr inbounds nuw float, ptr %8, i64 %104
  %124 = getelementptr inbounds nuw float, ptr %8, i64 %105
  %125 = getelementptr inbounds nuw float, ptr %8, i64 %106
  %126 = getelementptr inbounds nuw float, ptr %8, i64 %107
  %127 = getelementptr inbounds nuw float, ptr %8, i64 %108
  store float %112, ptr %120, align 4, !alias.scope !11, !noalias !15
  store float %113, ptr %121, align 4, !alias.scope !11, !noalias !15
  store float %114, ptr %122, align 4, !alias.scope !11, !noalias !15
  store float %115, ptr %123, align 4, !alias.scope !11, !noalias !15
  store float %116, ptr %124, align 4, !alias.scope !11, !noalias !15
  store float %117, ptr %125, align 4, !alias.scope !11, !noalias !15
  store float %118, ptr %126, align 4, !alias.scope !11, !noalias !15
  store float %119, ptr %127, align 4, !alias.scope !11, !noalias !15
  %128 = add nuw nsw <8 x i64> %16, splat (i64 4)
  %129 = extractelement <8 x i64> %128, i64 0
  %130 = extractelement <8 x i64> %128, i64 1
  %131 = extractelement <8 x i64> %128, i64 2
  %132 = extractelement <8 x i64> %128, i64 3
  %133 = extractelement <8 x i64> %128, i64 4
  %134 = extractelement <8 x i64> %128, i64 5
  %135 = extractelement <8 x i64> %128, i64 6
  %136 = extractelement <8 x i64> %128, i64 7
  %137 = getelementptr inbounds nuw float, ptr %4, <8 x i64> %128
  %wide.masked.gather55 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %137, <8 x i1> splat (i1 true), <8 x float> poison), !invariant.load !3, !alias.scope !6, !noalias !14
  %138 = fadd <8 x float> %wide.masked.gather55, %broadcast.splat37
  %139 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %138, <8 x float> zeroinitializer)
  %140 = extractelement <8 x float> %139, i64 0
  %141 = extractelement <8 x float> %139, i64 1
  %142 = extractelement <8 x float> %139, i64 2
  %143 = extractelement <8 x float> %139, i64 3
  %144 = extractelement <8 x float> %139, i64 4
  %145 = extractelement <8 x float> %139, i64 5
  %146 = extractelement <8 x float> %139, i64 6
  %147 = extractelement <8 x float> %139, i64 7
  %148 = getelementptr inbounds nuw float, ptr %8, i64 %129
  %149 = getelementptr inbounds nuw float, ptr %8, i64 %130
  %150 = getelementptr inbounds nuw float, ptr %8, i64 %131
  %151 = getelementptr inbounds nuw float, ptr %8, i64 %132
  %152 = getelementptr inbounds nuw float, ptr %8, i64 %133
  %153 = getelementptr inbounds nuw float, ptr %8, i64 %134
  %154 = getelementptr inbounds nuw float, ptr %8, i64 %135
  %155 = getelementptr inbounds nuw float, ptr %8, i64 %136
  store float %140, ptr %148, align 4, !alias.scope !11, !noalias !15
  store float %141, ptr %149, align 4, !alias.scope !11, !noalias !15
  store float %142, ptr %150, align 4, !alias.scope !11, !noalias !15
  store float %143, ptr %151, align 4, !alias.scope !11, !noalias !15
  store float %144, ptr %152, align 4, !alias.scope !11, !noalias !15
  store float %145, ptr %153, align 4, !alias.scope !11, !noalias !15
  store float %146, ptr %154, align 4, !alias.scope !11, !noalias !15
  store float %147, ptr %155, align 4, !alias.scope !11, !noalias !15
  %156 = add nuw nsw <8 x i64> %16, splat (i64 5)
  %157 = extractelement <8 x i64> %156, i64 0
  %158 = extractelement <8 x i64> %156, i64 1
  %159 = extractelement <8 x i64> %156, i64 2
  %160 = extractelement <8 x i64> %156, i64 3
  %161 = extractelement <8 x i64> %156, i64 4
  %162 = extractelement <8 x i64> %156, i64 5
  %163 = extractelement <8 x i64> %156, i64 6
  %164 = extractelement <8 x i64> %156, i64 7
  %165 = getelementptr inbounds nuw float, ptr %4, <8 x i64> %156
  %wide.masked.gather56 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %165, <8 x i1> splat (i1 true), <8 x float> poison), !invariant.load !3, !alias.scope !6, !noalias !14
  %166 = fadd <8 x float> %wide.masked.gather56, %broadcast.splat39
  %167 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %166, <8 x float> zeroinitializer)
  %168 = extractelement <8 x float> %167, i64 0
  %169 = extractelement <8 x float> %167, i64 1
  %170 = extractelement <8 x float> %167, i64 2
  %171 = extractelement <8 x float> %167, i64 3
  %172 = extractelement <8 x float> %167, i64 4
  %173 = extractelement <8 x float> %167, i64 5
  %174 = extractelement <8 x float> %167, i64 6
  %175 = extractelement <8 x float> %167, i64 7
  %176 = getelementptr inbounds nuw float, ptr %8, i64 %157
  %177 = getelementptr inbounds nuw float, ptr %8, i64 %158
  %178 = getelementptr inbounds nuw float, ptr %8, i64 %159
  %179 = getelementptr inbounds nuw float, ptr %8, i64 %160
  %180 = getelementptr inbounds nuw float, ptr %8, i64 %161
  %181 = getelementptr inbounds nuw float, ptr %8, i64 %162
  %182 = getelementptr inbounds nuw float, ptr %8, i64 %163
  %183 = getelementptr inbounds nuw float, ptr %8, i64 %164
  store float %168, ptr %176, align 4, !alias.scope !11, !noalias !15
  store float %169, ptr %177, align 4, !alias.scope !11, !noalias !15
  store float %170, ptr %178, align 4, !alias.scope !11, !noalias !15
  store float %171, ptr %179, align 4, !alias.scope !11, !noalias !15
  store float %172, ptr %180, align 4, !alias.scope !11, !noalias !15
  store float %173, ptr %181, align 4, !alias.scope !11, !noalias !15
  store float %174, ptr %182, align 4, !alias.scope !11, !noalias !15
  store float %175, ptr %183, align 4, !alias.scope !11, !noalias !15
  %184 = add nuw nsw <8 x i64> %16, splat (i64 6)
  %185 = extractelement <8 x i64> %184, i64 0
  %186 = extractelement <8 x i64> %184, i64 1
  %187 = extractelement <8 x i64> %184, i64 2
  %188 = extractelement <8 x i64> %184, i64 3
  %189 = extractelement <8 x i64> %184, i64 4
  %190 = extractelement <8 x i64> %184, i64 5
  %191 = extractelement <8 x i64> %184, i64 6
  %192 = extractelement <8 x i64> %184, i64 7
  %193 = getelementptr inbounds nuw float, ptr %4, <8 x i64> %184
  %wide.masked.gather57 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %193, <8 x i1> splat (i1 true), <8 x float> poison), !invariant.load !3, !alias.scope !6, !noalias !14
  %194 = fadd <8 x float> %wide.masked.gather57, %broadcast.splat41
  %195 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %194, <8 x float> zeroinitializer)
  %196 = extractelement <8 x float> %195, i64 0
  %197 = extractelement <8 x float> %195, i64 1
  %198 = extractelement <8 x float> %195, i64 2
  %199 = extractelement <8 x float> %195, i64 3
  %200 = extractelement <8 x float> %195, i64 4
  %201 = extractelement <8 x float> %195, i64 5
  %202 = extractelement <8 x float> %195, i64 6
  %203 = extractelement <8 x float> %195, i64 7
  %204 = getelementptr inbounds nuw float, ptr %8, i64 %185
  %205 = getelementptr inbounds nuw float, ptr %8, i64 %186
  %206 = getelementptr inbounds nuw float, ptr %8, i64 %187
  %207 = getelementptr inbounds nuw float, ptr %8, i64 %188
  %208 = getelementptr inbounds nuw float, ptr %8, i64 %189
  %209 = getelementptr inbounds nuw float, ptr %8, i64 %190
  %210 = getelementptr inbounds nuw float, ptr %8, i64 %191
  %211 = getelementptr inbounds nuw float, ptr %8, i64 %192
  store float %196, ptr %204, align 4, !alias.scope !11, !noalias !15
  store float %197, ptr %205, align 4, !alias.scope !11, !noalias !15
  store float %198, ptr %206, align 4, !alias.scope !11, !noalias !15
  store float %199, ptr %207, align 4, !alias.scope !11, !noalias !15
  store float %200, ptr %208, align 4, !alias.scope !11, !noalias !15
  store float %201, ptr %209, align 4, !alias.scope !11, !noalias !15
  store float %202, ptr %210, align 4, !alias.scope !11, !noalias !15
  store float %203, ptr %211, align 4, !alias.scope !11, !noalias !15
  %212 = add nuw nsw <8 x i64> %16, splat (i64 7)
  %213 = extractelement <8 x i64> %212, i64 0
  %214 = extractelement <8 x i64> %212, i64 1
  %215 = extractelement <8 x i64> %212, i64 2
  %216 = extractelement <8 x i64> %212, i64 3
  %217 = extractelement <8 x i64> %212, i64 4
  %218 = extractelement <8 x i64> %212, i64 5
  %219 = extractelement <8 x i64> %212, i64 6
  %220 = extractelement <8 x i64> %212, i64 7
  %221 = getelementptr inbounds nuw float, ptr %4, <8 x i64> %212
  %wide.masked.gather58 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %221, <8 x i1> splat (i1 true), <8 x float> poison), !invariant.load !3, !alias.scope !6, !noalias !14
  %222 = fadd <8 x float> %wide.masked.gather58, %broadcast.splat43
  %223 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %222, <8 x float> zeroinitializer)
  %224 = extractelement <8 x float> %223, i64 0
  %225 = extractelement <8 x float> %223, i64 1
  %226 = extractelement <8 x float> %223, i64 2
  %227 = extractelement <8 x float> %223, i64 3
  %228 = extractelement <8 x float> %223, i64 4
  %229 = extractelement <8 x float> %223, i64 5
  %230 = extractelement <8 x float> %223, i64 6
  %231 = extractelement <8 x float> %223, i64 7
  %232 = getelementptr inbounds nuw float, ptr %8, i64 %213
  %233 = getelementptr inbounds nuw float, ptr %8, i64 %214
  %234 = getelementptr inbounds nuw float, ptr %8, i64 %215
  %235 = getelementptr inbounds nuw float, ptr %8, i64 %216
  %236 = getelementptr inbounds nuw float, ptr %8, i64 %217
  %237 = getelementptr inbounds nuw float, ptr %8, i64 %218
  %238 = getelementptr inbounds nuw float, ptr %8, i64 %219
  %239 = getelementptr inbounds nuw float, ptr %8, i64 %220
  store float %224, ptr %232, align 4, !alias.scope !11, !noalias !15
  store float %225, ptr %233, align 4, !alias.scope !11, !noalias !15
  store float %226, ptr %234, align 4, !alias.scope !11, !noalias !15
  store float %227, ptr %235, align 4, !alias.scope !11, !noalias !15
  store float %228, ptr %236, align 4, !alias.scope !11, !noalias !15
  store float %229, ptr %237, align 4, !alias.scope !11, !noalias !15
  store float %230, ptr %238, align 4, !alias.scope !11, !noalias !15
  store float %231, ptr %239, align 4, !alias.scope !11, !noalias !15
  %240 = add nuw nsw <8 x i64> %16, splat (i64 8)
  %241 = extractelement <8 x i64> %240, i64 0
  %242 = extractelement <8 x i64> %240, i64 1
  %243 = extractelement <8 x i64> %240, i64 2
  %244 = extractelement <8 x i64> %240, i64 3
  %245 = extractelement <8 x i64> %240, i64 4
  %246 = extractelement <8 x i64> %240, i64 5
  %247 = extractelement <8 x i64> %240, i64 6
  %248 = extractelement <8 x i64> %240, i64 7
  %249 = getelementptr inbounds nuw float, ptr %4, <8 x i64> %240
  %wide.masked.gather59 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %249, <8 x i1> splat (i1 true), <8 x float> poison), !invariant.load !3, !alias.scope !6, !noalias !14
  %250 = fadd <8 x float> %wide.masked.gather59, %broadcast.splat45
  %251 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %250, <8 x float> zeroinitializer)
  %252 = extractelement <8 x float> %251, i64 0
  %253 = extractelement <8 x float> %251, i64 1
  %254 = extractelement <8 x float> %251, i64 2
  %255 = extractelement <8 x float> %251, i64 3
  %256 = extractelement <8 x float> %251, i64 4
  %257 = extractelement <8 x float> %251, i64 5
  %258 = extractelement <8 x float> %251, i64 6
  %259 = extractelement <8 x float> %251, i64 7
  %260 = getelementptr inbounds nuw float, ptr %8, i64 %241
  %261 = getelementptr inbounds nuw float, ptr %8, i64 %242
  %262 = getelementptr inbounds nuw float, ptr %8, i64 %243
  %263 = getelementptr inbounds nuw float, ptr %8, i64 %244
  %264 = getelementptr inbounds nuw float, ptr %8, i64 %245
  %265 = getelementptr inbounds nuw float, ptr %8, i64 %246
  %266 = getelementptr inbounds nuw float, ptr %8, i64 %247
  %267 = getelementptr inbounds nuw float, ptr %8, i64 %248
  store float %252, ptr %260, align 4, !alias.scope !11, !noalias !15
  store float %253, ptr %261, align 4, !alias.scope !11, !noalias !15
  store float %254, ptr %262, align 4, !alias.scope !11, !noalias !15
  store float %255, ptr %263, align 4, !alias.scope !11, !noalias !15
  store float %256, ptr %264, align 4, !alias.scope !11, !noalias !15
  store float %257, ptr %265, align 4, !alias.scope !11, !noalias !15
  store float %258, ptr %266, align 4, !alias.scope !11, !noalias !15
  store float %259, ptr %267, align 4, !alias.scope !11, !noalias !15
  %268 = add nuw nsw <8 x i64> %16, splat (i64 9)
  %269 = extractelement <8 x i64> %268, i64 0
  %270 = extractelement <8 x i64> %268, i64 1
  %271 = extractelement <8 x i64> %268, i64 2
  %272 = extractelement <8 x i64> %268, i64 3
  %273 = extractelement <8 x i64> %268, i64 4
  %274 = extractelement <8 x i64> %268, i64 5
  %275 = extractelement <8 x i64> %268, i64 6
  %276 = extractelement <8 x i64> %268, i64 7
  %277 = getelementptr inbounds nuw float, ptr %4, <8 x i64> %268
  %wide.masked.gather60 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %277, <8 x i1> splat (i1 true), <8 x float> poison), !invariant.load !3, !alias.scope !6, !noalias !14
  %278 = fadd <8 x float> %wide.masked.gather60, %broadcast.splat47
  %279 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %278, <8 x float> zeroinitializer)
  %280 = extractelement <8 x float> %279, i64 0
  %281 = extractelement <8 x float> %279, i64 1
  %282 = extractelement <8 x float> %279, i64 2
  %283 = extractelement <8 x float> %279, i64 3
  %284 = extractelement <8 x float> %279, i64 4
  %285 = extractelement <8 x float> %279, i64 5
  %286 = extractelement <8 x float> %279, i64 6
  %287 = extractelement <8 x float> %279, i64 7
  %288 = getelementptr inbounds nuw float, ptr %8, i64 %269
  %289 = getelementptr inbounds nuw float, ptr %8, i64 %270
  %290 = getelementptr inbounds nuw float, ptr %8, i64 %271
  %291 = getelementptr inbounds nuw float, ptr %8, i64 %272
  %292 = getelementptr inbounds nuw float, ptr %8, i64 %273
  %293 = getelementptr inbounds nuw float, ptr %8, i64 %274
  %294 = getelementptr inbounds nuw float, ptr %8, i64 %275
  %295 = getelementptr inbounds nuw float, ptr %8, i64 %276
  store float %280, ptr %288, align 4, !alias.scope !11, !noalias !15
  store float %281, ptr %289, align 4, !alias.scope !11, !noalias !15
  store float %282, ptr %290, align 4, !alias.scope !11, !noalias !15
  store float %283, ptr %291, align 4, !alias.scope !11, !noalias !15
  store float %284, ptr %292, align 4, !alias.scope !11, !noalias !15
  store float %285, ptr %293, align 4, !alias.scope !11, !noalias !15
  store float %286, ptr %294, align 4, !alias.scope !11, !noalias !15
  store float %287, ptr %295, align 4, !alias.scope !11, !noalias !15
  %296 = add nuw nsw <8 x i64> %16, splat (i64 10)
  %297 = extractelement <8 x i64> %296, i64 0
  %298 = extractelement <8 x i64> %296, i64 1
  %299 = extractelement <8 x i64> %296, i64 2
  %300 = extractelement <8 x i64> %296, i64 3
  %301 = extractelement <8 x i64> %296, i64 4
  %302 = extractelement <8 x i64> %296, i64 5
  %303 = extractelement <8 x i64> %296, i64 6
  %304 = extractelement <8 x i64> %296, i64 7
  %305 = getelementptr inbounds nuw float, ptr %4, <8 x i64> %296
  %wide.masked.gather61 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %305, <8 x i1> splat (i1 true), <8 x float> poison), !invariant.load !3, !alias.scope !6, !noalias !14
  %306 = fadd <8 x float> %wide.masked.gather61, %broadcast.splat49
  %307 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %306, <8 x float> zeroinitializer)
  %308 = extractelement <8 x float> %307, i64 0
  %309 = extractelement <8 x float> %307, i64 1
  %310 = extractelement <8 x float> %307, i64 2
  %311 = extractelement <8 x float> %307, i64 3
  %312 = extractelement <8 x float> %307, i64 4
  %313 = extractelement <8 x float> %307, i64 5
  %314 = extractelement <8 x float> %307, i64 6
  %315 = extractelement <8 x float> %307, i64 7
  %316 = getelementptr inbounds nuw float, ptr %8, i64 %297
  %317 = getelementptr inbounds nuw float, ptr %8, i64 %298
  %318 = getelementptr inbounds nuw float, ptr %8, i64 %299
  %319 = getelementptr inbounds nuw float, ptr %8, i64 %300
  %320 = getelementptr inbounds nuw float, ptr %8, i64 %301
  %321 = getelementptr inbounds nuw float, ptr %8, i64 %302
  %322 = getelementptr inbounds nuw float, ptr %8, i64 %303
  %323 = getelementptr inbounds nuw float, ptr %8, i64 %304
  store float %308, ptr %316, align 4, !alias.scope !11, !noalias !15
  store float %309, ptr %317, align 4, !alias.scope !11, !noalias !15
  store float %310, ptr %318, align 4, !alias.scope !11, !noalias !15
  store float %311, ptr %319, align 4, !alias.scope !11, !noalias !15
  store float %312, ptr %320, align 4, !alias.scope !11, !noalias !15
  store float %313, ptr %321, align 4, !alias.scope !11, !noalias !15
  store float %314, ptr %322, align 4, !alias.scope !11, !noalias !15
  store float %315, ptr %323, align 4, !alias.scope !11, !noalias !15
  %324 = add nuw nsw <8 x i64> %16, splat (i64 11)
  %325 = extractelement <8 x i64> %324, i64 0
  %326 = extractelement <8 x i64> %324, i64 1
  %327 = extractelement <8 x i64> %324, i64 2
  %328 = extractelement <8 x i64> %324, i64 3
  %329 = extractelement <8 x i64> %324, i64 4
  %330 = extractelement <8 x i64> %324, i64 5
  %331 = extractelement <8 x i64> %324, i64 6
  %332 = extractelement <8 x i64> %324, i64 7
  %333 = getelementptr inbounds nuw float, ptr %4, <8 x i64> %324
  %wide.masked.gather62 = tail call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 4 %333, <8 x i1> splat (i1 true), <8 x float> poison), !invariant.load !3, !alias.scope !6, !noalias !14
  %334 = fadd <8 x float> %wide.masked.gather62, %broadcast.splat51
  %335 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %334, <8 x float> zeroinitializer)
  %336 = extractelement <8 x float> %335, i64 0
  %337 = extractelement <8 x float> %335, i64 1
  %338 = extractelement <8 x float> %335, i64 2
  %339 = extractelement <8 x float> %335, i64 3
  %340 = extractelement <8 x float> %335, i64 4
  %341 = extractelement <8 x float> %335, i64 5
  %342 = extractelement <8 x float> %335, i64 6
  %343 = extractelement <8 x float> %335, i64 7
  %344 = getelementptr inbounds nuw float, ptr %8, i64 %325
  %345 = getelementptr inbounds nuw float, ptr %8, i64 %326
  %346 = getelementptr inbounds nuw float, ptr %8, i64 %327
  %347 = getelementptr inbounds nuw float, ptr %8, i64 %328
  %348 = getelementptr inbounds nuw float, ptr %8, i64 %329
  %349 = getelementptr inbounds nuw float, ptr %8, i64 %330
  %350 = getelementptr inbounds nuw float, ptr %8, i64 %331
  %351 = getelementptr inbounds nuw float, ptr %8, i64 %332
  store float %336, ptr %344, align 4, !alias.scope !11, !noalias !15
  store float %337, ptr %345, align 4, !alias.scope !11, !noalias !15
  store float %338, ptr %346, align 4, !alias.scope !11, !noalias !15
  store float %339, ptr %347, align 4, !alias.scope !11, !noalias !15
  store float %340, ptr %348, align 4, !alias.scope !11, !noalias !15
  store float %341, ptr %349, align 4, !alias.scope !11, !noalias !15
  store float %342, ptr %350, align 4, !alias.scope !11, !noalias !15
  store float %343, ptr %351, align 4, !alias.scope !11, !noalias !15
  %index.next = add nuw i64 %index, 8
  %vec.ind.next = add nuw nsw <8 x i64> %vec.ind, splat (i64 8)
  %352 = icmp eq i64 %index.next, 16
  br i1 %352, label %scalar.ph, label %vector.body, !llvm.loop !16

scalar.ph:                                        ; preds = %vector.body, %scalar.ph
  %353 = phi i64 [ %427, %scalar.ph ], [ 16, %vector.body ]
  %354 = mul nuw nsw i64 %353, 12
  %355 = add nuw nsw i64 %14, %354
  %356 = getelementptr inbounds nuw float, ptr %4, i64 %355
  %357 = load float, ptr %356, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %358 = fadd float %357, %.pre26.pre.pre
  %359 = tail call float @llvm.maximum.f32(float %358, float 0.000000e+00)
  %360 = getelementptr inbounds nuw float, ptr %8, i64 %355
  store float %359, ptr %360, align 4, !alias.scope !11, !noalias !15
  %361 = or disjoint i64 %355, 1
  %362 = getelementptr inbounds nuw float, ptr %4, i64 %361
  %363 = load float, ptr %362, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %364 = fadd float %363, %.pre.pre.pre
  %365 = tail call float @llvm.maximum.f32(float %364, float 0.000000e+00)
  %366 = getelementptr inbounds nuw float, ptr %8, i64 %361
  store float %365, ptr %366, align 4, !alias.scope !11, !noalias !15
  %367 = or disjoint i64 %355, 2
  %368 = getelementptr inbounds nuw float, ptr %4, i64 %367
  %369 = load float, ptr %368, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %370 = fadd float %369, %.pre7.pre.pre
  %371 = tail call float @llvm.maximum.f32(float %370, float 0.000000e+00)
  %372 = getelementptr inbounds nuw float, ptr %8, i64 %367
  store float %371, ptr %372, align 4, !alias.scope !11, !noalias !15
  %373 = or disjoint i64 %355, 3
  %374 = getelementptr inbounds nuw float, ptr %4, i64 %373
  %375 = load float, ptr %374, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %376 = fadd float %375, %.pre9.pre.pre
  %377 = tail call float @llvm.maximum.f32(float %376, float 0.000000e+00)
  %378 = getelementptr inbounds nuw float, ptr %8, i64 %373
  store float %377, ptr %378, align 4, !alias.scope !11, !noalias !15
  %379 = add nuw nsw i64 %355, 4
  %380 = getelementptr inbounds nuw float, ptr %4, i64 %379
  %381 = load float, ptr %380, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %382 = fadd float %381, %.pre11.pre.pre
  %383 = tail call float @llvm.maximum.f32(float %382, float 0.000000e+00)
  %384 = getelementptr inbounds nuw float, ptr %8, i64 %379
  store float %383, ptr %384, align 4, !alias.scope !11, !noalias !15
  %385 = add nuw nsw i64 %355, 5
  %386 = getelementptr inbounds nuw float, ptr %4, i64 %385
  %387 = load float, ptr %386, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %388 = fadd float %387, %.pre13.pre.pre
  %389 = tail call float @llvm.maximum.f32(float %388, float 0.000000e+00)
  %390 = getelementptr inbounds nuw float, ptr %8, i64 %385
  store float %389, ptr %390, align 4, !alias.scope !11, !noalias !15
  %391 = add nuw nsw i64 %355, 6
  %392 = getelementptr inbounds nuw float, ptr %4, i64 %391
  %393 = load float, ptr %392, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %394 = fadd float %393, %.pre15.pre.pre
  %395 = tail call float @llvm.maximum.f32(float %394, float 0.000000e+00)
  %396 = getelementptr inbounds nuw float, ptr %8, i64 %391
  store float %395, ptr %396, align 4, !alias.scope !11, !noalias !15
  %397 = add nuw nsw i64 %355, 7
  %398 = getelementptr inbounds nuw float, ptr %4, i64 %397
  %399 = load float, ptr %398, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %400 = fadd float %399, %.pre17.pre.pre
  %401 = tail call float @llvm.maximum.f32(float %400, float 0.000000e+00)
  %402 = getelementptr inbounds nuw float, ptr %8, i64 %397
  store float %401, ptr %402, align 4, !alias.scope !11, !noalias !15
  %403 = add nuw nsw i64 %355, 8
  %404 = getelementptr inbounds nuw float, ptr %4, i64 %403
  %405 = load float, ptr %404, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %406 = fadd float %405, %.pre19.pre.pre
  %407 = tail call float @llvm.maximum.f32(float %406, float 0.000000e+00)
  %408 = getelementptr inbounds nuw float, ptr %8, i64 %403
  store float %407, ptr %408, align 4, !alias.scope !11, !noalias !15
  %409 = add nuw nsw i64 %355, 9
  %410 = getelementptr inbounds nuw float, ptr %4, i64 %409
  %411 = load float, ptr %410, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %412 = fadd float %411, %.pre21.pre.pre
  %413 = tail call float @llvm.maximum.f32(float %412, float 0.000000e+00)
  %414 = getelementptr inbounds nuw float, ptr %8, i64 %409
  store float %413, ptr %414, align 4, !alias.scope !11, !noalias !15
  %415 = add nuw nsw i64 %355, 10
  %416 = getelementptr inbounds nuw float, ptr %4, i64 %415
  %417 = load float, ptr %416, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %418 = fadd float %417, %.pre23.pre.pre
  %419 = tail call float @llvm.maximum.f32(float %418, float 0.000000e+00)
  %420 = getelementptr inbounds nuw float, ptr %8, i64 %415
  store float %419, ptr %420, align 4, !alias.scope !11, !noalias !15
  %421 = add nuw nsw i64 %355, 11
  %422 = getelementptr inbounds nuw float, ptr %4, i64 %421
  %423 = load float, ptr %422, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %424 = fadd float %423, %.pre25.pre.pre
  %425 = tail call float @llvm.maximum.f32(float %424, float 0.000000e+00)
  %426 = getelementptr inbounds nuw float, ptr %8, i64 %421
  store float %425, ptr %426, align 4, !alias.scope !11, !noalias !15
  %427 = add nuw nsw i64 %353, 1
  %exitcond.not = icmp eq i64 %427, 20
  br i1 %exitcond.not, label %428, label %scalar.ph, !llvm.loop !20

428:                                              ; preds = %scalar.ph
  %429 = add nuw nsw i64 %12, 1
  %exitcond4.not = icmp eq i64 %429, 20
  br i1 %exitcond4.not, label %430, label %vector.ph, !llvm.loop !21

430:                                              ; preds = %428
  %431 = add nuw nsw i64 %10, 1
  %exitcond5.not = icmp eq i64 %431, 3
  br i1 %exitcond5.not, label %add_maximum_fusion_wrapped.exit, label %9, !llvm.loop !21

add_maximum_fusion_wrapped.exit:                  ; preds = %430
  ret ptr null
}

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.maximum.f32(float, float) #1

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #2

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr>, <8 x i1>, <8 x float>) #3

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.maximum.v8f32(<8 x float>, <8 x float>) #4

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #4 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 0}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 57600}
!5 = !{i64 48}
!6 = !{!7}
!7 = distinct !{!7, !8, !"add_maximum_fusion_wrapped: argument 0"}
!8 = distinct !{!8, !"add_maximum_fusion_wrapped"}
!9 = !{!10}
!10 = distinct !{!10, !8, !"add_maximum_fusion_wrapped: argument 1"}
!11 = !{!12}
!12 = distinct !{!12, !8, !"add_maximum_fusion_wrapped: argument 2"}
!13 = !{!7, !12}
!14 = !{!10, !12}
!15 = !{!7, !10}
!16 = distinct !{!16, !17, !18, !19}
!17 = !{!"llvm.loop.unroll.disable"}
!18 = !{!"llvm.loop.isvectorized", i32 1}
!19 = !{!"llvm.loop.unroll.runtime.disable"}
!20 = distinct !{!20, !17, !18}
!21 = distinct !{!21, !17}
