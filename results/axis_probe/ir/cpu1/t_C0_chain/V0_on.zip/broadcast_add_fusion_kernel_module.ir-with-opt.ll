; ModuleID = '__compute_module_broadcast_add_fusion_kernel_module'
source_filename = "__compute_module_broadcast_add_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @broadcast_add_fusion(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !5
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !4
  tail call void @llvm.experimental.noalias.scope.decl(metadata !6)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !11)
  %.phi.trans.insert = getelementptr inbounds nuw i8, ptr %6, i64 12
  %9 = load <4 x float>, ptr %.phi.trans.insert, align 4
  %.phi.trans.insert6 = getelementptr inbounds nuw i8, ptr %6, i64 16
  %10 = load <4 x float>, ptr %.phi.trans.insert6, align 4
  %.phi.trans.insert8 = getelementptr inbounds nuw i8, ptr %6, i64 20
  %11 = load <4 x float>, ptr %.phi.trans.insert8, align 4
  %.phi.trans.insert10 = getelementptr inbounds nuw i8, ptr %6, i64 24
  %12 = load <4 x float>, ptr %.phi.trans.insert10, align 4
  %.phi.trans.insert12 = getelementptr inbounds nuw i8, ptr %6, i64 28
  %13 = load <4 x float>, ptr %.phi.trans.insert12, align 4
  %.phi.trans.insert14 = getelementptr inbounds nuw i8, ptr %6, i64 32
  %14 = load <4 x float>, ptr %.phi.trans.insert14, align 4
  %.phi.trans.insert16 = getelementptr inbounds nuw i8, ptr %6, i64 36
  %.pre17 = load float, ptr %.phi.trans.insert16, align 4, !invariant.load !3, !alias.scope !9, !noalias !13
  %.phi.trans.insert18 = getelementptr inbounds nuw i8, ptr %6, i64 8
  %15 = load <4 x float>, ptr %.phi.trans.insert18, align 4
  %16 = load <4 x float>, ptr %6, align 4
  %17 = getelementptr inbounds nuw i8, ptr %6, i64 4
  %18 = load <4 x float>, ptr %17, align 4
  %19 = getelementptr inbounds nuw i8, ptr %6, i64 40
  %20 = load float, ptr %19, align 4, !invariant.load !3, !alias.scope !9, !noalias !13
  %21 = getelementptr inbounds nuw i8, ptr %6, i64 44
  %22 = load float, ptr %21, align 4, !invariant.load !3, !alias.scope !9, !noalias !13
  %broadcast.splat22 = shufflevector <4 x float> %16, <4 x float> poison, <4 x i32> zeroinitializer
  %broadcast.splat24 = shufflevector <4 x float> %18, <4 x float> poison, <4 x i32> zeroinitializer
  %broadcast.splat26 = shufflevector <4 x float> %15, <4 x float> poison, <4 x i32> zeroinitializer
  %broadcast.splat28 = shufflevector <4 x float> %9, <4 x float> poison, <4 x i32> zeroinitializer
  %broadcast.splat30 = shufflevector <4 x float> %10, <4 x float> poison, <4 x i32> zeroinitializer
  %broadcast.splat32 = shufflevector <4 x float> %11, <4 x float> poison, <4 x i32> zeroinitializer
  %broadcast.splat34 = shufflevector <4 x float> %12, <4 x float> poison, <4 x i32> zeroinitializer
  %broadcast.splat36 = shufflevector <4 x float> %13, <4 x float> poison, <4 x i32> zeroinitializer
  %broadcast.splat38 = shufflevector <4 x float> %14, <4 x float> poison, <4 x i32> zeroinitializer
  %broadcast.splatinsert39 = insertelement <4 x float> poison, float %.pre17, i64 0
  %broadcast.splat40 = shufflevector <4 x float> %broadcast.splatinsert39, <4 x float> poison, <4 x i32> zeroinitializer
  %broadcast.splatinsert41 = insertelement <4 x float> poison, float %20, i64 0
  %broadcast.splat42 = shufflevector <4 x float> %broadcast.splatinsert41, <4 x float> poison, <4 x i32> zeroinitializer
  %broadcast.splatinsert43 = insertelement <4 x float> poison, float %22, i64 0
  %broadcast.splat44 = shufflevector <4 x float> %broadcast.splatinsert43, <4 x float> poison, <4 x i32> zeroinitializer
  br label %23

23:                                               ; preds = %1, %248
  %24 = phi i64 [ 0, %1 ], [ %249, %248 ]
  %25 = mul nuw nsw i64 %24, 4800
  br label %vector.ph

vector.ph:                                        ; preds = %middle.block, %23
  %26 = phi i64 [ 0, %23 ], [ %247, %middle.block ]
  %27 = mul nuw nsw i64 %26, 240
  %28 = add nuw nsw i64 %27, %25
  %broadcast.splatinsert = insertelement <4 x i64> poison, i64 %28, i64 0
  %broadcast.splat = shufflevector <4 x i64> %broadcast.splatinsert, <4 x i64> poison, <4 x i32> zeroinitializer
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %vector.ph
  %index = phi i64 [ 0, %vector.ph ], [ %index.next, %vector.body ]
  %vec.ind = phi <4 x i64> [ <i64 0, i64 1, i64 2, i64 3>, %vector.ph ], [ %vec.ind.next, %vector.body ]
  %29 = mul nuw nsw <4 x i64> %vec.ind, splat (i64 12)
  %30 = add nuw nsw <4 x i64> %broadcast.splat, %29
  %31 = extractelement <4 x i64> %30, i64 0
  %32 = extractelement <4 x i64> %30, i64 1
  %33 = extractelement <4 x i64> %30, i64 2
  %34 = extractelement <4 x i64> %30, i64 3
  %35 = getelementptr inbounds nuw float, ptr %4, <4 x i64> %30
  %wide.masked.gather = tail call <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr> align 4 %35, <4 x i1> splat (i1 true), <4 x float> poison), !invariant.load !3, !alias.scope !6, !noalias !14
  %36 = fadd <4 x float> %wide.masked.gather, %broadcast.splat22
  %37 = tail call <4 x float> @llvm.maximum.v4f32(<4 x float> %36, <4 x float> zeroinitializer)
  %38 = fmul <4 x float> %37, splat (float 7.500000e-01)
  %39 = fadd <4 x float> %38, splat (float 1.250000e-01)
  %40 = extractelement <4 x float> %39, i64 0
  %41 = extractelement <4 x float> %39, i64 1
  %42 = extractelement <4 x float> %39, i64 2
  %43 = extractelement <4 x float> %39, i64 3
  %44 = getelementptr inbounds nuw float, ptr %8, i64 %31
  %45 = getelementptr inbounds nuw float, ptr %8, i64 %32
  %46 = getelementptr inbounds nuw float, ptr %8, i64 %33
  %47 = getelementptr inbounds nuw float, ptr %8, i64 %34
  store float %40, ptr %44, align 4, !alias.scope !11, !noalias !15
  store float %41, ptr %45, align 4, !alias.scope !11, !noalias !15
  store float %42, ptr %46, align 4, !alias.scope !11, !noalias !15
  store float %43, ptr %47, align 4, !alias.scope !11, !noalias !15
  %48 = or disjoint <4 x i64> %30, splat (i64 1)
  %49 = extractelement <4 x i64> %48, i64 0
  %50 = extractelement <4 x i64> %48, i64 1
  %51 = extractelement <4 x i64> %48, i64 2
  %52 = extractelement <4 x i64> %48, i64 3
  %53 = getelementptr inbounds nuw float, ptr %4, <4 x i64> %48
  %wide.masked.gather45 = tail call <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr> align 4 %53, <4 x i1> splat (i1 true), <4 x float> poison), !invariant.load !3, !alias.scope !6, !noalias !14
  %54 = fadd <4 x float> %wide.masked.gather45, %broadcast.splat24
  %55 = tail call <4 x float> @llvm.maximum.v4f32(<4 x float> %54, <4 x float> zeroinitializer)
  %56 = fmul <4 x float> %55, splat (float 7.500000e-01)
  %57 = fadd <4 x float> %56, splat (float 1.250000e-01)
  %58 = extractelement <4 x float> %57, i64 0
  %59 = extractelement <4 x float> %57, i64 1
  %60 = extractelement <4 x float> %57, i64 2
  %61 = extractelement <4 x float> %57, i64 3
  %62 = getelementptr inbounds nuw float, ptr %8, i64 %49
  %63 = getelementptr inbounds nuw float, ptr %8, i64 %50
  %64 = getelementptr inbounds nuw float, ptr %8, i64 %51
  %65 = getelementptr inbounds nuw float, ptr %8, i64 %52
  store float %58, ptr %62, align 4, !alias.scope !11, !noalias !15
  store float %59, ptr %63, align 4, !alias.scope !11, !noalias !15
  store float %60, ptr %64, align 4, !alias.scope !11, !noalias !15
  store float %61, ptr %65, align 4, !alias.scope !11, !noalias !15
  %66 = or disjoint <4 x i64> %30, splat (i64 2)
  %67 = extractelement <4 x i64> %66, i64 0
  %68 = extractelement <4 x i64> %66, i64 1
  %69 = extractelement <4 x i64> %66, i64 2
  %70 = extractelement <4 x i64> %66, i64 3
  %71 = getelementptr inbounds nuw float, ptr %4, <4 x i64> %66
  %wide.masked.gather46 = tail call <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr> align 4 %71, <4 x i1> splat (i1 true), <4 x float> poison), !invariant.load !3, !alias.scope !6, !noalias !14
  %72 = fadd <4 x float> %wide.masked.gather46, %broadcast.splat26
  %73 = tail call <4 x float> @llvm.maximum.v4f32(<4 x float> %72, <4 x float> zeroinitializer)
  %74 = fmul <4 x float> %73, splat (float 7.500000e-01)
  %75 = fadd <4 x float> %74, splat (float 1.250000e-01)
  %76 = extractelement <4 x float> %75, i64 0
  %77 = extractelement <4 x float> %75, i64 1
  %78 = extractelement <4 x float> %75, i64 2
  %79 = extractelement <4 x float> %75, i64 3
  %80 = getelementptr inbounds nuw float, ptr %8, i64 %67
  %81 = getelementptr inbounds nuw float, ptr %8, i64 %68
  %82 = getelementptr inbounds nuw float, ptr %8, i64 %69
  %83 = getelementptr inbounds nuw float, ptr %8, i64 %70
  store float %76, ptr %80, align 4, !alias.scope !11, !noalias !15
  store float %77, ptr %81, align 4, !alias.scope !11, !noalias !15
  store float %78, ptr %82, align 4, !alias.scope !11, !noalias !15
  store float %79, ptr %83, align 4, !alias.scope !11, !noalias !15
  %84 = or disjoint <4 x i64> %30, splat (i64 3)
  %85 = extractelement <4 x i64> %84, i64 0
  %86 = extractelement <4 x i64> %84, i64 1
  %87 = extractelement <4 x i64> %84, i64 2
  %88 = extractelement <4 x i64> %84, i64 3
  %89 = getelementptr inbounds nuw float, ptr %4, <4 x i64> %84
  %wide.masked.gather47 = tail call <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr> align 4 %89, <4 x i1> splat (i1 true), <4 x float> poison), !invariant.load !3, !alias.scope !6, !noalias !14
  %90 = fadd <4 x float> %wide.masked.gather47, %broadcast.splat28
  %91 = tail call <4 x float> @llvm.maximum.v4f32(<4 x float> %90, <4 x float> zeroinitializer)
  %92 = fmul <4 x float> %91, splat (float 7.500000e-01)
  %93 = fadd <4 x float> %92, splat (float 1.250000e-01)
  %94 = extractelement <4 x float> %93, i64 0
  %95 = extractelement <4 x float> %93, i64 1
  %96 = extractelement <4 x float> %93, i64 2
  %97 = extractelement <4 x float> %93, i64 3
  %98 = getelementptr inbounds nuw float, ptr %8, i64 %85
  %99 = getelementptr inbounds nuw float, ptr %8, i64 %86
  %100 = getelementptr inbounds nuw float, ptr %8, i64 %87
  %101 = getelementptr inbounds nuw float, ptr %8, i64 %88
  store float %94, ptr %98, align 4, !alias.scope !11, !noalias !15
  store float %95, ptr %99, align 4, !alias.scope !11, !noalias !15
  store float %96, ptr %100, align 4, !alias.scope !11, !noalias !15
  store float %97, ptr %101, align 4, !alias.scope !11, !noalias !15
  %102 = add nuw nsw <4 x i64> %30, splat (i64 4)
  %103 = extractelement <4 x i64> %102, i64 0
  %104 = extractelement <4 x i64> %102, i64 1
  %105 = extractelement <4 x i64> %102, i64 2
  %106 = extractelement <4 x i64> %102, i64 3
  %107 = getelementptr inbounds nuw float, ptr %4, <4 x i64> %102
  %wide.masked.gather48 = tail call <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr> align 4 %107, <4 x i1> splat (i1 true), <4 x float> poison), !invariant.load !3, !alias.scope !6, !noalias !14
  %108 = fadd <4 x float> %wide.masked.gather48, %broadcast.splat30
  %109 = tail call <4 x float> @llvm.maximum.v4f32(<4 x float> %108, <4 x float> zeroinitializer)
  %110 = fmul <4 x float> %109, splat (float 7.500000e-01)
  %111 = fadd <4 x float> %110, splat (float 1.250000e-01)
  %112 = extractelement <4 x float> %111, i64 0
  %113 = extractelement <4 x float> %111, i64 1
  %114 = extractelement <4 x float> %111, i64 2
  %115 = extractelement <4 x float> %111, i64 3
  %116 = getelementptr inbounds nuw float, ptr %8, i64 %103
  %117 = getelementptr inbounds nuw float, ptr %8, i64 %104
  %118 = getelementptr inbounds nuw float, ptr %8, i64 %105
  %119 = getelementptr inbounds nuw float, ptr %8, i64 %106
  store float %112, ptr %116, align 4, !alias.scope !11, !noalias !15
  store float %113, ptr %117, align 4, !alias.scope !11, !noalias !15
  store float %114, ptr %118, align 4, !alias.scope !11, !noalias !15
  store float %115, ptr %119, align 4, !alias.scope !11, !noalias !15
  %120 = add nuw nsw <4 x i64> %30, splat (i64 5)
  %121 = extractelement <4 x i64> %120, i64 0
  %122 = extractelement <4 x i64> %120, i64 1
  %123 = extractelement <4 x i64> %120, i64 2
  %124 = extractelement <4 x i64> %120, i64 3
  %125 = getelementptr inbounds nuw float, ptr %4, <4 x i64> %120
  %wide.masked.gather49 = tail call <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr> align 4 %125, <4 x i1> splat (i1 true), <4 x float> poison), !invariant.load !3, !alias.scope !6, !noalias !14
  %126 = fadd <4 x float> %wide.masked.gather49, %broadcast.splat32
  %127 = tail call <4 x float> @llvm.maximum.v4f32(<4 x float> %126, <4 x float> zeroinitializer)
  %128 = fmul <4 x float> %127, splat (float 7.500000e-01)
  %129 = fadd <4 x float> %128, splat (float 1.250000e-01)
  %130 = extractelement <4 x float> %129, i64 0
  %131 = extractelement <4 x float> %129, i64 1
  %132 = extractelement <4 x float> %129, i64 2
  %133 = extractelement <4 x float> %129, i64 3
  %134 = getelementptr inbounds nuw float, ptr %8, i64 %121
  %135 = getelementptr inbounds nuw float, ptr %8, i64 %122
  %136 = getelementptr inbounds nuw float, ptr %8, i64 %123
  %137 = getelementptr inbounds nuw float, ptr %8, i64 %124
  store float %130, ptr %134, align 4, !alias.scope !11, !noalias !15
  store float %131, ptr %135, align 4, !alias.scope !11, !noalias !15
  store float %132, ptr %136, align 4, !alias.scope !11, !noalias !15
  store float %133, ptr %137, align 4, !alias.scope !11, !noalias !15
  %138 = add nuw nsw <4 x i64> %30, splat (i64 6)
  %139 = extractelement <4 x i64> %138, i64 0
  %140 = extractelement <4 x i64> %138, i64 1
  %141 = extractelement <4 x i64> %138, i64 2
  %142 = extractelement <4 x i64> %138, i64 3
  %143 = getelementptr inbounds nuw float, ptr %4, <4 x i64> %138
  %wide.masked.gather50 = tail call <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr> align 4 %143, <4 x i1> splat (i1 true), <4 x float> poison), !invariant.load !3, !alias.scope !6, !noalias !14
  %144 = fadd <4 x float> %wide.masked.gather50, %broadcast.splat34
  %145 = tail call <4 x float> @llvm.maximum.v4f32(<4 x float> %144, <4 x float> zeroinitializer)
  %146 = fmul <4 x float> %145, splat (float 7.500000e-01)
  %147 = fadd <4 x float> %146, splat (float 1.250000e-01)
  %148 = extractelement <4 x float> %147, i64 0
  %149 = extractelement <4 x float> %147, i64 1
  %150 = extractelement <4 x float> %147, i64 2
  %151 = extractelement <4 x float> %147, i64 3
  %152 = getelementptr inbounds nuw float, ptr %8, i64 %139
  %153 = getelementptr inbounds nuw float, ptr %8, i64 %140
  %154 = getelementptr inbounds nuw float, ptr %8, i64 %141
  %155 = getelementptr inbounds nuw float, ptr %8, i64 %142
  store float %148, ptr %152, align 4, !alias.scope !11, !noalias !15
  store float %149, ptr %153, align 4, !alias.scope !11, !noalias !15
  store float %150, ptr %154, align 4, !alias.scope !11, !noalias !15
  store float %151, ptr %155, align 4, !alias.scope !11, !noalias !15
  %156 = add nuw nsw <4 x i64> %30, splat (i64 7)
  %157 = extractelement <4 x i64> %156, i64 0
  %158 = extractelement <4 x i64> %156, i64 1
  %159 = extractelement <4 x i64> %156, i64 2
  %160 = extractelement <4 x i64> %156, i64 3
  %161 = getelementptr inbounds nuw float, ptr %4, <4 x i64> %156
  %wide.masked.gather51 = tail call <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr> align 4 %161, <4 x i1> splat (i1 true), <4 x float> poison), !invariant.load !3, !alias.scope !6, !noalias !14
  %162 = fadd <4 x float> %wide.masked.gather51, %broadcast.splat36
  %163 = tail call <4 x float> @llvm.maximum.v4f32(<4 x float> %162, <4 x float> zeroinitializer)
  %164 = fmul <4 x float> %163, splat (float 7.500000e-01)
  %165 = fadd <4 x float> %164, splat (float 1.250000e-01)
  %166 = extractelement <4 x float> %165, i64 0
  %167 = extractelement <4 x float> %165, i64 1
  %168 = extractelement <4 x float> %165, i64 2
  %169 = extractelement <4 x float> %165, i64 3
  %170 = getelementptr inbounds nuw float, ptr %8, i64 %157
  %171 = getelementptr inbounds nuw float, ptr %8, i64 %158
  %172 = getelementptr inbounds nuw float, ptr %8, i64 %159
  %173 = getelementptr inbounds nuw float, ptr %8, i64 %160
  store float %166, ptr %170, align 4, !alias.scope !11, !noalias !15
  store float %167, ptr %171, align 4, !alias.scope !11, !noalias !15
  store float %168, ptr %172, align 4, !alias.scope !11, !noalias !15
  store float %169, ptr %173, align 4, !alias.scope !11, !noalias !15
  %174 = add nuw nsw <4 x i64> %30, splat (i64 8)
  %175 = extractelement <4 x i64> %174, i64 0
  %176 = extractelement <4 x i64> %174, i64 1
  %177 = extractelement <4 x i64> %174, i64 2
  %178 = extractelement <4 x i64> %174, i64 3
  %179 = getelementptr inbounds nuw float, ptr %4, <4 x i64> %174
  %wide.masked.gather52 = tail call <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr> align 4 %179, <4 x i1> splat (i1 true), <4 x float> poison), !invariant.load !3, !alias.scope !6, !noalias !14
  %180 = fadd <4 x float> %wide.masked.gather52, %broadcast.splat38
  %181 = tail call <4 x float> @llvm.maximum.v4f32(<4 x float> %180, <4 x float> zeroinitializer)
  %182 = fmul <4 x float> %181, splat (float 7.500000e-01)
  %183 = fadd <4 x float> %182, splat (float 1.250000e-01)
  %184 = extractelement <4 x float> %183, i64 0
  %185 = extractelement <4 x float> %183, i64 1
  %186 = extractelement <4 x float> %183, i64 2
  %187 = extractelement <4 x float> %183, i64 3
  %188 = getelementptr inbounds nuw float, ptr %8, i64 %175
  %189 = getelementptr inbounds nuw float, ptr %8, i64 %176
  %190 = getelementptr inbounds nuw float, ptr %8, i64 %177
  %191 = getelementptr inbounds nuw float, ptr %8, i64 %178
  store float %184, ptr %188, align 4, !alias.scope !11, !noalias !15
  store float %185, ptr %189, align 4, !alias.scope !11, !noalias !15
  store float %186, ptr %190, align 4, !alias.scope !11, !noalias !15
  store float %187, ptr %191, align 4, !alias.scope !11, !noalias !15
  %192 = add nuw nsw <4 x i64> %30, splat (i64 9)
  %193 = extractelement <4 x i64> %192, i64 0
  %194 = extractelement <4 x i64> %192, i64 1
  %195 = extractelement <4 x i64> %192, i64 2
  %196 = extractelement <4 x i64> %192, i64 3
  %197 = getelementptr inbounds nuw float, ptr %4, <4 x i64> %192
  %wide.masked.gather53 = tail call <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr> align 4 %197, <4 x i1> splat (i1 true), <4 x float> poison), !invariant.load !3, !alias.scope !6, !noalias !14
  %198 = fadd <4 x float> %wide.masked.gather53, %broadcast.splat40
  %199 = tail call <4 x float> @llvm.maximum.v4f32(<4 x float> %198, <4 x float> zeroinitializer)
  %200 = fmul <4 x float> %199, splat (float 7.500000e-01)
  %201 = fadd <4 x float> %200, splat (float 1.250000e-01)
  %202 = extractelement <4 x float> %201, i64 0
  %203 = extractelement <4 x float> %201, i64 1
  %204 = extractelement <4 x float> %201, i64 2
  %205 = extractelement <4 x float> %201, i64 3
  %206 = getelementptr inbounds nuw float, ptr %8, i64 %193
  %207 = getelementptr inbounds nuw float, ptr %8, i64 %194
  %208 = getelementptr inbounds nuw float, ptr %8, i64 %195
  %209 = getelementptr inbounds nuw float, ptr %8, i64 %196
  store float %202, ptr %206, align 4, !alias.scope !11, !noalias !15
  store float %203, ptr %207, align 4, !alias.scope !11, !noalias !15
  store float %204, ptr %208, align 4, !alias.scope !11, !noalias !15
  store float %205, ptr %209, align 4, !alias.scope !11, !noalias !15
  %210 = add nuw nsw <4 x i64> %30, splat (i64 10)
  %211 = extractelement <4 x i64> %210, i64 0
  %212 = extractelement <4 x i64> %210, i64 1
  %213 = extractelement <4 x i64> %210, i64 2
  %214 = extractelement <4 x i64> %210, i64 3
  %215 = getelementptr inbounds nuw float, ptr %4, <4 x i64> %210
  %wide.masked.gather54 = tail call <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr> align 4 %215, <4 x i1> splat (i1 true), <4 x float> poison), !invariant.load !3, !alias.scope !6, !noalias !14
  %216 = fadd <4 x float> %wide.masked.gather54, %broadcast.splat42
  %217 = tail call <4 x float> @llvm.maximum.v4f32(<4 x float> %216, <4 x float> zeroinitializer)
  %218 = fmul <4 x float> %217, splat (float 7.500000e-01)
  %219 = fadd <4 x float> %218, splat (float 1.250000e-01)
  %220 = extractelement <4 x float> %219, i64 0
  %221 = extractelement <4 x float> %219, i64 1
  %222 = extractelement <4 x float> %219, i64 2
  %223 = extractelement <4 x float> %219, i64 3
  %224 = getelementptr inbounds nuw float, ptr %8, i64 %211
  %225 = getelementptr inbounds nuw float, ptr %8, i64 %212
  %226 = getelementptr inbounds nuw float, ptr %8, i64 %213
  %227 = getelementptr inbounds nuw float, ptr %8, i64 %214
  store float %220, ptr %224, align 4, !alias.scope !11, !noalias !15
  store float %221, ptr %225, align 4, !alias.scope !11, !noalias !15
  store float %222, ptr %226, align 4, !alias.scope !11, !noalias !15
  store float %223, ptr %227, align 4, !alias.scope !11, !noalias !15
  %228 = add nuw nsw <4 x i64> %30, splat (i64 11)
  %229 = extractelement <4 x i64> %228, i64 0
  %230 = extractelement <4 x i64> %228, i64 1
  %231 = extractelement <4 x i64> %228, i64 2
  %232 = extractelement <4 x i64> %228, i64 3
  %233 = getelementptr inbounds nuw float, ptr %4, <4 x i64> %228
  %wide.masked.gather55 = tail call <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr> align 4 %233, <4 x i1> splat (i1 true), <4 x float> poison), !invariant.load !3, !alias.scope !6, !noalias !14
  %234 = fadd <4 x float> %wide.masked.gather55, %broadcast.splat44
  %235 = tail call <4 x float> @llvm.maximum.v4f32(<4 x float> %234, <4 x float> zeroinitializer)
  %236 = fmul <4 x float> %235, splat (float 7.500000e-01)
  %237 = fadd <4 x float> %236, splat (float 1.250000e-01)
  %238 = extractelement <4 x float> %237, i64 0
  %239 = extractelement <4 x float> %237, i64 1
  %240 = extractelement <4 x float> %237, i64 2
  %241 = extractelement <4 x float> %237, i64 3
  %242 = getelementptr inbounds nuw float, ptr %8, i64 %229
  %243 = getelementptr inbounds nuw float, ptr %8, i64 %230
  %244 = getelementptr inbounds nuw float, ptr %8, i64 %231
  %245 = getelementptr inbounds nuw float, ptr %8, i64 %232
  store float %238, ptr %242, align 4, !alias.scope !11, !noalias !15
  store float %239, ptr %243, align 4, !alias.scope !11, !noalias !15
  store float %240, ptr %244, align 4, !alias.scope !11, !noalias !15
  store float %241, ptr %245, align 4, !alias.scope !11, !noalias !15
  %index.next = add nuw i64 %index, 4
  %vec.ind.next = add nuw nsw <4 x i64> %vec.ind, splat (i64 4)
  %246 = icmp eq i64 %index.next, 20
  br i1 %246, label %middle.block, label %vector.body, !llvm.loop !16

middle.block:                                     ; preds = %vector.body
  %247 = add nuw nsw i64 %26, 1
  %exitcond4.not = icmp eq i64 %247, 20
  br i1 %exitcond4.not, label %248, label %vector.ph, !llvm.loop !20

248:                                              ; preds = %middle.block
  %249 = add nuw nsw i64 %24, 1
  %exitcond5.not = icmp eq i64 %249, 3
  br i1 %exitcond5.not, label %broadcast_add_fusion_wrapped.exit, label %23, !llvm.loop !20

broadcast_add_fusion_wrapped.exit:                ; preds = %248
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <4 x float> @llvm.masked.gather.v4f32.v4p0(<4 x ptr>, <4 x i1>, <4 x float>) #2

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <4 x float> @llvm.maximum.v4f32(<4 x float>, <4 x float>) #3

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #3 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 1}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 57600}
!5 = !{i64 48}
!6 = !{!7}
!7 = distinct !{!7, !8, !"broadcast_add_fusion_wrapped: argument 0"}
!8 = distinct !{!8, !"broadcast_add_fusion_wrapped"}
!9 = !{!10}
!10 = distinct !{!10, !8, !"broadcast_add_fusion_wrapped: argument 1"}
!11 = !{!12}
!12 = distinct !{!12, !8, !"broadcast_add_fusion_wrapped: argument 2"}
!13 = !{!7, !12}
!14 = !{!10, !12}
!15 = !{!7, !10}
!16 = distinct !{!16, !17, !18, !19}
!17 = !{!"llvm.loop.unroll.disable"}
!18 = !{!"llvm.loop.isvectorized", i32 1}
!19 = !{!"llvm.loop.unroll.runtime.disable"}
!20 = distinct !{!20, !17}
