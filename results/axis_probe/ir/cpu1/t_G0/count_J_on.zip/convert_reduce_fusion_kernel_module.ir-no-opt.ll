; ModuleID = '__compute_module_convert_reduce_fusion_kernel_module'
source_filename = "__compute_module_convert_reduce_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

%XLA_CPU_KernelCallFrame = type { ptr, ptr, i64, ptr }
%XLA_CPU_KernelArg = type { ptr, i64 }
%kernel_dim3 = type { i64, i64, i64 }

; Function Attrs: uwtable
define ptr @convert_reduce_fusion(ptr %0) #0 {
  %2 = getelementptr inbounds %XLA_CPU_KernelCallFrame, ptr %0, i32 0, i32 3
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 0, i32 0
  %5 = load ptr, ptr %4, align 8, !invariant.load !3, !dereferenceable !4
  %6 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 1, i32 0
  %7 = load ptr, ptr %6, align 8, !invariant.load !3, !dereferenceable !4
  %8 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 2, i32 0
  %9 = load ptr, ptr %8, align 8, !invariant.load !3, !dereferenceable !5
  %10 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 3, i32 0
  %11 = load ptr, ptr %10, align 8, !invariant.load !3, !dereferenceable !6
  %12 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 4, i32 0
  %13 = load ptr, ptr %12, align 8, !invariant.load !3, !dereferenceable !6
  %14 = getelementptr inbounds %XLA_CPU_KernelCallFrame, ptr %0, i32 0, i32 1
  %15 = load ptr, ptr %14, align 8
  %16 = getelementptr inbounds %kernel_dim3, ptr %15, i32 0, i32 0
  %17 = load i64, ptr %16, align 4, !invariant.load !3
  %18 = getelementptr inbounds %kernel_dim3, ptr %15, i32 0, i32 1
  %19 = load i64, ptr %18, align 4, !invariant.load !3
  %20 = getelementptr inbounds %kernel_dim3, ptr %15, i32 0, i32 2
  %21 = load i64, ptr %20, align 4, !invariant.load !3
  call void @convert_reduce_fusion_wrapped(ptr %5, ptr %7, ptr %9, ptr %11, ptr %13, i64 %17, i64 %19, i64 %21)
  ret ptr null
}

; Function Attrs: alwaysinline
define internal void @convert_reduce_fusion_wrapped(ptr noalias align 64 dereferenceable(23040) %0, ptr noalias align 64 dereferenceable(23040) %1, ptr noalias align 64 dereferenceable(576) %2, ptr noalias align 64 dereferenceable(4) %3, ptr noalias align 64 dereferenceable(4) %4, i64 %5, i64 %6, i64 %7) #1 {
  br label %9

9:                                                ; preds = %37, %8
  %10 = phi i64 [ %38, %37 ], [ 0, %8 ]
  %11 = phi i32 [ %18, %37 ], [ 0, %8 ]
  %12 = phi i32 [ %19, %37 ], [ 0, %8 ]
  %13 = icmp slt i64 %10, 40
  br i1 %13, label %14, label %39

14:                                               ; preds = %9
  %15 = mul nsw i64 %10, 144
  br label %16

16:                                               ; preds = %21, %14
  %17 = phi i64 [ %36, %21 ], [ 0, %14 ]
  %18 = phi i32 [ %34, %21 ], [ %11, %14 ]
  %19 = phi i32 [ %35, %21 ], [ %12, %14 ]
  %20 = icmp slt i64 %17, 144
  br i1 %20, label %21, label %37

21:                                               ; preds = %16
  %22 = add nsw i64 %15, %17
  %23 = getelementptr inbounds [5760 x float], ptr %1, i32 0, i64 %22
  %24 = load float, ptr %23, align 4, !invariant.load !3
  %25 = getelementptr inbounds [144 x float], ptr %2, i32 0, i64 %17
  %26 = load float, ptr %25, align 4, !invariant.load !3
  %27 = fadd float %24, %26
  %28 = fcmp ogt float %27, 0.000000e+00
  %29 = zext i1 %28 to i32
  %30 = getelementptr inbounds [5760 x float], ptr %0, i32 0, i64 %22
  %31 = load float, ptr %30, align 4, !invariant.load !3
  %32 = fcmp ogt float %31, 0.000000e+00
  %33 = zext i1 %32 to i32
  %34 = add i32 %18, %29
  %35 = add i32 %19, %33
  %36 = add i64 %17, 1
  br label %16

37:                                               ; preds = %16
  %38 = add i64 %10, 1
  br label %9, !llvm.loop !7

39:                                               ; preds = %9
  %40 = getelementptr inbounds [1 x i32], ptr %3, i32 0, i32 0
  store i32 %11, ptr %40, align 4
  %41 = getelementptr inbounds [1 x i32], ptr %4, i32 0, i32 0
  store i32 %12, ptr %41, align 4
  ret void
}

attributes #0 = { uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { alwaysinline }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 2}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 23040}
!5 = !{i64 576}
!6 = !{i64 4}
!7 = distinct !{!7, !8}
!8 = !{!"llvm.loop.unroll.disable"}
