; ModuleID = '__compute_module_compare_convert_fusion.1_kernel_module'
source_filename = "__compute_module_compare_convert_fusion.1_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @compare_convert_fusion.1(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !5
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !4
  tail call void @llvm.experimental.noalias.scope.decl(metadata !6)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !11)
  %9 = getelementptr inbounds nuw i8, ptr %6, i64 32
  %wide.load4 = load <8 x float>, ptr %6, align 4, !invariant.load !3, !alias.scope !9, !noalias !13
  %wide.load5 = load <8 x float>, ptr %9, align 4, !invariant.load !3, !alias.scope !9, !noalias !13
  %10 = getelementptr inbounds nuw i8, ptr %6, i64 64
  %11 = getelementptr inbounds nuw i8, ptr %6, i64 96
  %wide.load4.1 = load <8 x float>, ptr %10, align 4, !invariant.load !3, !alias.scope !9, !noalias !13
  %wide.load5.1 = load <8 x float>, ptr %11, align 4, !invariant.load !3, !alias.scope !9, !noalias !13
  %12 = getelementptr inbounds nuw i8, ptr %6, i64 128
  %13 = getelementptr inbounds nuw i8, ptr %6, i64 160
  %wide.load4.2 = load <8 x float>, ptr %12, align 4, !invariant.load !3, !alias.scope !9, !noalias !13
  %wide.load5.2 = load <8 x float>, ptr %13, align 4, !invariant.load !3, !alias.scope !9, !noalias !13
  %14 = getelementptr inbounds nuw i8, ptr %6, i64 192
  %15 = getelementptr inbounds nuw i8, ptr %6, i64 224
  %wide.load4.3 = load <8 x float>, ptr %14, align 4, !invariant.load !3, !alias.scope !9, !noalias !13
  %wide.load5.3 = load <8 x float>, ptr %15, align 4, !invariant.load !3, !alias.scope !9, !noalias !13
  %16 = getelementptr inbounds nuw i8, ptr %6, i64 256
  %17 = getelementptr inbounds nuw i8, ptr %6, i64 288
  %wide.load4.4 = load <8 x float>, ptr %16, align 4, !invariant.load !3, !alias.scope !9, !noalias !13
  %wide.load5.4 = load <8 x float>, ptr %17, align 4, !invariant.load !3, !alias.scope !9, !noalias !13
  br label %vector.ph

vector.ph:                                        ; preds = %1, %vector.ph
  %18 = phi i64 [ 0, %1 ], [ %74, %vector.ph ]
  %19 = mul nuw nsw i64 %18, 80
  %20 = getelementptr inbounds nuw float, ptr %4, i64 %19
  %21 = getelementptr inbounds nuw i8, ptr %20, i64 32
  %wide.load = load <8 x float>, ptr %20, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %wide.load3 = load <8 x float>, ptr %21, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %22 = fadd <8 x float> %wide.load, %wide.load4
  %23 = fadd <8 x float> %wide.load3, %wide.load5
  %24 = fcmp ogt <8 x float> %22, zeroinitializer
  %25 = fcmp ogt <8 x float> %23, zeroinitializer
  %26 = zext <8 x i1> %24 to <8 x i32>
  %27 = zext <8 x i1> %25 to <8 x i32>
  %28 = getelementptr inbounds nuw i32, ptr %8, i64 %19
  %29 = getelementptr inbounds nuw i8, ptr %28, i64 32
  store <8 x i32> %26, ptr %28, align 4, !alias.scope !11, !noalias !15
  store <8 x i32> %27, ptr %29, align 4, !alias.scope !11, !noalias !15
  %30 = add nuw nsw i64 %19, 16
  %31 = getelementptr inbounds nuw float, ptr %4, i64 %30
  %32 = getelementptr inbounds nuw i8, ptr %31, i64 32
  %wide.load.1 = load <8 x float>, ptr %31, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %wide.load3.1 = load <8 x float>, ptr %32, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %33 = fadd <8 x float> %wide.load.1, %wide.load4.1
  %34 = fadd <8 x float> %wide.load3.1, %wide.load5.1
  %35 = fcmp ogt <8 x float> %33, zeroinitializer
  %36 = fcmp ogt <8 x float> %34, zeroinitializer
  %37 = zext <8 x i1> %35 to <8 x i32>
  %38 = zext <8 x i1> %36 to <8 x i32>
  %39 = getelementptr inbounds nuw i32, ptr %8, i64 %30
  %40 = getelementptr inbounds nuw i8, ptr %39, i64 32
  store <8 x i32> %37, ptr %39, align 4, !alias.scope !11, !noalias !15
  store <8 x i32> %38, ptr %40, align 4, !alias.scope !11, !noalias !15
  %41 = add nuw nsw i64 %19, 32
  %42 = getelementptr inbounds nuw float, ptr %4, i64 %41
  %43 = getelementptr inbounds nuw i8, ptr %42, i64 32
  %wide.load.2 = load <8 x float>, ptr %42, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %wide.load3.2 = load <8 x float>, ptr %43, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %44 = fadd <8 x float> %wide.load.2, %wide.load4.2
  %45 = fadd <8 x float> %wide.load3.2, %wide.load5.2
  %46 = fcmp ogt <8 x float> %44, zeroinitializer
  %47 = fcmp ogt <8 x float> %45, zeroinitializer
  %48 = zext <8 x i1> %46 to <8 x i32>
  %49 = zext <8 x i1> %47 to <8 x i32>
  %50 = getelementptr inbounds nuw i32, ptr %8, i64 %41
  %51 = getelementptr inbounds nuw i8, ptr %50, i64 32
  store <8 x i32> %48, ptr %50, align 4, !alias.scope !11, !noalias !15
  store <8 x i32> %49, ptr %51, align 4, !alias.scope !11, !noalias !15
  %52 = add nuw nsw i64 %19, 48
  %53 = getelementptr inbounds nuw float, ptr %4, i64 %52
  %54 = getelementptr inbounds nuw i8, ptr %53, i64 32
  %wide.load.3 = load <8 x float>, ptr %53, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %wide.load3.3 = load <8 x float>, ptr %54, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %55 = fadd <8 x float> %wide.load.3, %wide.load4.3
  %56 = fadd <8 x float> %wide.load3.3, %wide.load5.3
  %57 = fcmp ogt <8 x float> %55, zeroinitializer
  %58 = fcmp ogt <8 x float> %56, zeroinitializer
  %59 = zext <8 x i1> %57 to <8 x i32>
  %60 = zext <8 x i1> %58 to <8 x i32>
  %61 = getelementptr inbounds nuw i32, ptr %8, i64 %52
  %62 = getelementptr inbounds nuw i8, ptr %61, i64 32
  store <8 x i32> %59, ptr %61, align 4, !alias.scope !11, !noalias !15
  store <8 x i32> %60, ptr %62, align 4, !alias.scope !11, !noalias !15
  %63 = add nuw nsw i64 %19, 64
  %64 = getelementptr inbounds nuw float, ptr %4, i64 %63
  %65 = getelementptr inbounds nuw i8, ptr %64, i64 32
  %wide.load.4 = load <8 x float>, ptr %64, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %wide.load3.4 = load <8 x float>, ptr %65, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %66 = fadd <8 x float> %wide.load.4, %wide.load4.4
  %67 = fadd <8 x float> %wide.load3.4, %wide.load5.4
  %68 = fcmp ogt <8 x float> %66, zeroinitializer
  %69 = fcmp ogt <8 x float> %67, zeroinitializer
  %70 = zext <8 x i1> %68 to <8 x i32>
  %71 = zext <8 x i1> %69 to <8 x i32>
  %72 = getelementptr inbounds nuw i32, ptr %8, i64 %63
  %73 = getelementptr inbounds nuw i8, ptr %72, i64 32
  store <8 x i32> %70, ptr %72, align 4, !alias.scope !11, !noalias !15
  store <8 x i32> %71, ptr %73, align 4, !alias.scope !11, !noalias !15
  %74 = add nuw nsw i64 %18, 1
  %exitcond2.not = icmp eq i64 %74, 48
  br i1 %exitcond2.not, label %compare_convert_fusion.1_wrapped.exit, label %vector.ph, !llvm.loop !16

compare_convert_fusion.1_wrapped.exit:            ; preds = %vector.ph
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 2}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 15360}
!5 = !{i64 320}
!6 = !{!7}
!7 = distinct !{!7, !8, !"compare_convert_fusion.1_wrapped: argument 0"}
!8 = distinct !{!8, !"compare_convert_fusion.1_wrapped"}
!9 = !{!10}
!10 = distinct !{!10, !8, !"compare_convert_fusion.1_wrapped: argument 1"}
!11 = !{!12}
!12 = distinct !{!12, !8, !"compare_convert_fusion.1_wrapped: argument 2"}
!13 = !{!7, !12}
!14 = !{!10, !12}
!15 = !{!7, !10}
!16 = distinct !{!16, !17}
!17 = !{!"llvm.loop.unroll.disable"}
