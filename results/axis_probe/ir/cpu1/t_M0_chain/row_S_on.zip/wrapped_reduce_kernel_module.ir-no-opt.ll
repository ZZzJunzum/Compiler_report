; ModuleID = '__compute_module_wrapped_reduce_kernel_module'
source_filename = "__compute_module_wrapped_reduce_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

%XLA_CPU_KernelCallFrame = type { ptr, ptr, i64, ptr }
%XLA_CPU_KernelArg = type { ptr, i64 }
%kernel_dim3 = type { i64, i64, i64 }

; Function Attrs: uwtable
define ptr @wrapped_reduce(ptr %0) #0 {
  %2 = getelementptr inbounds %XLA_CPU_KernelCallFrame, ptr %0, i32 0, i32 3
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 0, i32 0
  %5 = load ptr, ptr %4, align 8, !invariant.load !3, !dereferenceable !4
  %6 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 1, i32 0
  %7 = load ptr, ptr %6, align 8, !invariant.load !3, !dereferenceable !5
  %8 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 2, i32 0
  %9 = load ptr, ptr %8, align 8, !invariant.load !3, !dereferenceable !6
  %10 = getelementptr inbounds %XLA_CPU_KernelCallFrame, ptr %0, i32 0, i32 1
  %11 = load ptr, ptr %10, align 8
  %12 = getelementptr inbounds %kernel_dim3, ptr %11, i32 0, i32 0
  %13 = load i64, ptr %12, align 4, !invariant.load !3
  %14 = getelementptr inbounds %kernel_dim3, ptr %11, i32 0, i32 1
  %15 = load i64, ptr %14, align 4, !invariant.load !3
  %16 = getelementptr inbounds %kernel_dim3, ptr %11, i32 0, i32 2
  %17 = load i64, ptr %16, align 4, !invariant.load !3
  call void @wrapped_reduce_wrapped(ptr %5, ptr %7, ptr %9, i64 %13, i64 %15, i64 %17)
  ret ptr null
}

; Function Attrs: alwaysinline
define internal void @wrapped_reduce_wrapped(ptr noalias align 64 dereferenceable(576) %0, ptr noalias align 64 dereferenceable(4) %1, ptr noalias align 64 dereferenceable(192) %2, i64 %3, i64 %4, i64 %5) #1 {
  %7 = getelementptr inbounds [1 x i32], ptr %1, i32 0, i32 0
  %8 = load i32, ptr %7, align 4, !invariant.load !3
  br label %9

9:                                                ; preds = %24, %6
  %10 = phi i64 [ %26, %24 ], [ 0, %6 ]
  %11 = icmp slt i64 %10, 48
  br i1 %11, label %12, label %27

12:                                               ; preds = %9
  %13 = mul nsw i64 %10, 3
  br label %14

14:                                               ; preds = %18, %12
  %15 = phi i64 [ %23, %18 ], [ 0, %12 ]
  %16 = phi i32 [ %22, %18 ], [ %8, %12 ]
  %17 = icmp slt i64 %15, 3
  br i1 %17, label %18, label %24

18:                                               ; preds = %14
  %19 = add nsw i64 %13, %15
  %20 = getelementptr inbounds [144 x i32], ptr %0, i32 0, i64 %19
  %21 = load i32, ptr %20, align 4, !invariant.load !3
  %22 = add i32 %16, %21
  %23 = add i64 %15, 1
  br label %14

24:                                               ; preds = %14
  %25 = getelementptr inbounds [48 x i32], ptr %2, i32 0, i64 %10
  store i32 %16, ptr %25, align 4
  %26 = add i64 %10, 1
  br label %9, !llvm.loop !7

27:                                               ; preds = %9
  ret void
}

attributes #0 = { uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { alwaysinline }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 3}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 576}
!5 = !{i64 4}
!6 = !{i64 192}
!7 = distinct !{!7, !8}
!8 = !{!"llvm.loop.unroll.disable"}
