; ModuleID = '__compute_module_wrapped_reduce-window_kernel_module'
source_filename = "__compute_module_wrapped_reduce-window_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @wrapped_reduce-window(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !5
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !6
  tail call void @llvm.experimental.noalias.scope.decl(metadata !7)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !10)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !12)
  %9 = load i32, ptr %6, align 4, !invariant.load !3, !alias.scope !10, !noalias !14
  br label %.preheader

.preheader:                                       ; preds = %1, %117
  %10 = phi i64 [ 0, %1 ], [ %118, %117 ]
  %.idx1 = mul nuw nsw i64 %10, 320
  %invariant.gep3 = getelementptr i8, ptr %4, i64 %.idx1
  %.idx = mul nuw nsw i64 %10, 12
  %11 = getelementptr i8, ptr %8, i64 %.idx
  br label %12

12:                                               ; preds = %.preheader, %113
  %13 = phi i64 [ 0, %.preheader ], [ %116, %113 ]
  %gep4.idx = shl i64 %13, 7
  %gep4 = getelementptr i8, ptr %invariant.gep3, i64 %gep4.idx
  %.not = icmp eq i64 %13, 0
  br i1 %.not, label %.thread40, label %14

14:                                               ; preds = %12
  %15 = getelementptr i8, ptr %gep4, i64 -32
  %16 = load i32, ptr %15, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %17 = add i32 %16, %9
  %18 = getelementptr i8, ptr %gep4, i64 -28
  %19 = load i32, ptr %18, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %20 = add i32 %19, %17
  %21 = getelementptr i8, ptr %gep4, i64 -24
  %22 = load i32, ptr %21, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %23 = add i32 %22, %20
  %24 = getelementptr i8, ptr %gep4, i64 -20
  %25 = load i32, ptr %24, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %26 = add i32 %25, %23
  %27 = getelementptr i8, ptr %gep4, i64 -16
  %28 = load i32, ptr %27, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %29 = add i32 %28, %26
  %30 = getelementptr i8, ptr %gep4, i64 -12
  %31 = load i32, ptr %30, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %32 = add i32 %31, %29
  %33 = getelementptr i8, ptr %gep4, i64 -8
  %34 = load i32, ptr %33, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %35 = add i32 %34, %32
  %36 = getelementptr i8, ptr %gep4, i64 -4
  %37 = load i32, ptr %36, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %38 = add i32 %37, %35
  br label %.thread40

.thread40:                                        ; preds = %12, %14
  %39 = phi i32 [ %38, %14 ], [ %9, %12 ]
  %40 = load i32, ptr %gep4, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %41 = add i32 %40, %39
  %42 = getelementptr i8, ptr %gep4, i64 4
  %43 = load i32, ptr %42, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %44 = add i32 %43, %41
  %45 = getelementptr i8, ptr %gep4, i64 8
  %46 = load i32, ptr %45, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %47 = add i32 %46, %44
  %48 = getelementptr i8, ptr %gep4, i64 12
  %49 = load i32, ptr %48, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %50 = add i32 %49, %47
  %51 = getelementptr i8, ptr %gep4, i64 16
  %52 = load i32, ptr %51, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %53 = add i32 %52, %50
  %54 = getelementptr i8, ptr %gep4, i64 20
  %55 = load i32, ptr %54, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %56 = add i32 %55, %53
  %57 = getelementptr i8, ptr %gep4, i64 24
  %58 = load i32, ptr %57, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %59 = add i32 %58, %56
  %60 = getelementptr i8, ptr %gep4, i64 28
  %61 = load i32, ptr %60, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %62 = add i32 %61, %59
  %63 = getelementptr i8, ptr %gep4, i64 32
  %64 = load i32, ptr %63, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %65 = add i32 %64, %62
  %66 = getelementptr i8, ptr %gep4, i64 36
  %67 = load i32, ptr %66, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %68 = add i32 %67, %65
  %69 = getelementptr i8, ptr %gep4, i64 40
  %70 = load i32, ptr %69, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %71 = add i32 %70, %68
  %72 = getelementptr i8, ptr %gep4, i64 44
  %73 = load i32, ptr %72, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %74 = add i32 %73, %71
  %75 = getelementptr i8, ptr %gep4, i64 48
  %76 = load i32, ptr %75, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %77 = add i32 %76, %74
  %78 = getelementptr i8, ptr %gep4, i64 52
  %79 = load i32, ptr %78, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %80 = add i32 %79, %77
  %81 = getelementptr i8, ptr %gep4, i64 56
  %82 = load i32, ptr %81, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %83 = add i32 %82, %80
  %84 = getelementptr i8, ptr %gep4, i64 60
  %85 = load i32, ptr %84, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %86 = add i32 %85, %83
  %87 = icmp samesign ult i64 %13, 2
  br i1 %87, label %88, label %113

88:                                               ; preds = %.thread40
  %89 = getelementptr i8, ptr %gep4, i64 64
  %90 = load i32, ptr %89, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %91 = add i32 %90, %86
  %92 = getelementptr i8, ptr %gep4, i64 68
  %93 = load i32, ptr %92, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %94 = add i32 %93, %91
  %95 = getelementptr i8, ptr %gep4, i64 72
  %96 = load i32, ptr %95, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %97 = add i32 %96, %94
  %98 = getelementptr i8, ptr %gep4, i64 76
  %99 = load i32, ptr %98, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %100 = add i32 %99, %97
  %101 = getelementptr i8, ptr %gep4, i64 80
  %102 = load i32, ptr %101, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %103 = add i32 %102, %100
  %104 = getelementptr i8, ptr %gep4, i64 84
  %105 = load i32, ptr %104, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %106 = add i32 %105, %103
  %107 = getelementptr i8, ptr %gep4, i64 88
  %108 = load i32, ptr %107, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %109 = add i32 %108, %106
  %110 = getelementptr i8, ptr %gep4, i64 92
  %111 = load i32, ptr %110, align 4, !invariant.load !3, !alias.scope !7, !noalias !15
  %112 = add i32 %111, %109
  br label %113

113:                                              ; preds = %.thread40, %88
  %114 = phi i32 [ %112, %88 ], [ %86, %.thread40 ]
  %115 = getelementptr i32, ptr %11, i64 %13
  store i32 %114, ptr %115, align 4, !alias.scope !12, !noalias !16
  %116 = add nuw nsw i64 %13, 1
  %exitcond.not = icmp eq i64 %116, 3
  br i1 %exitcond.not, label %117, label %12, !llvm.loop !17

117:                                              ; preds = %113
  %118 = add nuw nsw i64 %10, 1
  %exitcond5.not = icmp eq i64 %118, 48
  br i1 %exitcond5.not, label %wrapped_reduce-window_wrapped.exit, label %.preheader, !llvm.loop !17

wrapped_reduce-window_wrapped.exit:               ; preds = %117
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 4}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 15360}
!5 = !{i64 4}
!6 = !{i64 576}
!7 = !{!8}
!8 = distinct !{!8, !9, !"wrapped_reduce-window_wrapped: argument 0"}
!9 = distinct !{!9, !"wrapped_reduce-window_wrapped"}
!10 = !{!11}
!11 = distinct !{!11, !9, !"wrapped_reduce-window_wrapped: argument 1"}
!12 = !{!13}
!13 = distinct !{!13, !9, !"wrapped_reduce-window_wrapped: argument 2"}
!14 = !{!8, !13}
!15 = !{!11, !13}
!16 = !{!8, !11}
!17 = distinct !{!17, !18}
!18 = !{!"llvm.loop.unroll.disable"}
