; ModuleID = '__compute_module_convert_reduce_fusion_kernel_module'
source_filename = "__compute_module_convert_reduce_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @convert_reduce_fusion(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !5
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !4
  %9 = getelementptr inbounds nuw i8, ptr %3, i64 48
  %10 = load ptr, ptr %9, align 8, !invariant.load !3, !dereferenceable !5
  %11 = getelementptr inbounds nuw i8, ptr %3, i64 64
  %12 = load ptr, ptr %11, align 8, !invariant.load !3, !dereferenceable !6
  %13 = getelementptr inbounds nuw i8, ptr %3, i64 80
  %14 = load ptr, ptr %13, align 8, !invariant.load !3, !dereferenceable !6
  tail call void @llvm.experimental.noalias.scope.decl(metadata !7)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !10)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !12)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !14)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !16)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !18)
  %15 = getelementptr inbounds nuw i8, ptr %10, i64 32
  %wide.load11 = load <8 x float>, ptr %10, align 4, !invariant.load !3, !alias.scope !14, !noalias !20
  %wide.load12 = load <8 x float>, ptr %15, align 4, !invariant.load !3, !alias.scope !14, !noalias !20
  %16 = getelementptr inbounds nuw i8, ptr %6, i64 32
  %wide.load15 = load <8 x float>, ptr %6, align 4, !invariant.load !3, !alias.scope !10, !noalias !21
  %wide.load16 = load <8 x float>, ptr %16, align 4, !invariant.load !3, !alias.scope !10, !noalias !21
  %17 = getelementptr inbounds nuw i8, ptr %10, i64 64
  %18 = getelementptr inbounds nuw i8, ptr %10, i64 96
  %wide.load11.1 = load <8 x float>, ptr %17, align 4, !invariant.load !3, !alias.scope !14, !noalias !20
  %wide.load12.1 = load <8 x float>, ptr %18, align 4, !invariant.load !3, !alias.scope !14, !noalias !20
  %19 = getelementptr inbounds nuw i8, ptr %6, i64 64
  %20 = getelementptr inbounds nuw i8, ptr %6, i64 96
  %wide.load15.1 = load <8 x float>, ptr %19, align 4, !invariant.load !3, !alias.scope !10, !noalias !21
  %wide.load16.1 = load <8 x float>, ptr %20, align 4, !invariant.load !3, !alias.scope !10, !noalias !21
  %21 = getelementptr inbounds nuw i8, ptr %10, i64 128
  %22 = getelementptr inbounds nuw i8, ptr %10, i64 160
  %wide.load11.2 = load <8 x float>, ptr %21, align 4, !invariant.load !3, !alias.scope !14, !noalias !20
  %wide.load12.2 = load <8 x float>, ptr %22, align 4, !invariant.load !3, !alias.scope !14, !noalias !20
  %23 = getelementptr inbounds nuw i8, ptr %6, i64 128
  %24 = getelementptr inbounds nuw i8, ptr %6, i64 160
  %wide.load15.2 = load <8 x float>, ptr %23, align 4, !invariant.load !3, !alias.scope !10, !noalias !21
  %wide.load16.2 = load <8 x float>, ptr %24, align 4, !invariant.load !3, !alias.scope !10, !noalias !21
  %25 = getelementptr inbounds nuw i8, ptr %10, i64 192
  %26 = getelementptr inbounds nuw i8, ptr %10, i64 224
  %wide.load11.3 = load <8 x float>, ptr %25, align 4, !invariant.load !3, !alias.scope !14, !noalias !20
  %wide.load12.3 = load <8 x float>, ptr %26, align 4, !invariant.load !3, !alias.scope !14, !noalias !20
  %27 = getelementptr inbounds nuw i8, ptr %6, i64 192
  %28 = getelementptr inbounds nuw i8, ptr %6, i64 224
  %wide.load15.3 = load <8 x float>, ptr %27, align 4, !invariant.load !3, !alias.scope !10, !noalias !21
  %wide.load16.3 = load <8 x float>, ptr %28, align 4, !invariant.load !3, !alias.scope !10, !noalias !21
  %29 = getelementptr inbounds nuw i8, ptr %10, i64 256
  %30 = getelementptr inbounds nuw i8, ptr %10, i64 288
  %wide.load11.4 = load <8 x float>, ptr %29, align 4, !invariant.load !3, !alias.scope !14, !noalias !20
  %wide.load12.4 = load <8 x float>, ptr %30, align 4, !invariant.load !3, !alias.scope !14, !noalias !20
  %31 = getelementptr inbounds nuw i8, ptr %6, i64 256
  %32 = getelementptr inbounds nuw i8, ptr %6, i64 288
  %wide.load15.4 = load <8 x float>, ptr %31, align 4, !invariant.load !3, !alias.scope !10, !noalias !21
  %wide.load16.4 = load <8 x float>, ptr %32, align 4, !invariant.load !3, !alias.scope !10, !noalias !21
  br label %vector.ph

vector.ph:                                        ; preds = %1, %vector.ph
  %33 = phi i64 [ 0, %1 ], [ %139, %vector.ph ]
  %34 = mul nuw nsw i64 %33, 80
  %35 = getelementptr inbounds nuw float, ptr %8, i64 %34
  %36 = getelementptr inbounds nuw i8, ptr %35, i64 32
  %wide.load = load <8 x float>, ptr %35, align 4, !invariant.load !3, !alias.scope !12, !noalias !22
  %wide.load10 = load <8 x float>, ptr %36, align 4, !invariant.load !3, !alias.scope !12, !noalias !22
  %37 = fadd <8 x float> %wide.load, %wide.load11
  %38 = fadd <8 x float> %wide.load10, %wide.load12
  %39 = fcmp ogt <8 x float> %37, zeroinitializer
  %40 = fcmp ogt <8 x float> %38, zeroinitializer
  %41 = zext <8 x i1> %39 to <8 x i32>
  %42 = zext <8 x i1> %40 to <8 x i32>
  %43 = getelementptr inbounds nuw float, ptr %4, i64 %34
  %44 = getelementptr inbounds nuw i8, ptr %43, i64 32
  %wide.load13 = load <8 x float>, ptr %43, align 4, !invariant.load !3, !alias.scope !7, !noalias !23
  %wide.load14 = load <8 x float>, ptr %44, align 4, !invariant.load !3, !alias.scope !7, !noalias !23
  %45 = fadd <8 x float> %wide.load13, %wide.load15
  %46 = fadd <8 x float> %wide.load14, %wide.load16
  %47 = fcmp ogt <8 x float> %45, zeroinitializer
  %48 = fcmp ogt <8 x float> %46, zeroinitializer
  %49 = zext <8 x i1> %47 to <8 x i32>
  %50 = zext <8 x i1> %48 to <8 x i32>
  %51 = add nuw nsw i64 %34, 16
  %52 = getelementptr inbounds nuw float, ptr %8, i64 %51
  %53 = getelementptr inbounds nuw i8, ptr %52, i64 32
  %wide.load.1 = load <8 x float>, ptr %52, align 4, !invariant.load !3, !alias.scope !12, !noalias !22
  %wide.load10.1 = load <8 x float>, ptr %53, align 4, !invariant.load !3, !alias.scope !12, !noalias !22
  %54 = fadd <8 x float> %wide.load.1, %wide.load11.1
  %55 = fadd <8 x float> %wide.load10.1, %wide.load12.1
  %56 = fcmp ogt <8 x float> %54, zeroinitializer
  %57 = fcmp ogt <8 x float> %55, zeroinitializer
  %58 = zext <8 x i1> %56 to <8 x i32>
  %59 = zext <8 x i1> %57 to <8 x i32>
  %60 = getelementptr inbounds nuw float, ptr %4, i64 %51
  %61 = getelementptr inbounds nuw i8, ptr %60, i64 32
  %wide.load13.1 = load <8 x float>, ptr %60, align 4, !invariant.load !3, !alias.scope !7, !noalias !23
  %wide.load14.1 = load <8 x float>, ptr %61, align 4, !invariant.load !3, !alias.scope !7, !noalias !23
  %62 = fadd <8 x float> %wide.load13.1, %wide.load15.1
  %63 = fadd <8 x float> %wide.load14.1, %wide.load16.1
  %64 = fcmp ogt <8 x float> %62, zeroinitializer
  %65 = fcmp ogt <8 x float> %63, zeroinitializer
  %66 = zext <8 x i1> %64 to <8 x i32>
  %67 = zext <8 x i1> %65 to <8 x i32>
  %68 = add nuw nsw <8 x i32> %41, %58
  %69 = add nuw nsw <8 x i32> %42, %59
  %70 = add nuw nsw <8 x i32> %49, %66
  %71 = add nuw nsw <8 x i32> %50, %67
  %72 = add nuw nsw i64 %34, 32
  %73 = getelementptr inbounds nuw float, ptr %8, i64 %72
  %74 = getelementptr inbounds nuw i8, ptr %73, i64 32
  %wide.load.2 = load <8 x float>, ptr %73, align 4, !invariant.load !3, !alias.scope !12, !noalias !22
  %wide.load10.2 = load <8 x float>, ptr %74, align 4, !invariant.load !3, !alias.scope !12, !noalias !22
  %75 = fadd <8 x float> %wide.load.2, %wide.load11.2
  %76 = fadd <8 x float> %wide.load10.2, %wide.load12.2
  %77 = fcmp ogt <8 x float> %75, zeroinitializer
  %78 = fcmp ogt <8 x float> %76, zeroinitializer
  %79 = zext <8 x i1> %77 to <8 x i32>
  %80 = zext <8 x i1> %78 to <8 x i32>
  %81 = getelementptr inbounds nuw float, ptr %4, i64 %72
  %82 = getelementptr inbounds nuw i8, ptr %81, i64 32
  %wide.load13.2 = load <8 x float>, ptr %81, align 4, !invariant.load !3, !alias.scope !7, !noalias !23
  %wide.load14.2 = load <8 x float>, ptr %82, align 4, !invariant.load !3, !alias.scope !7, !noalias !23
  %83 = fadd <8 x float> %wide.load13.2, %wide.load15.2
  %84 = fadd <8 x float> %wide.load14.2, %wide.load16.2
  %85 = fcmp ogt <8 x float> %83, zeroinitializer
  %86 = fcmp ogt <8 x float> %84, zeroinitializer
  %87 = zext <8 x i1> %85 to <8 x i32>
  %88 = zext <8 x i1> %86 to <8 x i32>
  %89 = add nuw nsw <8 x i32> %68, %79
  %90 = add nuw nsw <8 x i32> %69, %80
  %91 = add nuw nsw <8 x i32> %70, %87
  %92 = add nuw nsw <8 x i32> %71, %88
  %93 = add nuw nsw i64 %34, 48
  %94 = getelementptr inbounds nuw float, ptr %8, i64 %93
  %95 = getelementptr inbounds nuw i8, ptr %94, i64 32
  %wide.load.3 = load <8 x float>, ptr %94, align 4, !invariant.load !3, !alias.scope !12, !noalias !22
  %wide.load10.3 = load <8 x float>, ptr %95, align 4, !invariant.load !3, !alias.scope !12, !noalias !22
  %96 = fadd <8 x float> %wide.load.3, %wide.load11.3
  %97 = fadd <8 x float> %wide.load10.3, %wide.load12.3
  %98 = fcmp ogt <8 x float> %96, zeroinitializer
  %99 = fcmp ogt <8 x float> %97, zeroinitializer
  %100 = zext <8 x i1> %98 to <8 x i32>
  %101 = zext <8 x i1> %99 to <8 x i32>
  %102 = getelementptr inbounds nuw float, ptr %4, i64 %93
  %103 = getelementptr inbounds nuw i8, ptr %102, i64 32
  %wide.load13.3 = load <8 x float>, ptr %102, align 4, !invariant.load !3, !alias.scope !7, !noalias !23
  %wide.load14.3 = load <8 x float>, ptr %103, align 4, !invariant.load !3, !alias.scope !7, !noalias !23
  %104 = fadd <8 x float> %wide.load13.3, %wide.load15.3
  %105 = fadd <8 x float> %wide.load14.3, %wide.load16.3
  %106 = fcmp ogt <8 x float> %104, zeroinitializer
  %107 = fcmp ogt <8 x float> %105, zeroinitializer
  %108 = zext <8 x i1> %106 to <8 x i32>
  %109 = zext <8 x i1> %107 to <8 x i32>
  %110 = add nuw nsw <8 x i32> %89, %100
  %111 = add nuw nsw <8 x i32> %90, %101
  %112 = add nuw nsw <8 x i32> %91, %108
  %113 = add nuw nsw <8 x i32> %92, %109
  %114 = add nuw nsw i64 %34, 64
  %115 = getelementptr inbounds nuw float, ptr %8, i64 %114
  %116 = getelementptr inbounds nuw i8, ptr %115, i64 32
  %wide.load.4 = load <8 x float>, ptr %115, align 4, !invariant.load !3, !alias.scope !12, !noalias !22
  %wide.load10.4 = load <8 x float>, ptr %116, align 4, !invariant.load !3, !alias.scope !12, !noalias !22
  %117 = fadd <8 x float> %wide.load.4, %wide.load11.4
  %118 = fadd <8 x float> %wide.load10.4, %wide.load12.4
  %119 = fcmp ogt <8 x float> %117, zeroinitializer
  %120 = fcmp ogt <8 x float> %118, zeroinitializer
  %121 = zext <8 x i1> %119 to <8 x i32>
  %122 = zext <8 x i1> %120 to <8 x i32>
  %123 = getelementptr inbounds nuw float, ptr %4, i64 %114
  %124 = getelementptr inbounds nuw i8, ptr %123, i64 32
  %wide.load13.4 = load <8 x float>, ptr %123, align 4, !invariant.load !3, !alias.scope !7, !noalias !23
  %wide.load14.4 = load <8 x float>, ptr %124, align 4, !invariant.load !3, !alias.scope !7, !noalias !23
  %125 = fadd <8 x float> %wide.load13.4, %wide.load15.4
  %126 = fadd <8 x float> %wide.load14.4, %wide.load16.4
  %127 = fcmp ogt <8 x float> %125, zeroinitializer
  %128 = fcmp ogt <8 x float> %126, zeroinitializer
  %129 = zext <8 x i1> %127 to <8 x i32>
  %130 = zext <8 x i1> %128 to <8 x i32>
  %131 = add nuw nsw <8 x i32> %110, %121
  %132 = add nuw nsw <8 x i32> %111, %122
  %133 = add nuw nsw <8 x i32> %112, %129
  %134 = add nuw nsw <8 x i32> %113, %130
  %bin.rdx17 = add nuw nsw <8 x i32> %132, %131
  %135 = tail call i32 @llvm.vector.reduce.add.v8i32(<8 x i32> %bin.rdx17)
  %bin.rdx = add nuw nsw <8 x i32> %134, %133
  %136 = tail call i32 @llvm.vector.reduce.add.v8i32(<8 x i32> %bin.rdx)
  %137 = getelementptr inbounds nuw i32, ptr %12, i64 %33
  store i32 %135, ptr %137, align 4, !alias.scope !16, !noalias !24
  %138 = getelementptr inbounds nuw i32, ptr %14, i64 %33
  store i32 %136, ptr %138, align 4, !alias.scope !18, !noalias !25
  %139 = add nuw nsw i64 %33, 1
  %exitcond4.not = icmp eq i64 %139, 48
  br i1 %exitcond4.not, label %convert_reduce_fusion_wrapped.exit, label %vector.ph, !llvm.loop !26

convert_reduce_fusion_wrapped.exit:               ; preds = %vector.ph
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.vector.reduce.add.v8i32(<8 x i32>) #2

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #2 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 2}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 15360}
!5 = !{i64 320}
!6 = !{i64 192}
!7 = !{!8}
!8 = distinct !{!8, !9, !"convert_reduce_fusion_wrapped: argument 0"}
!9 = distinct !{!9, !"convert_reduce_fusion_wrapped"}
!10 = !{!11}
!11 = distinct !{!11, !9, !"convert_reduce_fusion_wrapped: argument 1"}
!12 = !{!13}
!13 = distinct !{!13, !9, !"convert_reduce_fusion_wrapped: argument 2"}
!14 = !{!15}
!15 = distinct !{!15, !9, !"convert_reduce_fusion_wrapped: argument 3"}
!16 = !{!17}
!17 = distinct !{!17, !9, !"convert_reduce_fusion_wrapped: argument 4"}
!18 = !{!19}
!19 = distinct !{!19, !9, !"convert_reduce_fusion_wrapped: argument 5"}
!20 = !{!8, !11, !13, !17, !19}
!21 = !{!8, !13, !15, !17, !19}
!22 = !{!8, !11, !15, !17, !19}
!23 = !{!11, !13, !15, !17, !19}
!24 = !{!8, !11, !13, !15, !19}
!25 = !{!8, !11, !13, !15, !17}
!26 = distinct !{!26, !27}
!27 = !{!"llvm.loop.unroll.disable"}
