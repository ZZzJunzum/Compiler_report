; ModuleID = '__compute_module_broadcast_add_fusion_kernel_module'
source_filename = "__compute_module_broadcast_add_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @broadcast_add_fusion(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !5
  tail call void @llvm.experimental.noalias.scope.decl(metadata !6)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9)
  %7 = getelementptr inbounds nuw i8, ptr %6, i64 32
  %8 = getelementptr inbounds nuw i8, ptr %6, i64 64
  %9 = getelementptr inbounds nuw i8, ptr %6, i64 96
  %wide.load5 = load <8 x float>, ptr %6, align 4, !invariant.load !3, !alias.scope !9, !noalias !6
  %wide.load6 = load <8 x float>, ptr %7, align 4, !invariant.load !3, !alias.scope !9, !noalias !6
  %wide.load7 = load <8 x float>, ptr %8, align 4, !invariant.load !3, !alias.scope !9, !noalias !6
  %wide.load8 = load <8 x float>, ptr %9, align 4, !invariant.load !3, !alias.scope !9, !noalias !6
  %10 = getelementptr inbounds nuw i8, ptr %6, i64 128
  %11 = getelementptr inbounds nuw i8, ptr %6, i64 160
  %12 = getelementptr inbounds nuw i8, ptr %6, i64 192
  %13 = getelementptr inbounds nuw i8, ptr %6, i64 224
  %wide.load5.1 = load <8 x float>, ptr %10, align 4, !invariant.load !3, !alias.scope !9, !noalias !6
  %wide.load6.1 = load <8 x float>, ptr %11, align 4, !invariant.load !3, !alias.scope !9, !noalias !6
  %wide.load7.1 = load <8 x float>, ptr %12, align 4, !invariant.load !3, !alias.scope !9, !noalias !6
  %wide.load8.1 = load <8 x float>, ptr %13, align 4, !invariant.load !3, !alias.scope !9, !noalias !6
  %14 = getelementptr inbounds nuw i8, ptr %6, i64 256
  %wide.load11 = load <8 x float>, ptr %14, align 4, !invariant.load !3, !alias.scope !9, !noalias !6
  %15 = getelementptr inbounds nuw i8, ptr %6, i64 288
  %wide.load11.1 = load <8 x float>, ptr %15, align 4, !invariant.load !3, !alias.scope !9, !noalias !6
  br label %iter.check

iter.check:                                       ; preds = %1, %iter.check
  %16 = phi i64 [ 0, %1 ], [ %67, %iter.check ]
  %.idx = mul nuw nsw i64 %16, 320
  %17 = getelementptr i8, ptr %4, i64 %.idx
  %18 = getelementptr i8, ptr %17, i64 32
  %19 = getelementptr i8, ptr %17, i64 64
  %20 = getelementptr i8, ptr %17, i64 96
  %wide.load = load <8 x float>, ptr %17, align 4, !alias.scope !6, !noalias !9
  %wide.load2 = load <8 x float>, ptr %18, align 4, !alias.scope !6, !noalias !9
  %wide.load3 = load <8 x float>, ptr %19, align 4, !alias.scope !6, !noalias !9
  %wide.load4 = load <8 x float>, ptr %20, align 4, !alias.scope !6, !noalias !9
  %21 = fadd <8 x float> %wide.load, %wide.load5
  %22 = fadd <8 x float> %wide.load2, %wide.load6
  %23 = fadd <8 x float> %wide.load3, %wide.load7
  %24 = fadd <8 x float> %wide.load4, %wide.load8
  %25 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %21, <8 x float> zeroinitializer)
  %26 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %22, <8 x float> zeroinitializer)
  %27 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %23, <8 x float> zeroinitializer)
  %28 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %24, <8 x float> zeroinitializer)
  %29 = fmul <8 x float> %25, splat (float 7.500000e-01)
  %30 = fmul <8 x float> %26, splat (float 7.500000e-01)
  %31 = fmul <8 x float> %27, splat (float 7.500000e-01)
  %32 = fmul <8 x float> %28, splat (float 7.500000e-01)
  %33 = fadd <8 x float> %29, splat (float 1.250000e-01)
  %34 = fadd <8 x float> %30, splat (float 1.250000e-01)
  %35 = fadd <8 x float> %31, splat (float 1.250000e-01)
  %36 = fadd <8 x float> %32, splat (float 1.250000e-01)
  store <8 x float> %33, ptr %17, align 4, !alias.scope !6, !noalias !9
  store <8 x float> %34, ptr %18, align 4, !alias.scope !6, !noalias !9
  store <8 x float> %35, ptr %19, align 4, !alias.scope !6, !noalias !9
  store <8 x float> %36, ptr %20, align 4, !alias.scope !6, !noalias !9
  %37 = getelementptr i8, ptr %17, i64 128
  %38 = getelementptr i8, ptr %17, i64 160
  %39 = getelementptr i8, ptr %17, i64 192
  %40 = getelementptr i8, ptr %17, i64 224
  %wide.load.1 = load <8 x float>, ptr %37, align 4, !alias.scope !6, !noalias !9
  %wide.load2.1 = load <8 x float>, ptr %38, align 4, !alias.scope !6, !noalias !9
  %wide.load3.1 = load <8 x float>, ptr %39, align 4, !alias.scope !6, !noalias !9
  %wide.load4.1 = load <8 x float>, ptr %40, align 4, !alias.scope !6, !noalias !9
  %41 = fadd <8 x float> %wide.load.1, %wide.load5.1
  %42 = fadd <8 x float> %wide.load2.1, %wide.load6.1
  %43 = fadd <8 x float> %wide.load3.1, %wide.load7.1
  %44 = fadd <8 x float> %wide.load4.1, %wide.load8.1
  %45 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %41, <8 x float> zeroinitializer)
  %46 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %42, <8 x float> zeroinitializer)
  %47 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %43, <8 x float> zeroinitializer)
  %48 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %44, <8 x float> zeroinitializer)
  %49 = fmul <8 x float> %45, splat (float 7.500000e-01)
  %50 = fmul <8 x float> %46, splat (float 7.500000e-01)
  %51 = fmul <8 x float> %47, splat (float 7.500000e-01)
  %52 = fmul <8 x float> %48, splat (float 7.500000e-01)
  %53 = fadd <8 x float> %49, splat (float 1.250000e-01)
  %54 = fadd <8 x float> %50, splat (float 1.250000e-01)
  %55 = fadd <8 x float> %51, splat (float 1.250000e-01)
  %56 = fadd <8 x float> %52, splat (float 1.250000e-01)
  store <8 x float> %53, ptr %37, align 4, !alias.scope !6, !noalias !9
  store <8 x float> %54, ptr %38, align 4, !alias.scope !6, !noalias !9
  store <8 x float> %55, ptr %39, align 4, !alias.scope !6, !noalias !9
  store <8 x float> %56, ptr %40, align 4, !alias.scope !6, !noalias !9
  %57 = getelementptr i8, ptr %17, i64 256
  %wide.load10 = load <8 x float>, ptr %57, align 4, !alias.scope !6, !noalias !9
  %58 = fadd <8 x float> %wide.load10, %wide.load11
  %59 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %58, <8 x float> zeroinitializer)
  %60 = fmul <8 x float> %59, splat (float 7.500000e-01)
  %61 = fadd <8 x float> %60, splat (float 1.250000e-01)
  store <8 x float> %61, ptr %57, align 4, !alias.scope !6, !noalias !9
  %62 = getelementptr i8, ptr %17, i64 288
  %wide.load10.1 = load <8 x float>, ptr %62, align 4, !alias.scope !6, !noalias !9
  %63 = fadd <8 x float> %wide.load10.1, %wide.load11.1
  %64 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %63, <8 x float> zeroinitializer)
  %65 = fmul <8 x float> %64, splat (float 7.500000e-01)
  %66 = fadd <8 x float> %65, splat (float 1.250000e-01)
  store <8 x float> %66, ptr %62, align 4, !alias.scope !6, !noalias !9
  %67 = add nuw nsw i64 %16, 1
  %exitcond1.not = icmp eq i64 %67, 48
  br i1 %exitcond1.not, label %broadcast_add_fusion_wrapped.exit, label %iter.check, !llvm.loop !11

broadcast_add_fusion_wrapped.exit:                ; preds = %iter.check
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.maximum.v8f32(<8 x float>, <8 x float>) #2

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 0}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 15360}
!5 = !{i64 320}
!6 = !{!7}
!7 = distinct !{!7, !8, !"broadcast_add_fusion_wrapped: argument 0"}
!8 = distinct !{!8, !"broadcast_add_fusion_wrapped"}
!9 = !{!10}
!10 = distinct !{!10, !8, !"broadcast_add_fusion_wrapped: argument 1"}
!11 = distinct !{!11, !12}
!12 = !{!"llvm.loop.unroll.disable"}
