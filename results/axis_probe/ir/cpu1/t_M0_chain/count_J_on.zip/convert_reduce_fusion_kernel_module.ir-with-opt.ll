; ModuleID = '__compute_module_convert_reduce_fusion_kernel_module'
source_filename = "__compute_module_convert_reduce_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @convert_reduce_fusion(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !5
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !4
  %9 = getelementptr inbounds nuw i8, ptr %3, i64 48
  %10 = load ptr, ptr %9, align 8, !invariant.load !3, !dereferenceable !5
  tail call void @llvm.experimental.noalias.scope.decl(metadata !6)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !11)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !13)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !15)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !17)
  %11 = getelementptr inbounds nuw i8, ptr %10, i64 32
  %wide.load13 = load <8 x float>, ptr %10, align 4, !invariant.load !3, !alias.scope !13, !noalias !19
  %wide.load14 = load <8 x float>, ptr %11, align 4, !invariant.load !3, !alias.scope !13, !noalias !19
  %12 = getelementptr inbounds nuw i8, ptr %6, i64 32
  %wide.load17 = load <8 x float>, ptr %6, align 4, !invariant.load !3, !alias.scope !9, !noalias !20
  %wide.load18 = load <8 x float>, ptr %12, align 4, !invariant.load !3, !alias.scope !9, !noalias !20
  %13 = getelementptr inbounds nuw i8, ptr %10, i64 64
  %14 = getelementptr inbounds nuw i8, ptr %10, i64 96
  %wide.load13.1 = load <8 x float>, ptr %13, align 4, !invariant.load !3, !alias.scope !13, !noalias !19
  %wide.load14.1 = load <8 x float>, ptr %14, align 4, !invariant.load !3, !alias.scope !13, !noalias !19
  %15 = getelementptr inbounds nuw i8, ptr %6, i64 64
  %16 = getelementptr inbounds nuw i8, ptr %6, i64 96
  %wide.load17.1 = load <8 x float>, ptr %15, align 4, !invariant.load !3, !alias.scope !9, !noalias !20
  %wide.load18.1 = load <8 x float>, ptr %16, align 4, !invariant.load !3, !alias.scope !9, !noalias !20
  %17 = getelementptr inbounds nuw i8, ptr %10, i64 128
  %18 = getelementptr inbounds nuw i8, ptr %10, i64 160
  %wide.load13.2 = load <8 x float>, ptr %17, align 4, !invariant.load !3, !alias.scope !13, !noalias !19
  %wide.load14.2 = load <8 x float>, ptr %18, align 4, !invariant.load !3, !alias.scope !13, !noalias !19
  %19 = getelementptr inbounds nuw i8, ptr %6, i64 128
  %20 = getelementptr inbounds nuw i8, ptr %6, i64 160
  %wide.load17.2 = load <8 x float>, ptr %19, align 4, !invariant.load !3, !alias.scope !9, !noalias !20
  %wide.load18.2 = load <8 x float>, ptr %20, align 4, !invariant.load !3, !alias.scope !9, !noalias !20
  %21 = getelementptr inbounds nuw i8, ptr %10, i64 192
  %22 = getelementptr inbounds nuw i8, ptr %10, i64 224
  %wide.load13.3 = load <8 x float>, ptr %21, align 4, !invariant.load !3, !alias.scope !13, !noalias !19
  %wide.load14.3 = load <8 x float>, ptr %22, align 4, !invariant.load !3, !alias.scope !13, !noalias !19
  %23 = getelementptr inbounds nuw i8, ptr %6, i64 192
  %24 = getelementptr inbounds nuw i8, ptr %6, i64 224
  %wide.load17.3 = load <8 x float>, ptr %23, align 4, !invariant.load !3, !alias.scope !9, !noalias !20
  %wide.load18.3 = load <8 x float>, ptr %24, align 4, !invariant.load !3, !alias.scope !9, !noalias !20
  %25 = getelementptr inbounds nuw i8, ptr %10, i64 256
  %26 = getelementptr inbounds nuw i8, ptr %10, i64 288
  %wide.load13.4 = load <8 x float>, ptr %25, align 4, !invariant.load !3, !alias.scope !13, !noalias !19
  %wide.load14.4 = load <8 x float>, ptr %26, align 4, !invariant.load !3, !alias.scope !13, !noalias !19
  %27 = getelementptr inbounds nuw i8, ptr %6, i64 256
  %28 = getelementptr inbounds nuw i8, ptr %6, i64 288
  %wide.load17.4 = load <8 x float>, ptr %27, align 4, !invariant.load !3, !alias.scope !9, !noalias !20
  %wide.load18.4 = load <8 x float>, ptr %28, align 4, !invariant.load !3, !alias.scope !9, !noalias !20
  br label %vector.ph

vector.ph:                                        ; preds = %1, %vector.ph
  %29 = phi i32 [ 0, %1 ], [ %138, %vector.ph ]
  %30 = phi i32 [ 0, %1 ], [ %137, %vector.ph ]
  %31 = phi i64 [ 0, %1 ], [ %139, %vector.ph ]
  %32 = insertelement <8 x i32> <i32 poison, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0>, i32 %30, i64 0
  %33 = insertelement <8 x i32> <i32 poison, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0, i32 0>, i32 %29, i64 0
  %34 = mul nuw nsw i64 %31, 80
  %35 = getelementptr inbounds nuw float, ptr %8, i64 %34
  %36 = getelementptr inbounds nuw i8, ptr %35, i64 32
  %wide.load = load <8 x float>, ptr %35, align 4, !invariant.load !3, !alias.scope !11, !noalias !21
  %wide.load12 = load <8 x float>, ptr %36, align 4, !invariant.load !3, !alias.scope !11, !noalias !21
  %37 = fadd <8 x float> %wide.load, %wide.load13
  %38 = fadd <8 x float> %wide.load12, %wide.load14
  %39 = fcmp ogt <8 x float> %37, zeroinitializer
  %40 = fcmp ogt <8 x float> %38, zeroinitializer
  %41 = zext <8 x i1> %39 to <8 x i32>
  %42 = zext <8 x i1> %40 to <8 x i32>
  %43 = getelementptr inbounds nuw float, ptr %4, i64 %34
  %44 = getelementptr inbounds nuw i8, ptr %43, i64 32
  %wide.load15 = load <8 x float>, ptr %43, align 4, !invariant.load !3, !alias.scope !6, !noalias !22
  %wide.load16 = load <8 x float>, ptr %44, align 4, !invariant.load !3, !alias.scope !6, !noalias !22
  %45 = fadd <8 x float> %wide.load15, %wide.load17
  %46 = fadd <8 x float> %wide.load16, %wide.load18
  %47 = fcmp ogt <8 x float> %45, zeroinitializer
  %48 = fcmp ogt <8 x float> %46, zeroinitializer
  %49 = zext <8 x i1> %47 to <8 x i32>
  %50 = zext <8 x i1> %48 to <8 x i32>
  %51 = add <8 x i32> %32, %41
  %52 = add <8 x i32> %33, %49
  %53 = add nuw nsw i64 %34, 16
  %54 = getelementptr inbounds nuw float, ptr %8, i64 %53
  %55 = getelementptr inbounds nuw i8, ptr %54, i64 32
  %wide.load.1 = load <8 x float>, ptr %54, align 4, !invariant.load !3, !alias.scope !11, !noalias !21
  %wide.load12.1 = load <8 x float>, ptr %55, align 4, !invariant.load !3, !alias.scope !11, !noalias !21
  %56 = fadd <8 x float> %wide.load.1, %wide.load13.1
  %57 = fadd <8 x float> %wide.load12.1, %wide.load14.1
  %58 = fcmp ogt <8 x float> %56, zeroinitializer
  %59 = fcmp ogt <8 x float> %57, zeroinitializer
  %60 = zext <8 x i1> %58 to <8 x i32>
  %61 = zext <8 x i1> %59 to <8 x i32>
  %62 = getelementptr inbounds nuw float, ptr %4, i64 %53
  %63 = getelementptr inbounds nuw i8, ptr %62, i64 32
  %wide.load15.1 = load <8 x float>, ptr %62, align 4, !invariant.load !3, !alias.scope !6, !noalias !22
  %wide.load16.1 = load <8 x float>, ptr %63, align 4, !invariant.load !3, !alias.scope !6, !noalias !22
  %64 = fadd <8 x float> %wide.load15.1, %wide.load17.1
  %65 = fadd <8 x float> %wide.load16.1, %wide.load18.1
  %66 = fcmp ogt <8 x float> %64, zeroinitializer
  %67 = fcmp ogt <8 x float> %65, zeroinitializer
  %68 = zext <8 x i1> %66 to <8 x i32>
  %69 = zext <8 x i1> %67 to <8 x i32>
  %70 = add <8 x i32> %51, %60
  %71 = add nuw nsw <8 x i32> %42, %61
  %72 = add <8 x i32> %52, %68
  %73 = add nuw nsw <8 x i32> %50, %69
  %74 = add nuw nsw i64 %34, 32
  %75 = getelementptr inbounds nuw float, ptr %8, i64 %74
  %76 = getelementptr inbounds nuw i8, ptr %75, i64 32
  %wide.load.2 = load <8 x float>, ptr %75, align 4, !invariant.load !3, !alias.scope !11, !noalias !21
  %wide.load12.2 = load <8 x float>, ptr %76, align 4, !invariant.load !3, !alias.scope !11, !noalias !21
  %77 = fadd <8 x float> %wide.load.2, %wide.load13.2
  %78 = fadd <8 x float> %wide.load12.2, %wide.load14.2
  %79 = fcmp ogt <8 x float> %77, zeroinitializer
  %80 = fcmp ogt <8 x float> %78, zeroinitializer
  %81 = zext <8 x i1> %79 to <8 x i32>
  %82 = zext <8 x i1> %80 to <8 x i32>
  %83 = getelementptr inbounds nuw float, ptr %4, i64 %74
  %84 = getelementptr inbounds nuw i8, ptr %83, i64 32
  %wide.load15.2 = load <8 x float>, ptr %83, align 4, !invariant.load !3, !alias.scope !6, !noalias !22
  %wide.load16.2 = load <8 x float>, ptr %84, align 4, !invariant.load !3, !alias.scope !6, !noalias !22
  %85 = fadd <8 x float> %wide.load15.2, %wide.load17.2
  %86 = fadd <8 x float> %wide.load16.2, %wide.load18.2
  %87 = fcmp ogt <8 x float> %85, zeroinitializer
  %88 = fcmp ogt <8 x float> %86, zeroinitializer
  %89 = zext <8 x i1> %87 to <8 x i32>
  %90 = zext <8 x i1> %88 to <8 x i32>
  %91 = add <8 x i32> %70, %81
  %92 = add nuw nsw <8 x i32> %71, %82
  %93 = add <8 x i32> %72, %89
  %94 = add nuw nsw <8 x i32> %73, %90
  %95 = add nuw nsw i64 %34, 48
  %96 = getelementptr inbounds nuw float, ptr %8, i64 %95
  %97 = getelementptr inbounds nuw i8, ptr %96, i64 32
  %wide.load.3 = load <8 x float>, ptr %96, align 4, !invariant.load !3, !alias.scope !11, !noalias !21
  %wide.load12.3 = load <8 x float>, ptr %97, align 4, !invariant.load !3, !alias.scope !11, !noalias !21
  %98 = fadd <8 x float> %wide.load.3, %wide.load13.3
  %99 = fadd <8 x float> %wide.load12.3, %wide.load14.3
  %100 = fcmp ogt <8 x float> %98, zeroinitializer
  %101 = fcmp ogt <8 x float> %99, zeroinitializer
  %102 = zext <8 x i1> %100 to <8 x i32>
  %103 = zext <8 x i1> %101 to <8 x i32>
  %104 = getelementptr inbounds nuw float, ptr %4, i64 %95
  %105 = getelementptr inbounds nuw i8, ptr %104, i64 32
  %wide.load15.3 = load <8 x float>, ptr %104, align 4, !invariant.load !3, !alias.scope !6, !noalias !22
  %wide.load16.3 = load <8 x float>, ptr %105, align 4, !invariant.load !3, !alias.scope !6, !noalias !22
  %106 = fadd <8 x float> %wide.load15.3, %wide.load17.3
  %107 = fadd <8 x float> %wide.load16.3, %wide.load18.3
  %108 = fcmp ogt <8 x float> %106, zeroinitializer
  %109 = fcmp ogt <8 x float> %107, zeroinitializer
  %110 = zext <8 x i1> %108 to <8 x i32>
  %111 = zext <8 x i1> %109 to <8 x i32>
  %112 = add <8 x i32> %91, %102
  %113 = add nuw nsw <8 x i32> %92, %103
  %114 = add <8 x i32> %93, %110
  %115 = add nuw nsw <8 x i32> %94, %111
  %116 = add nuw nsw i64 %34, 64
  %117 = getelementptr inbounds nuw float, ptr %8, i64 %116
  %118 = getelementptr inbounds nuw i8, ptr %117, i64 32
  %wide.load.4 = load <8 x float>, ptr %117, align 4, !invariant.load !3, !alias.scope !11, !noalias !21
  %wide.load12.4 = load <8 x float>, ptr %118, align 4, !invariant.load !3, !alias.scope !11, !noalias !21
  %119 = fadd <8 x float> %wide.load.4, %wide.load13.4
  %120 = fadd <8 x float> %wide.load12.4, %wide.load14.4
  %121 = fcmp ogt <8 x float> %119, zeroinitializer
  %122 = fcmp ogt <8 x float> %120, zeroinitializer
  %123 = zext <8 x i1> %121 to <8 x i32>
  %124 = zext <8 x i1> %122 to <8 x i32>
  %125 = getelementptr inbounds nuw float, ptr %4, i64 %116
  %126 = getelementptr inbounds nuw i8, ptr %125, i64 32
  %wide.load15.4 = load <8 x float>, ptr %125, align 4, !invariant.load !3, !alias.scope !6, !noalias !22
  %wide.load16.4 = load <8 x float>, ptr %126, align 4, !invariant.load !3, !alias.scope !6, !noalias !22
  %127 = fadd <8 x float> %wide.load15.4, %wide.load17.4
  %128 = fadd <8 x float> %wide.load16.4, %wide.load18.4
  %129 = fcmp ogt <8 x float> %127, zeroinitializer
  %130 = fcmp ogt <8 x float> %128, zeroinitializer
  %131 = zext <8 x i1> %129 to <8 x i32>
  %132 = zext <8 x i1> %130 to <8 x i32>
  %133 = add <8 x i32> %112, %123
  %134 = add nuw nsw <8 x i32> %113, %124
  %135 = add <8 x i32> %114, %131
  %136 = add nuw nsw <8 x i32> %115, %132
  %bin.rdx19 = add <8 x i32> %134, %133
  %137 = tail call i32 @llvm.vector.reduce.add.v8i32(<8 x i32> %bin.rdx19)
  %bin.rdx = add <8 x i32> %136, %135
  %138 = tail call i32 @llvm.vector.reduce.add.v8i32(<8 x i32> %bin.rdx)
  %139 = add nuw nsw i64 %31, 1
  %exitcond6.not = icmp eq i64 %139, 48
  br i1 %exitcond6.not, label %convert_reduce_fusion_wrapped.exit, label %vector.ph, !llvm.loop !23

convert_reduce_fusion_wrapped.exit:               ; preds = %vector.ph
  %140 = getelementptr inbounds nuw i8, ptr %3, i64 80
  %141 = load ptr, ptr %140, align 8, !invariant.load !3, !dereferenceable !25
  %142 = getelementptr inbounds nuw i8, ptr %3, i64 64
  %143 = load ptr, ptr %142, align 8, !invariant.load !3, !dereferenceable !25
  store i32 %137, ptr %143, align 4, !alias.scope !15, !noalias !26
  store i32 %138, ptr %141, align 4, !alias.scope !17, !noalias !27
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.vector.reduce.add.v8i32(<8 x i32>) #2

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #2 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 2}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 15360}
!5 = !{i64 320}
!6 = !{!7}
!7 = distinct !{!7, !8, !"convert_reduce_fusion_wrapped: argument 0"}
!8 = distinct !{!8, !"convert_reduce_fusion_wrapped"}
!9 = !{!10}
!10 = distinct !{!10, !8, !"convert_reduce_fusion_wrapped: argument 1"}
!11 = !{!12}
!12 = distinct !{!12, !8, !"convert_reduce_fusion_wrapped: argument 2"}
!13 = !{!14}
!14 = distinct !{!14, !8, !"convert_reduce_fusion_wrapped: argument 3"}
!15 = !{!16}
!16 = distinct !{!16, !8, !"convert_reduce_fusion_wrapped: argument 4"}
!17 = !{!18}
!18 = distinct !{!18, !8, !"convert_reduce_fusion_wrapped: argument 5"}
!19 = !{!7, !10, !12, !16, !18}
!20 = !{!7, !12, !14, !16, !18}
!21 = !{!7, !10, !14, !16, !18}
!22 = !{!10, !12, !14, !16, !18}
!23 = distinct !{!23, !24}
!24 = !{!"llvm.loop.unroll.disable"}
!25 = !{i64 4}
!26 = !{!7, !10, !12, !14, !18}
!27 = !{!7, !10, !12, !14, !16}
