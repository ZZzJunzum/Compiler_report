; ModuleID = '__compute_module_broadcast_maximum_fusion_kernel_module'
source_filename = "__compute_module_broadcast_maximum_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable
define noalias noundef ptr @broadcast_maximum_fusion(ptr readonly captures(none) %0) local_unnamed_addr #0 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 24
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = load ptr, ptr %3, align 8, !invariant.load !3, !dereferenceable !4
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %6 = load ptr, ptr %5, align 8, !invariant.load !3, !dereferenceable !5
  %7 = getelementptr inbounds nuw i8, ptr %3, i64 32
  %8 = load ptr, ptr %7, align 8, !invariant.load !3, !dereferenceable !4
  tail call void @llvm.experimental.noalias.scope.decl(metadata !6)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !9)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !11)
  %9 = getelementptr inbounds nuw i8, ptr %6, i64 32
  %wide.load4 = load <8 x float>, ptr %6, align 4, !invariant.load !3, !alias.scope !9, !noalias !13
  %wide.load5 = load <8 x float>, ptr %9, align 4, !invariant.load !3, !alias.scope !9, !noalias !13
  %10 = getelementptr inbounds nuw i8, ptr %6, i64 64
  %11 = getelementptr inbounds nuw i8, ptr %6, i64 96
  %wide.load4.1 = load <8 x float>, ptr %10, align 4, !invariant.load !3, !alias.scope !9, !noalias !13
  %wide.load5.1 = load <8 x float>, ptr %11, align 4, !invariant.load !3, !alias.scope !9, !noalias !13
  %12 = getelementptr inbounds nuw i8, ptr %6, i64 128
  %13 = getelementptr inbounds nuw i8, ptr %6, i64 160
  %wide.load4.2 = load <8 x float>, ptr %12, align 4, !invariant.load !3, !alias.scope !9, !noalias !13
  %wide.load5.2 = load <8 x float>, ptr %13, align 4, !invariant.load !3, !alias.scope !9, !noalias !13
  %14 = getelementptr inbounds nuw i8, ptr %6, i64 192
  %15 = getelementptr inbounds nuw i8, ptr %6, i64 224
  %wide.load4.3 = load <8 x float>, ptr %14, align 4, !invariant.load !3, !alias.scope !9, !noalias !13
  %wide.load5.3 = load <8 x float>, ptr %15, align 4, !invariant.load !3, !alias.scope !9, !noalias !13
  %16 = getelementptr inbounds nuw i8, ptr %6, i64 256
  %17 = getelementptr inbounds nuw i8, ptr %6, i64 288
  %wide.load4.4 = load <8 x float>, ptr %16, align 4, !invariant.load !3, !alias.scope !9, !noalias !13
  %wide.load5.4 = load <8 x float>, ptr %17, align 4, !invariant.load !3, !alias.scope !9, !noalias !13
  br label %vector.ph

vector.ph:                                        ; preds = %1, %vector.ph
  %18 = phi i64 [ 0, %1 ], [ %64, %vector.ph ]
  %19 = mul nuw nsw i64 %18, 80
  %20 = getelementptr inbounds nuw float, ptr %4, i64 %19
  %21 = getelementptr inbounds nuw i8, ptr %20, i64 32
  %wide.load = load <8 x float>, ptr %20, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %wide.load3 = load <8 x float>, ptr %21, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %22 = fadd <8 x float> %wide.load, %wide.load4
  %23 = fadd <8 x float> %wide.load3, %wide.load5
  %24 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %22, <8 x float> zeroinitializer)
  %25 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %23, <8 x float> zeroinitializer)
  %26 = getelementptr inbounds nuw float, ptr %8, i64 %19
  %27 = getelementptr inbounds nuw i8, ptr %26, i64 32
  store <8 x float> %24, ptr %26, align 4, !alias.scope !11, !noalias !15
  store <8 x float> %25, ptr %27, align 4, !alias.scope !11, !noalias !15
  %28 = add nuw nsw i64 %19, 16
  %29 = getelementptr inbounds nuw float, ptr %4, i64 %28
  %30 = getelementptr inbounds nuw i8, ptr %29, i64 32
  %wide.load.1 = load <8 x float>, ptr %29, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %wide.load3.1 = load <8 x float>, ptr %30, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %31 = fadd <8 x float> %wide.load.1, %wide.load4.1
  %32 = fadd <8 x float> %wide.load3.1, %wide.load5.1
  %33 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %31, <8 x float> zeroinitializer)
  %34 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %32, <8 x float> zeroinitializer)
  %35 = getelementptr inbounds nuw float, ptr %8, i64 %28
  %36 = getelementptr inbounds nuw i8, ptr %35, i64 32
  store <8 x float> %33, ptr %35, align 4, !alias.scope !11, !noalias !15
  store <8 x float> %34, ptr %36, align 4, !alias.scope !11, !noalias !15
  %37 = add nuw nsw i64 %19, 32
  %38 = getelementptr inbounds nuw float, ptr %4, i64 %37
  %39 = getelementptr inbounds nuw i8, ptr %38, i64 32
  %wide.load.2 = load <8 x float>, ptr %38, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %wide.load3.2 = load <8 x float>, ptr %39, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %40 = fadd <8 x float> %wide.load.2, %wide.load4.2
  %41 = fadd <8 x float> %wide.load3.2, %wide.load5.2
  %42 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %40, <8 x float> zeroinitializer)
  %43 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %41, <8 x float> zeroinitializer)
  %44 = getelementptr inbounds nuw float, ptr %8, i64 %37
  %45 = getelementptr inbounds nuw i8, ptr %44, i64 32
  store <8 x float> %42, ptr %44, align 4, !alias.scope !11, !noalias !15
  store <8 x float> %43, ptr %45, align 4, !alias.scope !11, !noalias !15
  %46 = add nuw nsw i64 %19, 48
  %47 = getelementptr inbounds nuw float, ptr %4, i64 %46
  %48 = getelementptr inbounds nuw i8, ptr %47, i64 32
  %wide.load.3 = load <8 x float>, ptr %47, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %wide.load3.3 = load <8 x float>, ptr %48, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %49 = fadd <8 x float> %wide.load.3, %wide.load4.3
  %50 = fadd <8 x float> %wide.load3.3, %wide.load5.3
  %51 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %49, <8 x float> zeroinitializer)
  %52 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %50, <8 x float> zeroinitializer)
  %53 = getelementptr inbounds nuw float, ptr %8, i64 %46
  %54 = getelementptr inbounds nuw i8, ptr %53, i64 32
  store <8 x float> %51, ptr %53, align 4, !alias.scope !11, !noalias !15
  store <8 x float> %52, ptr %54, align 4, !alias.scope !11, !noalias !15
  %55 = add nuw nsw i64 %19, 64
  %56 = getelementptr inbounds nuw float, ptr %4, i64 %55
  %57 = getelementptr inbounds nuw i8, ptr %56, i64 32
  %wide.load.4 = load <8 x float>, ptr %56, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %wide.load3.4 = load <8 x float>, ptr %57, align 4, !invariant.load !3, !alias.scope !6, !noalias !14
  %58 = fadd <8 x float> %wide.load.4, %wide.load4.4
  %59 = fadd <8 x float> %wide.load3.4, %wide.load5.4
  %60 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %58, <8 x float> zeroinitializer)
  %61 = tail call <8 x float> @llvm.maximum.v8f32(<8 x float> %59, <8 x float> zeroinitializer)
  %62 = getelementptr inbounds nuw float, ptr %8, i64 %55
  %63 = getelementptr inbounds nuw i8, ptr %62, i64 32
  store <8 x float> %60, ptr %62, align 4, !alias.scope !11, !noalias !15
  store <8 x float> %61, ptr %63, align 4, !alias.scope !11, !noalias !15
  %64 = add nuw nsw i64 %18, 1
  %exitcond2.not = icmp eq i64 %64, 48
  br i1 %exitcond2.not, label %broadcast_maximum_fusion_wrapped.exit, label %vector.ph, !llvm.loop !16

broadcast_maximum_fusion_wrapped.exit:            ; preds = %vector.ph
  ret ptr null
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.maximum.v8f32(<8 x float>, <8 x float>) #2

attributes #0 = { nofree norecurse nosync nounwind memory(readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 1}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 15360}
!5 = !{i64 320}
!6 = !{!7}
!7 = distinct !{!7, !8, !"broadcast_maximum_fusion_wrapped: argument 0"}
!8 = distinct !{!8, !"broadcast_maximum_fusion_wrapped"}
!9 = !{!10}
!10 = distinct !{!10, !8, !"broadcast_maximum_fusion_wrapped: argument 1"}
!11 = !{!12}
!12 = distinct !{!12, !8, !"broadcast_maximum_fusion_wrapped: argument 2"}
!13 = !{!7, !12}
!14 = !{!10, !12}
!15 = !{!7, !10}
!16 = distinct !{!16, !17}
!17 = !{!"llvm.loop.unroll.disable"}
