; ModuleID = '__compute_module_convert_reduce_fusion_kernel_module'
source_filename = "__compute_module_convert_reduce_fusion_kernel_module"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-win32"

%XLA_CPU_KernelCallFrame = type { ptr, ptr, i64, ptr }
%XLA_CPU_KernelArg = type { ptr, i64 }
%kernel_dim3 = type { i64, i64, i64 }

; Function Attrs: uwtable
define ptr @convert_reduce_fusion(ptr %0) #0 {
  %2 = getelementptr inbounds %XLA_CPU_KernelCallFrame, ptr %0, i32 0, i32 3
  %3 = load ptr, ptr %2, align 8, !invariant.load !3
  %4 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 0, i32 0
  %5 = load ptr, ptr %4, align 8, !invariant.load !3, !dereferenceable !4
  %6 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 1, i32 0
  %7 = load ptr, ptr %6, align 8, !invariant.load !3, !dereferenceable !4
  %8 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 2, i32 0
  %9 = load ptr, ptr %8, align 8, !invariant.load !3, !dereferenceable !4
  %10 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 3, i32 0
  %11 = load ptr, ptr %10, align 8, !invariant.load !3, !dereferenceable !5
  %12 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 4, i32 0
  %13 = load ptr, ptr %12, align 8, !invariant.load !3, !dereferenceable !4
  %14 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 5, i32 0
  %15 = load ptr, ptr %14, align 8, !invariant.load !3, !dereferenceable !6
  %16 = getelementptr inbounds %XLA_CPU_KernelArg, ptr %3, i32 6, i32 0
  %17 = load ptr, ptr %16, align 8, !invariant.load !3, !dereferenceable !6
  %18 = getelementptr inbounds %XLA_CPU_KernelCallFrame, ptr %0, i32 0, i32 1
  %19 = load ptr, ptr %18, align 8
  %20 = getelementptr inbounds %kernel_dim3, ptr %19, i32 0, i32 0
  %21 = load i64, ptr %20, align 4, !invariant.load !3
  %22 = getelementptr inbounds %kernel_dim3, ptr %19, i32 0, i32 1
  %23 = load i64, ptr %22, align 4, !invariant.load !3
  %24 = getelementptr inbounds %kernel_dim3, ptr %19, i32 0, i32 2
  %25 = load i64, ptr %24, align 4, !invariant.load !3
  call void @convert_reduce_fusion_wrapped(ptr %5, ptr %7, ptr %9, ptr %11, ptr %13, ptr %15, ptr %17, i64 %21, i64 %23, i64 %25)
  ret ptr null
}

; Function Attrs: alwaysinline
define internal void @convert_reduce_fusion_wrapped(ptr noalias align 64 dereferenceable(640) %0, ptr noalias align 64 dereferenceable(640) %1, ptr noalias align 64 dereferenceable(640) %2, ptr noalias align 64 dereferenceable(184320) %3, ptr noalias align 64 dereferenceable(640) %4, ptr noalias align 64 dereferenceable(1152) %5, ptr noalias align 64 dereferenceable(1152) %6, i64 %7, i64 %8, i64 %9) #1 {
  br label %11

11:                                               ; preds = %45, %10
  %12 = phi i64 [ %48, %45 ], [ 0, %10 ]
  %13 = icmp slt i64 %12, 288
  br i1 %13, label %14, label %49

14:                                               ; preds = %11
  %15 = mul nsw i64 %12, 160
  br label %16

16:                                               ; preds = %21, %14
  %17 = phi i64 [ %44, %21 ], [ 0, %14 ]
  %18 = phi i32 [ %42, %21 ], [ 0, %14 ]
  %19 = phi i32 [ %43, %21 ], [ 0, %14 ]
  %20 = icmp slt i64 %17, 160
  br i1 %20, label %21, label %45

21:                                               ; preds = %16
  %22 = add nsw i64 %15, %17
  %23 = getelementptr inbounds [46080 x float], ptr %3, i32 0, i64 %22
  %24 = load float, ptr %23, align 4, !invariant.load !3
  %25 = getelementptr inbounds [160 x float], ptr %4, i32 0, i64 %17
  %26 = load float, ptr %25, align 4, !invariant.load !3
  %27 = fmul float %24, %26
  %28 = getelementptr inbounds [160 x float], ptr %2, i32 0, i64 %17
  %29 = load float, ptr %28, align 4, !invariant.load !3
  %30 = fadd float %27, %29
  %31 = fcmp ogt float %30, 0.000000e+00
  %32 = zext i1 %31 to i32
  %33 = call float @llvm.maximum.f32(float %30, float 0.000000e+00)
  %34 = getelementptr inbounds [160 x float], ptr %1, i32 0, i64 %17
  %35 = load float, ptr %34, align 4, !invariant.load !3
  %36 = fmul float %33, %35
  %37 = getelementptr inbounds [160 x float], ptr %0, i32 0, i64 %17
  %38 = load float, ptr %37, align 4, !invariant.load !3
  %39 = fadd float %36, %38
  %40 = fcmp ogt float %39, 0.000000e+00
  %41 = zext i1 %40 to i32
  %42 = add i32 %18, %32
  %43 = add i32 %19, %41
  %44 = add i64 %17, 1
  br label %16

45:                                               ; preds = %16
  %46 = getelementptr inbounds [288 x i32], ptr %5, i32 0, i64 %12
  store i32 %18, ptr %46, align 4
  %47 = getelementptr inbounds [288 x i32], ptr %6, i32 0, i64 %12
  store i32 %19, ptr %47, align 4
  %48 = add i64 %12, 1
  br label %11, !llvm.loop !7

49:                                               ; preds = %11
  ret void
}

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.maximum.f32(float, float) #2

attributes #0 = { uwtable "frame-pointer"="all" "prefer-vector-width"="256" }
attributes #1 = { alwaysinline }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0, !1}
!xla_cpu_memory_region_name = !{!2}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"xla_dylib_index", i64 0}
!2 = !{!"xla_cpu_emitter__loop_fusion_kernel_emitter__hlo_opcode__fusion"}
!3 = !{}
!4 = !{i64 640}
!5 = !{i64 184320}
!6 = !{i64 1152}
!7 = distinct !{!7, !8}
!8 = !{!"llvm.loop.unroll.disable"}
